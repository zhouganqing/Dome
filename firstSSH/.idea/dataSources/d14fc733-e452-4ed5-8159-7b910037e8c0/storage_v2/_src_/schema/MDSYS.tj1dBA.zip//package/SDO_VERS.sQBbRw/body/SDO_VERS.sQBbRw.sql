create package body SDO_VERS wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
b
10b 103
UAOwlnBLIP7fJ4FHYWoLC78iX7Ywg+nQLtMVfOdgTMGOiuWHa4ZmJFSMvfXmoOtcuaqZ3l6A
QJQ0u2xHPJ2KRo9X2Mo3BVttqZSGuBiRpqBEtpKeBRtlNRqXJIlU/v4ViKwDOxFgJ5M4QnA1
pW7Bbx1ocGnPBNeaQzougc/t9YiWvunxJ14VDlBrNlA1C/53RoqGuVxBS92H/IfC2GUWWQAS
w3Iqwoi/fscp2saUBKMN0Wt+mmVaOHoQ+9cqZz0=
/

