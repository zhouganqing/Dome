create trigger SDO_GEOM_TRIG_UPD1
    instead of update
    on USER_SDO_GEOM_METADATA
    for each row
declare
BEGIN

  mdsys.sdo_meta.change_all_sdo_geom_metadata(user,
                                              :old.table_name,
                                              :old.column_name,
                                              :n.table_name,
                                              :n.column_name,
                                              :n.diminfo,
                                              :n.srid);

END;
/

