create TYPE         "GridFileType598_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","Grids" "Grids599_T")NOT FINAL INSTANTIABLE
/

