create TYPE       OpenLS_Ordinates AS VARRAY(1048576) OF VARCHAR2(64);
/

