create function SDO_Aggr_LRS_Concat wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
bd ce
Ar3Ihk9xFN92cvwYDLs8tP/drEEwgwJKLcsVfHSiWPiUHNkVKHy+9PRmbNwB2oTo53/1Hb0I
tWZMl4V5sOsSRboBFy18TZakxM1VtxG/ZMGG+Vh/NmupYDfyG7c5tuQMM4PSZX7afnljTnBG
2J61YT/nAIihSnY9UdaURF5Rd/RSoSGkWw4nXaYSLLVxOAefABD7Bhd8AQ==
/

