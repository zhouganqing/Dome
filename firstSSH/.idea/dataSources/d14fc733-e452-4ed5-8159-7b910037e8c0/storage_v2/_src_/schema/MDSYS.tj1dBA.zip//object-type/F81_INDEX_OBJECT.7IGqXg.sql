create type F81_INDEX_OBJECT wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
d
4e 85
ZWUadRLrQvBrxvqwEBWjnjobioMwg5n0dLhcuAN8X/7Sx1Lw4/6/m8Ayy8y4dCupwiFTrEzk
hpBzTHGUrHZqKl9ZLioy3eavqEqoa6+eOEo1/xxKNWCrQOzsPHSmYli2sw==
/

