create TYPE         "GridApplicationsType590_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","GridApplication" "GridApplication592_COLL")NOT FINAL INSTANTIABLE
/

