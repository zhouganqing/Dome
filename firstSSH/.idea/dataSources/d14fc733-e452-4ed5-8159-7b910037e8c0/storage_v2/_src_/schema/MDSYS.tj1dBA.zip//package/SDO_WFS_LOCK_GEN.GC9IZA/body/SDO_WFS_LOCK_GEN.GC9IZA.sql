create PACKAGE BODY       SDO_WFS_LOCK_GEN wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
b
e8 f3
/e11ZC70mOPf1IXWpUw9pDqeB2cwg+ncmG+sfHQyueqRuFACr40+oPsSFibfPpd3tbWZbcrJ
Wv++vmRbg/NbrNFFRNuVm/xjRhHGZS/9jguSRysQkU2mbMMlV9MSW/QhSUCIt+0LRTVsB5sS
wEF78jspEaV+cCxrZys4wMJaTmNvQkH96MT/BN0DYM4S0j7cj2VAM3y0grFRkxARYXXlFvYH
2WvtYdQvmEXEEpKmJYHajQ==
/

