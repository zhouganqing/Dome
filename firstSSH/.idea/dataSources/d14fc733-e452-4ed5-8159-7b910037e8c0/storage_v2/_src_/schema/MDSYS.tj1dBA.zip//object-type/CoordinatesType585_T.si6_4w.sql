create TYPE         "CoordinatesType585_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","Coordinate" "Coordinate586_COLL")NOT FINAL INSTANTIABLE
/

