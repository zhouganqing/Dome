create TYPE sdo_geor_blk_range wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
d
89 81
LG9kPBvkjdG2eTc/81MEmJzkeHUwg5n0dLhcFtz60K6u15YYrpf6SpbyRwyuXLh0K6W/m8Ay
y7OPCaasykkkhEQWpZmBMsCyJcypoQQ4jbjUY2qIhAfhnOgqHaYApRyj
/

