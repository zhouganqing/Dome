create trigger SDO_NETWORK_HIS_DEL_TRIG
    instead of delete
    on USER_SDO_NETWORK_HISTORIES
    for each row
DECLARE
  user_name    VARCHAR2(256);
BEGIN

  EXECUTE IMMEDIATE 'SELECT USER FROM DUAL' INTO user_name;

  DELETE
    FROM  sdo_network_histories
    WHERE NLS_UPPER(OWNER) = NLS_UPPER(user_name)
      AND network = :o.network;

END;
/

