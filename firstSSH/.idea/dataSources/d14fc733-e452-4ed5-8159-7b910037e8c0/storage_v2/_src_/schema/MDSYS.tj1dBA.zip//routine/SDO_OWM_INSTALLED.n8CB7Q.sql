create function SDO_OWM_INSTALLED wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
76 9e
OiQjEUEomT6oKu6yj8B6CycHdEMwg1xHLbJqfHSizLHsrLaR++rxMr3nWrCpGvEJ+CA4U3+P
+bX+QXrmW5UeVIaanCXvxEDs2y/rFm7t3RpmcEwmHCOFeAVcDUSLJcoxXq+AQg+c/tY6Hje5
vdj4n+Fk88o4
/

