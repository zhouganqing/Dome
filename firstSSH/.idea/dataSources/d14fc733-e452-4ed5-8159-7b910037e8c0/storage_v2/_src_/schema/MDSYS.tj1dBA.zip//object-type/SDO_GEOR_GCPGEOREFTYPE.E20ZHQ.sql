create TYPE SDO_GEOR_GCPGEOREFTYPE
                                                                      
AS OBJECT
(
   FFMethodType          VARCHAR2(32),
   numberGCP             NUMBER,
   GCPs                  SDO_GEOR_GCP_COLLECTION,
   solutionAccuracy      SDO_NUMBER_ARRAY,

   CONSTRUCTOR FUNCTION SDO_GEOR_GCPGEOREFTYPE(SELF IN OUT NOCOPY SDO_GEOR_GCPGEOREFTYPE)
     RETURN SELF AS RESULT

)
/

