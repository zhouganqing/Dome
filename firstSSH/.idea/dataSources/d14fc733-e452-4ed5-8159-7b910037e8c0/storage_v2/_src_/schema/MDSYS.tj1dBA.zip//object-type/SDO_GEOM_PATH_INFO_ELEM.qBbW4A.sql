create type       sdo_geom_path_info_elem as object (pathInfo mdsys.sdo_geom_path_info, pkcol varchar2(4000), tableName varchar2(61))
/

