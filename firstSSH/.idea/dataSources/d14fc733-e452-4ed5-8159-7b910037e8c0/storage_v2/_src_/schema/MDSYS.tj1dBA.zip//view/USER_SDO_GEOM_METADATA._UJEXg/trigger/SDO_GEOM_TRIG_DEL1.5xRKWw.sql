create trigger SDO_GEOM_TRIG_DEL1
    instead of delete
    on USER_SDO_GEOM_METADATA
    for each row
declare
BEGIN

  mdsys.sdo_meta.delete_all_sdo_geom_metadata(user,
                                              :n.table_name,
                                              :n.column_name);

END;
/

