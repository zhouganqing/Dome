create PROCEDURE ElocationSetJVMHeapSize(sz NUMBER)
 AS LANGUAGE JAVA NAME
  'oracle.aurora.vm.OracleRuntime.setMaxMemorySize(long)';
/

