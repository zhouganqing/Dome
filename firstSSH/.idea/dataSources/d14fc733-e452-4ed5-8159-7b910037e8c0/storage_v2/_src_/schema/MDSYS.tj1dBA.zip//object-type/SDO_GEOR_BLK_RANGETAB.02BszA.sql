create TYPE sdo_geor_blk_rangetab AS TABLE OF sdo_geor_blk_range;
/

