create trigger SDO_CRS_GEOG_SRID_UPDATE
    after update or delete
    on SDO_CRS_GEOGRAPHIC_PLUS_HEIGHT
    for each row
BEGIN
  mdsys.mdprvt_srid.sdo_invalidate_srid_metadata(:old.srid);
END;
/

