create trigger SDO_CS_SRS_SRID_INSERT
    before insert
    on SDO_CS_SRS
    for each row
BEGIN

  mdsys.mdprvt_srid.sdo_invalidate_srid_metadata(:new.srid);
END;
/

