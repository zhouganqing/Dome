create TYPE sdo_geor_mosaic_0 wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
d
1bc e3
/p3sKB05ygAUu7gMpFpTksi5pNIwgzLX154VfC82cHIQGABhj6iB/D6qcKK3wjFvekTMPgBa
3bwkFqw38r/iLIKEnP8Vz3Lez13qI4s6e1XxpoioTYw9NjJET1cdbLwk1W26zuGrxXxad1v0
mEWUUTpCGiVMb0QDTa1pdnDZLlIOV32uRnYRy3eSBxw8JObGbvhwFPpdNDodhmZi/Wkq+Nf9
++wrOg==
/

