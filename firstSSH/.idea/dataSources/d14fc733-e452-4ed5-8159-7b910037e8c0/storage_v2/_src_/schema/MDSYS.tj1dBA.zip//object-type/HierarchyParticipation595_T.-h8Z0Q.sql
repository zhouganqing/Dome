create TYPE         "HierarchyParticipation595_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","Parent" "Parent596_COLL")FINAL INSTANTIABLE
/

