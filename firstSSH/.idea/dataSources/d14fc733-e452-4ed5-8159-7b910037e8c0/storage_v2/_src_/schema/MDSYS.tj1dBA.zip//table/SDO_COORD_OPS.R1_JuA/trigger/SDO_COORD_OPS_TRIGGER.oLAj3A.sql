create trigger SDO_COORD_OPS_TRIGGER
    before insert or update or delete
    on SDO_COORD_OPS
    for each row
BEGIN
  MDSYS.sdo_cs.sdo_cs_context_invalidate;
END;
/

