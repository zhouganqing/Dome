create view USER_SDO_NETWORK_LOCKS_WM as
SELECT  lock_id, network, workspace, original_node_filter, original_link_filter, original_path_filter, adjusted_node_filter, adjusted_link_filter, adjusted_path_filter
    FROM  sdo_network_locks_wm
    WHERE sdo_owner = sys_context('USERENV', 'CURRENT_USER')
/

create trigger SDO_NETWORK_LOCKS_INS_TRIG
    instead of insert
    on USER_SDO_NETWORK_LOCKS_WM
    for each row
-- missing source code
/

create trigger SDO_NETWORK_LOCKS_DEL_TRIG
    instead of delete
    on USER_SDO_NETWORK_LOCKS_WM
    for each row
-- missing source code
/

create trigger SDO_NETWORK_LOCKS_UPD_TRIG
    instead of update
    on USER_SDO_NETWORK_LOCKS_WM
    for each row
-- missing source code
/

