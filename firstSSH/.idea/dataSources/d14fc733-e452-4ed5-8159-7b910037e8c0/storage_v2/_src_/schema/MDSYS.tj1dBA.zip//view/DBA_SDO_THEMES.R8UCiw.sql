create view DBA_SDO_THEMES as
SELECT SDO_OWNER OWNER, NAME, DESCRIPTION, BASE_TABLE,
              GEOMETRY_COLUMN, STYLING_RULES
FROM SDO_THEMES_TABLE
WHERE
(exists
   (select table_name from dba_tables
    where table_name=base_table
    union all
      select table_name from dba_object_tables
      where table_name=base_table
    union all
    select view_name table_name from dba_views
    where  view_name=base_table))
/

