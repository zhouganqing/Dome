create trigger SDO_COORD_REF_SRID_UPDATE
    after update or delete
    on SDO_COORD_REF_SYS
    for each row
BEGIN
  mdsys.mdprvt_srid.sdo_invalidate_srid_metadata(:old.srid,
                                                 :old.coord_ref_sys_kind);
END;
/

