create trigger SDO_COORD_REF_SRID_INSERT
    before insert
    on SDO_COORD_REF_SYS
    for each row
BEGIN
  mdsys.mdprvt_srid.sdo_invalidate_srid_metadata(:new.srid,
                                                 :new.coord_ref_sys_kind);
END;
/

