create function SDO_VERSION wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
6e 9a
bmi3aLJbw0LxjRLRuATTL2hLqfUwg+lHmLKpfHTpzPxZ7r0WESZuXfunrNZurhNzxKnhor/s
EsToa/IrxX/Qy9XQpIgngmP/b8thAmbFio6NCWxQldQ+qLIW+DYGBnqfOpi7Kp1QNHsRcbD9
nL6kBg==
/

