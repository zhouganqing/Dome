create function SDO_Aggr_Centroid wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
d2 ca
HyJXC/9gd9vAtw7Y+kBcdC1NO2Ywg5BKf8sVfC82Jk4Y1WvuHcPUh9i3isf1Ih8maKlmq8hm
+ZbxG9J+xKPeySAuNFLz5Wv1eHIM/tCxF0Iku4AfjGZ7hKL6fJARDqq3hJD8QjJ+aRNgbiun
FeyXIB6YFt0OWAIKLbCzJgy9JoRoKji00MwKVvdhuajoAmpDpUQwWGUa
/

