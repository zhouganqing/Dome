create trigger SDO_PREFERRED_OPS_SYSTEM_TRIG
    before insert or update or delete
    on SDO_PREFERRED_OPS_SYSTEM
    for each row
BEGIN
  MDSYS.sdo_cs.sdo_cs_context_invalidate;
END;
/

