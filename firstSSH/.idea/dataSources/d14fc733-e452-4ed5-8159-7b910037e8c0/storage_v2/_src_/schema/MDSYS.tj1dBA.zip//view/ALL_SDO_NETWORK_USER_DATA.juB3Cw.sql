create view ALL_SDO_NETWORK_USER_DATA as
SELECT  sdo_owner owner, network, table_type, data_name, data_type,data_length, category_id
    FROM  sdo_network_user_data
/

