create TYPE         "GridFile601_T" UNDER "GridFileType598_T"("creation" TIMESTAMP,"update" TIMESTAMP)FINAL INSTANTIABLE
/

