create FUNCTION RtreeJoinFunc wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
24e 154
kDmc8FI8Q5ZsT0T12KvQz601CE8wg5DxLdzbfHRAWEKe0AAmeylFZWP0us+ce/eGppBlDv1I
vrcvNCQpsl9iyK+nYqqdAXOIZbpj3cpPLMFOCJ++yw+x/ovzPEHX4foC7AbeaJmt7i1vzXvp
i6be3PiPVvPaz+8cFRvrc1i980RXrgDymR6Mt6FJkO8VbfP4fhoFyJ+hDBgRN85b+wfW+oce
8rt4MK9rojWAPBb56qIumnPmAcRo0U2TMH8KWjBsnGn2eKt/GYyWhej+5y55FlWdr+B5JNYE
HC0m/xyjTS0FVT1m6dLbfcpJBvOiRAgE45kuLX3ranjj0M+E
/

