create TYPE SDO_GEORASTER
                                                                                  
      AS OBJECT
      (
        rasterType        NUMBER,
        spatialExtent     MDSYS.SDO_GEOMETRY,
        rasterDataTable   VARCHAR2(32),
        rasterID          NUMBER,
        metadata          SYS.XMLType
      )
/

