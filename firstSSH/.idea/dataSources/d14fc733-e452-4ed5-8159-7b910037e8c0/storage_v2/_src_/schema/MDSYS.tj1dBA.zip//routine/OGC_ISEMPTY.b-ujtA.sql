create FUNCTION OGC_IsEmpty(
  g ST_Geometry)
    RETURN Integer IS
BEGIN
  RETURN g.ST_IsEmpty();
END OGC_IsEmpty;
/

