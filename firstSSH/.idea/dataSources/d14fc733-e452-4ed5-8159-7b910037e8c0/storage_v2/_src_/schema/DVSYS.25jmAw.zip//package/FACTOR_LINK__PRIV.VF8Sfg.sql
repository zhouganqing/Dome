create PACKAGE       FACTOR_LINK$_priv AS

  TYPE attribute_rec IS RECORD (
      ID# FACTOR_LINK$.ID#%TYPE
    , PARENT_FACTOR_ID# FACTOR_LINK$.PARENT_FACTOR_ID#%TYPE
    , CHILD_FACTOR_ID# FACTOR_LINK$.CHILD_FACTOR_ID#%TYPE
    , LABEL_IND FACTOR_LINK$.LABEL_IND%TYPE
  );

  TYPE attribute_list IS VARRAY(4096) OF attribute_rec;

  -- Create method
  PROCEDURE create_row(
    p_PARENT_FACTOR_ID# IN NUMBER,
    p_CHILD_FACTOR_ID# IN NUMBER,
    p_LABEL_IND IN VARCHAR2,
    x_id# OUT number);

  -- Read method
  PROCEDURE read_row(p_id#        IN     number,
      x_ID# OUT NUMBER
    , x_PARENT_FACTOR_ID# OUT NUMBER
    , x_CHILD_FACTOR_ID# OUT NUMBER
    , x_LABEL_IND OUT VARCHAR2
    );

  PROCEDURE read_by_PARENT_FACTOR_ID#_(
    p_PARENT_FACTOR_ID# IN number,
    x_attribute_list OUT attribute_list);

  PROCEDURE read_by_CHILD_FACTOR_ID#_(
    p_CHILD_FACTOR_ID# IN number,
    x_attribute_list OUT attribute_list);

  -- Update method
  PROCEDURE update_row(
      p_id# NUMBER
    , p_PARENT_FACTOR_ID# IN NUMBER
    , p_CHILD_FACTOR_ID# IN NUMBER
    , p_LABEL_IND IN VARCHAR2
    );

  -- Delete method
  PROCEDURE delete_row(p_id# IN number,
                    p_delete_children IN boolean := false);

  PROCEDURE delete_by_PARENT_FACTOR_ID#_(
    p_PARENT_FACTOR_ID# IN number,
    p_delete_children IN boolean := false);

  PROCEDURE delete_by_CHILD_FACTOR_ID#_(
    p_CHILD_FACTOR_ID# IN number,
    p_delete_children IN boolean := false);

END;
/

