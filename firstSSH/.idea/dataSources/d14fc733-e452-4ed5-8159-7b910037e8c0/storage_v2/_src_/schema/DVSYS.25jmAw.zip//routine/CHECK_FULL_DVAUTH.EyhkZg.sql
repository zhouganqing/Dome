create FUNCTION       check_full_dvauth RETURN BINARY_INTEGER
IS
BEGIN
  RETURN dvsys.dbms_macutl.check_full_dvauth;
END;
/

