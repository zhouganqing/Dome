create FUNCTION       is_secure_application_role(p_role VARCHAR2)
RETURN BOOLEAN IS
BEGIN
  RETURN dvsys.dbms_macsec.is_secure_application_role(p_role => p_role);
END;
/

