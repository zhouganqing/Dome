create PACKAGE       MAC_POLICY$_priv AS

  TYPE attribute_rec IS RECORD (
      ID# MAC_POLICY$.ID#%TYPE
    , POLICY_ID# MAC_POLICY$.POLICY_ID#%TYPE
    , ALGORITHM_CODE_ID# MAC_POLICY$.ALGORITHM_CODE_ID#%TYPE
    , ERROR_LABEL MAC_POLICY$.ERROR_LABEL%TYPE
  );

  TYPE attribute_list IS VARRAY(4096) OF attribute_rec;

  -- Create method
  PROCEDURE create_row(
    p_POLICY_ID# IN NUMBER,
    p_ALGORITHM_CODE_ID# IN NUMBER,
    p_ERROR_LABEL IN VARCHAR2,
    x_id# OUT number);

  -- Read method
  PROCEDURE read_row(p_id#        IN     number,
      x_ID# OUT NUMBER
    , x_POLICY_ID# OUT NUMBER
    , x_ALGORITHM_CODE_ID# OUT NUMBER
    , x_ERROR_LABEL OUT VARCHAR2
    );

  PROCEDURE read_by_ALGORITHM_CODE_ID#_(
    p_ALGORITHM_CODE_ID# IN number,
    x_attribute_list OUT attribute_list);

  -- Update method
  PROCEDURE update_row(
      p_id# NUMBER
    , p_POLICY_ID# IN NUMBER
    , p_ALGORITHM_CODE_ID# IN NUMBER
    , p_ERROR_LABEL IN VARCHAR2
    );

  -- Delete method
  PROCEDURE delete_row(p_id# IN number,
                    p_delete_children IN boolean := false);

  PROCEDURE delete_by_ALGORITHM_CODE_ID#_(
    p_ALGORITHM_CODE_ID# IN number,
    p_delete_children IN boolean := false);

END;
/

