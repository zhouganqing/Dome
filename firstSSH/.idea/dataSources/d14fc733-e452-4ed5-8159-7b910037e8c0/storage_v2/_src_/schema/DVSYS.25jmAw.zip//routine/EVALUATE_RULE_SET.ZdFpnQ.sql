create PROCEDURE       evaluate_rule_set(
                        p_rule_set      IN  VARCHAR2,
                        x_result        OUT INTEGER,
                        x_rule          OUT VARCHAR2,
                        x_rule_error    OUT INTEGER,
                        x_handler_error OUT INTEGER,
                        x_error_code    OUT NUMBER,
                        x_error_text    OUT VARCHAR2)
  IS
    x_result_bool        BOOLEAN;
    x_rule_error_bool    BOOLEAN;
    x_handler_error_bool BOOLEAN;
  BEGIN
    -- buffer overflow checks
    IF (LENGTH(p_rule_set) > 90) THEN
        dvsys.DBMS_MACUTL.RAISE_ERROR(47951,'p_rule_set');
    END IF;

    DVSYS.DBMS_MACSEC_RULES.EVALUATE(
             p_rule_set,
             NULL,
             x_result_bool,
             x_rule,
             x_rule_error_bool,
             x_handler_error_bool,
             x_error_code,
             x_error_text);

    IF (x_result_bool) THEN
      x_result := 1;
    ELSE
      x_result := 0;
    END IF;

    IF (x_rule_error_bool) THEN
      x_rule_error := 1;
    ELSE
      x_rule_error := 0;
    END IF;

    IF (x_handler_error_bool) THEN
      x_handler_error := 1;
    ELSE
      x_handler_error := 0;
    END IF;
  END;
/

