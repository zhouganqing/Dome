create PACKAGE       dbms_macadm AS

  /* Global Constants */

  MANDATORY_REALM                  CONSTANT BINARY_INTEGER := 1;
  FACTOR_TYPE_CREATION_AUDIT       CONSTANT PLS_INTEGER :=     20032;
  FACTOR_TYPE_DELETION_AUDIT       CONSTANT PLS_INTEGER :=     20033;
  FACTOR_TYPE_UPDATE_AUDIT         CONSTANT PLS_INTEGER :=     20034;
  FACTOR_TYPE_RENAME_AUDIT         CONSTANT PLS_INTEGER :=     20035;

  FACTOR_CREATION_AUDIT            CONSTANT PLS_INTEGER :=     20036;
  FACTOR_DELETION_AUDIT            CONSTANT PLS_INTEGER :=     20037;
  FACTOR_UPDATE_AUDIT              CONSTANT PLS_INTEGER :=     20038;
  FACTOR_RENAME_AUDIT              CONSTANT PLS_INTEGER :=     20039;

  ADD_FACTOR_LINK_AUDIT            CONSTANT PLS_INTEGER :=     20040;
  DELETE_FACTOR_LINK_AUDIT         CONSTANT PLS_INTEGER :=     20041;
  ADD_POLICY_FACTOR_AUDIT          CONSTANT PLS_INTEGER :=     20042;
  DELETE_POLICY_FACTOR_AUDIT       CONSTANT PLS_INTEGER :=     20043;

  IDENTITY_CREATION_AUDIT          CONSTANT PLS_INTEGER :=     20044;
  IDENTITY_DELETION_AUDIT          CONSTANT PLS_INTEGER :=     20045;
  IDENTITY_UPDATE_AUDIT            CONSTANT PLS_INTEGER :=     20046;
  CHANGE_IDENTITY_FACTOR_AUDIT     CONSTANT PLS_INTEGER :=     20047;
  CHANGE_IDENTITY_VALUE_AUDIT      CONSTANT PLS_INTEGER :=     20048;

  IDENTITY_MAP_CREATION_AUDIT      CONSTANT PLS_INTEGER :=     20049;
  IDENTITY_MAP_DELETION_AUDIT      CONSTANT PLS_INTEGER :=     20050;

  POLICY_LABEL_CREATION_AUDIT      CONSTANT PLS_INTEGER :=     20051;
  POLICY_LABEL_DELETION_AUDIT      CONSTANT PLS_INTEGER :=     20052;
  MAC_POLICY_CREATION_AUDIT        CONSTANT PLS_INTEGER :=     20053;
  MAC_POLICY_UPDATE_AUDIT          CONSTANT PLS_INTEGER :=     20054;
  MAC_POLICY_DELETION_AUDIT        CONSTANT PLS_INTEGER :=     20055;

  ROLE_CREATION_AUDIT              CONSTANT PLS_INTEGER :=     20056;
  ROLE_DELETION_AUDIT              CONSTANT PLS_INTEGER :=     20057;
  ROLE_UPDATE_AUDIT                CONSTANT PLS_INTEGER :=     20058;
  ROLE_RENAME_AUDIT                CONSTANT PLS_INTEGER :=     20059;

  DOMAIN_IDENTITY_CREATION_AUDIT   CONSTANT PLS_INTEGER :=     20060;
  DOMAIN_IDENTITY_DROP_AUDIT       CONSTANT PLS_INTEGER :=     20061;
  /*****************************/
  /**Public Administration API */
  /*****************************/

  /**
  * Used to enable auditing on activities performed by user with
  * DV_PATCH_ADMIN role. If DV authorization is successful only because of
  * a user having dv_patch_admin, we would not normally audit this event. But
  * if this procedure is executed, we will record the event in the audit trail.
  */
  PROCEDURE enable_dv_patch_admin_audit;

  /**
  * Used to disable auditing on dv_patch_admin bypass of DV protection.
  */
  PROCEDURE disable_dv_patch_admin_audit;


  /**
  * Used to do the sanity check before configure DV. Check Items includes:
  * The total number of dvsys tables, views, packages package bodies
  * dvf packages, dvf package bodies, dvf functions
  * dependent lbacsys packages and all the dv roles' existence
  */
  PROCEDURE dv_sanity_check;

  /**
  * Used to allow mixed case identifiers.  By default, they are not allowed.
  *
  * @param setting TRUE to allow mixed case
  */
  PROCEDURE set_preserve_case(setting IN BOOLEAN);

  /* Factor Type */

  /**
  * Create a Factor Type
  *
  * @param name Factor Type name
  * @param description Description
  * @throws ORA 20000 Factor Type already exists
  * @throws ORA 20002 Error creating Factor Type
  */
  PROCEDURE create_factor_type
              (name        IN varchar2,
               description IN varchar2);

  /**
  * Delete a Factor Type
  *
  * @param name Factor Type name
  * @throws ORA 20003 Error deleting Factor Type
  */
  PROCEDURE delete_factor_type
              (name IN varchar2);

  /**
  * Update a Factor Type
  *
  * @param name Factor Type name
  * @param description New Description
  * @throws ORA 20004 Error updating Factor Type
  */
  PROCEDURE update_factor_type
              (name IN varchar2,
               description IN varchar2);

  /**
  * Rename a Factor Type
  *
  * @param old_name Previous Factor Type name
  * @param new_name New Factor Type name
  * @throws ORA 20005 Error renaming Factor Type
  */
  PROCEDURE rename_factor_type
              (old_name IN varchar2,
               new_name    IN varchar2);

  /* Factor */

  /**
  * Create a Factor
  *
  * @param factor_name Factor Name
  * @param factor_type_name Factor Type Name
  * @param description Factor description
  * @param rule_set_name Rule Set Name (for assignment)
  * @param get_expr Expression for evaluating Factor
  * @param validate_expr Name of function to validate Factor
  * @param identify_by Options for determining the Factor's identity (see dbms_macutl)
  * @param labeled_by Options for labeling the Factor (see dbms_macutl)
  * @param eval_options Options for evaluating the Factor (see dbms_macutl)
  * @param audit_options Options for auditing the Factor (see dbms_macutl)
  * @param fail_options Options for reporting Factor errors (see dbms_macutl)
  *
  * @throws ORA 20020 Factor already defined
  * @throws ORA 20022 Error creating Factor
  */
  PROCEDURE create_factor
              (factor_name      IN varchar2,
               factor_type_name IN varchar2,
               description      IN varchar2,
               rule_set_name    IN varchar2,
               get_expr         IN varchar2,
               validate_expr    IN varchar2,
               identify_by      IN number,
               labeled_by       IN number,
               eval_options     IN number,
               audit_options    IN number,
               fail_options     IN number,
               namespace           IN varchar2 DEFAULT NULL,
               namespace_attribute IN varchar2 DEFAULT NULL
               );

  /**
  * Update a Factor
  *
  * @param factor_name Factor Name
  * @param factor_type_name Factor Type Name
  * @param description Factor description
  * @param rule_set_name Rule Set Name (for assignment)
  * @param get_expr Expression for evaluating Factor
  * @param validate_expr Name of function to validate Factor
  * @param identify_by Options for determining the Factor's identity (see dbms_macutl)
  * @param labeled_by Options for labeling the Factor (see dbms_macutl)
  * @param eval_options Options for evaluating the Factor (see dbms_macutl)
  * @param audit_options Options for auditing the Factor (see dbms_macutl)
  * @param fail_options Options for reporting Factor errors (see dbms_macutl)
  *
  * @throws ORA 20024 Error updating Factor
  */
  PROCEDURE update_factor
              (factor_name      IN varchar2,
               factor_type_name IN varchar2,
               description      IN varchar2,
               rule_set_name    IN varchar2,
               get_expr         IN varchar2,
               validate_expr    IN varchar2,
               identify_by      IN number,
               labeled_by       IN number,
               eval_options     IN number,
               audit_options    IN number,
               fail_options     IN number,
               namespace           IN varchar2 DEFAULT NULL,
               namespace_attribute IN varchar2 DEFAULT NULL
               );

  /**
  * Delete a Factor
  *
  * @param factor_name Factor to delete
  *
  * @throws ORA 20023 Error deleting Factor
  */
  PROCEDURE delete_factor
              (factor_name IN varchar2);

  /**
  * Delete a Factor
  *
  * @param factor_name Factor to delete
  *
  * @throws ORA 20024 Error updating Factor
  */
  PROCEDURE rename_factor
              (factor_name IN varchar2, new_factor_name IN varchar2);

  /**Factor Link **/

  /**
  * Specify a parent-child relationship for two factors.  The relationship may be
  * used for computing the Factor's identity or label.
  *
  * @param parent_factor_name Parent Factor name
  * @param child_factor_name Child Factor name
  * @param label_indicator Indication of whether the child contributes to the parent's label
  * @throws ORA 20025 Link already exists
  * @throws ORA 20026 Error adding link
  */
  PROCEDURE add_factor_link
              (parent_factor_name IN varchar2,
               child_factor_name  IN varchar2,
               label_indicator    IN varchar2);

  /**
  * Remove a parent-child relationship for two factors.
  *
  * @param parent_factor_name Parent Factor name
  * @param child_factor_name Child Factor name
  *
  * @throws ORA 20027 Link does not exist
  * @throws ORA 20028 Error removing link
  */
  PROCEDURE delete_factor_link
              (parent_factor_name IN varchar2,
               child_factor_name  IN varchar2);


  /* Policy Factor */

  /**
  * Specify that the label for a Factor contributes to the MAC OLS Label for a
  * policy.
  *
  * @param policy_name OLS Policy Name
  * @param factor_name Factor Name
  *
  * @throws ORA 20200 MAC Policy Factor already defined
  * @throws ORA 20202 Error adding MAC Policy FACTOR
  */
  PROCEDURE add_policy_factor
              (policy_name IN varchar2,
               factor_name IN varchar2);

  /**
  * Remove the Factor from contributing to the MAC OLS Label.
  *
  * @param policy_name OLS Policy Name
  * @param factor_name Factor Name
  *
  * @throws ORA 20203 Error deleting MAC Policy FACTOR
  */
  PROCEDURE delete_policy_factor
              (policy_name IN varchar2,
               factor_name IN varchar2);


  /**
  * Create an Identity.  Entities in the environment which will be labeled should be
  * given an identity (except for users, which are handled by OLS).
  *
  * @param factor_name Factor Name
  * @param value VARCHAR2 value associated with the identity
  * @param trust_level >0 for trust level, =0 for not trusted, <0 for distrust level
  *
  * @throws ORA 20040 Identity already defined
  * @throws ORA 20042 Error creating identity
  */
  PROCEDURE create_identity
              (factor_name IN varchar2,
               value       IN varchar2,
               trust_level IN number);

  /**
  * Update an Identity.
  *
  * @param factor_name Factor Name
  * @param value VARCHAR2 value associated with the identity
  * @param trust_level >0 for trust level, =0 for not trusted, <0 for distrust level
  *
  * @throws ORA 20044 Error updating identity
  */
  PROCEDURE update_identity
              (factor_name IN varchar2,
               value       IN varchar2,
               trust_level IN number);

  /**
  * Associate an identity with a different Factor.
  *
  * @param factor_name Current Factor Name
  * @param value Value of the Identity to update
  * @param new_factor_name Factor Name
  *
  * @throws ORA 20044 Error updating identity
  */
  PROCEDURE change_identity_factor
              (factor_name      IN varchar2,
               value            IN varchar2,
               new_factor_name  IN varchar2);

  /**
  * Update the value of an Identity.
  *
  * @param factor_name Factor Name
  * @param value Current value associated with the identity
  * @param new_value New Identity value
  *
  * @throws ORA 20044 Error updating identity
  */
  PROCEDURE change_identity_value
              (factor_name IN varchar2,
               value       IN varchar2,
               new_value   IN varchar2);

  /**
  * Remove an Identity.
  *
  * @param factor_name Factor Name
  * @param value Value associated with the identity
  *
  * @throws ORA 20044 Error deleting identity
  */
  PROCEDURE delete_identity
              (factor_name IN varchar2,
               value       IN varchar2);

  /* Identity Map */

  /*
  * Define a set of tests that are used to derive the identity of a Factor from
  * the value of linked child factors (sub-factors).
  *
  * @param identity_factor_name Factor the identity map is for
  * @param identity_factor_value Value the Factor will assume if the Identity Map is TRUE
  * @param parent_factor_name Identifies the Factor Link the Map is related to
  * @param child_factor_name Identifies the Factor Link the Map is related to
  * @param operation Relational operator for the Map (i.e. <, >, =, ...)
  * @param operand1 Left operand for the relational operator
  * @param operand1 Right operand for the relational operator
  *
  * @throws ORA 20081 Operation not found
  * @throws ORA 20060 Factor Link not found
  * @throws ORA 20062 Error creating Identity Map
  */
  PROCEDURE create_identity_map
               (identity_factor_name  IN varchar2,
                identity_factor_value IN varchar2,
                parent_factor_name    IN varchar2,
                child_factor_name     IN varchar2,
                operation             IN varchar2,
                operand1              IN varchar2,
                operand2              IN varchar2);

  /*
  * Remove an Identity Map for a Factor.
  *
  * @param identity_factor_name Factor the identity map is for
  * @param identity_factor_value Value the Factor will assume if the Identity Map is TRUE
  * @param parent_factor_name Identifies the Factor Link the Map is related to
  * @param child_factor_name Identifies the Factor Link the Map is related to
  * @param operation Relational operator for the Map (i.e. <, >, =, ...)
  * @param operand1 Left operand for the relational operator
  * @param operand1 Right operand for the relational operator
  *
  * @throws ORA 20081 Operation not found
  * @throws ORA 20063 Error deleting Identity Map
  */
  PROCEDURE delete_identity_map
               (identity_factor_name  IN varchar2,
                identity_factor_value IN varchar2,
                parent_factor_name    IN varchar2,
                child_factor_name     IN varchar2,
                operation             IN varchar2,
                operand1              IN varchar2,
                operand2              IN varchar2);

  /**Policy Label */

  /**
  * Label an Identity within a MAC OLS Policy.
  *
  * @param identity_factor_name Name of factor being labeled
  * @param identity_factor_value Value of Identity for the Factor being labeled
  * @param policy_name OLS Policy Name
  * @param label OLS Label
  *
  * @throws ORA 20220 Label already defined in policy
  * @throws ORA 20222 Error creating policy label
  */
  PROCEDURE create_policy_label
              (identity_factor_name  IN varchar2,
               identity_factor_value IN varchar2,
               policy_name           IN varchar2,
               label                 IN varchar2);
               -- algorithm             IN varchar2);

  /**
  * Remove the Label from an Identity within a MAC OLS Policy.
  *
  * @param identity_factor_name Name of factor being labeled
  * @param identity_factor_value Value of Identity for the Factor being labeled
  * @param policy_name OLS Policy Name
  * @param label OLS Label
  *
  * @throws ORA 20223 Error deleting policy label
  */
  PROCEDURE delete_policy_label
              (identity_factor_name  IN varchar2,
               identity_factor_value IN varchar2,
               policy_name           IN varchar2,
               label                 IN varchar2);
               -- algorithm             IN varchar2);

  /* MAC Policy Algorithm */

  /**
  * Specify the algorithm that is used to merge labels when computing the label for
  * a Factor, or the MAC OLS Session label.  The algorithm is a 3-letter acronym
  * (e.g. LII, HUU, ...).  Consult OLS documentation for details.
  *
  * @param policy_name OLS Policy Name
  * @param algorithm Merge algorithm
  *
  * @throws ORA 20180 MAC Policy already defined
  * @throws ORA 20182 Algorithm not found
  * @throws ORA 20381 Policy not found
  */
  PROCEDURE create_mac_policy
              (policy_name           IN varchar2,
               algorithm             IN varchar2,
               error_label           IN varchar2 DEFAULT NULL);

  /**
  * Specify the algorithm that is used to merge labels when computing the label for
  * a Factor, or the MAC OLS Session label.  The algorithm is a 3-letter acronym
  * (e.g. LII, HUU, ...).  Consult OLS documentation for details.
  *
  * @param policy_name OLS Policy Name
  * @param algorithm Merge algorithm
  *
  * @throws ORA 20182 Algorithm not found
  * @throws ORA 20184 Error updating MAC Policy
  * @throws ORA 20381 Policy not found
  */
  PROCEDURE update_mac_policy
              (policy_name  IN varchar2,
               algorithm             IN varchar2,
               error_label           IN varchar2 DEFAULT NULL);

  /**
  * Deletes all DV objects related to an OLS policy.  This method should be called
  * after an OLS policy has been deleted to ensure that there are not any broken
  * references between DV and OLS.  Note that there is not any referential integrity
  * constraints between DV and OLS.  The affected objects are in the mac_policy$,
  * mac_policy_factor$, and policy_label$ tables.
  *
  * @param policy_name OLS Policy Name
  *
  * @throws ORA 20185 Error deleting MAC Policy
  * @throws ORA 20381 Policy not found
  */
  PROCEDURE delete_mac_policy_cascade(policy_name IN varchar2);

  /* Realm */

  /**
  * Create a Realm
  *
  * @param realm_name Realm name
  * @param description Realm description
  * @param enabled Indication of whether the realm checking is on or off (g_yes/g_no)
  * @param audit_options How to audit realm (described in dbms_macutl)
  * @param realm_type Realm type
  *
  * @throws ORA 20240 Realm already defined
  * @throws ORA 20242 Error creating realm
  */
  PROCEDURE create_realm
              (realm_name  IN varchar2,
               description IN varchar2,
               enabled IN varchar2,
               audit_options IN number,
               realm_type    IN number default NULL) ;

  /**
  * Update a Realm
  *
  * @param realm_name Realm name
  * @param description Realm description
  * @param enabled Indication of whether the realm checking is on or off (g_yes/g_no)
  * @param audit_options How to audit realm (described in dbms_macutl)
  * @param realm_type Realm type
  *
  * @throws ORA 20244 Error updating realm
  */
  PROCEDURE update_realm
              (realm_name  IN varchar2,
               description IN varchar2,
               enabled IN varchar2,
               audit_options IN number default NULL,
               realm_type    IN number default NULL) ;

  /**
  * Rename a Realm
  *
  * @param realm_name Realm name
  * @param new_name New Realm name
  *
  * @throws ORA 20245 Error renaming realm
  */
  PROCEDURE rename_realm
              (realm_name  IN varchar2,
               new_name    IN varchar2);

  /**
  * Drop a Realm
  *
  * @param realm_name Realm name
  *
  * @throws ORA 20243 Error deleting realm
  */
  PROCEDURE delete_realm
              (realm_name IN varchar2);

  /**
  * Deletes a DV realm, including the related Realm objects (realm_object$),
  * and authorizations (realm_auth$).
  *
  * @param realm_name Realm name
  *
  * @throws ORA 20241 Realm not found
  * @throws ORA 20243 Error deleting realm
  */
  PROCEDURE delete_realm_cascade
              (realm_name IN varchar2);

  /**
  * Authorize a user or role to access a realm as a participant or owner.  The
  * authorization can be made conditional based on a Rule Set (i.e. only authorized
  * if the Rule Set evaluates to TRUE).
  *
  * @param realm_name Realm name
  * @param grantee User or role name
  * @param rule_set_name Rule Set to check before authorizing (optional)
  * @param auth_options Authorization level (participant or owner - see dbms_macutl)
  *
  * @throws ORA 20260 Realm Authorization already defined
  * @throws ORA 20262 Error adding Realm Authorization
  */
  PROCEDURE add_auth_to_realm
              (realm_name    IN varchar2,
               grantee       IN varchar2,
               rule_set_name IN varchar2,
               auth_options  IN number);

  /**
  * Authorize a user or role to access a realm as a participant.
  *
  * @param realm_name Realm name
  * @param grantee User or role name
  *
  * @throws ORA 20260 Realm Authorization already defined
  * @throws ORA 20262 Error adding Realm Authorization
  */
  PROCEDURE add_auth_to_realm
              (realm_name    IN varchar2,
               grantee       IN varchar2);

  /**
  * Authorize a user or role to access a realm as an owner or participant (no Rule Set).
  *
  * @param realm_name Realm name
  * @param grantee User or role name
  * @param auth_options Authorization level (participant or owner - see dbms_macutl)
  *
  * @throws ORA 20260 Realm Authorization already defined
  * @throws ORA 20262 Error adding Realm Authorization
  */
  PROCEDURE add_auth_to_realm
              (realm_name    IN varchar2,
               grantee       IN varchar2,
               auth_options  IN number);

  /**
  * Authorize a user or role to access a realm as a participant (optional).
  *
  * @param realm_name Realm name
  * @param grantee User or role name
  * @param rule_set_name Rule Set to check before authorizing (optional)
  *
  * @throws ORA 20260 Realm Authorization already defined
  * @throws ORA 20262 Error adding Realm Authorization
  */
  PROCEDURE add_auth_to_realm
              (realm_name    IN varchar2,
               grantee       IN varchar2,
               rule_set_name IN varchar2);

  /**
  * Remove the authorization of a user or role to access a realm.
  *
  * @param realm_name Realm name
  * @param grantee User or role name
  *
  * @throws ORA 20263 Error deleting Realm Authorization
  */
  PROCEDURE delete_auth_from_realm
              (realm_name    IN varchar2,
               grantee       IN varchar2);
               -- rule_set_name IN varchar2);

  /**
  * Update the authorization of a user or role to access a realm.
  *
  * @param realm_name Realm name
  * @param grantee User or role name
  * @param rule_set_name Rule Set to check before authorizing (optional)
  * @param auth_options Authorization level (participant or owner - see dbms_macutl)
  *
  * @throws ORA 20264 Error updating Realm Authorization
  */
  PROCEDURE update_realm_auth
              (realm_name    IN varchar2,
               grantee       IN varchar2,
               rule_set_name IN varchar2,
               auth_options  IN number);

  /**
  * Register a set of objects for Realm protection.
  *
  * @param realm_name Realm name
  * @param object_owner Object owner
  * @param object_name Object name (Wild card % is allowed)
  * @param object_type Object type (Wild card % is allowed)
  *
  * @throws ORA 20280 Object already in Realm
  * @throws ORA 20282 Error adding object to Realm
  */
  PROCEDURE add_object_to_realm
              (realm_name    IN varchar2,
               object_owner  IN varchar2,
               object_name   IN varchar2,
               object_type   IN varchar2);

  /**
  * Remove a set of objects from Realm protection.
  *
  * @param realm_name Realm name
  * @param object_owner Object owner
  * @param object_name Object name (Wild card % is allowed)
  * @param object_type Object type (Wild card % is allowed)
  *
  * @throws ORA 20283 Error deleting object to Realm
  */
  PROCEDURE delete_object_from_realm
              (realm_name    IN varchar2,
               object_owner  IN varchar2,
               object_name   IN varchar2,
               object_type   IN varchar2);

  /**
  * Enable/disable Event
  *
  * @param enable
  *
  */
  PROCEDURE enable_event(event IN number);
  PROCEDURE disable_event(event IN number);

  /* Rule Set */

  /**
  * Create a Rule Set.
  *
  * @param rule_set_name Rule Set name
  * @param description Description
  * @param enabled Whether to evaluate Rule Set or ignore it
  * @param eval_options Evaluation options (see dbms_macutl)
  * @param audit_options Audit options (see dbms_macutl)
  * @param fail_options Fail options (see dbms_macutl)
  * @param fail_message Error message for failure
  * @param fail_code Error code to return on failure
  * @param handler_options Handler options (see dbms_macutl)
  * @param handler Handler method
  *
  * @throws ORA 20340 Rule Set already defined
  * @throws ORA 20342 Error creating Rule Set
  */
  PROCEDURE create_rule_set
              (rule_set_name   IN varchar2,
               description     IN varchar2,
               enabled         IN varchar2,
               eval_options    IN number,
               audit_options   IN number,
               fail_options    IN number,
               fail_message    IN varchar2,
               fail_code       IN number,
               handler_options IN number,
               handler         IN varchar2,
               is_static       IN boolean default false);

  /**
  * Update a Rule Set.
  *
  * @param rule_set_name Rule Set name
  * @param description Description
  * @param enabled Whether to evaluate Rule Set or ignore it
  * @param eval_options Evaluation options (see dbms_macutl)
  * @param audit_options Audit options (see dbms_macutl)
  * @param fail_options Fail options (see dbms_macutl)
  * @param fail_message Error message for failure
  * @param fail_code Error code to return on failure
  * @param handler_options Handler options (see dbms_macutl)
  * @param handler Handler method
  *
  * @throws ORA 20344 Error updating Rule Set
  */
  PROCEDURE update_rule_set
              (rule_set_name   IN varchar2,
               description     IN varchar2,
               enabled         IN varchar2,
               eval_options    IN number,
               audit_options   IN number,
               fail_options    IN number,
               fail_message    IN varchar2,
               fail_code       IN number,
               handler_options IN number,
               handler         IN varchar2,
               is_static       IN boolean default false);

  /**
  * Rename a Rule Set.
  *
  * @param rule_set_name Rule Set name
  * @param new_name New rule set name
  *
  * @throws ORA 20344 Error updating Rule Set
  */
  PROCEDURE rename_rule_set
              (rule_set_name IN varchar2,
               new_name      IN varchar2);

  /**
  * Delete a Rule Set.
  *
  * @param rule_set_name Rule Set name
  *
  * @throws ORA 20343 Error deleting Rule Set
  */
  PROCEDURE delete_rule_set
              (rule_set_name IN varchar2);

  /**
  * Add a Rule to a Rule Set.
  *
  * @param rule_set_name Rule Set name
  * @param rule_name Rule name
  * @param rule_order Order of evaluation for Rule in Rule Set
  * @param enabled Whether or not the Rule is enabled
  *
  * @throws ORA 20360 Rule already added to Rule Set
  * @throws ORA 20362 Error adding Rule to Rule Set
  */
  PROCEDURE add_rule_to_rule_set
              (rule_set_name IN varchar2,
               rule_name     IN varchar2,
               rule_order    IN number,
               enabled       IN varchar2) ;

  /**
  * Add an enabled Rule to a Rule Set.
  *
  * @param rule_set_name Rule Set name
  * @param rule_name Rule name
  * @param rule_order Order of evaluation for Rule in Rule Set
  *
  * @throws ORA 20360 Rule already added to Rule Set
  * @throws ORA 20362 Error adding Rule to Rule Set
  */
  PROCEDURE add_rule_to_rule_set
              (rule_set_name IN varchar2,
               rule_name     IN varchar2,
               rule_order    IN number);

  /**
  * Add an enabled Rule to the end of Rule Set (i.e. evaluated last).
  *
  * @param rule_set_name Rule Set name
  * @param rule_name Rule name
  *
  * @throws ORA 20360 Rule already added to Rule Set
  * @throws ORA 20362 Error adding Rule to Rule Set
  */
  PROCEDURE add_rule_to_rule_set
              (rule_set_name IN varchar2,
               rule_name     IN varchar2);

  /**
  * Delete a Rule from a Rule Set.
  *
  * @param rule_set_name Rule Set name
  * @param rule_name Rule name
  *
  * @throws ORA 20363 Error deleting Rule to Rule Set
  */
  PROCEDURE delete_rule_from_rule_set
              (rule_set_name IN varchar2,
               rule_name     IN varchar2);

  /* Rule */

  /**
  * Create a Rule
  *
  * @param rule_name Rule name
  * @param rule_expr PL/SQL Boolean expression
  *
  * @throws ORA 20320 Rule already defined
  * @throws ORA 20322 Error creating Rule
  */
  PROCEDURE create_rule
              (rule_name  IN varchar2,
               rule_expr  IN varchar2);
  /**
  * Update a Rule
  *
  * @param rule_name Rule name
  * @param rule_expr PL/SQL Boolean expression
  *
  * @throws ORA 20324 Error updating Rule
  */
  PROCEDURE update_rule
              (rule_name  IN varchar2,
               rule_expr  IN varchar2);

  /**
  * Rename a Rule
  *
  * @param rule_name Rule name
  * @param new_name New Rule name
  *
  * @throws ORA 20324 Error updating Rule
  */
  PROCEDURE rename_rule
              (rule_name  IN varchar2,
               new_name  IN varchar2);

  /**
  * Delete a Rule
  *
  * @param rule_name Rule name
  *
  * @throws ORA 20323 Error deleting Rule
  */
  PROCEDURE delete_rule
              (rule_name  IN varchar2);


  /* Role */

  /**
  * Create a DV Secure Application Role.  Access to the role is protected
  * by a Rule Set.
  *
  * @param role_name Role name
  * @param enabled Whether the role is enabled or diabled
  * @param rule_set_name Rule Set to determine whether a user can set the role
  *
  * @throws ORA 20300 Role already defined
  * @throws ORA 20302 Error creating role
  *
  */
  PROCEDURE create_role
              (role_name IN varchar2,
               enabled   IN varchar2,
               rule_set_name IN varchar2);

  /**
  * Delete a DV Secure Application Role.
  *
  * @param role_name Role name
  *
  * @throws ORA 20303 Error deleting role
  *
  */
  PROCEDURE delete_role
              (role_name IN varchar2);

  /**
  * Update a DV Secure Application Role.  Access to the role is protected
  * by a Rule Set.
  *
  * @param role_name Role name
  * @param enabled Whether the role is enabled or diabled
  * @param rule_set_name Rule Set to determine whether a user can set the role
  *
  * @throws ORA 20304 Error updating role
  *
  */
  PROCEDURE update_role
              (role_name IN varchar2,
               enabled   IN varchar2,
               rule_set_name IN varchar2);

  /**
  * Rename a DV Secure Application Role.
  *
  * @param role_name Role name
  * @param new_role_name Role name
  *
  * @throws ORA 20304 Error updating role
  *
  */
  PROCEDURE rename_role
              (role_name IN varchar2,
               new_role_name  IN varchar2);

  /* Command Rule */

  /**
  * Protect a database command by associating it with a Rule Set.  The
  * command can only be executed if the Rule Set evaluates to TRUE.
  *
  * @param command SQL command to protect
  * @param rule_set_name Rule Set to protect command
  * @param object_owner Related database object schema
  * @param object_name Related database object name
  * @param enabled Whether the command rule is enabled or disabled
  *
  * @throws ORA 20081 Command not found
  * @throws ORA 20100 Command rule already defined
  * @throws ORA 20102 Error creating Command Rule
  */
  PROCEDURE create_command_rule
              (command IN varchar2,
               rule_set_name IN varchar2,
               object_owner  IN varchar2,
               object_name   IN varchar2,
               enabled       IN varchar2,
               privilege_scope IN NUMBER DEFAULT NULL);

  /**
  * Drop a Command Rule declaration.
  *
  * @param command SQL command to protect
  * @param object_owner Related database object schema
  * @param object_name Related database object name
  *
  * @throws ORA 20081 Command not found
  * @throws ORA 20103 Error deleting Command Rule
  */
  PROCEDURE delete_command_rule
              (command IN varchar2,
               object_owner  IN varchar2,
               object_name   IN varchar2);

  /**
  * Update a Command Rule declaration.
  *
  * @param command SQL command to protect
  * @param rule_set_name Rule Set to protect command
  * @param object_owner Related database object schema
  * @param object_name Related database object name
  * @param enabled Whether the command rule is enabled or disabled
  *
  * @throws ORA 20081 Command not found
  * @throws ORA 20104 Error updating Command Rule
  */
  PROCEDURE update_command_rule
              (command IN varchar2,
               rule_set_name IN varchar2,
               object_owner  IN varchar2,
               object_name   IN varchar2,
               enabled       IN varchar2,
               privilege_scope IN NUMBER DEFAULT NULL);

  /**
  * Returns information from the sys.v_$instance view.
  *
  *  @param p_parameter Column name in sys.v_$instance
  *  @return Value of column p_parameter in sys.v_$instance
  */
  FUNCTION get_instance_info(p_parameter IN VARCHAR2) RETURN VARCHAR2;

  /**
  * Returns information from the sys.v_$session view for the current session
  *
  *  @param p_parameter Column name in sys.v_$session
  *  @return Value of column p_parameter in sys.v_$session
  */
  FUNCTION get_session_info(p_parameter IN VARCHAR2) RETURN VARCHAR2;

  /**
  * Add a RAC database node to a domain. If the identity for the domain does
  * not exist the identity will be added.
  * Creates the required identity map information for the database hostname provided.
  * If the OLS policy is provided, domain will be added as a policy factor
  * if it is not already associated. If the label for the identity of this domain
  * does not exist the label will be added.
  * This call must be made with the instance running on the host specified.
  *
  * @param domain_name Name of the domain to add the host to
  * @param domain_host RAC host name being added to the domain
  * @param policy_name OLS Policy Name to label the domain for
  * @param label OLS Label to label the domain within this policy
  *
  * @throws ORA 20921 Error adding host to domain
  */

  PROCEDURE create_domain_identity
              (domain_name IN varchar2,
               domain_host IN varchar2,
               policy_name IN varchar2 DEFAULT NULL,
               domain_label IN varchar2 DEFAULT NULL
               );

  /**
  * Remove a RAC database node from a domain.
  * Creates the required identity map information for the database hostname provided.
  *
  * @param domain_name Name of the domain to add the host to
  * @param domain_host RAC host name being added to the domain
  *
  * @throws ORA 20922 Error removing host to domain
  */
  PROCEDURE drop_domain_identity
              (domain_name IN varchar2,
               domain_host IN varchar2);

  /**
  * Returns the character set for the database
  *
  * @return character set for the database
  */
  FUNCTION get_db_charset RETURN VARCHAR2;

  /**
  * Returns the 3 character Oracle language for the current administration session
  * Based on set_ora_lang_from_java
  *
  * @return 3 character oracle language identifier for the administration current session
  */
  FUNCTION get_ora_lang RETURN VARCHAR2;

  /**
  * Sets the 3 character Oracle language for the current session
  * based on the Java language parameter passed in, converting as required
  *
  * @param p_lang Java language to set
  */
  PROCEDURE set_ora_lang_from_java(p_lang IN VARCHAR2);

  /**
  * check to see if alter system set system_trig_enabled
  *
  * return 'Y' or 'N'
  */
  FUNCTION check_trig_parm_varchar RETURN VARCHAR2;

  /**
  * check to see if following O7_DICTIONARY_ACCESSIBILITY
  * is allowed:
  *
  * return 'Y' or 'N'
  */
  FUNCTION check_o7_parm_varchar RETURN VARCHAR2;

  /**
  * check to see if alter system set _dynamic_rls_policies
  * are allowed
  *
  * return 'Y' or 'N'
  */
  FUNCTION check_dynrls_parm_varchar RETURN VARCHAR2;

  /**
  * check to see if following ALTER SYSTEM security system parameters
  * are allowed :
  *    _SYSTEM_TRIG_ENABLED POLICIES
  *    O7_DICTIONARY_ACCESSIBILITY
  *    _DYNAMIC_RLS_POLICIES
  *
  * return 'Y' or 'N'
  */
  FUNCTION check_sys_sec_parm_varchar RETURN VARCHAR2;

  /**
  * check to see if following ALTER SYSTEM dump or dest parameters
  * are allowed :
  *    MAX_DUMP_FILE_SIZE
  *    %DUMP%
  *    %_DEST%
  *    LOG_ARCHIVE%
  *    STANDBY_ARCHIVE%
  *    DB_RECOVERY_FILE_DEST_SIZE
  *
  * return 'Y' or 'N'
  */
  FUNCTION check_dump_dest_parm_varchar RETURN VARCHAR2;

  /**
  * check to see if following ALTER SYSTEM backup restore parameters
  * are allowed :
  *    RECYCLEBIN
  *
  * return 'Y' or 'N'
  */
  FUNCTION check_backup_parm_varchar RETURN VARCHAR2;

  /**
  * check to see if following ALTER SYSTEM database file parameters
  * are allowed :
  *    CONTROL_FILES
  *
  * return 'Y' or 'N'
  */
  FUNCTION check_db_file_parm_varchar RETURN VARCHAR2;

  /**
  * check to see if following ALTER SYSTEM optimizer parameters
  * are allowed :
  *    OPTIMIZER_SECURE_VIEW_MERGING
  *
  * return 'Y' or 'N'
  */
  FUNCTION check_optimizer_parm_varchar RETURN VARCHAR2;

  /**
  * check to see if following ALTER SYSTEM plsql parameters
  * are allowed :
  *    UTL_FILE_DIR
  *    PLSQL_DEBUG
  *
  * return 'Y' or 'N'
  */
  FUNCTION check_plsql_parm_varchar RETURN VARCHAR2;

  /**
  * check to see if following ALTER SYSTEM security parameters
  * are allowed :
  *    AUDIT_SYS_OPERATIONS
  *    AUDIT_TRAIL
  *    AUDIT_SYSLOG_LEVEL
  *    REMOTE_OS_ROLES
  *    OS_ROLES
  *    SQL92_SECURITY
  *
  * return 'Y' or 'N'
  */
  FUNCTION check_security_parm_varchar RETURN VARCHAR2;

  /**
  * check to see if alter dvsys
  *
  * return 'Y' or 'N'
  */
  FUNCTION is_alter_user_allow_varchar(login_user VARCHAR2) RETURN VARCHAR2;

  FUNCTION is_drop_user_allow_varchar(login_user VARCHAR2) RETURN VARCHAR2;

  PROCEDURE authorize_datapump_user(
       uname       IN VARCHAR2,
       sname       IN VARCHAR2 DEFAULT NULL,
       objname     IN VARCHAR2 DEFAULT NULL
   );

  PROCEDURE unauthorize_datapump_user(
       uname       IN VARCHAR2,
       sname       IN VARCHAR2 DEFAULT NULL,
       objname     IN VARCHAR2 DEFAULT NULL
  );

  PROCEDURE authorize_tts_user(
       uname       IN VARCHAR2,
       tsname      IN VARCHAR2
  );

  PROCEDURE unauthorize_tts_user(
       uname       IN VARCHAR2,
       tsname      IN VARCHAR2
  );

  /* API to authorize a user to run jobs in the schema of other users. */
  PROCEDURE authorize_scheduler_user(
       uname       IN VARCHAR2,
       sname       IN VARCHAR2 DEFAULT NULL
   );

  PROCEDURE unauthorize_scheduler_user(
       uname       IN VARCHAR2,
       sname       IN VARCHAR2 DEFAULT NULL
   );

  /* APIs to authorize a user to proxy as another user. */
  PROCEDURE authorize_proxy_user
           ( uname       IN VARCHAR2 ,
             sname       IN VARCHAR2 DEFAULT NULL
           );

  PROCEDURE unauthorize_proxy_user
           ( uname       IN VARCHAR2 ,
             sname       IN VARCHAR2 DEFAULT NULL
           );

  /* APIs to authorize a user to execute DDLs on another user's schema. */
  PROCEDURE authorize_ddl
           ( uname       IN VARCHAR2 ,
             sname       IN VARCHAR2 DEFAULT NULL
           );

  PROCEDURE unauthorize_ddl
           ( uname       IN VARCHAR2 ,
             sname       IN VARCHAR2 DEFAULT NULL
           );

  /* BUG FIX 10225918 - Procedure to insert DV metadata in supported languages.
   Supported input Language values are :
   ENGLISH
   GERMAN
   SPANISH
   FRENCH
   ITALIAN
   JAPANESE
   KOREAN
   BRAZILIAN PORTUGUESE
   SIMPLIFIED CHINESE
   TRADITIONAL CHINESE
  */
  PROCEDURE add_nls_data(
       lang         IN VARCHAR2
   );

  /*
  * Enable/disable DV enforcement
  */

  PROCEDURE enable_dv;
  PROCEDURE disable_dv;

  -- Control ORADEBUG in Database Vault environment
  PROCEDURE enable_oradebug;
  PROCEDURE disable_oradebug;

  -- Control whether user can log into DVSYS and DVF accounts
  PROCEDURE enable_dv_dictionary_accts;
  PROCEDURE disable_dv_dictionary_accts;

END;
/

