create PACKAGE       MAC_POLICY_FACTOR$_priv AS

  TYPE attribute_rec IS RECORD (
      ID# MAC_POLICY_FACTOR$.ID#%TYPE
    , FACTOR_ID# MAC_POLICY_FACTOR$.FACTOR_ID#%TYPE
    , MAC_POLICY_ID# MAC_POLICY_FACTOR$.MAC_POLICY_ID#%TYPE
  );

  TYPE attribute_list IS VARRAY(4096) OF attribute_rec;

  -- Create method
  PROCEDURE create_row(
    p_FACTOR_ID# IN NUMBER,
    p_MAC_POLICY_ID# IN NUMBER,
    x_id# OUT number);

  -- Read method
  PROCEDURE read_row(p_id#        IN     number,
      x_ID# OUT NUMBER
    , x_FACTOR_ID# OUT NUMBER
    , x_MAC_POLICY_ID# OUT NUMBER
    );

  PROCEDURE read_by_FACTOR_ID#_(
    p_FACTOR_ID# IN number,
    x_attribute_list OUT attribute_list);

  PROCEDURE read_by_MAC_POLICY_ID#_(
    p_MAC_POLICY_ID# IN number,
    x_attribute_list OUT attribute_list);

  -- Update method
  PROCEDURE update_row(
      p_id# NUMBER
    , p_FACTOR_ID# IN NUMBER
    , p_MAC_POLICY_ID# IN NUMBER
    );

  -- Delete method
  PROCEDURE delete_row(p_id# IN number,
                    p_delete_children IN boolean := false);

  PROCEDURE delete_by_FACTOR_ID#_(
    p_FACTOR_ID# IN number,
    p_delete_children IN boolean := false);

  PROCEDURE delete_by_MAC_POLICY_ID#_(
    p_MAC_POLICY_ID# IN number,
    p_delete_children IN boolean := false);

END;
/

