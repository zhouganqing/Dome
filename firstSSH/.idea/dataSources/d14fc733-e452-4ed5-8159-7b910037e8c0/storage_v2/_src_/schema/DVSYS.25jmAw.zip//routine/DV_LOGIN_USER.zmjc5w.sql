create function       DV_LOGIN_USER return VARCHAR2 as
begin
   -- Fix for Bug 6068504
   return SYS_CONTEXT('DV_EVENT_SESSION_STATE', 'LOGIN_USER');
end;
/

