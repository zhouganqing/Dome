create PACKAGE       FACTOR_TYPE$_priv AS

  TYPE attribute_rec IS RECORD (
      ID# FACTOR_TYPE$.ID#%TYPE
    --, NAME FACTOR_TYPE$.NAME%TYPE
    --, DESCRIPTION FACTOR_TYPE$.DESCRIPTION%TYPE
  );

  TYPE attribute_list IS VARRAY(4096) OF attribute_rec;

  -- Create method
  PROCEDURE create_row(
    p_NAME IN VARCHAR2,
    p_DESCRIPTION IN VARCHAR2,
    x_id# OUT number);

  -- Read method
  PROCEDURE read_row(p_id#        IN     number,
      x_ID# OUT NUMBER
    , x_NAME OUT VARCHAR2
    , x_DESCRIPTION OUT VARCHAR2
    );

  -- Update method
  PROCEDURE update_row(
      p_id# NUMBER
    , p_NAME IN VARCHAR2
    , p_DESCRIPTION IN VARCHAR2
    );

  -- Delete method
  PROCEDURE delete_row(p_id# IN number,
                    p_delete_children IN boolean := false);

END;
/

