create FUNCTION       role_is_enabled(p_role IN VARCHAR2) RETURN BOOLEAN
IS
BEGIN
  RETURN dvsys.dbms_macsec.role_is_enabled(p_role => p_role);
END;
/

