create function       DV_SYSEVENT return VARCHAR2 as
begin
  -- Fix for Bug 6068504
  return SYS_CONTEXT('DV_EVENT_SESSION_STATE', 'SYSEVENT');
end;
/

