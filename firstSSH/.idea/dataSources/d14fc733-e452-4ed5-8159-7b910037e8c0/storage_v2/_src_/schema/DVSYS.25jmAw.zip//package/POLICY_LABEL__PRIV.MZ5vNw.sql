create PACKAGE       POLICY_LABEL$_priv AS

  TYPE attribute_rec IS RECORD (
      ID# POLICY_LABEL$.ID#%TYPE
    , IDENTITY_ID# POLICY_LABEL$.IDENTITY_ID#%TYPE
    , POLICY_ID# POLICY_LABEL$.POLICY_ID#%TYPE
    , LABEL_ID# POLICY_LABEL$.LABEL_ID#%TYPE
  );

  TYPE attribute_list IS VARRAY(4096) OF attribute_rec;

  -- Create method
  PROCEDURE create_row(
    p_IDENTITY_ID# IN NUMBER,
    p_POLICY_ID# IN NUMBER,
    p_LABEL_ID# IN NUMBER,
    x_id# OUT number);

  -- Read method
  PROCEDURE read_row(p_id#        IN     number,
      x_ID# OUT NUMBER
    , x_IDENTITY_ID# OUT NUMBER
    , x_POLICY_ID# OUT NUMBER
    , x_LABEL_ID# OUT NUMBER
    );

  PROCEDURE read_by_IDENTITY_ID#_(
    p_IDENTITY_ID# IN number,
    x_attribute_list OUT attribute_list);

  -- Update method
  PROCEDURE update_row(
      p_id# NUMBER
    , p_IDENTITY_ID# IN NUMBER
    , p_POLICY_ID# IN NUMBER
    , p_LABEL_ID# IN NUMBER
    );

  -- Delete method
  PROCEDURE delete_row(p_id# IN number,
                    p_delete_children IN boolean := false);

  PROCEDURE delete_by_IDENTITY_ID#_(
    p_IDENTITY_ID# IN number,
    p_delete_children IN boolean := false);

END;
/

