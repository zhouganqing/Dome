create FUNCTION     "F$AUTHENTICATION_METHOD" RETURN VARCHAR2 AS BEGIN RETURN DVSYS.get_factor(p_factor =>'Authentication_Method'); END;
/

