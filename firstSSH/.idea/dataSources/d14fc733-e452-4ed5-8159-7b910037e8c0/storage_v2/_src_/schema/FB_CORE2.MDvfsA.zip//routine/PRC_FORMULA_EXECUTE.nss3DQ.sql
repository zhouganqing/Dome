create procedure PRC_FORMULA_EXECUTE
(
mytable varchar2,
SelRecord out varchar2
)
is
spltRow ty_str_split;
spltColumn ty_str_split;
v_guid varchar2(200);
v_formula varchar2(2000);
v_result number:=0;
begin
  SelRecord:='';
  spltRow:=fun_split(mytable,'##');--行
  for idx in 1..spltRow.Count loop
      exit when v_result=1;
      spltColumn:=fun_split(spltRow(idx),'#');--列
      if spltColumn.Count=2 then
         v_guid:=spltColumn(1);
         v_formula:=spltColumn(2);
         Execute immediate v_formula into v_result;
         if v_result=1 then
                 SelRecord:=v_guid;
                 return;
         end if;
       end if;
   end loop;
end PRC_FORMULA_EXECUTE;
/

