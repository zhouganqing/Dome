create procedure prc_collect_element_pa(p_IdCredit cs_credit.id%type,p_ReturnCode out varchar2) is
       -- Author  : MaJianFeng
       -- Create Date : 2018-06-06
       -- Purpose : put credit data into decision_element_data_pa_PA table;
       error_info                  varchar2(1000);
        v_IdPerson                  cs_person.id%type;      
       v_PersonName                cs_person.name%type;
       v_Ident                     cs_person.ident%type;
       v_CommitTime                cs_credit.commit_time%type;    
       v_IdSa                      cs_credit.id_sa%type;
       v_CreditType                cs_credit.credit_type%type;     
       v_PreInterCode                cs_credit.pa_inter_code%type;                          
       v_PosCode                   sellerplace.pos_code%type;        
       v_IdSellerPlace             sellerplace.id%type;        
       v_Province                  sellerplace.province%type;
       v_City                      sellerplace.city%type;
       v_Seq                       decision_element_data_pa.sort_code%type;
       v_IdCredit                  number;
       v_Count                     integer;       
       v_GoodsVolume               number:=0;
       v_MaxGoodsPrice             number:=-1;
       v_MaxGoodsType              goods_type.name%type;
       v_MinGoodsPrice             number:=-1;
       v_MinGoodsType              goods_type.name%type;
       v_IsRecall                  number:=0;
       v_CreditAmount              cs_credit.credit_amount%type;
       v_SCI_Amount                status_change_information.credit_amount%type;
       v_SCI_Category              status_change_information.goodsnewcategory%type;
       v_NewCategory               varchar2(50);

       v_ElementType               decision_element_data_pa.element_type%type;
       v_ContractNo                cs_credit.contract_no%type;
       v_Price                     cs_credit.price%type;
       v_Annuity                   cs_credit.annuity%type;
       
       v_Birthday                  varchar2(20);
       v_Age                       integer;
       v_Sex                       cs_person.sex%type;
       
       v_IdProduct                 product.id%type;
       v_ProdType                  product.prod_type%type;
       v_SearchType                product.search_type%type;
       v_TempVue                   varchar2(50);
       strSql                      varchar2(4000);
    begin
       delete decision_element_data_pa where id_credit=p_IdCredit;
       -------------------------Start--------------------------------
      -- prc_save_cs_contact(100000,p_IdCredit,p_ReturnCode);
       v_Seq:=0;
       v_ElementType:='Special';
       insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
            values(p_IdCredit,v_ElementType,'Random5',round(dbms_random.value(),6),v_Seq+1);
       v_Seq:=v_Seq + 1;
      
       v_ElementType:='Credit';
       select a.contract_no,a.commit_time,nvl(a.id_sa,''),a.credit_amount,a.price,a.annuity,a.id_person,a.credit_type,a.pa_inter_code
         into v_ContractNo,v_CommitTime,v_IdSa,v_CreditAmount,v_Price,v_Annuity,v_IdPerson,v_CreditType,v_PreInterCode
         from cs_credit a where a.id=p_IdCredit;
       --2017/03/21 update wangxiaofeng v_AppDate date 改为datetime
       strSql:='insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
                select '||p_IdCredit||','''||v_ElementType||''','||'''ContractNo'''||','''||v_ContractNo||''','||(v_Seq+1)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''Price'''||','''||v_Price||''','||(v_Seq+12)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''CreditAmount'''||','''||v_CreditAmount||''','||(v_Seq+10)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''Annuity'''||','''||v_Annuity||''','||(v_Seq+13)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''CommitTime'''||','''||to_char(v_CommitTime,'yyyy-MM-dd HH24:mi:ss')||''','||(v_Seq+3)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''PreInterCode'''||','''||v_PreInterCode||''','||(v_Seq+4)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''IdSa'''||','''||v_IdSa||''','||(v_Seq+5)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''CreditType'''||','''||v_CreditType||''','||(v_Seq+6)||' from dual';
       Execute immediate strSql;
       v_Seq:=v_Seq +6;

       for fee in(select t.insurance_fee from cs_credit_fee t where t.id_credit=p_IdCredit)
         loop
           --保险费用
           insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
           values(p_IdCredit,'Credit','*','InsuranceFee',fee.insurance_fee,v_Seq+1);
           v_Seq:=v_Seq + 1;
       end loop;
     
       ---------------------------------------------------------
       v_ElementType:='Person';
       select name,ident,sex
         into v_PersonName,v_Ident,v_Sex
         from cs_person a where id=v_IdPerson;

       if length(v_Ident)=15 then
           v_Birthday:=to_char(to_date('19'||substr(v_Ident,7,6),'yyyy-MM-dd'),'yyyy-MM-dd');
           select to_number(to_char(sysdate,'yyyy')) - to_number('19'||substr(v_Ident,7,2)) into v_Age from dual;
       else
           v_Birthday:=to_char(to_date(substr(v_Ident,7,8),'yyyy-MM-dd'),'yyyy-MM-dd');
           select to_number(to_char(sysdate,'yyyy')) - to_number(substr(v_Ident,7,4)) into v_Age from dual;
       end if;
       strSql:='insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
                select '||p_IdCredit||','''||v_ElementType||''','||'''Birthday'''||','''||v_Birthday||''','||(v_Seq+1)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''IdPerson'''||','''||v_IdPerson||''','||(v_Seq+2)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''Age'''||','''||v_Age||''','||(v_Seq+3)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''Sex'''||','''||v_Sex||''','||(v_Seq+4)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''Name'''||','''||v_PersonName||''','||(v_Seq+5)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''Ident'''||','''||v_Ident||''','||(v_Seq+6)||' from dual';
       v_Seq:=v_Seq +6;
       Execute immediate strSql;
     
       select a.id_product into  v_IdProduct from cs_credit a where a.id=p_IdCredit;
       if v_IdProduct!=0 then
         v_ElementType:='Product';
         select prod_type,search_type
           into v_ProdType,v_SearchType
           from product where id=v_IdProduct;

         strSql:='insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
                  select '||p_IdCredit||','''||v_ElementType||''','||'''ProdType'''||','''||v_ProdType||''','||(v_Seq+1)||' from dual
                  union select '||p_IdCredit||','''||v_ElementType||''','||'''SearchType'''||','''||v_SearchType||''','||(v_Seq+2)||' from dual';
         Execute immediate strSql;
         v_Seq:=v_Seq +2;
         end if;
     select a.id_sellerplace into  v_IdSellerPlace from cs_credit a where a.id=p_IdCredit;

       if v_IdSellerPlace>0 then
           v_ElementType:='SellerPlace';
           select province,city,pos_code
             into v_Province,v_City,v_PosCode
             from sellerplace where id=v_IdSellerPlace;

           strSql:='insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
                    select '||p_IdCredit||','''||v_ElementType||''','||'''Province'''||','''||v_Province||''','||(v_Seq+1)||' from dual
                    union select '||p_IdCredit||','''||v_ElementType||''','||'''PosCode'''||','''||v_PosCode||''','||(v_Seq+2)||' from dual
                    union select '||p_IdCredit||','''||v_ElementType||''','||'''City'''||','''||v_City||''','||(v_Seq+3)||' from dual';
                    
           v_Seq:=v_Seq +3;
           Execute immediate strSql;
      end if;
    --AfPosCate:反欺诈门店等级类别，取于表RISK_CONTROL.DF_AF_GSPN，当status=a中的字段AF_TYPE 2016/03/16 wangxiaofeng
     insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
     select p_IdCredit,'SellerPlace','AfPosCate',nvl(max(t.af_type),0),v_Seq from mv_df_af_gspn t
     where t.status='a' and t.pos_code=v_PosCode;
     v_Seq:=v_Seq +1;

     
    --AfSaCate:反欺诈销售等级类别，取于表RISK_CONTROL.DF_AF_GSPN_ABNORMAL，当status=a中的字段AF_TYPE 2016/03/16 wangxiaofeng
    insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
    select p_IdCredit,'SellerPlace','AfSaCate',nvl(max(t.af_type),0),v_Seq from mv_df_af_gspn_abnormal t
    where t.status='a' and t.id_sa=v_IdSa;
    v_Seq:=v_Seq + 1;


    --添加元素Credit.TotalAnnuity，包括以下期款及费用 annuity+power_fee+insurance_fee+screen_fee+post_fee-COUPON_AMOUNT
    insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
    select p_IdCredit,'Credit','*','TotalAnnuity',nvl(sum(TotalAnnuity),0),v_Seq
    from(select nvl(annuity,0)+nvl(power_fee,0)+nvl(insurance_fee,0)+nvl(broken_screen_service,0)+nvl(stag_insurance_service,0)
          -nvl(coupon_amount,0)+nvl(treasure_box_fee,0)+nvl(COMPREHENSIVE_INSURANCE,0) as TotalAnnuity
    from cs_credit_fee where id_credit=p_IdCredit);
    
     --区分召回客户的决策流程
     select b.name  ,b.ident,b.id,a.credit_amount into v_PersonName,v_Ident,v_IdPerson,v_CreditAmount from cs_credit a join cs_person b on a.id_person=b.id and a.id=p_IdCredit;
     select count(1) into v_Count from status_change_information where personname=v_PersonName and personident=v_Ident;
       if v_Count=0 then
          v_IsRecall:=0;
       else
          select credit_amount,goodsnewcategory into v_SCI_Amount,v_SCI_Category from status_change_information
           where rownum=1 and personname=v_PersonName and personident=v_Ident;
          if v_CreditAmount<=v_SCI_Amount and v_NewCategory=v_SCI_Category then
             v_IsRecall:=1;
          else
             v_IsRecall:=2;
          end if;
       end if;
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            values(p_IdCredit,'Credit','*','IsRecall',v_IsRecall,v_Seq);



     --客户在申请此合同时，前30天内的合同总次数
         v_Seq:=0;
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            select p_IdCredit,'HardCheck','*','ApplicationLast30Day',count(1),v_Seq from cs_credit a where a.id_person=v_IdPerson
               and a.id<>p_IdCredit and trunc(a.create_time)>=trunc(sysdate)-30 and a.create_time<v_CommitTime;--2017-09-22增加时间范围
       v_Seq:=v_Seq + 1;     

       --BlackListCateFraudMetrix:同盾黑名单分类 
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select  p_IdCredit,'HardCheck','*','BlackListCateFraudMetrix',substr(max(case when rule_no in (
          840098,2900153,2901749,2992525,840072,891780,891784,2900089,840080,840116,2992509,2992523,2992511,2901741,840076,
          891788,2901719,2992521,891804,840106,2901711,2992507,840096,891814,2901715,11532,14130,840100,78586,891806,891824,891808,
          5638201,5640421,5640431,5640411) then '9失信名单'
          when rule_no in (840086,2901725,891794,891816,2901743,840108,840118,2901751,891826) then '8灰名单'
          when rule_no in (2900149,891792,2901723,840084,584894) then '7已结案名单'
          when rule_no in (2900083,2901761,2901759,891782,840074,2901713,840082,891790,891802,840094,891812,891832,891834,891836,
            2901731,891828,840120,891830,840122,11534,840104,840126,44126,15726,840124,840128) then '6低风险失信名单'
          else '0其他' end),2,10) BlackListCateFraudMetrix,v_Seq
          from WFI_FRAUD_METRIX_RESULT a join WFI_FRAUD_METRIX_RULE t on a.id=t.fraud_metrix_result_id
          where a.event_name='Credit' and a.associated_id=p_IdCredit
          group by a.associated_id;
          v_Seq:=v_Seq + 1;
          
       --客户身份证黑名单
       select count(1) into v_Count from customer_blacklist where ident=v_Ident;
       if v_Count>0 then
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
              values(p_IdCredit,'HardCheck','*','BlackListIDent','1',v_Seq);
          v_Seq:=v_Seq + 1;
       end if;
       
      --客户本人手机号码黑名单
       select count(1) into v_Count from customer_blacklist
       where mobile in(select contact_value from cs_contact where id_person=v_IdPerson and person_type='1' and contact_type in('2','3','18','19'));
       if v_Count>0 then
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
              values(p_IdCredit,'HardCheck','*','BlackListMobile','1',v_Seq);
          v_Seq:=v_Seq + 1;
       end if;       
       
       --客户在申请此合同时，当天取消的合同总数
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            select p_IdCredit,'HardCheck','*','CancleApplicationSameDay',count(1),v_Seq from cs_credit a where a.id_person=v_IdPerson
               and trunc(a.commit_time)=trunc(sysdate) and a.status='t' and a.id<>p_IdCredit  and a.create_time<v_CommitTime;--2017-09-22增加时间范围
       v_Seq:=v_Seq + 1;
     

  --是否查得同盾数据FraudMetrixActive (1, 查得; 0, 未查得)
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'HardCheck','*','FraudMetrixActive',decode(count(1),0,0,1),v_Seq
       from wfi_fraud_metrix_result t where t.event_name='Credit' and t.associated_id=p_IdCredit;
       v_Seq:=v_Seq + 1;
       -- 过去半小时内同盾未查得合同数FraudMetrixFailedCount 2017/03/03 update
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'HardCheck','*','FraudMetrixFailedCount',count(1),v_Seq
       from cs_credit a where not exists(select 1 from wfi_fraud_metrix_result b
                                           where b.event_name='Credit'  and b.associated_id=a.id)
                         and a.status not in('r','t') and nvl(a.inter_code,0) not in(3,4)
                         and a.credit_type=decode(v_CreditType,'SC','SC','SS')
                         and a.create_time>=v_CommitTime-35/24/60 and a.create_time<=v_CommitTime-5/24/60;
       v_Seq:=v_Seq + 1;
       --IsSAIdent客户申请时,身份证是否属于销售代表/销售经理/门店法人身份证  
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'HardCheck','*','IsSAIdent',case when sum(amount)>0 then 1 else 0 end,v_Seq
       from (
         select count(1) amount from sys_user_list a where upper(a.role_id) in('SA','DSM','MENTOR') and a.ident=v_Ident
         union
         select count(1) amount from seller where legal_ident=v_Ident);
       v_Seq:=v_Seq + 1;     
     
       --HardCheck.MaxCpd,HardCheck.Last3mCpd
       for prev_instalment in
          (select to_char(min(date_due_first),'yyyy-MM-dd') as date_due_first,--客户最早的应还款日期
               max(cpd) as cpd,--客户在申请合同时其他合同的现在的未还的逾期天数，精确到天              
               max(max_dpd) as max_dpd,--客户在申请合同时历史上最大逾期天数，精确到天
               max(last_3m_dpd) as last_3m_dpd, --客户在申请合同时最近三个月（自然月）的最大逾期天数，精确到天
               max(max_cpd) as max_cpd,
               max(last_3m_cpd) as last_3m_cpd
              from mv_DF_PD_SUM_GL where id_person=v_IdPerson)
       loop
            if prev_instalment.date_due_first is not null then
                insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                    values(p_IdCredit,'HardCheck','*','DateDueFirst',prev_instalment.date_due_first,v_Seq+1);
                v_Seq:=v_Seq + 1;
        
        --客户在申请合同时其他合同的现在的未还的逾期天数，精确到天
                insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                     values(p_IdCredit,'HardCheck','*','Cpd',prev_instalment.cpd,v_Seq);
                v_Seq:=v_Seq + 1;
               
        
        --客户在申请合同时最近三个月（自然月）的最大逾期天数，精确到天
                insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                     values(p_IdCredit,'HardCheck','*','Last3mDpd',prev_instalment.last_3m_dpd,v_Seq);
                v_Seq:=v_Seq + 1;
        
        --客户在申请合同时历史上最大逾期天数，精确到天
                insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                     values(p_IdCredit,'HardCheck','*','MaxCpd',prev_instalment.max_cpd,v_Seq);
                v_Seq:=v_Seq + 1;
        --客户在申请合同时历史上最大逾期天数，精确到天
                insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                     values(p_IdCredit,'HardCheck','*','MaxDpd',prev_instalment.max_dpd,v_Seq);
                v_Seq:=v_Seq + 1;
        
        --客户在申请合同时最近三个月（自然月）的最大逾期天数，精确到天
                insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                     values(p_IdCredit,'HardCheck','*','Last3mCpd',prev_instalment.last_3m_cpd,v_Seq);
                v_Seq:=v_Seq + 1;        
            end if;
       end loop;  
      --客户在申请此合同时前面一张通过的合同的申请时间，除拒绝和取消的合同外（状态为d/t/x/u的除外）update_time2016/11/30
      
        select to_char(max(create_time),'yyyy-MM-dd HH24:mi:ss') into v_TempVue from cs_credit
             where id_person=v_IdPerson and create_time<=v_CommitTime and credit_type in('SS','SC') and id!=p_IdCredit and status not in('d','t','x','u','r','q');
             if v_TempVue is not null then
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       values(p_IdCredit,'HardCheck','*','MaxPrevCommitTime',v_TempVue,v_Seq );
            /*select p_IdCredit,'HardCheck','*','MaxPrevCommitTime',to_char(max(create_time),'yyyy-MM-dd HH24:mi:ss'),v_Seq from cs_credit
             where id_person=v_IdPerson and create_time<=v_CommitTime and credit_type in('SS','SC') and id!=p_IdCredit and status not in('d','t','x','u','r','q');*/
             end if;
       v_Seq:=v_Seq + 1;
       --3个月内借款平台数MultiLoanTypeCountFraudMetrix3M: rule_name='新_3个月内申请人身份证或手机在多个平台申请借款'，从extra_data中取值
       select nvl(max(b.extra_data),0) into v_Count
       from WFI_FRAUD_METRIX_RESULT a
       join WFI_FRAUD_METRIX_RULE b on a.id=b.fraud_metrix_result_id
       where b.rule_no in(1044388,1053416)
             and a.event_name='Credit' and a.associated_id=p_IdCredit;

       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
              values(p_IdCredit,'HardCheck','*','MultiLoanTypeCountFraudMetrix3M',v_Count,v_Seq);
       v_Seq:=v_Seq + 1;
       --该客户上一单拒绝原因
       select nvl(max(id),0) into v_IdCredit from cs_credit t where id_person=v_IdPerson and t.id!=p_IdCredit and t.status='d';
       if v_IdCredit!=0 then
         insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         select p_IdCredit,'HardCheck','*','PreRejectReason',case when c.event is null then fun_get_reject_reason(a.id) else replace(replace(fun_getreg_value(779,nvl(c.event,-1)),'[',''),']','') end,v_Seq
         from cs_credit a,wfi_final_decision c where a.id=c.id_credit(+) and a.id=v_IdCredit;
       end if;
       v_Seq:=v_Seq + 1;
  
       --客户在申请此合同时前面一张拒绝的合同的申请时间（状态为d）
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            select p_IdCredit,'HardCheck','*','RejectPrevCommitTime',to_char(max(create_time),'yyyy-MM-dd HH24:mi:ss'),v_Seq from cs_credit
             where id_person=v_IdPerson and create_time<=v_CommitTime and (credit_type in('SS','SC','MQ') or (credit_type='QB' and id_sa is not null)) and id!=p_IdCredit and status='d';
       v_Seq:=v_Seq + 1;
      --客户在申请此合同时现行状态的合同数量(状态为a）           
      select count(1) into v_Count from cs_credit where id_person=v_IdPerson and create_time<=v_CommitTime and id!=p_IdCredit and status ='a';
      insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
           values(p_IdCredit,'HardCheck','*','SumDue',v_Count,v_Seq);
      v_Seq:=v_Seq + 1;          

      --IsMysteryIdent 客户申请时身份证是否属于暗访人员白名单(select ident from mv_WHITELIST_MYST_INVE where status='a')
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         select p_IdCredit,'HardCheck','*','IsMysteryIdent',decode(count(1),0,0,1),v_Seq
         from mv_WHITELIST_MYST_INVE t where status='a' and t.ident=v_Ident;
       v_Seq:=v_Seq + 1;
       
     /* --客户在申请此合同时，前6个月内客户手机号码被使用过次数
      insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'HardCheck','*','SameMobileLast6Month',count(1),v_Seq from v_phone_depository
       where contact_type='2' and relationship='client'
       and id_person!=v_IdPerson and status not in('r','t') and commit_time>=sysdate-180 and commit_time<=v_CommitTime;
     */ 

       for phone_depository in (select relationship,contact_value,status,contact_type,id_sellerplace,city from v_phone_depository where id_credit=p_IdCredit)
       loop
          if phone_depository.relationship='client' and phone_depository.contact_type='2' then
              --客户在申请此合同时，客户手机号码存在，在职SA移动电话列表
              select count(1) into v_Count from sys_user_list a where upper(a.role_id)='SA' and a.phone=phone_depository.contact_value;
              if v_Count>0 then
                 insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                   values(p_IdCredit,'HardCheck','*','SAMobilelist','1',v_Seq+1);
                 v_Seq:=v_Seq + 1;
              end if;
             end if;
       end loop;
      --2017/03/29 wangxiaofeng 元素Goods.NewCategory，区分手机类型中的苹果与非苹果，其他类型不变
       for c in(with a as (select cc.id id_credit,cg.id_goods_category,cg.producer,
                 c.name goods_category,t.name goods_type,row_number() over(order by cg.goods_price desc) rn
                from cs_credit cc
                join cs_goods cg on cc.id=cg.id_credit
                join goods_category c on cg.id_goods_category=c.id
                join goods_type t on cg.id_goods_type=t.id
                where cc.id=p_IdCredit)
                select case when id_goods_category=7 and (goods_type like '%苹果%' or producer like '%苹果%'
                   or upper(producer) like '%IPHONE%' or upper(producer) like '%APPLE%') THEN '苹果'
                   else to_char(goods_category) end as new_category
                from a where rn=1
         )loop
           insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
           values(p_IdCredit,'Goods','NewCategory',c.new_category,v_Seq);
           v_Seq:=v_Seq + 1;
           v_NewCategory:=c.new_category;
         end loop;
         
       for goods in (select b.name goods_category,c.name goods_type,producer,brand,goods_price from cs_goods a,goods_category b,goods_type c
              where a.id_goods_category=b.id and a.id_goods_type=c.id and a.id_credit=p_IdCredit)
       loop
           if v_MaxGoodsPrice=-1 or v_MaxGoodsPrice<goods.goods_price then
              v_MaxGoodsPrice:=goods.goods_price;
              v_MaxGoodsType:=goods.goods_type;
           end if;

           if v_MinGoodsPrice=-1 or v_MinGoodsPrice>goods.goods_price then
              v_MinGoodsPrice:=goods.goods_price;
              v_MinGoodsType:=goods.goods_type;
           end if;

           insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,'Goods','Category',goods.goods_category,v_Seq+1);
           insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,'Goods','GoodsType',goods.goods_type,v_Seq+2);
           insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,'Goods','Producer',goods.producer,v_Seq+3);
           v_Seq:=v_Seq + 3;
           v_GoodsVolume:=v_GoodsVolume+1;
       end loop;
       insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,'Goods','MaxPrice',v_MaxGoodsPrice,v_Seq+1);
       insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,'Goods','MaxGoodsType',v_MaxGoodsType,v_Seq+2);
       insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,'Goods','MinGoodsType',v_MinGoodsType,v_Seq+3);
       insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,'Goods','GoodsVolume',v_GoodsVolume,v_Seq+4);   
          v_Seq:=v_Seq + 4;          
       
        --External.zhongzhicheng.ConfirmBlackList 中智城 客户命中中智诚黑名单 2018-05-09 majianfeng  
        insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
          select p_IdCredit,'External','ZhongZhiCheng','ConfirmBlackList',nvl(substr(max(case when qr.confirm_type='overdue' then '4overdue'
              when qr.confirm_type='reject' then '3reject'
              when qr.confirm_type='fraud' then '2fraud'
              else '0other'end ),2,10),'0other') as ConfirmBlackList,v_Seq+1
          from external_intelli_bl_query bq
        left join external_intelli_bl_q_records qr on bq.id=qr.bl_q_id
        where bq.id_credit=p_IdCredit;
       commit;

       p_ReturnCode:='A';
       return;
    exception
       When others Then
         error_info := sqlerrm;
         p_ReturnCode:='Z-'||error_info;
         rollback;
    end;
/

