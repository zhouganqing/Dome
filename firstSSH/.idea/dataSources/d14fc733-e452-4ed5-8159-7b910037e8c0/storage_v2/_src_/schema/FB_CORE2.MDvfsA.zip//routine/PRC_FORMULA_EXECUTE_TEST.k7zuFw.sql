create procedure PRC_FORMULA_EXECUTE_test
(
SelRecord out number
)
is
v_result number;
v_formula varchar2(1000);
begin

       v_formula:='select count(1) from dual where 0<1';
       Execute immediate v_formula into v_result;
       SelRecord:=v_result;
RETURN;
end PRC_FORMULA_EXECUTE_test;
/

