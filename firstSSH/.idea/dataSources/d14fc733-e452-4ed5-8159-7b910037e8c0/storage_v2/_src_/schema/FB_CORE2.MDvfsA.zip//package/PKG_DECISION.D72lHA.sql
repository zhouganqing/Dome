create package PKG_DECISION is

  -- Author  : 100009
  -- Create Date : 2014/10/8 14:36:22
  -- Purpose : Decision System

  -- Author  : wangxiaofeng
  -- Create Date : 2016/10/03
  -- Purpose : 过滤掉不必要的字符
  function filterStr(p_str  varchar2) return varchar2;

  -- Author  : wangxiaofeng
  -- Create Date : 2016-12-21
  -- Purpose : 24小时审单元素值
  function get_24hour_element(p_IdCredit cs_credit.id%type) return number;

end;
/

