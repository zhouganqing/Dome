create procedure PRC_DECISIION_INIT_EMPTY
is
begin

delete from decision_hard_check ;--where remark like'%yzx';
delete from decision_scorecard_formula ;--where remark like'%yzx';
delete from decision_risk_group ;--where remark like'%yzx';
delete from decision_wfi_selection ;--where remark like'%yzx';
delete from decision_branch_list ;--where remark like'%yzx';
delete from decision_formula_lib ;--where remark='备注';
delete from decision_scorecard_params ;
delete from decision_step_group ;--where remark like'%yzx';
delete from DECISION_BRANCH_MAP;
delete from DECISION_STEP_MAP;
delete from DECISION_ELEMENT_TYPE;
delete from DECISION_ELEMENT_DEFINE;
delete from DECISION_ELEMENT_PRESET;
delete from DECISION_ELEMENT_DATA;
delete from DECISION_WORK_FLOW;
commit;

end PRC_DECISIION_INIT_EMPTY;
/

