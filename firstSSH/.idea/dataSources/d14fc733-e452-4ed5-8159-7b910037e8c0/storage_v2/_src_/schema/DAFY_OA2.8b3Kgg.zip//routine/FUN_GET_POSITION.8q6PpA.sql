create function FUN_GET_POSITION(p_OrgId    sys_organize.id%type)
                                            return varchar2 is
  v_Position      sys_organize.position%type;
  v_Count         integer;
begin
   select count(1) into v_Count from sys_organize where id=p_OrgId;
   if v_Count=1 then
      select position into v_Position from sys_organize where id=p_OrgId;
   else
      v_Position:='';
   end if;
   return(v_Position);
end;
/

