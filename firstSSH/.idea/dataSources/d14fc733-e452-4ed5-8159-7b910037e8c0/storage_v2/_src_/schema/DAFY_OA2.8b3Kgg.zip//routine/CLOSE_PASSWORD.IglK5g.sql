create function close_password(passwordStr in varchar2) return varchar2 is
/**
功能：对密码进行加密 返回值：为加密后的值
作者：王聘群
日期：2012-06-04
**/
begin
declare v_password varchar2(100);
begin
select translate(passwordStr,'qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM1234567890!@#$%^&*'
,'M!qNw@eBr#tVy$uCi%oXp^aZs*mWn1Qb2AvE3ScRxD4FzTlG5YkH6jUhJ7gI8KOP90') into v_password from dual;
return v_password;
end;
end close_password;


/

