create function FUN_GET_USERNAME(p_UserId    sys_user_list.id%type)
                                            return varchar2 is
  v_UserName      sys_user_list.user_name%type;
  v_Count         integer;
begin
   select count(1) into v_Count from sys_user_list where id=p_UserId;
   if v_Count=1 then
      select user_name into v_UserName from sys_user_list where id=p_UserId;
   else
      v_UserName:='';
   end if;
   return(v_UserName);
end;
/

