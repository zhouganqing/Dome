create PROCEDURE INSERT_USER_ORG(usrid  IN SYS_USER_ORGANIZE.USER_ID%TYPE,
                                            orgid IN SYS_USER_ORGANIZE.ORG_ID%TYPE) AS
BEGIN
        INSERT INTO SYS_USER_ORGANIZE VALUES(usrid,orgid,100000,SYSDATE,sysdate);
END;
/

