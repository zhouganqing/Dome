create PROCEDURE UPDATE_USER_ORG(usrid  IN SYS_USER_ORGANIZE.USER_ID%TYPE,
                                            orgid IN SYS_USER_ORGANIZE.ORG_ID%TYPE) AS
BEGIN
       UPDATE SYS_USER_ORGANIZE A SET A.org_id=orgid,update_time=sysdate WHERE A.USER_ID=usrid;
END;
/

