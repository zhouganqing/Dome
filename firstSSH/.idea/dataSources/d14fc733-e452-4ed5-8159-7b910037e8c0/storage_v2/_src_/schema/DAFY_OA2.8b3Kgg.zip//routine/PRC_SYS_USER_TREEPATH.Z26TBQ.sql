create procedure prc_sys_user_treepath is

  /*创建日期：  2016/11/04   作者： lishan
    功能描述：  生成用户树
  */
  V_ORDER    NUMBER;
  ERROR_INFO VARCHAR2(1000);
  V_JOBNAME  VARCHAR2(50);

begin
  V_JOBNAME := 'PRC_SYS_USER_TREEPATH';
  V_ORDER   := 1;

  --start write log
  INSERT INTO job_detail_log
  VALUES
    (V_JOBNAME, V_ORDER, 'PRC_SYS_USER_TREEPATH', SYSDATE, 'START');
  COMMIT;

  --execute immediate 'truncate table sys_user_treepath';

  delete sys_user_treepath;

  insert into sys_user_treepath
    WITH tab1 AS
     (SELECT t.ID,
             t.parent_id,
             t.USER_NAME,
             t.ROLE_ID,
             t.PHONE,
             t.EMAIL,
             t.IDENT,
             t.STATUS
        FROM (SELECT a_2.pid,
                     a_2.user_id,
                     a_2.parent_id,
                     a_2.parent_role_id,
                     a_2.id,
                     a_2.user_name,
                     a_2.status,
                     a_2.role_id,
                     a_2.ident,
                     a_2.password,
                     a_2.phone,
                     a_2.email,
                     NULL,
                     NULL,
                     a_2.gender,
                     a_2.parent_name
                FROM (SELECT a_1.*,
                             ROW_NUMBER() OVER(PARTITION BY a_1.id ORDER BY a_1.parent_id) AS group_idx
                        FROM (SELECT *
                                FROM (SELECT c.pid,
                                             d.user_id,
                                             a.id AS parent_id,
                                             a.USER_NAME AS parent_name,
                                             a.role_id AS parent_role_id,
                                             sa.*,
                                             ROW_NUMBER() OVER(PARTITION BY d.user_id ORDER BY d.user_id) AS id_order
                                        FROM SYS_USER_ORGANIZE d,
                                             SYS_ORGANIZE      c,
                                             SYS_USER_ORGANIZE b,
                                             SYS_USER_LIST     a,
                                             SYS_USER_LIST     sa
                                       WHERE d.org_id = c.id
                                         AND b.org_id = c.pid
                                         AND b.user_id = a.id
                                         AND d.user_id = sa.id) ud
                               WHERE ud.id_order = 1
                              UNION ALL
                              SELECT NULL AS pid,
                                     NULL AS user_id,
                                     NULL AS parent_id,
                                     NULL AS parent_name,
                                     NULL AS parent_role_id,
                                     sb.*,
                                     0    AS id_order
                                FROM SYS_USER_LIST sb) a_1) a_2
               WHERE a_2.group_idx = 1) t),
    tab2 AS
     (SELECT a.id,
             a.parent_id pd1,
             b.parent_id pd2,
             c.parent_id pd3,
             d.parent_id pd4,
             e.parent_id pd5,
             f.parent_id pd6,
             g.parent_id pd7,
             h.parent_id pd8,
             i.parent_id pd9,
             j.parent_id pd10,
             k.parent_id pd11,
             l.parent_id pd12,
             m.parent_id pd13,
             n.parent_id pd14
        FROM tab1 a
        LEFT JOIN tab1 b
          ON b.id = a.parent_id
        LEFT JOIN tab1 c
          ON c.id = b.parent_id
        LEFT JOIN tab1 d
          ON d.id = c.parent_id
        LEFT JOIN tab1 e
          ON e.id = d.parent_id
        LEFT JOIN tab1 f
          ON f.id = e.parent_id
        LEFT JOIN tab1 g
          ON g.id = f.parent_id
        LEFT JOIN tab1 h
          ON h.id = g.parent_id
        LEFT JOIN tab1 i
          ON i.id = h.parent_id
        LEFT JOIN tab1 j
          ON j.id = i.parent_id
        LEFT JOIN tab1 k
          ON k.id = j.parent_id
        LEFT JOIN tab1 l
          ON l.id = k.parent_id
        LEFT JOIN tab1 m
          ON m.id = l.parent_id
        LEFT JOIN tab1 n
          ON n.id = m.parent_id),
    tab3 AS
     (SELECT id user_id, id PARENT_USER_ID, 0 patl
        FROM tab2
      UNION ALL
      SELECT id, pd1, 1 patl
        FROM tab2
      UNION ALL
      SELECT id, pd2, 2 patl
        FROM tab2
      UNION ALL
      SELECT id, pd3, 3 patl
        FROM tab2
      UNION ALL
      SELECT id, pd4, 4 patl
        FROM tab2
      UNION ALL
      SELECT id, pd5, 5 patl
        FROM tab2
      UNION ALL
      SELECT id, pd6, 6 patl
        FROM tab2
      UNION ALL
      SELECT id, pd7, 7 patl
        FROM tab2
      UNION ALL
      SELECT id, pd8, 8 patl
        FROM tab2
      UNION ALL
      SELECT id, pd9, 9 patl
        FROM tab2
      UNION ALL
      SELECT id, pd10, 10 patl
        FROM tab2
      UNION ALL
      SELECT id, pd11, 11 patl
        FROM tab2
      UNION ALL
      SELECT id, pd12, 12 patl
        FROM tab2
      UNION ALL
      SELECT id, pd13, 13 patl
        FROM tab2
      UNION ALL
      SELECT id, pd14, 14 patl
        FROM tab2),
    tab4 AS
     (SELECT user_id,
             PARENT_USER_ID,
             patl,
             ROW_NUMBER() OVER(PARTITION BY user_id, PARENT_USER_ID ORDER BY patl) ptid
        FROM tab3 /*where user_id =100017*/
      ),
    tab5 AS
     (SELECT user_id,
             PARENT_USER_ID,
             ROW_NUMBER() OVER(PARTITION BY user_id ORDER BY patl) - 1 PATH_LENGTH
        FROM tab4
       WHERE ptid = 1
         AND PARENT_USER_ID IS NOT NULL
         AND user_id IS NOT NULL)
    SELECT '' ID,
           user_id,
           PARENT_USER_ID parent_userid,
           tl2.ROLE_ID,
           PATH_LENGTH,
           tl2.USER_NAME,
           tl3.USER_NAME parent_name,
           tl3.ROLE_ID PARENT_ROLE_ID,
           tl2.PHONE,
           tl2.EMAIL,
           tl2.IDENT,
           tl3.PHONE PARENT_PHONE,
           tl3.EMAIL PARENT_EMAIL,
           tl3.IDENT PARENT_IDENT,
           tl2.STATUS,
           tl3.STATUS PARENT_STATUS
      FROM tab5 tl1
      LEFT JOIN tab1 tl2
        ON tl1.user_id = tl2.id
      LEFT JOIN tab1 tl3
        ON tl1.PARENT_USER_ID = tl3.id;
  commit;
  -- write log end
  V_ORDER := 99;
  INSERT INTO job_detail_log
  VALUES
    (V_JOBNAME, V_ORDER, 'PRC_SYS_USER_TREEPATH', SYSDATE, 'FINISH');

  COMMIT;
Exception
  When others Then
    ERROR_INFO := SQLERRM;
    INSERT INTO job_detail_log
    VALUES
      (V_JOBNAME, 100, 'JOB FAILED', SYSDATE, ERROR_INFO);

    COMMIT;
end;
/

