create PROCEDURE UPDATE_ORG_DEPT(userid  IN NUMBER,
                                            dept IN SYS_ORGANIZE.DEPARTMENT%TYPE,
                                            dept2 IN SYS_ORGANIZE.DEPARTMENT2%TYPE) AS
BEGIN
        UPDATE SYS_ORGANIZE A SET A.department=dept,A.department2=dept2,update_time=sysdate WHERE A.ID=userid;
END;
/

