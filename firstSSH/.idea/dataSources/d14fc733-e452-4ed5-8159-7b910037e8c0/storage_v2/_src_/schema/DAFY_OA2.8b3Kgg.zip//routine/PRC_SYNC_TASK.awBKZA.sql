create PROCEDURE PRC_SYNC_TASK(p_ReturnCode      out varchar2) IS
    -- Author  : Luchangjiang
    -- Create Date : 2015-6-18
    -- Purpose : 将功能菜单等从测试 2 库同步过来;
    error_info            varchar2(1000);
BEGIN
   merge into sys_subsys_list a using sys_subsys_list@dbl_dev_db c ON (c.subsys_name=a.subsys_name)
         when matched then
              update set a.subsys_desc=c.subsys_desc,a.seq=c.seq,a.update_user=c.update_user,a.update_time=c.update_time,a.update_ip=c.update_ip
         when not matched then
              insert(a.subsys_name,a.subsys_desc,a.status,a.update_user,a.update_time,a.update_ip,a.seq)
              values(c.subsys_name,c.subsys_desc,c.status,c.update_user,c.update_time,c.update_ip,c.seq);

   merge into sys_task_group a using sys_task_group@dbl_dev_db c ON (c.group_id=a.group_id)
         when matched then
              update set a.group_desc=c.group_desc,a.seq=c.seq,a.icon=c.icon,a.data=c.data,a.update_user=c.update_user,a.update_time=c.update_time
         when not matched then
              insert(a.group_id,a.group_desc,a.status,a.update_user,a.update_time,a.seq,a.subsys_name,a.data,a.icon)
              values(c.group_id,c.group_desc,c.status,c.update_user,c.update_time,c.seq,c.subsys_name,c.data,c.icon);

   merge into sys_task_list a using sys_task_list@dbl_dev_db c ON (c.task_code=a.task_code)
         when matched then
              update set a.web_url=c.web_url,a.remark=c.remark,a.seq=c.seq,a.icon=c.icon,a.data=c.data,a.update_user=c.update_user,a.update_time=c.update_time
         when not matched then
              insert(a.task_code,a.task_name,a.status,a.group_id,a.form_name,a.url,a.web_url,a.remark,a.update_user,a.update_time,a.seq,a.subsys_name,a.data,a.icon)
              values(c.task_code,c.task_name,c.status,c.group_id,c.form_name,c.url,c.web_url,c.remark,c.update_user,c.update_time,c.seq,c.subsys_name,c.data,c.icon);

   merge into sys_task_buttons a using sys_task_buttons@dbl_dev_db c ON (c.button_id=a.button_id)
         when matched then
              update set a.form_id=c.form_id,a.parent_id=c.parent_id,a.btn_code=c.btn_code,a.btn_title=c.btn_title,a.icon=c.icon,a.btn_type=c.btn_type,
                    a.js_event=c.js_event,a.action_event=c.action_event,a.split=c.split,a.remark=c.remark,a.status=c.status,a.seq=c.seq,
                    a.create_user=c.create_user,a.create_time=c.create_time,a.update_user=c.update_user,a.update_time=c.update_time,a.update_ip=c.update_ip
         when not matched then
              insert(a.button_id,a.form_id,a.parent_id,a.btn_code,a.btn_title,a.icon,a.btn_type,a.js_event,a.action_event,a.split,a.remark,a.status,a.seq,a.create_user,a.create_time,a.update_user,a.update_time,a.update_ip)
              values(c.button_id,c.form_id,c.parent_id,c.btn_code,c.btn_title,c.icon,c.btn_type,c.js_event,c.action_event,c.split,c.remark,c.status,c.seq,c.create_user,c.create_time,c.update_user,c.update_time,c.update_ip);

   commit;
   p_ReturnCode:='A';
   return;
Exception
   When others Then
     error_info := sqlerrm;
     rollback;
     p_ReturnCode:='Z-'||error_info;
END;
/

