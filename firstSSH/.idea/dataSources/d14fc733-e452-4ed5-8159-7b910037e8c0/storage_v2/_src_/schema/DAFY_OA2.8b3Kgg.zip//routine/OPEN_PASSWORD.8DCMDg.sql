create function open_password(passwordStr in varchar2) return varchar2 is
/**
功能：对加密后密码进行解密 返回值：为解密后的值
作者：王聘群
日期：2012-06-04
**/
begin
declare v_password varchar2(100);
begin
select translate(passwordStr,'M!qNw@eBr#tVy$uCi%oXp^aZs*mWn1Qb2AvE3ScRxD4FzTlG5YkH6jUhJ7gI8KOP90'
,'qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM1234567890!@#$%^&*') into v_password from dual;
return v_password;
end;
end open_password;


/

