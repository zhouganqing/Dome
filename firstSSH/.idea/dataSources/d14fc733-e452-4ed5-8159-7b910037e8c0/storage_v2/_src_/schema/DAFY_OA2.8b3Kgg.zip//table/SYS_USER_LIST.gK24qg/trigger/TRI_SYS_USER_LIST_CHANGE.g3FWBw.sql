create trigger TRI_SYS_USER_LIST_CHANGE
    after insert or update or delete
    on SYS_USER_LIST
    for each row
declare
begin
  if inserting then
     insert into sys_user_list_log(id,user_name,status,role_id,ident,password,phone,email,province,city,remark,ease_mob_name,update_user,update_time,update_ip,action,create_time)
          values(:new.id,:new.user_name,:new.status,:new.role_id,:new.ident,:new.password,:new.phone,:new.email,:new.province,:new.city,:new.remark,:new.ease_mob_name,
          :new.update_user,:new.update_time,SYS_CONTEXT('USERENV','IP_ADDRESS'),'insert',sysdate);
  elsif updating then
     insert into sys_user_list_log(id,user_name,status,role_id,ident,password,phone,email,province,city,remark,ease_mob_name,update_user,update_time,update_ip,action,create_time)
          values(:new.id,:new.user_name,:new.status,:new.role_id,:new.ident,:new.password,:new.phone,:new.email,:new.province,:new.city,:new.remark,:new.ease_mob_name,
          :new.update_user,:new.update_time,SYS_CONTEXT('USERENV','IP_ADDRESS'),'update',sysdate);
  elsif deleting then
     insert into sys_user_list_log(id,user_name,status,role_id,ident,password,phone,email,province,city,remark,ease_mob_name,update_user,update_time,update_ip,action,create_time)
          values(:old.id,:old.user_name,:old.status,:old.role_id,:old.ident,:old.password,:old.phone,:old.email,:old.province,:old.city,:old.remark,:old.ease_mob_name,
          :old.update_user,sysdate,SYS_CONTEXT('USERENV','IP_ADDRESS'),'delete',sysdate);
  end if;
end;
/

