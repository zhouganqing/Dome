create procedure Compile_Invalid_Procedure as
   strSql   varchar2(500);
   v_Count  integer;
begin
  For x in (select object_name from user_objects
     where status='INVALID' AND object_type='FUNCTION') loop
     strSql:='Alter function '||x.object_name ||' compile';
     begin
        Execute immediate strsql;
        exception
           when others then dbms_output.put_line(sqlerrm);
     end;
  end loop;
  For x in (select object_name from user_objects
     where status='INVALID' AND object_type='PROCEDURE') loop
     strSql:='Alter procedure '||x.object_name ||' compile';
     begin
        Execute immediate strsql;
        exception
           when others then dbms_output.put_line(sqlerrm);
     end;
  end loop;
  For x in (select object_name from user_objects
     where status='INVALID' AND object_type='TRIGGER') loop
     select count(1) into v_Count from user_triggers where trigger_name=x.object_name
        and status='ENABLED';
     if v_Count=1 then
         strSql:='Alter trigger '||x.object_name ||' compile';
         begin
            Execute immediate strsql;
            exception
               when others then dbms_output.put_line(sqlerrm);
         end;
     end if;
  end loop;
end Compile_Invalid_Procedure;


/

