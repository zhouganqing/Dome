create FUNCTION         lbac_label_to_char wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
cb d6
ivG6yXGA95rqxVcl5+i/N/wF2bIwg3nwLZ5qyo7p2viUIMMWpEXJI+wXxXVJVM3FG4575wIl
tbChhVCov9poau3fA6HRfKAm/2M9KTGX/kyL6nOpjrgv0Ox6qQulqy4xpc8Rgy+AWQo63RFI
BGRQt5WKtrgzh/RaPsadPFUC6K8IwmHqboAYSKo+Polcif1Mb/JXWmN7NWi/sCyN4H/q
/

