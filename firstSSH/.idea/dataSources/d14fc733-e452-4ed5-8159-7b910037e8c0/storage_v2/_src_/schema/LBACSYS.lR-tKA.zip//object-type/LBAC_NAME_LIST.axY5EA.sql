create TYPE         lbac_name_list
IS VARRAY(32) OF VARCHAR2(30);
/

