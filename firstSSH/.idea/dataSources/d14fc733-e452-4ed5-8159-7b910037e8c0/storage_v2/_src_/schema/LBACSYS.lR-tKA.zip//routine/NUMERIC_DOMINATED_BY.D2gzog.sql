create FUNCTION         numeric_dominated_by wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
128 f7
GdkESTH+iWP+3wKK5JULexLXNO0wg41KfyisfC8CkPjVSEZGBFIBUbiPbENa8tpXKsV0dHDg
9aWaBTnTMusTGe1dELtcp5mEYmrkdUAFMFJzMqvB6xB9VTqIvc4Iw9HMY2d0fv30ezqWvqpJ
C2uzVNcZf1SMOfxGyFS2WxRcUEP/qw1iBUBXeFR7Ql+nkpE4lXDLhR6plKfJ7oA97sSdus/R
AK22ZuckHSqUuQPKBTSmEsk1Gw==
/

