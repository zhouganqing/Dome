create FUNCTION         to_lbac_label wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
226 117
5ONszemN3/bSA7ydBeEMgUD1068wg5XIJJkVZ3SVkLtekdiPXaN24nkjAOPeviSs67MYuq+V
u9DBXNjWb5BH0+E67f7xg8cp9dm47UZSfa44igdOFo8LAUwMRXo5pxI217jI6H4aMUhvBPFE
CUv/ESudf9zl+C9YSn5QimlrN572Kfr7ElENfH00OA7mp6jM5rrMDiV2QzKyMVYNEy+4ssCb
P0visoJBfnQMIwAyPvyYgp0xrpObU+ORCLVSQSDsZVKUT5xttE49sjeFx5Y=
/

