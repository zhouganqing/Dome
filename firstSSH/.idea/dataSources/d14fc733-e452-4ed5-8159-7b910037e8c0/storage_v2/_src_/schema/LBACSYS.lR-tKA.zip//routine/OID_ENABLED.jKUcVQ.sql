create FUNCTION         oid_enabled wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
94 ba
LAPuamjkFAtXdu5+XQzVUS8GIH0wg8eZgcfLCNL+XoVyWfSu1wxZl6Eu7p7Asr2ym16l0plS
Mr+yCaV0i8DAMv7ShglpaaX1XqVSwPVKv5/1M7g9Tv719L+Bx/WbUjLMaecIuETV++FN+0A8
yrwKrkvV5VP7omhyRBFuKh/jYGWF7PumK6AUcQ==
/

