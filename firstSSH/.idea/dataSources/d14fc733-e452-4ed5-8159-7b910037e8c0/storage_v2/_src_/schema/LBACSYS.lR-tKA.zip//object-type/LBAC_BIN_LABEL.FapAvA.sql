create TYPE         lbac_bin_label                                       
AS OPAQUE VARYING(*)
USING LIBRARY LBACSYS.lbac$type_libt
(
  STATIC FUNCTION new_lbac_bin_label(policy_id IN PLS_INTEGER,
                                     bin_size IN PLS_INTEGER)
  RETURN LBAC_BIN_LABEL,
  PRAGMA RESTRICT_REFERENCES(new_lbac_bin_label, RNDS, WNDS, RNPS, WNPS),
  MEMBER FUNCTION eq_sql(SELF IN lbac_bin_label,
                         comp_label IN lbac_bin_label)
  RETURN PLS_INTEGER DETERMINISTIC,
  PRAGMA RESTRICT_REFERENCES(eq_sql, RNDS, WNDS, RNPS, WNPS),
  MEMBER FUNCTION eq(SELF IN lbac_bin_label,
                     comp_label IN lbac_bin_label)
  RETURN BOOLEAN DETERMINISTIC,
  PRAGMA RESTRICT_REFERENCES(eq, RNDS, WNDS, RNPS, WNPS),
  MEMBER FUNCTION bin_size(SELF IN lbac_bin_label)
  RETURN PLS_INTEGER,
  PRAGMA RESTRICT_REFERENCES(bin_size, RNDS, WNDS, RNPS, WNPS),
  MEMBER FUNCTION set_raw(SELF      IN OUT NOCOPY lbac_bin_label,
                          position  IN PLS_INTEGER,
                          byte_len  IN PLS_INTEGER,
                          raw_label IN RAW)
  RETURN PLS_INTEGER,
  PRAGMA RESTRICT_REFERENCES(set_raw, RNDS, WNDS, RNPS, WNPS),
  MEMBER FUNCTION set_int(SELF IN OUT NOCOPY lbac_bin_label,
                          position  IN PLS_INTEGER,
                          byte_len  IN PLS_INTEGER,
                          int_label IN PLS_INTEGER)
  RETURN PLS_INTEGER,
  PRAGMA RESTRICT_REFERENCES(set_int, RNDS, WNDS, RNPS, WNPS),
  MEMBER FUNCTION to_raw(SELF     IN lbac_bin_label,
                         position IN PLS_INTEGER,
                         byte_len IN PLS_INTEGER)
  RETURN RAW,
  PRAGMA RESTRICT_REFERENCES(to_raw, RNDS, WNDS, RNPS, WNPS),
  MEMBER FUNCTION to_int(SELF     IN lbac_bin_label,
                         position IN PLS_INTEGER,
                         byte_len IN PLS_INTEGER)
  RETURN PLS_INTEGER,
  PRAGMA RESTRICT_REFERENCES(to_int, RNDS, WNDS, RNPS, WNPS),
  MEMBER FUNCTION policy_id (SELF   IN lbac_bin_label)
  RETURN PLS_INTEGER,
  PRAGMA RESTRICT_REFERENCES(policy_id, RNDS, WNDS, RNPS, WNPS)
);
/

