create FUNCTION         numeric_dominates wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
117 eb
nvwofbAghfCvOEnQtFkwG0JDqzQwg41KAJnWZ3RA2ppkhU3KY58ymyGD3Yju0XgsY3tXEWss
tZ0YJSU719Ob3fg0Jnof5mJq0nb4Bbi9VTJ26E6MnYCeP4i39iE+Lx34YIwu+eOkJC1Uk44g
QhusKqPKsCE8221KxbhCpeAzAQUvwazRoxK3PbbWbsjEiy6Jydnw1O54JNhu2ZMTJgFyLA5j
ZjRDMblEfywAzA==
/

