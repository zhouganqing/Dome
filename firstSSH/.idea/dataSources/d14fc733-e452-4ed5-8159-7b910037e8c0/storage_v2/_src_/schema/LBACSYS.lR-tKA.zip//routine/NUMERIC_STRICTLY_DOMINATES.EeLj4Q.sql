create FUNCTION         numeric_strictly_dominates wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
145 ff
c+OxhlP56r9qrYdw9rhyBwCmf5Qwg5BKrpmsZy+V2ruwtIysop+BXU+zOTzznxcokKcWKOar
GqSSMzsWovXlrUd8KBm77SUJ/7TIdhwQErv/SG7kQeKuv76BVbjsg38vm7DM3jnFp1rxfpA3
SvkIu5r5aRFwCvrVdJQR9GDjdMUaiF9jISYD2GFAKovYSuIRJxqJrzYMjRGoQPEoZ/ZYlIhJ
TiiX3bC8uvXFeiTzToFM3U5Vv/LCQvtXR6Fl
/

