create FUNCTION         ols_label_dominates wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
181 117
N011QjlbAYH5L4YA5QaEtG0mg9gwg/BKLZ7WfC9A2sE+Zasv3ph7lTAnyofy05ncrwkHrDvW
EKonPW8fr7q5uQe1htnFjtwnGhB4zuK+DZCd/nLGCkLEhGd9vL4RbOnN95xnbCXVeFGPi3a5
zdVBqaO5XE/zHeJlV8nLwHzDo/Fn0VJdl185p/iXJhY9Y6K53fnh2PJ8Cc69/dhdtOj38lNL
DfBuMxPNuDORX8zqptxN6aWO0CwWmR6lVwJ1SuJ/Okg7ilmBqkPOpfuYxurH
/

