create FUNCTION         numeric_label_to_lbac wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
b7 b6
ewWAX2C9LgwcznBrvB3fAyd6fzMwg8eZgcfLCNL+XoXV1y5il1lKcqFZ8tf0lvrQcqHyWStQ
jwnd4eTmEEzWepCGEHaQcRCOenNn4dziNexxNeKoazU/niLcSrj6cNFJ6r+uJA6tBPEjP+Lu
COfiORgt7Dxx4j/RTSuVB87WPbqCpqYNwHyv
/

