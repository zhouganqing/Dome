create PROCEDURE         configure_ols wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
7
65 9e
RbU/XzTOCB1MYZ7sOGcIrxsQymUwg5nnm7+fMr2ywFxa/3IM2VmWYvLwcnI+iwlppXQrpVLS
xygy9b9cuDmbc3YQTJSJ5cDACZA4xXMQrI2pZSJB3DVKNfeeItxK/6/3ryPKo5UqRz2WFBwW
lODXpqZby6R4
/

