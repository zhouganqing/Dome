create FUNCTION         numeric_merge_label wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
148 df
pL5+OYNePI+GmzdmmjCwGhLY8W4wg8eZgcfLCNL+XoXV1y5il1lKW/EpJgit9KEmratxntsd
LIBJ6iyERK4kRJ1pD0mxyqTxKv33JjGxKoVVKhnXJIWxfzaRonULyAMHC8j3G+rI9loRL0dZ
RHJw0Unqv64kDjFp9HDGzlAvLADj+3B4EWc0ax0y98sY7uw8ceI/0cqGcdZ6kIb3oJOCpqak
2mDW
/

