create FUNCTION         lbac_label_to_numeric wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
9f ba
NbicpCUH92sRewr8QUZBWQQrI28wg8eZgcfLCNL+XoWh8llKcqFZ8tf0lvrQctXXLmKXWStQ
jwnd4c92kHEQjnpzjs9udpCGr3ou4sqxyFDKJESdaQ9JscpEcnDRSeq/riQOP0025juH46rP
44yYOaKMKpwKT5nxfnppbxHj9siwAyodptrePms=
/

