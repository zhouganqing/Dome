create view DRV$DELETE as
select "DEL_IDX_ID","DEL_IXP_ID","DEL_DOCID" from dr$delete
/

