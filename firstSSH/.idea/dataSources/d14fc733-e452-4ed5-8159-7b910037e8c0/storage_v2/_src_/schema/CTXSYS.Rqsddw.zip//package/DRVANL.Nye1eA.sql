create package drvanl authid current_user as

PROCEDURE ADD_DICTIONARY(name     in VARCHAR2,
                         language in VARCHAR2,
                         dictionary  in CLOB,
                         preference_implicit_commit in boolean);

PROCEDURE DROP_DICTIONARY(name in VARCHAR2,
                          preference_implicit_commit in boolean);

PROCEDURE COPY_USER_ANL_DICT(p_idx_id in NUMBER,
                             lv_pref  in dr_def.pref_rec);

PROCEDURE REM_USER_ANL_DICT(p_idxid in NUMBER);

end drvanl;
/

