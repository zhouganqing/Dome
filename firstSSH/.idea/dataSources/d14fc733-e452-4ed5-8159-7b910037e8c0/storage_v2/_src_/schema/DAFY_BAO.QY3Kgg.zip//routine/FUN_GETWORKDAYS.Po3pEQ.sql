create function fun_getworkdays(originalTime date) return date is
  Result date;
begin
  declare
    n number := 0;
    c number := 1;
  begin
    while c > 0 loop
       n := n + 1;
      select count(*)
        into c
        from p2p_holiday a
       where a.holiday_date = trunc(originalTime +n, 'd');
    end loop;
    Result := originalTime + n ;
  end;
  return(Result);
end fun_getworkdays;
/

