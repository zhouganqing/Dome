create trigger TRG_P2P_RECHARGE_RECORD
    after insert or update or delete
    on P2P_RECHARGE_RECORD
    for each row
DECLARE
   /*2015-7-21   谢正波
   充值日志*/
   v_OperationType      varchar2(20);
   v_InverstorId        number(10);
BEGIN
   IF inserting THEN
      v_OperationType :='A';
      v_InverstorId:=:new.investor_id;
   ELSIF updating THEN
      v_OperationType :='U';
      v_InverstorId:=:old.investor_id;
   elsif deleting then
      v_OperationType :='D';
      v_InverstorId:=:old.investor_id;
   END IF;
   insert into P2P_CHECK_LOG(id,investor_id,property_name,property_field,old_VALUE,new_VALUE,update_type,update_time,update_ip,check_flag)
        values(SEQ_P2P_CHECK_LOG.NEXTVAL,v_InverstorId,'p2p_recharge_record','RECHARGE_AMOUT',:old.RECHARGE_AMOUT,:new.RECHARGE_AMOUT,v_OperationType,sysdate,'',0);
END;
/

