create package wwv_flow_authentication_dev as
--------------------------------------------------------------------------------
--
--  Copyright (c) Oracle Corporation 1999 - 2012. All Rights Reserved.
--
--    NAME
--      wwv_flow_authentication_dev.sql
--
--    DESCRIPTION
--      Builder-specific internal authentication-related routines
--
--    RUNTIME DEPLOYMENT: NO
--    PUBLIC:             NO
--
--    MODIFIED   (MM/DD/YYYY)
--    cneumuel    05/03/2012 - Created
--                           - moved get_login_help_for_app, get_translated_authent_name, activate_in_app from wwv_flow_authentication to this package
--
--------------------------------------------------------------------------------

--==============================================================================
-- helper routine for app 4155 (scheme authentication login)
--==============================================================================
procedure get_login_help_for_app (
    p_app_id                   in  number,
    p_plugin_help_text         out varchar2,
    p_authentication_help_text out varchar2,
    p_workspace_name           out varchar2,
    p_needs_password_yn        out varchar2 );
--
--==============================================================================
-- helper function to get the translated authentication name
--==============================================================================
function get_translated_authent_name (
    p_authentication_name in varchar2 )
    return varchar2;
--
--==============================================================================
-- helper procedure to activate/create an authentication within the application,
-- also used in wwv_flow_data_quick_flow, etc.
--
-- valid values for p_authentication_name:
--   (a) any authentication that already exists within the app
--   or (b) 'Application Express', 'SSO', 'DATABASE', 'DBACCOUNT'
-- if (b) then the native authentication will be created, if it does not yet
-- exist.
--==============================================================================
procedure activate_in_app (
    p_app_id              in number,
    p_authentication_name in varchar2 );

end wwv_flow_authentication_dev;
/

