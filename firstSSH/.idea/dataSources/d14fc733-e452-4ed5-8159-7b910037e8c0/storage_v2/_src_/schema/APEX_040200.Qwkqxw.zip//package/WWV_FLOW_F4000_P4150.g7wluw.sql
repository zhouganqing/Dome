create package wwv_flow_f4000_p4150
as
--------------------------------------------------------------------------------
--
--  Copyright (c) Oracle Corporation 2009. All Rights Reserved.
--
--    NAME
--      wwv_flow_f4000_p4150.sql
--
--    DESCRIPTION
--      This package is resonsible for the tree handling on 4000:4150.
--
--    RUNTIME DEPLOYMENT: YES
--
--    MODIFIED   (MM/DD/YYYY)
--    pawolf      11/02/2009 - Created
--    pawolf      03/19/2010 - Added view modes "Name" and "Label"
--
--------------------------------------------------------------------------------
--
--==============================================================================
-- Procedure which reads the meta data for the tree and initializes other
-- global variables.
-- Note: This procedure has to be called before calling any other procedure in
--       this package!
--==============================================================================
procedure init (
    p_application_id in number,
    p_page_id        in number );
--
--==============================================================================
-- Procedure which generates the necessary HTML code for the rendering tree.
-- Note: init has to be called before calling this procedure
--==============================================================================
procedure show_rendering_tree (
    p_show_labels in boolean default false );
--
--==============================================================================
-- Procedure which generates the necessary HTML code for the processing tree.
-- Note: init has to be called before calling this procedure
--==============================================================================
procedure show_processing_tree;
--
--==============================================================================
-- Procedure which generates the necessary HTML code for the shared component tree.
-- Note: init has to be called before calling this procedure
--==============================================================================
procedure show_shared_tree;
--
--==============================================================================
-- Central dispatch procedure for refreshing parts of the tree. Called from the
-- on-demand process on page 4150.
--==============================================================================
procedure get_tree_data;
--
--==============================================================================
-- Central dispatch procedure for the tree operations. Called from the
-- on-demand process on page 4150.
--==============================================================================
procedure execute_tree_operation;
--
--
end wwv_flow_f4000_p4150;
/

