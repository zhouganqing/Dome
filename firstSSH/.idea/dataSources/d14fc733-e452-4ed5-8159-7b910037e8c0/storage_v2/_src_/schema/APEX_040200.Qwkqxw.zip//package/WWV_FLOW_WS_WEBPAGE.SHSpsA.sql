create package wwv_flow_ws_webpage
as

g_tree                  wwv_flow_plugin_util.t_column_value_list; -- for use with jstrees
g_running_data_section  boolean := false;

type t_datagrid_section is record (
    section_id           number,
    show_edit_row        varchar2(1),
    max_row_count        number,
    last_page_id         number);
g_data_grid_section t_datagrid_section;

g_data_section_html     varchar2(32767) := null; -- for data section

function clean_out_editor_tag (
    p_string        in clob)
    return clob;

function validate_string (
    p_str              in clob,
    p_ws_app_id        in number,
    p_page_id          in number,
    p_section_id       in number) return varchar2;

procedure show_tag_clouds (
    p_ws_app_id             in number,
    p_session_id            in number,
    p_alpha                 in number default 1,
    p_max                   in number default 100,
    p_limit                 in number default 10000,
    p_link_to_page          in varchar2 default '904',
    p_tag_item_filter       in varchar2 default 'IRC_TAG',
    p_clear_cache           in varchar2 default '904,RIR') ;

procedure show (
    p_ws_app_id         in number,
    p_webpage_id        in number,
    p_request           in varchar2 default null,
    p_presentation_mode in varchar2 default 'N');

function get_login_url(
	p_ws_app_id  in number,
	p_ws_page_id in number default null )
return varchar2;

function get_url (
    p_ws_app_id       in number,
    p_session         in number,
    p_alias           in varchar2,
    p_url_postfix     in varchar2 default null )
    return varchar2;

function get_anchor (
    p_ws_app_id       in number,
    p_session         in number,
    p_alias           in varchar2,
    p_url_postfix     in varchar2 default null,
    p_text            in varchar2,
    p_escape_sc       in varchar2 default 'Y')
    return varchar2;

end wwv_flow_ws_webpage;
/

