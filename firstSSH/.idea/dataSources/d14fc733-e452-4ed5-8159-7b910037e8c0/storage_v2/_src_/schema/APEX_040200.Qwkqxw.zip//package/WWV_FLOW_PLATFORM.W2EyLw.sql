create package wwv_flow_platform as
--------------------------------------------------------------------------------
--
--  Copyright (c) Oracle Corporation 1999 - 2013. All Rights Reserved.
--
--    NAME
--      wwv_flow_platform.sql
--
--    DESCRIPTION
--      Low-level interface to instance parameters.
--
--    RUNTIME DEPLOYMENT: NO
--    PUBLIC:             NO
--
--    MODIFIED   (MM/DD/YYYY)
--      mhichwa  03/04/2001 - Created
--      mhichwa  03/26/2001 - changes pres to pref
--      mhichwa  04/18/2001 - Changed platform pref to platform prefs
--      jkallman 05/17/2005 - Added set_preference
--      nagkrish 11/12/2007 - If workspace creation via email notification is re-enabled, corresponding system message is deleted.
--      jkallman 02/23/2011 - Added support for application activity logging
--      pawolf   02/23/2011 - Fixed a bug in application activity logging and changed the order execution
--      jkallman 04/01/2011 - Added result_cache hint to get_preference
--      jkallman 11/29/2012 - Added support for application_activity_logging = 'O', and update of packaged applications (Bug 15918165)
--      cneumuel 03/05/2013 - Added internal caching. moved from platform.sql to wwv_flow_platform.{sql,plb} (bug #15893138)
--      cneumuel 05/06/2013 - In get_preference: use pl/sql function result cache (bug #15893138)
--      cneumuel 05/12/2013 - In get_preference: no relies_on clause in spec on 11.1
--
--------------------------------------------------------------------------------

--==============================================================================
-- G E T   P R E F E R E N C E
-- preference names include:
--    EXP_COMMAND_PATH = command path used to execute the export and import utilities
--==============================================================================
function get_preference (
   p_preference_name in varchar2)
   return varchar2
$if sys.dbms_db_version.version < 11 $then
   /* no result_cache */
$else
   result_cache
$end
   ;

--==============================================================================
procedure set_preference (
   p_preference_name  in varchar2,
   p_preference_value in varchar2 );

end wwv_flow_platform;
/

