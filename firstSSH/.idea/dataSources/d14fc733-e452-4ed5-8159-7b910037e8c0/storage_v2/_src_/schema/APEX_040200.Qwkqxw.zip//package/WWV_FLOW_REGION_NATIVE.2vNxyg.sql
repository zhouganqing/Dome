create package wwv_flow_region_native
as
--------------------------------------------------------------------------------
--
--  Copyright (c) Oracle Corporation 2011 - 2012. All Rights Reserved.
--
--    NAME
--      wwv_flow_region_native.sql
--
--    DESCRIPTION
--      This package is resonsible for handling native region types.
--
--    MODIFIED   (MM/DD/YYYY)
--    pawolf      06/07/2011 - Created
--    pawolf      02/27/2012 - Renamed package wwv_flow_plugin to wwv_flow_plugin_api and wwv_flow_plugin_engine to wwv_flow_plugin
--    pawolf      03/23/2012 - Added new region type jQM List View (feature# 884)
--    pawolf      04/02/2012 - Added p_plugin to APIs
--    pawolf      04/04/2012 - Renamed wwv_flow_region_native to wwv_flow_region_native
--    pawolf      04/27/2012 - Added Builder checks for jQM List View region type
--
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
-- Public type definitions
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
-- Public constant definitions
--------------------------------------------------------------------------------
c_data_upload_column_mapping constant varchar2(40) := 'NATIVE_DATA_UPLOAD_COLUMN_MAPPING';
c_jqm_list_view              constant varchar2(40) := 'NATIVE_JQM_LIST_VIEW';

--==============================================================================
-- Dispatcher which actually calls the native region plug-in.
--==============================================================================
function render_region (
    p_type                in varchar2,
    p_plugin              in wwv_flow_plugin_api.t_plugin,
    p_region              in wwv_flow_plugin_api.t_region,
    p_is_printer_friendly in boolean )
    return wwv_flow_plugin_api.t_region_render_result;
--
--==============================================================================
-- Dispatcher which actually calls the native region plug-in.
--==============================================================================
function ajax_region (
    p_type   in varchar2,
    p_plugin in wwv_flow_plugin_api.t_plugin,
    p_region in wwv_flow_plugin_api.t_region )
    return wwv_flow_plugin_api.t_region_ajax_result;
--
--==============================================================================
-- Dispatcher which validates the entered data in the Builder.
--==============================================================================
procedure validate_builder_region (
    p_type             in varchar2,
    p_attribute_scope  in varchar2,
    p_page_item_prefix in varchar2 );
--
--
end wwv_flow_region_native;
/

