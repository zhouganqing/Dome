create function wwv_flows_version wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
60 89
nPp8w1xw/C2rNUJZXIUSppPYJWUwg8eZgcfLCNL+XhaWlm2u2fqWlkqWDGLF/0dyhp7Asr2y
m17nx3TAM7h0BsB0i8DAMv7Shgmm4SHh5cNVhd1QWnLdL+N3O75xc3HYiKZlBx9N
/

