create package wwv_flow_forms as
--------------------------------------------------------------------------------
--
--  Copyright (c) Oracle Corporation 1999 - 2002. All Rights Reserved.
--
--    DESCRIPTION
--      Flow form rendering engine package specification.
--
--    SECURITY
--
--    INTERNATIONALIZATION
--
--    NOTES
--      This program generates HTML form fields, this package is a utility package to wwv_flow.
--
--    RUNTIME DEPLOYMENT: YES
--
--    SCRIPT ARGUMENTS
--      none
--
--    MODIFIED   (MM/DD/YYYY)
--      mhichwa   01/26/2000 - Created
--      mhichwa   05/14/2000 - Added g_current_item_sequence function increment_item_sequence
--      mhichwa   12/05/2001 - Added g_i
--      mhichwa   02/20/2002 - Added g_current_form_element
--      tmuth     10/14/2002 - Added g_current_x
--      sspadafo  08/31/2006 - Increased size of g_current_form_element to 256 (Bug 5503306)
--      pawolf    04/02/2009 - Added get_element as public function
--      pawolf    08/17/2009 - Added parameter p_plug_form_tab_attr
--      msewtz    04/08/2011 - Added p_render_form_items_in_table to display_positional_form  (feature 586)
--      pawolf    04/27/2011 - Added current_subs as public API (feature 679)
--      pawolf    06/01/2011 - Added get_default_value (feature 629)
--      pawolf    04/10/2012 - Added read only on page and region level (feature# 570)
--      cneumuel  05/24/2012 - Removed display_template_form (dead code)
--      pawolf    05/31/2012 - Continued work on grid layout (feature #936)
--      pawolf    06/05/2012 - Continued work on grid layout (feature #936)
--      pawolf    06/15/2012 - Added region display points support (feature# #936)
--      pawolf    06/27/2012 - Added page display points support (feature #936)
--      cneumuel  08/08/2012 - Moved g_current_form_element to package body
--
--------------------------------------------------------------------------------

g_i                     int := 0; -- index of wwv_flow.g_item_cattributes

--------------------------------------------------------------------------------
-- Returns the name attribute which has to be used for the HTML input element if
-- you want that the value of the element is stored in session state when the
-- page is submitted. If you use a HTML input element which returns multiple
-- values (eg. select list with multiple="multiple") you have
-- to set p_is_multi_value.
--------------------------------------------------------------------------------
function get_html_page_item_name (
    p_is_multi_value in boolean := false )
    return varchar2;

procedure init_form (
    p_region_id in number );

procedure emit_form (
    p_region_id              in number,
    p_page_template_id       in number,
    p_region_template_id     in number,
    p_max_fixed_grid_columns in pls_integer,
    p_grid_template          in wwv_flow_template.t_grid_template,
    p_grid_attributes        in varchar2,
    p_region_is_read_only    in boolean );

function current_subs (
    p_text in varchar2,
    p_i    in number default wwv_flow_forms.g_i )
    return varchar2;

function get_display_value (
    p_item_idx in pls_integer )
    return varchar2;

end wwv_flow_forms;
/

