create package wwv_flow_conditions as

--  Copyright (c) Oracle Corporation 2002-2012. All Rights Reserved.
--
--    DESCRIPTION
--      Flow conditions
--
--    SECURITY
--      Internal function available only to the flows user.
--
--    RUNTIME DEPLOYMENT: YES
--

function standard_condition (
    p_condition_type    in varchar2 default null,
    p_condition         in varchar2 default null,
    p_condition2        in varchar2 default null)
    return boolean;

function is_read_only (
    p_condition_type      in varchar2,
    p_expression1         in varchar2,
    p_expression2         in varchar2,
    p_parent_is_read_only in boolean  default null )
    return boolean;

end wwv_flow_conditions;
/

