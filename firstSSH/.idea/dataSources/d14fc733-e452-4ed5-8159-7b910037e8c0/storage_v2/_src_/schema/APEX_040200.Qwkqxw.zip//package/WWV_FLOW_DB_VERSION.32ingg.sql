create package wwv_flow_db_version as
--------------------------------------------------------------------------------
--
--  Copyright (c) Oracle Corporation 2011. All Rights Reserved.
--
--    NAME
--      wwv_flow_db_version.sql
--
--    DESCRIPTION
--      This package gives information about the current database version,
--      including the patch level (e.g. the last number in 11.2.0.2), which is
--      missing in dbms_db_version.
--
--      Because c_full_version is a varchar2 constant, this can not be used for
--      conditional compilation, however.
--
--    RUNTIME DEPLOYMENT: YES
--
--    MODIFIED (MM/DD/YYYY)
--     cneumuel 04/26/2011 - Created
--
--------------------------------------------------------------------------------

c_full_version    constant varchar2(4000) := sys.dbms_registry.release_version;

c_ver_le_11_2_0_1 constant boolean        := c_full_version < '11.2.0.2.';

end wwv_flow_db_version;
/

