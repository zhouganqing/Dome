create package wwv_flow_team
as

g_bug_id number;
g_todo_id number;
g_feature_id number;

procedure team_dash_1 (
	p_developer         in varchar2 default null,
    p_release           in varchar2 default '0',
    p_application       in number   default 0,
    p_session           in number default 0,
    p_security_group_id in number default 0,
    p_show              in varchar2 default 'ALL'
    );

procedure feedback_dash_1 (
	p_developer         in varchar2 default null,
    p_release           in varchar2 default '0',
    p_application       in number   default 0,
    p_session           in number default 0,
    p_security_group_id in number default 0,
    p_show              in varchar2 default 'ALL'
    );

procedure show_todo_dash_1 (
	p_developer         in varchar2 default null,
    p_release           in varchar2 default '0',
    p_application       in number   default 0,
    p_show              in varchar2 default 'ALL',
    p_session           in number default 0,
    p_security_group_id in number default 0
   );

procedure show_feature_dash_1 (
    p_release        in varchar2 default '0',
    p_application    in number   default 0,
    p_show           in varchar2 default 'ALL',
    p_session        in number default 0,
    p_security_group_id in number default 0
	);

procedure log_feedback_as_todo (
    p_feedback_id        in number,
    p_workspace_id       in number,
	P_ASSIGNED_TO        in varchar2 default null,
	P_DESCRIPTION        in varchar2 default null,
	p_name               in varchar2 default null,
	p_RELEASE            in varchar2 default null,
	p_STATUS             in varchar2 default null,
	p_CATEGORY           in varchar2 default null,
	p_delete_feedback_yn in varchar2 default 'N'
    );

procedure log_feedback_as_bug (
    p_feedback_id  in number,
    p_workspace_id in number,
	P_ASSIGNED_TO  in varchar2 default null,
	P_BUG_TITLE    in varchar2 default null,
	P_SEVERITY     in varchar2 default null,
	P_RELEASE      in varchar2 default null)
	;

function get_default_release (
   p_security_group_id in number   default null,
   p_return_null_as    in varchar2 default null)
   return varchar2
   ;

function get_email (
   p_security_group_id in number   default null,
   p_apex_developer    in varchar2 default null)
   return varchar2
   ;

procedure send_developer_summary (
   p_current_user       in varchar2 default null,
   p_release             in varchar2 default null,
   p_security_group_id  in number,
   p_developer          in varchar2 default null,
   p_subject            in varchar2 default null,
   p_from               in varchar2 default null,
   p_to                 in varchar2 default null,
   p_cc                 in varchar2 default null,
   p_body               in varchar2 default null,
   p_number_format      in varchar2 default '999G999G999G990',
   p_date_format        in varchar2 default 'DD-MON-YYYY',
   p_show_milestone_details in varchar2 default 'Y')
   ;

procedure show_developer_summary (
    p_security_group_id in number   default null,
    p_release           in varchar2 default null,
    p_developer         in varchar2 default null,
    p_number_format     in varchar2 default '999G999G999G990',
    p_date_format        in varchar2 default 'DD-MON-YYYY',
    p_htp_result_yn     in varchar2 default 'Y',
    p_show_milestone_details in varchar2 default 'Y')
    ;

procedure show_bug_dashboard1 (
    p_show              in varchar2 default null,
    p_security_group_id in number   default null,
    p_release           in varchar2 default null,
    p_session           in number   default null)
    ;

procedure show_milestone_dashboard1 (
    p_security_group_id in number   default null,
    p_release           in varchar2 default null,
    p_session           in number   default null)
    ;

procedure show_breadcrumbs (
    p_application_id    in number,
    p_security_group_id in number,
    p_app_session       in number)
    ;


procedure wwv_flow_team_tag_sync (
    p_component_type    in varchar2 default 'FEATURE',
    p_component_id      in number   default null,
    p_new_tags          in varchar2 default null,
    p_security_group_id in number   default null)
    ;

procedure wwv_flow_render_tag_cloud (
    p_security_group_id     in number,
    p_session_id            in number,
    P_tag_type              in varchar2 default 'ALL',
    p_alpha                 in number default 1,
    p_max                   in number default 100,
    p_limit                 in number default 10000,
    p_link_to_page          in varchar2 default '8800',
    p_tag_item_filter       in varchar2 default 'IRC_TAGS',
    p_clear_cache           in varchar2 default '8800,RIR')
    ;

end wwv_flow_team;
/

