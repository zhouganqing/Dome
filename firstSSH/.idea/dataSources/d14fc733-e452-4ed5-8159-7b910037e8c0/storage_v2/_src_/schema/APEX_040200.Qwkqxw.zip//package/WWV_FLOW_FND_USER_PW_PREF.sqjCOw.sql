create package wwv_flow_fnd_user_pw_pref
as
    web_password_format varchar2(255) := 'CLEAR_TEXT';
end wwv_flow_fnd_user_pw_pref;
/

