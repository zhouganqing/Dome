create package wwv_flow_region_layout
as

    g_first_process boolean := true;

procedure page_rendering_icons (
    p_page in varchar2 default null)
    ;
procedure shared_component_icons (
    p_page in varchar2 default null)
    ;
procedure page_processing_icons (
    p_page in varchar2 default null)
    ;

-------------------------
-- Page Rendering On Load
--
procedure show_on_load_page (
    p_page                 in number,
    p_global_page_id       in number,
    p_flow                 in number,
    p_session              in number)
    ;
procedure show_on_load_regions (
    p_page                 in number,
    p_global_page_id       in number,
    p_flow                 in number,
    p_session              in number)
    ;
procedure show_page_buttons (
    p_page          in number,
    p_flow          in number,
    p_session       in number)
    ;
procedure show_page_items (
    p_page          in number,
    p_flow          in number,
    p_session       in number)
    ;
procedure show_on_load_computations (
    p_page                 in number,
    p_flow                 in number,
    p_session              in number)
    ;
procedure show_on_load_processes (
    p_page                 in number,
    p_flow                 in number,
    p_session              in number)
    ;
procedure show_on_load_dynact (
    p_page                 in number,
    p_flow                 in number,
    p_session              in number)
    ;

----------------------------
-- Page Processing on submit
--
procedure show_on_submit_comp (
    p_page in number,
    p_flow in number,
    p_session in number)
    ;
procedure show_on_submit_val (
    p_page in number,
    p_flow in number,
    p_session in number)
    ;
procedure show_on_submit_proc (
    p_page    in number,
    p_flow    in number,
    p_session in number)
    ;

procedure show_on_submit_branch (
    p_page    in number,
    p_flow    in number,
    p_session in number)
    ;

-- shared
procedure show_shared_tabs (
    p_page in number,
    p_flow in number,
    p_session in number)
    ;
procedure show_shared_standard_tabs (
    p_page in number,
    p_flow in number,
    p_session in number)
    ;
procedure show_shared_lov (
    p_page in number,
    p_flow in number,
    p_session in number)
    ;
procedure show_shared_bc (
    p_page     in number,
    p_flow     in number,
    p_session  in number)
    ;
procedure show_shared_lists (
    p_page     in number,
    p_flow     in number,
    p_session  in number)
    ;
procedure show_shared_theme (
    p_page     in number,
    p_flow     in number,
    p_session  in number)
    ;
procedure show_shared_templates (
    p_page     in number,
    p_flow     in number,
    p_session  in number)
    ;
procedure show_shared_security (
    p_page     in number,
    p_flow     in number,
    p_session  in number)
    ;
procedure show_shared_navbar (
    p_page     in number,
    p_flow     in number,
    p_session  in number)
    ;



-- 4150 helper functions

 procedure show_apex_home_pg_elink (
    p_page     in number default null,
    p_flow     in number default null,
    p_session  in number default null)
    ;
 procedure set_lock_status (
    p_flow in number,
    p_page in number)
    ;



-- other


procedure show_page_template (
    p_flow          in number,
    p_page          in number default null,
    p_template      in varchar2 default null,
    p_template_id   in number   default null)
    ;

procedure page_temp_substitution (
    p_flow          in number,
    p_template_id   in number)
    ;

procedure show_on_load_flow (
    p_page     in number,
    p_flow     in number,
    p_session  in number,
    p_show_all in boolean default false)
    ;

procedure show_on_accept_flow (
    p_page          in number,
    p_flow          in number,
    p_session       in number,
    p_show_all      in boolean default false)
    ;

procedure show_related_pages_report (
    p_flow          in number,
    p_page_id       in number,
    p_session       in number)
    ;


procedure show_region_template (
    p_flow          in number,
    p_template_id   in number);

procedure region_temp_substitution (
    p_flow          in number,
    p_template_id   in number);

procedure set_most_recently_edited (
    p_security_group_id in number,
    p_user              in varchar2);

procedure show_title (
       p_title in varchar2,
       p_t1    in varchar2 default null,
       p_n1    in varchar2 default null,
       p_t2    in varchar2 default null,
       p_n2    in varchar2 default null,
       p_t3    in varchar2 default null,
       p_n3    in varchar2 default null,
       p_t4    in varchar2 default null,
       p_n4    in varchar2 default null,
       p_t5    in varchar2 default null,
       p_n5    in varchar2 default null,
       p_t6    in varchar2 default null,
       p_n6    in varchar2 default null,
       p_button_class in varchar2 default null,
       p_title_tab_attributes in varchar2 default null,
       p_help  in varchar2,
       p_name  in varchar2 default null);

--
-- page zero information reports
--

procedure show_global_page_app_proc (
    p_flow    in number,
    p_session in number)
    ;

procedure show_global_page_app_comp (
    p_flow    in number,
    p_session in number)
    ;

procedure show_global_page_app_items (
    p_flow    in number,
    p_session in number)
    ;

function get_process_type_desc (
    p_flow_id      in number,
    p_process_type in varchar2 )
    return varchar2;

function get_computation_type_desc (
    p_computation_type in varchar2 )
    return varchar2;

function get_validation_type_desc (
    p_validation_type in varchar2 )
    return varchar2;

function get_dyn_action_cond_type_desc (
    p_triggering_condition_type in varchar2 )
    return varchar2;

function get_page_item_type_desc (
    p_flow_id    in number,
    p_display_as in varchar2 )
    return varchar2;

function get_tabform_column_type_desc (
    p_display_as in varchar2 )
    return varchar2;

function get_ir_column_type_desc (
    p_display_as in varchar2 )
    return varchar2;

function get_condition_type_desc (
    p_condition_type in varchar2 )
    return varchar2;

function get_authorization_scheme_desc (
    p_authorization_scheme_id in varchar2 )
    return varchar2;

function get_build_option_desc (
    p_build_option_id in number )
    return varchar2;

end wwv_flow_region_layout;
/

