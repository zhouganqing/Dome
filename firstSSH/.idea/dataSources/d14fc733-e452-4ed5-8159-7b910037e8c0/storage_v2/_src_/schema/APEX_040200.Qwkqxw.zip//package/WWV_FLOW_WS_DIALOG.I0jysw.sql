create package wwv_flow_ws_dialog as
--------------------------------------------------------------------------------
--
--  Copyright (c) Oracle Corporation 1999 - 2012. All Rights Reserved.
--
--    NAME
--      wwv_flow_ws_dialog.sql
--
--    DESCRIPTION
--
--    RUNTIME DEPLOYMENT: YES
--
--    MODIFIED (MM/DD/YYYY)
--    cbcho     03/31/2008 - Created
--    cbcho     07/01/2008 - Changed list_of_values to edit existing LOV
--    cbcho     07/24/2008 - Added add_column_validation
--    cbcho     07/29/2008 - Added p_mode to column_groups
--    cbcho     08/18/2008 - Added p_websheet_id to add_notification
--    cbackstr  08/20/2008 - Added list_of_values_text to get csv string of LOV item
--    cbcho     04/23/2009 - Added p_websheet_id where needed
--    cbcho     05/22/2009 - Added p_link_id to add_links
--    cbcho     05/28/2009 - Changed reset_geocode to accept p_websheet_id
--    cbcho     08/04/2009 - Removed add_notification
--    cbcho     08/14/2009 - Added p_note_id to add_notes
--    cbcho     09/04/2009 - Removed add_webpage_section
--    jkallman  02/05/2010 - Removed websheet_sharing
--    arayner   04/15/2010 - Added p_column_name parameter to add_column_validation
--    cneumuel  12/10/2012 - Added ondemand_dialog (bug #15977940)
--
--------------------------------------------------------------------------------

procedure websheet_properties (
    p_worksheet_id   in number,
    p_base_report_id in number,
    p_app_user       in varchar2,
	p_mode           in varchar2 default 'REPORT'
    );

procedure add_column (
    p_worksheet_id   in number,
	p_mode           in varchar2 default 'REPORT'
    );

procedure column_properties (
    p_worksheet_id        in number,
    p_base_report_id      in number,
    p_app_user            in varchar2,
    p_column_name         in varchar2 default null,
    p_mode                in varchar2 default 'REPORT');

procedure list_of_values_text (
    p_worksheet_id        in number,
    p_base_report_id      in number,
    p_app_user            in varchar2,
    p_lov_id              in number default null,
    p_mode                in varchar2 default 'REPORT');

procedure list_of_values (
    p_worksheet_id        in number,
    p_base_report_id      in number,
    p_app_user            in varchar2,
    p_lov_id              in number default null,
    p_mode                in varchar2 default 'REPORT');

procedure remove_columns (
    p_worksheet_id        in number,
    p_base_report_id      in number,
    p_app_user            in varchar2,
	p_mode                in varchar2 default 'REPORT'
	);

procedure set_column_value (
    p_worksheet_id    in number,
    p_base_report_id  in number,
    p_app_user        in varchar2,
	p_mode            in varchar2 default 'REPORT');

procedure replace_value (
    p_worksheet_id    in number,
    p_base_report_id  in number,
    p_app_user        in varchar2,
	p_mode            in varchar2 default 'REPORT');

procedure fill (
    p_worksheet_id    in number,
    p_base_report_id  in number,
    p_app_user        in varchar2,
	p_mode            in varchar2 default 'REPORT');

procedure delete_rows (
    p_worksheet_id    in number,
    p_base_report_id  in number,
    p_app_user        in varchar2,
	p_mode            in varchar2 default 'REPORT');

procedure geocode (
    p_worksheet_id     in number,
    p_base_report_id   in number,
    p_app_user         in varchar2,
	p_mode             in varchar2 default 'REPORT');

procedure copy (
    p_worksheet_id in number,
	p_mode         in varchar2 default 'REPORT'
    );

procedure export (
    p_worksheet_id in number,
	p_mode         in varchar2 default 'REPORT'
    );

procedure delete_websheet (
    p_worksheet_id     in number,
    p_base_report_id   in number,
    p_app_user         in varchar2,
	p_mode             in varchar2 default 'REPORT');

procedure column_groups (
    p_worksheet_id     in number,
    p_base_report_id   in number,
    p_app_user         in varchar2,
    p_group_id         in number default null,
    p_mode             in varchar2 default 'REPORT');

procedure reset_geocode (
    p_worksheet_id   in number,
    p_websheet_id    in number,
    p_base_report_id in number,
    p_app_user       in varchar2,
	p_mode           in varchar2 default 'REPORT');

procedure column_expression  (
    p_worksheet_id    in number,
    p_base_report_id  in number,
    p_app_user        in varchar2,
	p_mode            in varchar2 default 'REPORT'
    );

procedure add_attachment (
    p_worksheet_id  in number,
	p_mode          in varchar2 default 'REPORT'
    );

procedure add_notes (
    p_worksheet_id  in number default null,
	p_mode          in varchar2 default 'REPORT',
	p_note_id       in number default null
    );

procedure add_links (
    p_worksheet_id  in number,
	p_mode          in varchar2 default 'REPORT',
	p_link_id       in number default null
    );

procedure add_tags (
    p_worksheet_id  in number,
    p_row_id        in number,
	p_mode          in varchar2 default 'REPORT'
    );

procedure move_columns (
    p_worksheet_id     in number,
	p_mode             in varchar2 default 'REPORT'
    );

procedure add_column_validation (
    p_worksheet_id    in number,
    p_app_user        in varchar2,
    p_base_report_id  in number,
    p_validation_id   in number         default null,
    p_column_name     in varchar2       default null,
	p_mode            in varchar2       default 'REPORT'
    );

--==============================================================================
-- on-demand process DIALOG in 4900
--==============================================================================
procedure ondemand_dialog (
    p_websheet_id     in number,  -- P2_WEBSHEET_ID
    p_worksheet_id    in number,  -- P2_ID
    p_base_report_id  in number,  -- RPT_ID
    p_row_id          in number );-- CURRENT_WORKSHEET_ROW

end  wwv_flow_ws_dialog;
/

