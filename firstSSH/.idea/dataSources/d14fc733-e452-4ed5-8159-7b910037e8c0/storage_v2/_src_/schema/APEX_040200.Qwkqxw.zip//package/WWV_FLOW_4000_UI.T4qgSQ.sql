create package wwv_flow_4000_ui as

	procedure p320_create_collection (
	    p_flow_id           in number,
	    p_session           in number,
	    p_security_group_id in number,
	    p_image_prefix      in varchar2
	    );

procedure show_tabs (
	p_application_id    in number   default null,
	p_security_group_id in number   default null,
	p_session_id        in number  default null,
	p_parent_tabset     in varchar2 default null)
	;

function get_timeframe (
	p_days in number default 1)
	return varchar2
	;

function get_validation (
	    p_validation_id     in number default null,
	    p_application_id    in number default null,
	    p_security_group_id in number default null,
	    p_validation        in varchar2 default null,
	    p_bind_01           in varchar2 default null,
	    p_bind_02           in varchar2 default null,
	    p_bind_03           in varchar2 default null,
	    p_bind_04           in varchar2 default null,
	    p_bind_05           in varchar2 default null,
	    p_bind_06           in varchar2 default null
	    )
	return varchar2
	;

procedure print_lov_examples (
    p_display_as in varchar2 )
    ;

procedure print_apex_online_info (
    p_ul_attr in varchar2 default null)
    ;

procedure print_cgi_env (
   p_html_table_attr  in varchar2 default null
   )
   ;

procedure show_news (
  p_workspace_id in number,
  p_num_seconds  in number default 5,
  p_max_rows     in number default 5)
  ;

--
-- logging of internal events
-- such as:
--      seeding translations
--
procedure log_event (
    p_event                    in varchar2 default null,
    p_event_application_id     in varchar2 default null,
    p_event_env                in varchar2 default null,
    p_elap_seconds             in number   default null,
    p_event_details            in varchar2 default null,
    p_event_database_object    in varchar2 default null)
    ;
--
-- workspace notification
--
procedure show_workspace_notification (
   p_workspace_id       in number default null,
   p_session            in number default null,
   p_text_span_class    in varchar2 default 'fielddata')
   ;

function workspace_notification_exists (
    p_workspace_id in number default null)
    return boolean   ;

--
-- history
--
procedure show_history (
   p_id                 in number   default null,
   p_component_type     in varchar2 default null,
   p_LAST_UPDATED_BY    in varchar2 default null,
   p_LAST_UPDATED_ON    in date     default null,
   p_CREATED_BY         in varchar2 default null,
   p_CREATED_ON         in date     default null,
   p_date_format_mask   in varchar2 default 'Day Month DD, YYYY HH24:MI')
   ;


--
-- instance level reporting
--

/* procedure top_applications_combo (
    p_app_session       in varchar2,
    p_security_group_id in varchar2,
    p_image_prefix      in varchar2,
    p_days              in varchar2 default null,
    p_display_count     in number default 8,
    p_max_length        in number default 20,
    p_chart_width       in number default 50,
    p_show_internal_yn  in varchar2 default 'Y',
    p_link              in varchar2 default null)
    ;
*/


procedure top_applications_combo2 (
    p_app_session       in varchar2,
    p_security_group_id in varchar2,
    p_image_prefix      in varchar2,
    p_days              in varchar2 default null,
    p_display_count     in number default 8,
    p_max_length        in number default 20,
    p_chart_width       in number default 50,
    p_show_internal_yn  in varchar2 default 'Y',
    p_link              in varchar2 default null)
    ;

procedure top_applications (
    p_app_session       in varchar2,
    p_security_group_id in varchar2,
    p_image_prefix      in varchar2,
    p_days              in varchar2 default null,
    p_display_count     in number default 8,
    p_max_length        in number default 20,
    p_chart_width       in number default 50,
    p_show_internal_yn  in varchar2 default 'Y')
    ;

procedure top_websheets (
    p_app_session       in varchar2,
    p_security_group_id in varchar2,
    p_image_prefix      in varchar2,
    p_days              in varchar2 default null,
    p_display_count     in number default 8,
    p_max_length        in number default 20,
    p_apex_owner        in varchar2 default null,
    p_chart_width       in number default 50)
    ;

/* procedure top_users (
    p_app_session       in varchar2,
    p_security_group_id in varchar2,
    p_image_prefix      in varchar2,
    p_days              in varchar2 default null,
    p_display_count     in number default 8,
    p_max_length        in number default 20,
    p_chart_width       in number default 50,
    p_link              in varchar2 default null)
    ;
*/

procedure top_users2 (
    p_app_session       in varchar2,
    p_security_group_id in varchar2,
    p_image_prefix      in varchar2,
    p_days              in varchar2 default null,
    p_display_count     in number default 8,
    p_max_length        in number default 20,
    p_chart_width       in number default 50,
    p_link              in varchar2 default null)
    ;
procedure show_page_event_link (
    p_days              in varchar2 default null,
    p_link              in varchar2 default null)
;
procedure show_sent_statistics;

procedure statistics;

procedure updates;

procedure news;

procedure repository;

end wwv_flow_4000_ui;
/

