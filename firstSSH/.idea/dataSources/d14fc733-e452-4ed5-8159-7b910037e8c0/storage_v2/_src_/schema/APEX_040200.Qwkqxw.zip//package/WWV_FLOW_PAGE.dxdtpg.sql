create package wwv_flow_page
as
--------------------------------------------------------------------------------
--
--  Copyright (c) Oracle Corporation 2012. All Rights Reserved.
--
--    NAME
--      wwv_flow_page.sql
--
--    DESCRIPTION
--      This package is responsible for handling pages the
--      runtime engine.
--
--    MODIFIED   (MM/DD/YYYY)
--      pawolf    02/29/2012 - Created
--      pawolf    03/20/2012 - Added trace information
--      pawolf    03/22/2012 - Added get_page_id
--      pawolf    03/29/2012 - Changed get_page_id to raise an error if the specified page doesn't exists
--      pawolf    04/10/2012 - Added read only on page and region level (feature# 570)
--      pawolf    04/11/2012 - Changed is_read_only handling and added reset
--      pawolf    04/08/2012 - Moved code from flow.plb to render a page
--
--------------------------------------------------------------------------------

--==============================================================================
-- Global types
--==============================================================================


--==============================================================================
-- Global constants
--==============================================================================


--==============================================================================
-- Global variables
--==============================================================================


--==============================================================================
-- Returns the name of the UI type for which the current page has been designed
-- for.
--==============================================================================
function get_ui_type (
    p_application_id    in number default wwv_flow_security.g_flow_id,
    p_page_id           in number default wwv_flow.g_flow_step_id,
    p_security_group_id in number default wwv_flow_security.g_curr_flow_security_group_id )
    return varchar2;

--==============================================================================
-- Returns TRUE if the current page has been designed for Desktop browsers.
--==============================================================================
function is_desktop_ui (
    p_application_id    in number default wwv_flow_security.g_flow_id,
    p_page_id           in number default wwv_flow.g_flow_step_id,
    p_security_group_id in number default wwv_flow_security.g_curr_flow_security_group_id )
    return boolean;

--==============================================================================
-- Returns TRUE if the current page has been designed for
-- jQuery Mobile (Smartphone, Tablet or Phonegap) browsers.
--==============================================================================
function is_jqm_ui (
    p_application_id    in number default wwv_flow_security.g_flow_id,
    p_page_id           in number default wwv_flow.g_flow_step_id,
    p_security_group_id in number default wwv_flow_security.g_curr_flow_security_group_id )
    return boolean;

--==============================================================================
-- Returns TRUE if the current page has been designed for
-- jQuery Mobile Smartphones browsers.
--==============================================================================
function is_jqm_smartphone_ui (
    p_application_id    in number default wwv_flow_security.g_flow_id,
    p_page_id           in number default wwv_flow.g_flow_step_id,
    p_security_group_id in number default wwv_flow_security.g_curr_flow_security_group_id )
    return boolean;

--==============================================================================
-- Returns TRUE if the current page has been designed for
-- jQuery Mobile Tablet browsers.
--==============================================================================
function is_jqm_tablet_ui (
    p_application_id    in number default wwv_flow_security.g_flow_id,
    p_page_id           in number default wwv_flow.g_flow_step_id,
    p_security_group_id in number default wwv_flow_security.g_curr_flow_security_group_id )
    return boolean;

--==============================================================================
-- Returns the theme id which is used by the specified page.
--==============================================================================
function get_theme_id (
    p_application_id    in number default wwv_flow_security.g_flow_id,
    p_page_id           in number default wwv_flow.g_flow_step_id,
    p_security_group_id in number default wwv_flow_security.g_curr_flow_security_group_id )
    return number;

--==============================================================================
-- Returns the id of the page templates which should be used by the current page.
-- If the page itself doesn't have an assigned page template, the theme default
-- will be used.
--==============================================================================
function get_page_template_id (
    p_application_id    in number default wwv_flow_security.g_flow_id,
    p_page_id           in number default wwv_flow.g_flow_step_id,
    p_security_group_id in number default wwv_flow_security.g_curr_flow_security_group_id )
    return number;

--==============================================================================
-- Purge the cache of the specified application, page and optional for
-- the specified user. If the user isn't specified, all cached versions of
-- that page are purged.
--==============================================================================
procedure purge_cache (
    p_application_id in number,
    p_page_id        in number,
    p_user_name      in varchar2 default null );

--==============================================================================
-- Returns the id of the specified page alias. If the parameter p_page_id_or_alias
-- is a numeric value. The function also checks if the specified page exists.
--==============================================================================
function get_page_id (
    p_application_id   in number default wwv_flow_security.g_flow_id,
    p_page_id_or_alias in varchar2 )
    return number;

--==============================================================================
-- Returns TRUE if the current page should be rendered read only and FALSE if not.
--==============================================================================
function is_read_only return boolean;

--==============================================================================
-- Render the current page
--==============================================================================
procedure render;

--==============================================================================
-- Renders the error page with the specified values in p_error.
--==============================================================================
procedure render_error_page (
    p_error in wwv_flow_error_api.t_error );

--==============================================================================
-- Resets all global variables.
-- Note: Always call this procedure if the current page changes!
--==============================================================================
procedure reset;
--
end wwv_flow_page;
/

