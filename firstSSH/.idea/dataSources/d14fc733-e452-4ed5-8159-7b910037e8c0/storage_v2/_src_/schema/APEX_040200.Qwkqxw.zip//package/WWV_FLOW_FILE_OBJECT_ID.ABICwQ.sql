create package wwv_flow_file_object_id
is
   g_id number;
end;
/

