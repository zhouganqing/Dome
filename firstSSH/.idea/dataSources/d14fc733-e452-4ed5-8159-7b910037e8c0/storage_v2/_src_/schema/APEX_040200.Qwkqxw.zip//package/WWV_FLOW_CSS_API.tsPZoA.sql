create package wwv_flow_css_api as
--------------------------------------------------------------------------------
--
--  Copyright (c) Oracle Corporation 2009 - 2012. All Rights Reserved.
--
--    NAME
--      wwv_flow_css_api.sql
--
--    DESCRIPTION
--      This package contains utility functions for adding CSS styles to the HTTP output.
--
--    MODIFIED   (MM/DD/YYYY)
--    pawolf      02/27/2012 - Created
--    pawolf      04/05/2012 - Added support for content delivery networks (feature #819)
--    pawolf      05/03/2012 - Added p_media_query and p_ie_condition to add_file (feature 930)
--
--------------------------------------------------------------------------------
--
--
--==============================================================================
-- Global constants
--==============================================================================
c_library_jquery        constant varchar2(20) := 'jquery';
c_library_jquery_ui     constant varchar2(20) := 'jquery-ui';
c_library_jquery_mobile constant varchar2(20) := 'jquery.mobile';
--
--
--==============================================================================
-- This procedure adds the link tag to load a CSS library.
-- If a library has already been added, it will not be added a second time.
-- Parameter:
--   p_name:           has to be specified without .js
--   p_directory:      has to have a trailing slash
--   p_version:        version identifier which should be added to the library name (optional)
--   p_skip_extension: if true the extension .css is NOT added (optional)
--   p_media_query:    value which should be set as media query (optional)
--   p_ie_condition:   condition which should be used as Internet Explorer condition (optional)
--==============================================================================
procedure add_file (
    p_name           in varchar2,
    p_directory      in varchar2 default wwv_flow.g_image_prefix||'css/',
    p_version        in varchar2 default null,
    p_skip_extension in boolean  default false,
    p_media_query    in varchar2 default null,
    p_ie_condition   in varchar2 default null );
--
--==============================================================================
-- This procedure adds the link tag to load a 3rd party css file (supported
-- libraries: jQuery, jQueryUI, jQueryMobile) and will also take into account
-- the specified Content Delivery Network for the application.
--
-- If a library has already been added, it will not be added a second time.
--
-- Parameter:
--   p_library:     Use one of the c_library_* constants
--   p_file_name:   Has to be specified without version, .min and .css
--   p_directory:   Directory where the file p_file_name is located (optional)
--   p_version:     If no value is provided then the same version APEX ships
--                  will be used (optional)
--   p_media_query: value which should be set as media query (optional)
--
-- Examples:
--
--   add_3rd_party_library_file (
--     p_library   => c_library_jquery_ui,
--     p_file_name => 'jquery.ui.accordion' )
--
--==============================================================================
procedure add_3rd_party_library_file (
    p_library     in varchar2,
    p_file_name   in varchar2,
    p_directory   in varchar2 default null,
    p_version     in varchar2 default null,
    p_media_query in varchar2 default null );
--
--==============================================================================
-- Adds a CSS style snippet which is included inline into the HTML output
-- eg. You can use this procedure to add new css style declarations.
--
-- If an entry with the same key exits it will be ignored.
-- If p_key is null the snippet will always be added.
--
-- Parameter:
--   p_style: CSS style snippet. eg: #test { color:#fff }
--   p_key:   identifier for the style snippet. If specified and a style snippet with
--            the same name has already been added the new style snippet will be ignored.
--==============================================================================
procedure add (
    p_css in varchar2,
    p_key in varchar2 default null );
--
/*
 * Create a new css_repository entry, returns unique id for
 *  wwv_flow_css_repository table.
 */
function new_css_repository_record (
    p_name                  in out varchar2,
    p_varchar2_table            in sys.dbms_sql.varchar2_table,
    p_mimetype                  in varchar2,
    p_flow_id                   in number,
    p_notes                     in varchar2 )
    return number
    ;
--
-- F I L E S Y S T E M   I N T E G R A T I O N
--
/*
 * pass in the css id of the wwv_flow_css_repository record representing
 *  the css file you want to drop. If this css does not exist according to the
 *  wwv_flow_css_repository table, this will fail.
 */
--
-- remove by name
--
procedure remove_css (
    p_css_name in varchar2,
    p_flow_id  in number   default null );
--
end wwv_flow_css_api;
/

