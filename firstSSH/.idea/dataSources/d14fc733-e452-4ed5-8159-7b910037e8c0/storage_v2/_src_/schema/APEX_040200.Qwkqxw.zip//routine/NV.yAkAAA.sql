create function nv wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
a4 ca
CycvgH0iuBim62DpcSpWjnAzdSYwgy7wf8tqynTp2see0MrppEXJZndrWtvKC4V9/fVHOv0q
CT14PwDtnZ+e8Z6v+Kb2jxon02jK83Ry7kM67rzajPUbDrxihYuAJ8mvdX2a91GcyYj2M/vN
S+o8Lku7hLFxMxKizJcu75yHDTiBimOl9Yddimh+yEFnC7wQpuwPFnk=
/

