create package wwv_flow_rest as

g_sql       clob;
g_result    clob;

procedure getReport(
    app             in varchar2,
    page            in varchar2,
    reportid        in varchar2,
    parmvalues      in varchar2     default null,
    lang            in varchar2     default 'en',
    output          in varchar2     default 'xml'
    );

procedure getServiceDescription(
    app             in varchar2
    );

end wwv_flow_rest;
/

