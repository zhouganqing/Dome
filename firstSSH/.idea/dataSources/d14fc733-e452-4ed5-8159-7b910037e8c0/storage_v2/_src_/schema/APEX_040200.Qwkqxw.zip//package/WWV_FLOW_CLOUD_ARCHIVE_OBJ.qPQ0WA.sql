create package wwv_flow_cloud_archive_obj
authid current_user
as

procedure create_archive_objects;

procedure create_archive_tables;

procedure create_archive_triggers;

procedure remove_archive_objects;

end wwv_flow_cloud_archive_obj;
/

