create PACKAGE wwv_flow_sample_app
IS

procedure deinstall_websheet (
	p_security_group_id in number,
	p_id                in number);

procedure install_websheet (
	p_name              in varchar2,
	p_security_group_id in number,
	p_id                in number);

procedure deinstall_db_app (
  p_id                in number);

procedure install_db_app (
  p_app_id            in number,
  p_schema            in varchar2,
  p_security_group_id in number default wwv_flow_security.g_security_group_id,
  p_id                in number default wwv_flow_utilities.minimum_free_flow);

END wwv_flow_sample_app;
/

