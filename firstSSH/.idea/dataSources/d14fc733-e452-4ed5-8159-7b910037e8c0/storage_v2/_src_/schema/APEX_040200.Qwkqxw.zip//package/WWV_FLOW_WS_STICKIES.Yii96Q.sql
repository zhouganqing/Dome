create package wwv_flow_ws_stickies
as
procedure show_stickies (
    p_application_id    in number,
    p_worksheet_id      in number,
    p_session           in number,
    p_row_id            in number,
    p_print             in varchar2 default 'Y',
    p_body_array        out wwv_flow_global.vc_arr2)
    ;
end wwv_flow_ws_stickies;
/

