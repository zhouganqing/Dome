create package wwv_flow_check
as

--  Copyright (c) Oracle Corporation 1999. All Rights Reserved.
--
--    DESCRIPTION
--      Flow utility to check conditions
--
--    SECURITY
--
--    NOTES
--      To improve performance checks are cached to avoid evaluating duplicate checks.
--

function check_cond_plsql_expresion (
    p_condition in varchar2 default null)
    return boolean
    ;

function check_condition_sql_expresion (
    p_condition in varchar2 default null)
    return boolean
    ;
end wwv_flow_check;
/

