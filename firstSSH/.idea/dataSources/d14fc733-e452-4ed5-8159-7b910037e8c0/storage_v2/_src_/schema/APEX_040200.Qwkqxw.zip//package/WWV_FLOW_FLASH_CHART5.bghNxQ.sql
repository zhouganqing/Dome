create package wwv_flow_flash_chart5 as

g_chart_engine       varchar2(255) := 'ANYCHART';
g_clob               clob;
g_data_clob          clob;
g_region_src_clob    clob;
empty_vc_arr         wwv_flow_global.vc_arr2;
g_dbms_output        sys.dbms_output.chararr;
g_max_size_reached   boolean := false;
g_status varchar2(32767) := null;

procedure chart(p_region_id in number default null);

procedure show (
    p_region_id        in number,
    p_region_static_id in varchar2,
    p_region_source    in varchar2 );

function static_xml (
    p_region_id in number
    ) return varchar2;

-----------------------------------------------------------------------------------------------
-- get varchar2 array of report results
-- p_owner:  owner / schema name
-- p_query:  SQL statement
-- p_report_name: name of chart and series
-- p_format: CSV, HTML or XML
-- p_values: bind values
-- p_max_rows: number of report rows processed
-- p_dbms_output_lines: number of dbms output lines

function get_accessible_report (
    p_owner             varchar2,
    p_query             varchar2,
    p_report_name       varchar2,
    p_format            varchar2 default 'HTML',
    p_max_size          number   default 10000,
    p_max_rows          number   default 10,
    p_limit_type        varchar2 default 'S', -- 'S' for size 'R' for rows
    p_dbms_output_lines number   default 10000,
    p_headers           in wwv_flow_global.vc_arr2 default empty_vc_arr,
    p_header_align      in wwv_flow_global.vc_arr2 default empty_vc_arr,
    p_column_align      in wwv_flow_global.vc_arr2 default empty_vc_arr
) return wwv_flow_global.vc_arr2;

procedure ajax;

end wwv_flow_flash_chart5;
/

