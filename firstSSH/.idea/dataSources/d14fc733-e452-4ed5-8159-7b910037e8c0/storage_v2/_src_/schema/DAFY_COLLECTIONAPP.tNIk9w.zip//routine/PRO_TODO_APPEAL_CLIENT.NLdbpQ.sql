create procedure PRO_TODO_APPEAL_CLIENT(
                                                 p_Oper      varchar2,
                                                 p_AppealId number,
                                                 p_CollectionId number,
                                                 p_UserId number,
                                                 p_ReturnCode  out varchar2) is
   error_info  varchar2(4000);
   v_CompanyId number(10);
   v_ComplaintHandleCount number;
   v_ComplaintId number;
--create user:Tianxiangchuan
--use: 申诉催收员操作
begin
   if p_Oper='QBDJ' then    ---全部冻结
     update sys_userinfo set status='-3',update_user=p_UserId,update_time=sysdate where customer_id=p_CollectionId and customer_type=1;
     update coll_appeal set handle_time=sysdate,update_time=sysdate,update_user=p_UserId,handle_result='冻结全部催收员帐号',status=1 where id=p_AppealId;
   elsif p_Oper='BFDJ' then    ---部分冻结
     update sys_userinfo set status='-2',update_user=p_UserId,update_time=sysdate where customer_id=p_CollectionId and customer_type=1;
     select c.company_id,a.complaint_id into v_CompanyId,v_ComplaintId from coll_appeal a join coll_complaint c on a.complaint_id=c.id where a.id=p_AppealId;
     update coll_appeal set handle_time=sysdate,update_time=sysdate,update_user=p_UserId,handle_result='冻结部分催收员帐号',status=1 where id=p_AppealId;
     
     select count(id) into v_ComplaintHandleCount from coll_complaint_handle where company_id=v_CompanyId and collection_id=p_CollectionId;
     if v_ComplaintHandleCount>0 then
       update coll_complaint_handle set is_frozen=1,update_user=p_UserId,handle_time=sysdate where company_id=v_CompanyId and collection_id=p_CollectionId;
     else
       insert into coll_complaint_handle(id,complaint_id,collection_id,company_id,is_frozen,create_user,handle_time) 
       values(seq_coll_complaint_handle.nextval,v_ComplaintId,p_CollectionId,v_CompanyId,1,p_UserId,sysdate);
     end if;
   elsif p_Oper='FF' then    ---恢复
     update sys_userinfo set status='2',update_user=p_UserId,update_time=sysdate where customer_id=p_CollectionId and customer_type=1;
     select c.company_id,a.complaint_id into v_CompanyId,v_ComplaintId from coll_appeal a join coll_complaint c on a.complaint_id=c.id where a.id=p_AppealId;
     
     select count(id) into v_ComplaintHandleCount from coll_complaint_handle where complaint_id=v_ComplaintId and collection_id=p_CollectionId;
     if v_ComplaintHandleCount>0 then
        update coll_complaint_handle set is_frozen=0,update_user=p_UserId,update_time=sysdate where complaint_id=v_ComplaintId and collection_id=p_CollectionId;
     end if;
     update coll_appeal set handle_time=sysdate,update_time=sysdate,update_user=p_UserId,handle_result='恢复催收员帐号',status=1 where id=p_AppealId;
   elsif p_Oper='ZX' then --- 注销
     update sys_userinfo set status='-5',update_user=p_UserId,update_time=sysdate where customer_id=p_CollectionId and customer_type=1;
     update coll_appeal set handle_time=sysdate,update_time=sysdate,update_user=p_UserId,handle_result='注销催收员帐号',status=1 where id=p_AppealId;
   end if;
   commit;
   p_ReturnCode:='A';
   return;
exception
   when others Then
     error_info := sqlerrm;
     p_ReturnCode:='Z-'||error_info;
     rollback;
end;
/

