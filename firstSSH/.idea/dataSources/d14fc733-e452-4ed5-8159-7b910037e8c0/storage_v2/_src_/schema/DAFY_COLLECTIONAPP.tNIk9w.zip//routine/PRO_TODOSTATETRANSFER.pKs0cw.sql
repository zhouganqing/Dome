create procedure Pro_ToDoStateTransfer
(p_ReturnCode out number)
 is 
    
  v_rate  number(18, 2);
   --委托单超期结束
   cursor cur is select  d.id, d.status, d.entrust_days  from delegate_credit d where d.status in (0 ,1 ,2, 3, 7) and d.entrust_days = 0 ;
   
   -- 用户领取的委托到期状态转为确认状态处理
   cursor curdreceive is select drc.id, drc.status, drc.surplus_days, drc.credit_id, dca.entrust_days from delegate_receive drc
          inner join  delegate_credit dca on drc.credit_id=dca.id
          where drc.status in (0, 1)  and drc.surplus_days = 0 and dca.entrust_days != 0 ;
          
   --获取待调整的佣金比例
   cursor curRate is select dt.id, dt.company_id, dt.overdue_stage overstage from delegate_credit dt  where dt.status in (0 ,1 ,2, 3, 7);
          
   --用户领取的委托单确认状态的处理
   cursor curdreceives is select drce.id, drce.status, drce.surplus_days, drce.credit_id from delegate_receive drce where drce.status = 2 and drce.surplus_days = 0;
   
begin
    --增加逾期天数, 减少持有时长
    update delegate_credit cde set cde.overdue_days=cde.overdue_days + 1 , cde.entrust_days=cde.entrust_days - 1, cde.update_time=sysdate,
     cde.overdue_stage='M'||to_char(floor((cde.overdue_days + 1)/30)+1)
    where cde.status in (0 ,1 ,2, 3, 7) and cde.entrust_days >0 ;
      
  --减少持有时长
    update delegate_receive  r set r.surplus_days=r.surplus_days - 1, r.update_time=sysdate
    where r.status in (0, 1, 2) and r.surplus_days > 0 ;   
    
    --委托单超期处理
    for c in cur loop
    BEGIN
             --修改委托单的状态
             update delegate_credit dc set dc.status = 4 , dc.update_time=sysdate where dc.id = c.id;
             --修改委托单领取状态
             update delegate_receive dr set dr.status = 4, dr.update_time=sysdate where dr.credit_id = c.id;                    
        
    END;
    end loop;
    
  --用户领取的委托到期处理
    for cdr in curdreceive loop
      BEGIN
          --修改委托单领取状态 为确认中状态
        if cdr.entrust_days<2
          then
              update delegate_receive d set d.status = 2, d.surplus_days = fun_get_holidays(sysdate, 1), d.update_time=sysdate where d.id = cdr.id;
        else
              update delegate_receive d set d.status = 2, d.surplus_days = fun_get_holidays(sysdate, 2), d.update_time=sysdate where d.id = cdr.id;
        end   if;
           
          update delegate_credit dc set dc.status = 3, dc.update_time=sysdate where dc.id = cdr.credit_id;
          
      END;
    end loop;
    
  --用户领取的委托单确认状态到期后的处理
    for cdrs in curdreceives loop
      BEGIN
          --修改委托单领取状态 为确认中状态
          update delegate_receive d  set d.status = 4, d.update_time=sysdate where d.id = cdrs.id;
          
          update delegate_credit dc set dc.status = 0, dc.update_time=sysdate where dc.id = cdrs.credit_id;
          
      END;
    end loop;
    
   --佣金比例的调整
    for cdRate in curRate loop
      begin
          -- 获取佣金比例
           for b in(select (dr.rate - nvl(dc.intermediary_rate,0)) rate  from delegate_rate_rule  dr 
                    inner join delegate_company dc on dr.company_id = dc.id
                    where dr.company_id = cdRate.Company_Id 
                    and (( dr.start_late_stage <= cdRate.Overstage  and   dr.end_late_stage >= cdRate.Overstage) 
                    or ( dr.start_late_stage <= cdRate.Overstage   and  dr.end_late_stage is null ) )
                    and rowNum<=1)
           loop
             v_rate:=b.rate;
           end loop;  
          -- 修改佣金比例
          update delegate_credit  dc set dc.rate=v_rate  where dc.id = cdRate.Id;
      
      end;
     end loop;
    
    commit;
    p_ReturnCode:=1;
   return;
   
end Pro_ToDoStateTransfer;
/

