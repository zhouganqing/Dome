create procedure PRO_INIDATA is
--create user:Tianxiangchuan
--use: 初始化当年节假日期
v_StartData date;
v_EndData date;
v_Week nvarchar2(10);
v_HTCount number;
v_Days number;
v_Count number;
begin
   --delete coll_holidays;
   select count(id) into v_Count from coll_holidays where to_number(to_char(holidays,'yyyy'))=to_number(to_char(sysdate,'yyyy'));
   
   if v_Count<=0 then  ---判断是否已经初始化
     
      select trunc(sysdate,'y') into v_StartData from dual;
      select last_day(add_months(trunc(sysdate,'y'),11)) into v_EndData from dual;

       while v_StartData<=v_EndData loop

         select count(*) into v_HTCount from coll_holidays_time where to_char(holidays,'yyyy-MM-dd')=to_char(v_StartData,'yyyy-MM-dd') and status=1;
         select to_char(v_StartData,'Dy') into v_Week from DUAL;

         if v_HTCount>0 then

             select days into v_Days from coll_holidays_time where to_char(holidays,'yyyy-MM-dd')=to_char(v_StartData,'yyyy-MM-dd');

             insert into coll_holidays(id,holidays,status,days,create_time,create_user) values(seq_coll_holidays.nextval,v_StartData,3,v_Days,sysdate,10000);
         
         elsif v_Week='星期四' then

           insert into coll_holidays(id,holidays,status,days,create_time,create_user) values(seq_coll_holidays.nextval,v_StartData,0,2,sysdate,10000);
           
         
         elsif v_Week='星期五' then

           insert into coll_holidays(id,holidays,status,days,create_time,create_user) values(seq_coll_holidays.nextval,v_StartData,0,2,sysdate,10000);


         elsif v_Week='星期六' then

           insert into coll_holidays(id,holidays,status,days,create_time,create_user) values(seq_coll_holidays.nextval,v_StartData,1,1,sysdate,10000);


         elsif v_Week='星期日' then

               insert into coll_holidays(id,holidays,status,days,create_time,create_user) values(seq_coll_holidays.nextval,v_StartData,2,0,sysdate,10000);

         else

              insert into coll_holidays(id,holidays,status,days,create_time,create_user) values(seq_coll_holidays.nextval,v_StartData,0,0,sysdate,10000);

         end if;
             v_StartData:= v_StartData + 1;
      end loop;
   end if;
end;
/

