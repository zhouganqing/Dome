create function FUN_GET_HOLIDAYS(p_DateTime date,p_Days number)
return number
is
--create user:Tianxiangchuan
--use: 返回自然日天数
 v_Days number;
begin
  select days+p_Days into v_Days from coll_holidays where to_char(holidays,'yyyy-MM-dd')=to_char(p_DateTime,'yyyy-MM-dd');
  return v_Days;
end ;
/

