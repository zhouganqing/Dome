create procedure InsertQuestion is
--录入常见问题
begin
  delete from COLL_QUESTIONS;
insert into COLL_QUESTIONS(ID,Title,Contents) values(SEQ_SYS_CITY.NEXTVAL,'问题1：什么是催收360服务平台？','答：催收360服务平台是深圳前海纵腾金融科技服务有限公司全力打造的一款通过高效整合企业及个人资源，快速消化金融市场不良资产、与品牌同名的APP应用程序。旨在向不良资产市场提供更贴合、更对称的处置服务，
从而大大降低不良资产的处置成本。
');
insert into COLL_QUESTIONS(ID,Title,Contents) values(SEQ_SYS_CITY.NEXTVAL,'问题2：什么是资格认证？','答：为了保障您的资金安全及债权人的资料以及其他安全，您需要进行相关资格认证后方可进行任务领取和操作。
资格认证信息包括：身份证信息认证、工作信息认证。
请您确保提交资料的真实性，若经检测出虚假信息，系统将会取消您的操作资格。若涉嫌恶意信息作假或盗用他人信息，涉及犯罪的将移送公安机关处理。
');
insert into COLL_QUESTIONS(ID,Title,Contents) values(SEQ_SYS_CITY.NEXTVAL,'问题3：资格认证需要多长时间？','答：如果你提交的资料真实有效，我们将会在30分钟-2个工作日内为你进行资格审核。如遇高峰期，审核时间可能会有所延迟。
');
insert into COLL_QUESTIONS(ID,Title,Contents) values(SEQ_SYS_CITY.NEXTVAL,'问题4：如何查看任务详情？','答：为保护用户隐私安全，您在任务大厅及推荐中心看到的任务信息仅为该任务的基础信息，只有当您成功领取了任务后，方能查看任务的完整信息。
领取任务后，可点击个人中心“待办任务”－＞任一条未开始或执行中的任务，查看任务详情
');
insert into COLL_QUESTIONS(ID,Title,Contents) values(SEQ_SYS_CITY.NEXTVAL,'问题5：什么是任务的剩余天数？可以延长吗？','答：每个任务的持有期默认为３天，有效期结束后，任务将回到任务大厅供其他用户领取／催收。
剩余天数对应的是持有期剩余天数。
您在为该任务进行填写记录时，可对任务持有期进行延长，可延长至6天。每个任务仅能延长一次。
');
insert into COLL_QUESTIONS(ID,Title,Contents) values(SEQ_SYS_CITY.NEXTVAL,'问题6：什么是提前退回？','答：每用户持有的任务数上限为20个，当您当前持有任务为20件时，您将暂时不能领取新的任务。若您想继续领取新任务，可对某些任务进行提前退回操作。但需注意，每天最多可提前退回两个任务。
');
insert into COLL_QUESTIONS(ID,Title,Contents) values(SEQ_SYS_CITY.NEXTVAL,'问题7：可以采用什么样的催收方式？','答：可使用电话或上门催收两种方式。需采取合法、文明方式进行催收。');
insert into COLL_QUESTIONS(ID,Title,Contents) values(SEQ_SYS_CITY.NEXTVAL,'问题8：为什么要真实填写催收记录？','答：填写真实催收记录是您是否对该任务开始的标志。只有当您填写了真实催收记录，该任务的状态才会从“未开始”进入到“执行中”，您才能在成功催收后获得该任务的佣金。
请您务必要如实填写催收记录，当系统检测到您涉嫌信息作假，系统将会取消您的佣金，情节严重者进行诉讼处理。
');
insert into COLL_QUESTIONS(ID,Title,Contents) values(SEQ_SYS_CITY.NEXTVAL,'问题9：什么是待确认的任务状态？','答：当某一任务持有期结束，将进入到“待确认”中状态。待确认的状态持续2个工作日，我们将在确认期对您该笔任务的佣金情况及业绩状态进行审核，待确认状态的任务不支持进行任何形式的操作。
');
insert into COLL_QUESTIONS(ID,Title,Contents) values(SEQ_SYS_CITY.NEXTVAL,'问题10：如何才能获得及计算佣金？','答：佣金的结算有以下条件：
1.  该任务处于您的持有期中（状态为执行中、或确认中）；
2.  您对该任务进行过真实催收记录填写；
3.  该任务的委托方收到该任务借款人的还款；
佣金计算公式：还款金额*佣金比例，如某任务的佣金比例为5%，借款人还款10000元，则您的佣金为10000*5%=500元

');
insert into COLL_QUESTIONS(ID,Title,Contents) values(SEQ_SYS_CITY.NEXTVAL,'问题11：何时能对佣金进行提现？','答：当您持有的某一任务接收到还款后，我们将实时更新您的佣金信息。您可前往我的->我的业绩进行查看。
每月16号，平台将对上一个自然月的佣金进行结算，您可对本月以前获得的所有佣金进行提现。
即3月16日时，您可以对2月份及以前获得的所有佣金进行提现。
');
insert into COLL_QUESTIONS(ID,Title,Contents) values(SEQ_SYS_CITY.NEXTVAL,'问题12：提现有什么限制？ ','答：每月最多可以发起3次提现。每次最低提现金额为100元，不足100元时，须一次性提现完毕。提现的款项将在发起申请后的2个工作日内到账。
');
   commit;
   return;
exception 
   when others Then
     rollback;
end;
/

