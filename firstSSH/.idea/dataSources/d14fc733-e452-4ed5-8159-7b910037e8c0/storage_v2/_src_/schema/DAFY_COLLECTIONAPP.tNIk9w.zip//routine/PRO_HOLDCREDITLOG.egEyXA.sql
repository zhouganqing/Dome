create procedure Pro_HoldCreditLog(p_ReturnCode out number) is
begin
declare
  begin
    --查询没有处理的Hold委托单
    for i in (select * from DELEGATE_CREDIT_LOG where flag=0 and ID=(select ID from DELEGATE_CREDIT where Status=0)) loop
         Update DELEGATE_CREDIT set
         id=i.Id, 
         contract_no=i.contract_no, 
         client_id=i.client_id, 
         principal=i.principal,  
         interest=i.interest,  
         breach=i.breach,   
         --overdue_stage=i.overdue_stage,   
         --overdue_days=i.overdue_days,  
         --rate=i.rate,  
         --entrust_days=i.entrust_days,  
         history_collection=i.history_collection,  
         special=i.special,  
         requirement=i.requirement,  
         litigation=i.litigation,   
         company_id=i.company_id,   
         status=i.status,   
         is_frozen=i.is_frozen,    
         delay_days=i.delay_days,   
         update_user=1, 
         update_time=sysdate,
         task_type=i.task_type,   
         loan_application=i.loan_application, 
         month_loan_rate=i.month_loan_rate, 
         month_service_rate=i.month_service_rate, 
         --overdue_begin_time=i.overdue_begin_time,  
         long_loan=i.long_loan,  
         loan_amount=i.loan_amount,   
         payment_amount=i.payment_amount,    
         payment_day=i.payment_day,    
         payment_number=i.payment_number,
         repayment_total=i.repayment_total;
         --更新为已处理
         update DELEGATE_CREDIT_LOG set flag=1;
         Commit;
   end loop;
   --删除已处理
   delete from DELEGATE_CREDIT_LOG where flag=1;
    p_ReturnCode:=1;
   return;
end;
   commit;
   return;
exception 
   when others Then
     rollback;
end;
/

