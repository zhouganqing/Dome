create procedure ClearDatas is
--create user:Tianxiangchuan
--use: 清除数据库表数据 （注：不要随便执行）
begin
     --委托客户还款信息
delete from DELEGATE_PAYMENT;
--委托客户地址
delete from DELEGATE_ADDRESS;
--委托客户联系方式
delete from DELEGATE_CONTACT;
--委托客户担保信息
delete from DELEGATE_GUARANTEE;
--委托方信息
--delete from DELEGATE_COMPANY;
--委托单领取
delete from DELEGATE_RECEIVE;
--委托单
delete from DELEGATE_CREDIT;
--委托客户
delete from DELEGATE_CLIENT;


--催收活跃区域
delete from COLL_ACTIVE_AREA;
--催收新增信息
delete from COLL_ADDINFO;
--催收申诉页面
delete from COLL_APPEAL;
--提前退回
delete from COLL_APPLY_RETURN;
--催收结果附件
delete from COLL_ATTACHMENT;
--催收员绑定的银行卡
delete from COLL_BANK_ACCOUNT;
--催收员奖金明细
delete from COLL_BONUS_DETAIL;
--投诉处理结果
delete from COLL_COMPLAINT;
--冻结催收员领取甲方所有的委托单
delete from COLL_COMPLAINT_HANDLE;
--用户反馈表
delete from COLL_FEEDBACKINFO;
   commit;
   return;
exception 
   when others Then
     rollback;
end;
/

