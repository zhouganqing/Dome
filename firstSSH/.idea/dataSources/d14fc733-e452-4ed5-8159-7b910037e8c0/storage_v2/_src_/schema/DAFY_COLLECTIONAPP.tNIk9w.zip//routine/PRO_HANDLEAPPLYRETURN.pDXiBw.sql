create procedure PRO_HandleApplyReturn
(p_ReturnCode out number)
IS
   --获取提前退回的委托单
   cursor cur is select dr.id, dr.status from  delegate_credit dr where dr.status=7;
begin
    --提前退回的委托单处理
    for c in cur loop
             --修改委托单的状态
             update delegate_credit d set d.status = 0, d.update_time = sysdate where d.id = c.id;
             --修改提前退回表
             update coll_apply_return cr set cr.status= '1', cr.handle_result ='agree', cr.handle_content ='', cr.update_time=sysdate
             where cr.credit_id = c.id;
                               
        
    end loop;
    
    commit;
    p_ReturnCode:=1;
    return;
   
end PRO_HandleApplyReturn;
/

