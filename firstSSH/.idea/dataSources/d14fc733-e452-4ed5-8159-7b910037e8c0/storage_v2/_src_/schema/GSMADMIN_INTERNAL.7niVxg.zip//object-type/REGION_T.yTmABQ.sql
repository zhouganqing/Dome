create TYPE region_t FORCE IS OBJECT ( name      varchar2(30),
                                            buddy     varchar2(30) );
/

