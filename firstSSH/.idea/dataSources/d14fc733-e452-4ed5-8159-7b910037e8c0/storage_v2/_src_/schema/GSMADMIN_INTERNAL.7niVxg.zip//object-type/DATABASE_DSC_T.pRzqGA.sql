create type database_dsc_t as object (
  version     number,

  do_sync_db   number,
  do_start_svc number,
  do_mod_local_svc number,

  want_ons_config number,

  db_number   number,
  cloud_name  varchar2(100),
  dbpool_name varchar2(100),
  region_name varchar2(100),
  num_inst    number,
  cpu_thld    number,
  disk_thld   number,
  do_force    number,

  service_list   service_dsc_list_t,
  region_list    region_list_t,
  gsm_list       gsm_list_t,

  ons_port  varchar2(256),
  scan_name varchar2(256),
  hostname  varchar2(256),
  db_type   char,

  status number
);
/

