create TYPE gsm_t FORCE IS OBJECT ( name      varchar2(30),
                                         endpoint  varchar2(4000),
                                         ons_port  number,
                                         region    varchar2(30) );
/

