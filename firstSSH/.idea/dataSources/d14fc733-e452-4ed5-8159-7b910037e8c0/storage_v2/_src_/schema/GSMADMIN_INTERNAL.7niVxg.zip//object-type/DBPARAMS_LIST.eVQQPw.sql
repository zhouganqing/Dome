create TYPE dbparams_list IS VARRAY(10) OF dbparams_t
/

