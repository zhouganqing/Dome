create procedure prc_collect_PAelement(p_IdCredit cs_credit.id%type,p_ReturnCode out varchar2) is
       error_info                  varchar2(1000);
       -- Author  : MaJianFeng
       -- Create Date : 2018-06-06
       -- Purpose : put credit data into decision_element_data_pa_PA table;
       v_ContractNo                cs_credit.contract_no%type;
       v_AppDate                   cs_credit.app_date%type;
       v_CommitTime                cs_credit.commit_time%type;
       v_InterCode                 cs_credit.inter_code%type;
       v_IdSa                      cs_credit.id_sa%type;
       v_IdDsm                     number;
       v_SaName                    sys_user_list.user_name%type;
       v_SaMobile                  sys_user_list.phone%type;
       v_SaIdent                   sys_user_list.ident%type;
       v_SaInDate                  sys_user_list.update_time%type;

       v_CreditType                cs_credit.credit_type%type;
       v_PayAmount                 cs_credit.pay_amount%type;
       v_CreditAmount              cs_credit.credit_amount%type;
       v_InitPay                   cs_credit.init_pay%type;
       v_Price                     cs_credit.price%type;
       v_Annuity                   cs_credit.annuity%type;

       v_IdPerson                  cs_person.id%type;
       v_PersonName                cs_person.name%type;
       v_Ident                     cs_person.ident%type;
       v_IdentAuth                 cs_person.ident_auth%type;
       v_IdentExp                  cs_person.ident_exp%type;
       v_Birthday                  varchar2(20);
       v_Age                       integer;
       v_Sex                       cs_person.sex%type;
       v_National                  cs_person.national%type;
       v_PersonMobile              varchar2(100);
       v_OfficeTel                 varchar2(100);

       v_IdSellerPlace             sellerplace.id%type;
       v_DealerName                sellerplace.name%type;
       v_PosCode                   sellerplace.pos_code%type;
       v_Province                  sellerplace.province%type;
       v_City                      sellerplace.city%type;
       v_DealerActivityStart       sellerplace.activity_start%type;
       v_Address                   sellerplace.address%type;

       v_AreaCode                  cn_city_list.area_code%type;

       v_IdSeller                  seller.id%type;
       v_SellerName                seller.name%type;
       v_SellerActivityStart       seller.activity_start%type;

       v_IdProduct                 product.id%type;
       v_ProdCode                  product.prod_code%type;
       v_ProdName                  product.prod_name%type;
       v_PaymentNum                product.payment_num%type;
       v_ProdType                  product.prod_type%type;
       v_SearchType                product.search_type%type;
       v_ValidFrom                 varchar2(20);
       v_ValidTo                   varchar2(20);
       v_Eir                       product.effective_interest_rate%type;
       v_MonthIr                   product.month_ir%type;
       v_MonthFee                  product.month_fee%type;
       v_AccountFee                product.account_fee%type;
       v_CsFee                     product.cs_fee%type;
       v_OverPayYear               product.overpay_year%type;
       v_CreditFrom                product.credit_from%type;
       v_CreditTo                  product.credit_to%type;

       v_OtherPersonType           registers.reg_val_name%type;

       v_GoodsVolume               number:=0;
       v_MaxGoodsPrice             number:=-1;
       v_MaxGoodsType              goods_type.name%type;
       v_MinGoodsPrice             number:=-1;
       v_MinGoodsType              goods_type.name%type;

       v_Position                  number:=-1;

       v_ElementType               decision_element_data_pa.element_type%type;
       v_Seq                       decision_element_data_pa.sort_code%type;

       v_FamilyPhoneUseCount           number:=0;
       v_OtherPhoneUseCount            number:=0;
       v_FamilyPhoneUseSameCityCount   number:=0;
       v_FamilyPhoneUseSamePosCount    number:=0;
       v_OtherPhoneUseSameCityCount    number:=0;
       v_OtherPhoneUseSamePosCount     number:=0;
       v_UseCity                   sellerplace.city%type;

       v_CurrentAddressCity        wechat_credit_address.current_address_city%type;
       v_CurrentCity               wechat_credit_address.current_city%type;

       v_IsRecall                  number:=0;
       v_SCI_Amount                status_change_information.credit_amount%type;
       v_SCI_Category              status_change_information.goodsnewcategory%type;
       v_NewCategory               varchar2(50);

       v_Temp                      varchar2(50);
       v_IdCredit                  number;
       v_Count                     integer;
       strSql                      varchar2(4000);
    begin
       delete decision_element_data_pa where id_credit=p_IdCredit;
       ---------------------------------------------------------
       prc_save_cs_contact(100000,p_IdCredit,p_ReturnCode);

       v_Seq:=0;
       v_ElementType:='Special';
       insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
            values(p_IdCredit,v_ElementType,'Random1',round(dbms_random.value(),6),v_Seq+1);
       insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
            values(p_IdCredit,v_ElementType,'Random2',round(dbms_random.value(),6),v_Seq+2);
       insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
            values(p_IdCredit,v_ElementType,'Random3',round(dbms_random.value(),6),v_Seq+3);
       insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
            values(p_IdCredit,v_ElementType,'Random4',round(dbms_random.value(),6),v_Seq+4);
       insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
            select p_IdCredit,v_ElementType,para_id,para_value,v_Seq+5 from sys_parameters where para_id='BIB';
       insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
            select p_IdCredit,v_ElementType,para_id,para_value,v_Seq+6 from sys_parameters where para_id='BIB2';
       v_Seq:=v_Seq + 6;
       ---------------------------------------------------------
       v_ElementType:='Credit';
       select a.contract_no,a.app_date,a.commit_time,a.inter_code,nvl(a.id_sa,''),nvl(b.user_name,'') sa_name,nvl(b.ident,'') sa_ident,nvl(b.phone,'') sa_mobile,
       nvl(trunc(b.update_time),trunc(sysdate)),a.credit_amount,a.init_pay,a.price,a.annuity,a.id_sellerplace,a.id_product,a.id_person,a.credit_type,nvl(a.pay_amount,0) pay_amount
         into v_ContractNo,v_AppDate,v_CommitTime,v_InterCode,v_IdSa,v_SaName,v_SaIdent,v_SaMobile,v_SaInDate,v_CreditAmount,v_InitPay,v_Price,v_Annuity,v_IdSellerPlace,v_IdProduct,v_IdPerson,v_CreditType,v_PayAmount
         from cs_credit a,sys_user_list b where a.id_sa=b.id(+) and a.id=p_IdCredit;
       --2017/03/21 update wangxiaofeng v_AppDate date 改为datetime
       strSql:='insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
                select '||p_IdCredit||','''||v_ElementType||''','||'''ContractNo'''||','''||v_ContractNo||''','||(v_Seq+1)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''AppDate'''||','''||to_char(v_AppDate,'yyyy-MM-dd HH24:mi:ss')||''','||(v_Seq+2)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''CommitTime'''||','''||to_char(v_CommitTime,'yyyy-MM-dd HH24:mi:ss')||''','||(v_Seq+3)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''InterCode'''||','''||v_InterCode||''','||(v_Seq+4)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''IdSa'''||','''||v_IdSa||''','||(v_Seq+5)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''SaName'''||','''||v_SaName||''','||(v_Seq+6)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''SaMobile'''||','''||v_SaMobile||''','||(v_Seq+7)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''SaIdent'''||','''||v_SaIdent||''','||(v_Seq+8)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''SaInDate'''||','''||to_char(v_SaInDate,'yyyy-MM-dd')||''','||(v_Seq+9)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''CreditAmount'''||','''||v_CreditAmount||''','||(v_Seq+10)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''InitPay'''||','''||v_InitPay||''','||(v_Seq+11)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''Price'''||','''||v_Price||''','||(v_Seq+12)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''Annuity'''||','''||v_Annuity||''','||(v_Seq+13)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''CreditType'''||','''||v_CreditType||''','||(v_Seq+14)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''PayAmount'''||','''||v_PayAmount||''','||(v_Seq+14)||' from dual';
       Execute immediate strSql;
       v_Seq:=v_Seq + 14;
       ---------------------------------------------------------
       v_ElementType:='Person';
       select name,ident,nvl(ident_auth,''),nvl(ident_exp,''),sex,nvl(fun_getreg_value(790,a.national),'汉')
         into v_PersonName,v_Ident,v_IdentAuth,v_IdentExp,v_Sex,v_National
         from cs_person a where id=v_IdPerson;

       if length(v_Ident)=15 then
           v_Birthday:=to_char(to_date('19'||substr(v_Ident,7,6),'yyyy-MM-dd'),'yyyy-MM-dd');
           select to_number(to_char(sysdate,'yyyy')) - to_number('19'||substr(v_Ident,7,2)) into v_Age from dual;
       else
           v_Birthday:=to_char(to_date(substr(v_Ident,7,8),'yyyy-MM-dd'),'yyyy-MM-dd');
           select to_number(to_char(sysdate,'yyyy')) - to_number(substr(v_Ident,7,4)) into v_Age from dual;
       end if;
       strSql:='insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
                select '||p_IdCredit||','''||v_ElementType||''','||'''Name'''||','''||v_PersonName||''','||(v_Seq+1)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''IdPerson'''||','''||v_IdPerson||''','||(v_Seq+2)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''Ident'''||','''||v_Ident||''','||(v_Seq+3)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''IdentAuth'''||','''||v_IdentAuth||''','||(v_Seq+4)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''IdentExp'''||','''||to_char(v_IdentExp,'yyyy-MM-dd')||''','||(v_Seq+5)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''Birthday'''||','''||v_Birthday||''','||(v_Seq+6)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''Age'''||','''||v_Age||''','||(v_Seq+7)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''Sex'''||','''||v_Sex||''','||(v_Seq+8)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''National'''||','''||v_National||''','||(v_Seq+9)||' from dual';

       Execute immediate strSql;

       v_Seq:=v_Seq + 9;
       ---------------------------------------------------------
       select count(1) into v_Count from sellerplace where id=v_IdSellerPlace;
       if v_Count=1 then
           v_ElementType:='SellerPlace';
           select name,province,city,address,activity_start,id_seller,pos_code,nvl(dsm_id,0)
             into v_DealerName,v_Province,v_City,v_Address,v_DealerActivityStart,v_IdSeller,v_PosCode,v_IdDsm
             from sellerplace where id=v_IdSellerPlace;
           v_UseCity:=v_City;

           insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
                  select p_IdCredit,v_ElementType,'ActiveDate',decode(min(update_time),null,'',to_char(min(update_time),'yyyy-mm-dd')),v_Seq+1
                  from sellerplace_status_change t where t.new_status=1 and t.id_sellerplace=v_IdSellerPlace;
           v_Seq:=v_Seq + 1;

           strSql:='insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
                    select '||p_IdCredit||','''||v_ElementType||''','||'''Name'''||','''||v_DealerName||''','||(v_Seq+1)||' from dual
                    union select '||p_IdCredit||','''||v_ElementType||''','||'''Province'''||','''||v_Province||''','||(v_Seq+2)||' from dual
                    union select '||p_IdCredit||','''||v_ElementType||''','||'''PosCode'''||','''||v_PosCode||''','||(v_Seq+3)||' from dual
                    union select '||p_IdCredit||','''||v_ElementType||''','||'''City'''||','''||v_City||''','||(v_Seq+4)||' from dual
                    union select '||p_IdCredit||','''||v_ElementType||''','||'''Address'''||','''||v_Address||''','||(v_Seq+5)||' from dual';
                    --union select '||p_IdCredit||','''||v_ElementType||''','||'''ActiveDate'''||','''||to_char(v_DealerActivityStart,'yyyy-MM-dd')||''','||(v_Seq+6)||' from dual';

           Execute immediate strSql;

           --wangxiaofeng 2017/03/03 update begin----
           /*select area_code into v_AreaCode from cn_city_list where rownum=1 and province=v_Province and city=v_City;
           strSql:='insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
                   select '||p_IdCredit||','''||v_ElementType||''',''AreaCode'','''||v_AreaCode||''','||(v_Seq+7)||' from dual';
           Execute immediate strSql;

           strSql:='insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
                   select '||p_IdCredit||','''||v_ElementType||''',''RiskCate'',risk_cate,'||(v_Seq+8)||' from mv_DF_POS_RISK_CATE_GL where pos_code='''||v_PosCode||'''';
           Execute immediate strSql;

           strSql:='insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
                   select '||p_IdCredit||','''||v_ElementType||''',''RiskCate_Challenge'',risk_cate_Challenge,'||(v_Seq+9)||' from mv_DF_POS_RISK_CATE_GL where pos_code='''||v_PosCode||'''';
           Execute immediate strSql;*/
           for c in(select area_code from cn_city_list
                     where rownum=1 and province=v_Province and city=v_City
             )loop
              insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
                   values(p_IdCredit,v_ElementType,'AreaCode',c.area_code,v_Seq+7);
              v_Seq:=v_Seq + 7;
           end loop;

           insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
             select p_IdCredit,v_ElementType,'RiskCate',risk_cate,v_Seq+1 from mv_df_pos_risk_cate_gl
             where pos_code=v_PosCode;

           insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
             select p_IdCredit,v_ElementType,'RiskCate_Challenge',risk_cate_Challenge,v_Seq+2 from mv_df_pos_risk_cate_gl
             where pos_code=v_PosCode;

           v_Seq:=v_Seq + 2;

           --wangxiaofeng 2017/03/03 update end----

           --AfPosCate:反欺诈门店等级类别，取于表RISK_CONTROL.DF_AF_GSPN，当status=a中的字段AF_TYPE 2016/03/16 wangxiaofeng
           insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
           select p_IdCredit,v_ElementType,'AfPosCate',nvl(max(t.af_type),0),v_Seq+10 from mv_df_af_gspn t
           where t.status='a' and t.pos_code=v_PosCode;

           v_Seq:=v_Seq + 9;
           ---------------------------------------------------------
           v_ElementType:='Seller';
           select name,province,city,activity_start
             into v_SellerName,v_Province,v_City,v_SellerActivityStart
             from seller where id=v_IdSeller;

           strSql:='insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
                    select '||p_IdCredit||','''||v_ElementType||''','||'''Name'''||','''||v_DealerName||''','||(v_Seq+1)||' from dual
                    union select '||p_IdCredit||','''||v_ElementType||''','||'''Province'''||','''||v_Province||''','||(v_Seq+2)||' from dual
                    union select '||p_IdCredit||','''||v_ElementType||''','||'''City'''||','''||v_City||''','||(v_Seq+3)||' from dual
                    union select '||p_IdCredit||','''||v_ElementType||''','||'''ActiveDate'''||','''||to_char(v_SellerActivityStart,'yyyy-MM-dd')||''','||(v_Seq+4)||' from dual';
           Execute immediate strSql;

           select count(1) into v_Count from sellerplace where id_seller=v_IdSeller;
           strSql:='insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
                   select '||p_IdCredit||',''Seller'',''DealerCount'','''||v_Count||''','||(v_Seq+5)||' from dual';
           Execute immediate strSql;
       end if;
       v_Seq:=v_Seq + 5;
       ---------------------------------------------------------
       --machaochun 2017/10/30 添加生成循环现金贷的元素

       if v_CreditType in ('SC', 'CY','SP','POS') then
         --SCTD_RiskCate：交叉现金贷同盾等级分类 yangzhenxian 2017/08/22
         for w in(with TD as (
            select
            a.associated_id as id_credit
            ,max(case when rule_no in (1044388,1053416) then extra_data end) as extra_data2_3m
            from WFI_FRAUD_METRIX_RESULT  a
            join WFI_FRAUD_METRIX_RULE b on a.id=b.fraud_metrix_result_id
            where a.event_name='Credit' and a.associated_id=p_IdCredit
            group by a.associated_id )
            select a.sctd_riskcate
            from  TD td
            join MV_DF_XS_TD_RISK_CATE_GL a on nvl(td.extra_data2_3m,0)=a.extra_data2_3m
          )loop
           insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
           values( p_IdCredit,'HardCheck','*','SCTD_RiskCate',w.sctd_riskcate,v_Seq+1 );
           v_Seq:=v_Seq + 1;
          end loop;
       end if;

       --wangxiaofeng 2016/11/15
       if v_CreditType in ('SC','POS') then

         for c in(select pos_code
                   from(select b.pos_code,row_number() over(order by a.commit_time desc) num
                        from cs_credit a,sellerplace b
                        where a.id_sellerplace=b.id and a.status in('a','p','k')
                        and a.commit_time<=trunc(sysdate-90) and a.id_person=v_IdPerson)
                   where num=1
           )loop
             --ScPosCode:交叉现金贷对应的pos贷来自的门店
             insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
             values(p_IdCredit,'SellerPlace','ScPosCode',c.pos_code,v_Seq+1);
             v_Seq:=v_Seq + 1;

             for r in(select t.risk_cate,t.risk_cate_challenge from mv_df_xs_pos_risk_cate_gl t
                       where t.pos_code=c.pos_code and rownum=1
               )loop
                 --ScRiskCate:交叉贷虚拟门店类别
                 insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
                 values(p_IdCredit,'SellerPlace','ScRiskCate',r.risk_cate,v_Seq+1);
                 v_Seq:=v_Seq + 1;
                 --ScRiskCate_Challenge:交叉贷虚拟门店类别
                 insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
                 values(p_IdCredit,'SellerPlace','ScRiskCate_Challenge',r.risk_cate_challenge,v_Seq+1);
                 v_Seq:=v_Seq + 1;
                 --wangxiaofeng 2017/03/03
                 --ScRiskCate:交叉贷虚拟门店类别
                 insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
                 values(p_IdCredit,'SellerPlace','RiskCate',r.risk_cate,v_Seq+1);
                 v_Seq:=v_Seq + 1;
                 --ScRiskCate_Challenge:交叉贷虚拟门店类别
                 insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
                 values(p_IdCredit,'SellerPlace','RiskCate_Challenge',r.risk_cate_challenge,v_Seq+1);
                 v_Seq:=v_Seq + 1;
                 --wangxiaofeng 2017/03/03
               end loop;
           end loop;
       end if;

       if v_IdProduct!=0 then
         v_ElementType:='Product';
         select prod_code,prod_name,payment_num,decode(valid_from, null, '', to_char(valid_from, 'yyyy-MM-dd')),decode(valid_to, null, '', to_char(valid_to, 'yyyy-MM-dd')),
                effective_interest_rate,month_ir,month_fee,account_fee,cs_fee,overpay_year,init_pay,credit_from,credit_to,prod_type,search_type
           into v_ProdCode,v_ProdName,v_PaymentNum,v_ValidFrom,v_ValidTo,v_Eir,v_MonthIr,v_MonthFee,v_AccountFee,v_CsFee,v_OverPayYear,v_InitPay,v_CreditFrom,v_CreditTo,v_ProdType,v_SearchType
           from product where id=v_IdProduct;

         strSql:='insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
                  select '||p_IdCredit||','''||v_ElementType||''','||'''ProdCode'''||','''||v_ProdCode||''','||(v_Seq+1)||' from dual
                  union select '||p_IdCredit||','''||v_ElementType||''','||'''ProdName'''||','''||v_ProdName||''','||(v_Seq+2)||' from dual
                  union select '||p_IdCredit||','''||v_ElementType||''','||'''PaymentNum'''||','''||v_PaymentNum||''','||(v_Seq+3)||' from dual
                  union select '||p_IdCredit||','''||v_ElementType||''','||'''InitPay'''||','''||v_InitPay||''','||(v_Seq+4)||' from dual
                  union select '||p_IdCredit||','''||v_ElementType||''','||'''CreditFrom'''||','''||v_CreditFrom||''','||(v_Seq+5)||' from dual
                  union select '||p_IdCredit||','''||v_ElementType||''','||'''CreditTo'''||','''||v_CreditTo||''','||(v_Seq+6)||' from dual
                  union select '||p_IdCredit||','''||v_ElementType||''','||'''EIR'''||','''||v_Eir||''','||(v_Seq+7)||' from dual
                  union select '||p_IdCredit||','''||v_ElementType||''','||'''MonthIr'''||','''||v_MonthIr||''','||(v_Seq+8)||' from dual
                  union select '||p_IdCredit||','''||v_ElementType||''','||'''MonthFee'''||','''||v_MonthFee||''','||(v_Seq+9)||' from dual
                  union select '||p_IdCredit||','''||v_ElementType||''','||'''AccountFee'''||','''||v_AccountFee||''','||(v_Seq+10)||' from dual
                  union select '||p_IdCredit||','''||v_ElementType||''','||'''CsFee'''||','''||v_CsFee||''','||(v_Seq+11)||' from dual
                  union select '||p_IdCredit||','''||v_ElementType||''','||'''OverPayYear'''||','''||v_OverPayYear||''','||(v_Seq+12)||' from dual
                  union select '||p_IdCredit||','''||v_ElementType||''','||'''ProdType'''||','''||v_ProdType||''','||(v_Seq+13)||' from dual
                  union select '||p_IdCredit||','''||v_ElementType||''','||'''ValidFrom'''||','''||v_ValidFrom||''','||(v_Seq+14)||' from dual
                  union select '||p_IdCredit||','''||v_ElementType||''','||'''SearchType'''||','''||v_SearchType||''','||(v_Seq+15)||' from dual';
         Execute immediate strSql;
         v_Seq:=v_Seq + 15;
         if v_ValidTo is not null then
             insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
             select p_IdCredit,''||v_ElementType||'','ValidTo',''||v_ValidTo||'',(v_Seq+1) from dual;
             v_Seq:=v_Seq + 1;
         end if;
       end if;
       ---------------------------------------------------------
       v_ElementType:='Photo';
       for photo in (select file_name,fun_getreg_value(775,a.photo_type) photo_type from cs_fast_photo a where id_credit=p_IdCredit)
       loop
            insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,nvl(photo.photo_type,'#'),photo.file_name,v_Seq+1);
            v_Seq:=v_Seq + 1;
       end loop;

       --元素[Photo.Count]逻辑修改至：不会对同类型照片重复累加 yangzhenxian 2018-04-26 update
       insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
       select p_IdCredit,v_ElementType,'Count',count(distinct photo_type),v_Seq+1 from cs_fast_photo where id_credit=p_IdCredit;
       v_Seq:=v_Seq + 1;
       ---------------------------------------------------------
       v_ElementType:='Goods';
       for goods in (select b.name goods_category,c.name goods_type,producer,brand,goods_price from cs_goods a,goods_category b,goods_type c
              where a.id_goods_category=b.id and a.id_goods_type=c.id and a.id_credit=p_IdCredit)
       loop
           if v_MaxGoodsPrice=-1 or v_MaxGoodsPrice<goods.goods_price then
              v_MaxGoodsPrice:=goods.goods_price;
              v_MaxGoodsType:=goods.goods_type;
           end if;

           if v_MinGoodsPrice=-1 or v_MinGoodsPrice>goods.goods_price then
              v_MinGoodsPrice:=goods.goods_price;
              v_MinGoodsType:=goods.goods_type;
           end if;

           insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,'Category',goods.goods_category,v_Seq+1);
           insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,'GoodsType',goods.goods_type,v_Seq+2);
           insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,'Producer',goods.producer,v_Seq+3);
           insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,'Brand',goods.brand,v_Seq+4);
           v_Seq:=v_Seq + 4;
           v_GoodsVolume:=v_GoodsVolume+1;
       end loop;
       insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,'MaxPrice',v_MaxGoodsPrice,v_Seq+1);
       insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,'MaxGoodsType',v_MaxGoodsType,v_Seq+2);
       insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,'MinGoodsType',v_MinGoodsType,v_Seq+3);
       insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,'GoodsVolume',v_GoodsVolume,v_Seq+4);
       v_Seq:=v_Seq + 3;
       --wangxiaofeng 2017/02/15  update 2017/03/21
       --针对不同手机产品生成官方价格：商品为苹果手机，根据型号Brand取对应的官方价格；
       --商品为非苹果手机，根据品牌Producer取对应的官方价格。
       --如果商品没有对应的官方价格，或申请多个商品，则不生成元素。

         for c in(select b.offical_price
                   from cs_goods a,mv_df_af_goods_price b
                      where a.id_goods_category=7 and a.id_goods_type=52 and b.status=1 and rownum=1
                      and a.producer=b.producer and a.brand=b.brand and a.id_credit=p_IdCredit
                   union
                   select b.offical_price
                   from cs_goods a,mv_df_af_goods_price b,goods_type c
                      where a.id_goods_category=7 and a.id_goods_type=21 and b.status=1 and rownum=1
                      and a.producer=b.producer and a.id_credit=p_IdCredit
           )loop
             insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,'OfficalPrice',c.offical_price,v_Seq+4);
             v_Seq:=v_Seq + 1;
           end loop;
       --2017/03/29 wangxiaofeng 元素Goods.NewCategory，区分手机类型中的苹果与非苹果，其他类型不变
       for c in(with a as (select cc.id id_credit,cg.id_goods_category,cg.producer,
                 c.name goods_category,t.name goods_type,row_number() over(order by cg.goods_price desc) rn
                from cs_credit cc
                join cs_goods cg on cc.id=cg.id_credit
                join goods_category c on cg.id_goods_category=c.id
                join goods_type t on cg.id_goods_type=t.id
                where cc.id=p_IdCredit)
                select case when id_goods_category=7 and (goods_type like '%苹果%' or producer like '%苹果%'
                   or upper(producer) like '%IPHONE%' or upper(producer) like '%APPLE%') THEN '苹果'
                   else to_char(goods_category) end as new_category
                from a where rn=1
         )loop
           insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
           values(p_IdCredit,v_ElementType,'NewCategory',c.new_category,v_Seq+1);
           v_NewCategory:=c.new_category;
           v_Seq:=v_Seq + 1;
         end loop;
       --2017/03/29 wangxiaofeng 元素Good.AvgPriceSameCityLast1M
       --商品在同一个城市过去一个月的平均价格(商品类型、品牌、型号相同)，如果没有相同的商品，平均价格为0
       for c in(with c as(select a.*,
                case when producer1 in('苹果','苹果手机','iPhone','苹果公司','apple') then '苹果'
                     when producer1 in('OPPO','0pp0','0ppo','opp0') then 'oppo'
                     when producer1 in('vivo','步步高','vlvo','opp0') then 'vivo'
                     when producer1 in('DIY','组装机' ,'组装电脑' ) then '组装'
                     else to_char(lower(producer1)) end as producer,
                case when replace(replace(lower(brand1),' ',''),'-','') in ('r9pius','r9puls','r9p','oppor9plus','r9pus','r9lus','r9，plus','r9（plus）','r9(plus)','r9plas') then 'r9plus'
                 when replace(replace(lower(brand1),' ',''),'-','') in ('oppor9') then 'r9'
                 when replace(replace(lower(brand1),' ',''),'-','') in ('xpialy5','x5play' ) then 'xplay5'
                 when replace(replace(lower(brand1),' ',''),'-','') like '%xplay5%高配%' then 'xplay5高配'
                 when replace(replace(lower(brand1),' ',''),'-','') in('x7pius','x7puls','x7p') then 'x7plus'
                 when replace(replace(lower(brand1),' ',''),'-','') in ('p9pius','p9puls') then 'p9plus'
                 else to_char(replace(replace(replace(lower(brand1),' ',''),'-',''),'红米','') )end as brand
                from
                (select cc.id,cc.contract_no,cg.goods_price,sp.city
                ,cg.id_goods_category,cg.id_goods_type,cg.producer producer1,cg.brand brand1,c.name as goods_category,t.name as goods_type
                ,row_number() over(partition by cc.id order by goods_price desc) as num_id
                from cs_credit cc
                join cs_goods cg on cc.id=cg.ID_CREDIT
                join goods_category c on cg.id_goods_category=c.id
                join goods_type t on cg.id_goods_type=t.id
                join sellerplace sp on cc.id_sellerplace=sp.id
                where cc.id=p_IdCredit
                )a where num_id=1)
                select nvl(max(b.avg_price),0) avg_price from mv_city_goods_avg_price b
                join c on c.city=b.city and c.goods_category=b.goods_category and c.brand=b.brand and c.producer=b.producer
         )loop
           insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,'AvgPriceSameCityLast1M',c.avg_price,v_Seq+1);
           v_Seq:=v_Seq + 1;
         end loop;
       ---------------------------------------------------------
       v_ElementType:='Contact';
       for contact in (select fun_getreg_value(395,t.contact_type) contact_type,t.contact_type cont_type,contact_value from cs_contact t where person_type='1' and id_credit=p_IdCredit)
       loop
           insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,contact.contact_type,contact.contact_value,v_Seq+1);
           v_Seq:=v_Seq + 1;

           if contact.cont_type='3' then
             v_OfficeTel:=contact.contact_value;
           end if;
           if contact.cont_type='2' then
             v_PersonMobile:=contact.contact_value;
           end if;
       end loop;
       ---------------------------------------------------------
       v_ElementType:='Address';
       for address in (select decode(address_type,1,'ResidentAddress',2,'CurrentAddress','CompanyAddress') address_type,province,city,region,town,street,building,room
              from cs_address where id_credit=p_IdCredit order by address_type)
       loop
           insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,address.address_type,'Province',address.province,v_Seq+1);
           insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,address.address_type,'City',address.city,v_Seq+2);
           insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,address.address_type,'Region',address.region,v_Seq+3);
           insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,address.address_type,'Town',address.town,v_Seq+4);
           insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,address.address_type,'Street',address.street,v_Seq+5);
           insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,address.address_type,'Building',address.building,v_Seq+6);
           insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,address.address_type,'Room',address.room,v_Seq+7);
           if address.address_type='CurrentAddress' then
             for c in(select area_code from cn_city_list
                      where rownum=1 and province=address.province and city=address.city
               )loop
                 v_AreaCode:=c.area_code;
                 insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                   values(p_IdCredit,v_ElementType,address.address_type,'AreaCode',v_AreaCode,v_Seq);
                 v_Seq:=v_Seq + 8;
               end loop;
           else
               v_Seq:=v_Seq + 7;
           end if;
       end loop;
       ---------------------------------------------------------
       v_ElementType:='OtherPerson';
       for otherperson in (select a.name,fun_getreg_value(decode(length(a.person_type),1,265,396),a.person_type) persontype,b.contact_value
              from cs_other_person a,cs_contact b where a.id_credit=b.id_credit and a.person_type=b.person_type and a.id_credit=p_IdCredit order by a.id)
       loop
           if instr(otherperson.persontype,'-')>0 then
              v_OtherPersonType:=substr(otherperson.persontype,1,instr(otherperson.persontype,'-')-1);
           else
              v_OtherPersonType:=otherperson.persontype;
           end if;
           insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,v_OtherPersonType,'Name',otherperson.name,v_Seq+1);
           insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,v_OtherPersonType,'ContactValue',otherperson.contact_value,v_Seq+2);

           v_Seq:=v_Seq + 2;
       end loop;

       ---------------------------------------------------------
       v_ElementType:='Career';

       for employer in (select nvl(fun_getreg_value(399,a.company_type),'') as company_type,nvl(fun_getreg_value(397,a.industry),'') as industry,a.position,
              nvl(b.university,a.company_name1) university,nvl(a.department,'') as department,decode(a.start_date, null, '', to_char(a.start_date, 'yyyy-MM-dd')) startdate,decode(a.end_date, null, '', to_char(a.end_date, 'yyyy-MM-dd')) enddate
              from cs_employer a,university b where a.company_name=b.id(+) and a.id_credit=p_IdCredit)
       loop
           v_Position:=employer.position;
           insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,'CompanyType',employer.company_type,v_Seq+1);
           insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,'Industry',employer.Industry,v_Seq+2);
           insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,'Position',employer.position,v_Seq+3);
           insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,'University',pkg_decision.filterStr(employer.university),v_Seq+4);
           insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,'Department',employer.department,v_Seq+5);
           insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,'StartDate',employer.startdate,v_Seq+6);
           if employer.enddate is not null then
               insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
                   (p_IdCredit,v_ElementType,'EndDate',employer.enddate,v_Seq+7);
               v_Seq:=v_Seq + 7;
           else
               v_Seq:=v_Seq + 6;
           end if;
       end loop;

       ---------------------------------------------------------
       v_ElementType:='Other';

       for experience in (select nvl(a.total_wk_exp,0) total_wk_exp,nvl(a.wk_income,0) wk_income,nvl(a.other_income,0) other_income,nvl(a.family_income,0) family_income,
              nvl(fun_getreg_value(11,a.education),'') education,nvl(ssi,'') ssi,nvl(a.cur_wk_exp,0) cur_wk_exp,fun_getreg_value(776,a.bank_name) bank_name,a.bank_no,a.branch,
              fun_get_ybscity(a.id_ybs_city,a.id_credit) bank_region,nvl(a.is_dd,0) is_dd,nvl(a.is_ssi,0) is_ssi,to_char(a.fst_date_pay, 'yyyy-MM-dd') fst_date_pay
              from cs_experience a where id_credit=p_IdCredit)
       loop
          if v_Position=9 then
               v_Temp:='LeftGraduateMonth';
          else
               v_Temp:='CurrentEmpMonth';
          end if;
          insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
                 (p_IdCredit,v_ElementType,v_Temp,experience.total_wk_exp,v_Seq+1);
          insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
                 (p_IdCredit,v_ElementType,'PersonIncome',experience.wk_income,v_Seq+2);
          insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
                 (p_IdCredit,v_ElementType,'OtherIncome',experience.other_income,v_Seq+3);
          insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
                 (p_IdCredit,v_ElementType,'FamilyIncome',experience.family_income,v_Seq+4);
          insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
                 (p_IdCredit,v_ElementType,'Education',experience.education,v_Seq+5);
          insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
                 (p_IdCredit,v_ElementType,'LengthOfSchooling',experience.ssi,v_Seq+6);
          insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
                 (p_IdCredit,v_ElementType,'BankName',experience.bank_name,v_Seq+7);
          insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
                 (p_IdCredit,v_ElementType,'BankNo',experience.bank_no,v_Seq+8);
          insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
                 (p_IdCredit,v_ElementType,'BankCity',experience.bank_region,v_Seq+9);
          insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
                 (p_IdCredit,v_ElementType,'Branch',experience.branch,v_Seq+10);
          insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
                 (p_IdCredit,v_ElementType,'IsDD',experience.is_dd,v_Seq+11);
          insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
                 (p_IdCredit,v_ElementType,'IsSSI',experience.is_ssi,v_Seq+12);
          insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
                 (p_IdCredit,v_ElementType,'SSI',experience.ssi,v_Seq+13);
          insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
                 (p_IdCredit,v_ElementType,'FirstPayDate',experience.fst_date_pay,v_Seq+14);

          v_Seq:=v_Seq + 14;
       end loop;

       v_ElementType:='FamilyInfo';
       for familyinfo in (select decode(id_spouse, 1, '未婚', 2, '已婚', '其它') mariage,nvl(child,0) children_count,fun_getreg_value(2, house_type) house_type,expense_month
                   from cs_family_info where id_credit=p_IdCredit)
       loop
          insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
                 (p_IdCredit,v_ElementType,'Marriage',familyinfo.mariage,v_Seq+1);
          insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
                 (p_IdCredit,v_ElementType,'ChildrenCount',familyinfo.children_count,v_Seq+2);
          insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
                 (p_IdCredit,v_ElementType,'HouseType',familyinfo.house_type,v_Seq+3);
          insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
                 (p_IdCredit,v_ElementType,'ExpenseMonth',familyinfo.expense_month,v_Seq+4);
          v_Seq:=v_Seq + 4;
       end loop;

       -----------------以下为需要计算的变量-----------------------------------------------
       --2017/03/21 wangxiaofeng  2017/03/29 wangxiaofeng update yangzhenxian 2017-12-22 update TotalAnnuity
       --添加元素Credit.TotalAnnuity，包括以下期款及费用 annuity+power_fee+insurance_fee+screen_fee+post_fee-COUPON_AMOUNT
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'Credit','*','TotalAnnuity',nvl(sum(TotalAnnuity),0),v_Seq+1
       from(select nvl(annuity,0)+nvl(power_fee,0)+nvl(insurance_fee,0)+nvl(broken_screen_service,0)+nvl(stag_insurance_service,0)
             -nvl(coupon_amount,0)+nvl(treasure_box_fee,0)+nvl(COMPREHENSIVE_INSURANCE,0) as TotalAnnuity
       from cs_credit_fee where id_credit=p_IdCredit);
       v_Seq:=v_Seq + 1;
       --2017/7/12 wangxiaofeng Credit.GiveuGlobleLimit 计算客户在申请此合同时即有钱包的总额度GLOBLE_LIMIT
       for c in (select t.total_limit from giveu_credit_eligible t where t.status in(1,2,8) and  t.id_person=v_IdPerson)
       loop
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)values
                 (p_IdCredit,'Credit','*','GiveuGlobleLimit',c.total_limit,v_Seq+1);
          v_Seq:=v_Seq + 1;
       end loop;
       --IsSAIdent客户申请时,身份证是否属于销售代表/销售经理/门店法人身份证  yangzhenxian 2017-12-06
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'HardCheck','*','IsSAIdent',case when sum(amount)>0 then 1 else 0 end,v_Seq+1
       from (
         select count(1) amount from sys_user_list a where upper(a.role_id) in('SA','DSM','MENTOR') and a.ident=v_Ident
         union
         select count(1) amount from seller where legal_ident=v_Ident);
       v_Seq:=v_Seq + 1;

       --AfSaCate:反欺诈销售等级类别，取于表RISK_CONTROL.DF_AF_GSPN_ABNORMAL，当status=a中的字段AF_TYPE 2016/03/16 wangxiaofeng
       insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
       select p_IdCredit,'SellerPlace','AfSaCate',nvl(max(t.af_type),0),v_Seq+6 from mv_df_af_gspn_abnormal t
       where t.status='a' and t.id_sa=v_IdSa;
       v_Seq:=v_Seq + 1;

       --IsMysteryIdent 客户申请时身份证是否属于暗访人员白名单(select ident from mv_WHITELIST_MYST_INVE where status='a')
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         select p_IdCredit,'HardCheck','*','IsMysteryIdent',decode(count(1),0,0,1),v_Seq+1
         from mv_WHITELIST_MYST_INVE t where status='a' and t.ident=v_Ident;
       v_Seq:=v_Seq + 1;

       ---客户现行合同的总贷款额---
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         select p_IdCredit,'HardCheck','*','SumActiveCreditAmount',nvl(sum(a.credit_amount),0),v_Seq+1
         from cs_credit a where a.id_person=v_IdPerson and a.status='a' and a.COMMIT_TIME<v_CommitTime;--2017-09-22增加时间范围 ;
       v_Seq:=v_Seq + 1;

       ---客户循环贷现行合同的总贷款额---
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         select p_IdCredit,'HardCheck','*','SumActiveCycleCreditAmount',nvl(sum(a.credit_amount),0),v_Seq+1
         from cycle_credit a where a.id_person=v_IdPerson and a.status='a' and a.CREATE_TIME<v_CommitTime;--2017-09-22增加时间范围 ;
       v_Seq:=v_Seq + 1;

       --此门店第一张合同的申请时间，status<>'r'
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         select p_IdCredit,'SellerPlace','*','FirstAppDate',to_char(nvl(min(trunc(a.commit_time)),trunc(sysdate)),'yyyy-mm-dd'),v_Seq+1
         from cs_credit a where a.id_sellerplace=v_IdSellerPlace and a.id_sa not in('800079','300079') and a.commit_time>to_date('2014-09-01','yyyy-mm-dd') and a.status!='r';
       v_Seq:=v_Seq + 1;

       --客户在申请此合同时，前30天内的合同总次数
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            select p_IdCredit,'HardCheck','*','ApplicationLast30Day',count(1),v_Seq+1 from cs_credit a where a.id_person=v_IdPerson
               and a.id<>p_IdCredit and trunc(a.commit_time)>=trunc(sysdate)-30 and a.COMMIT_TIME<v_CommitTime;--2017-09-22增加时间范围
       v_Seq:=v_Seq + 1;

       --客户在申请此合同时，当天取消的合同总数
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            select p_IdCredit,'HardCheck','*','CancleApplicationSameDay',count(1),v_Seq+1 from cs_credit a where a.id_person=v_IdPerson
               and trunc(a.commit_time)=trunc(sysdate) and a.status='t' and a.id<>p_IdCredit  and a.COMMIT_TIME<v_CommitTime;--2017-09-22增加时间范围
       v_Seq:=v_Seq + 1;

       --客户在申请此合同时前面一张合同的申请时间
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            select p_IdCredit,'HardCheck','*','PrevCommitTime',to_char(max(commit_time),'yyyy-MM-dd HH24:mi:ss'),v_Seq+1 from cs_credit
             where id_person=v_IdPerson and commit_time<=v_CommitTime and id!=p_IdCredit;
       v_Seq:=v_Seq + 1;

       --客户在申请此合同时前面一张通过的合同的申请时间，除拒绝和取消的合同外（状态为d/t/x/u的除外）update_time2016/11/30
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            select p_IdCredit,'HardCheck','*','MaxPrevCommitTime',to_char(max(commit_time),'yyyy-MM-dd HH24:mi:ss'),v_Seq+1 from cs_credit
             where id_person=v_IdPerson and commit_time<=v_CommitTime and credit_type in('SS','SC') and id!=p_IdCredit and status not in('d','t','x','u','r','q');
       v_Seq:=v_Seq + 1;

       --MaxPrevSSCommitTime:客户在申请此合同时前面一张消费贷通过的合同的申请时间，除拒绝和取消的合同外（状态为d/t/x的除外）
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            select p_IdCredit,'HardCheck','*','MaxPrevSSCommitTime',to_char(max(commit_time),'yyyy-MM-dd HH24:mi:ss'),v_Seq+1 from cs_credit
             where id_person=v_IdPerson and commit_time<=v_CommitTime and credit_type='SS' and id!=p_IdCredit and status not in ('d','t','x');
       v_Seq:=v_Seq + 1;

       --MaxPrevSCCommitTime:客户在申请此合同时前面一张现金贷通过的合同的申请时间，除拒绝和取消的合同外（状态为d/t/x的除外）
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            select p_IdCredit,'HardCheck','*','MaxPrevSCCommitTime',to_char(max(commit_time),'yyyy-MM-dd HH24:mi:ss'),v_Seq+1 from cs_credit
             where id_person=v_IdPerson and commit_time<=v_CommitTime and credit_type!='SS' and id!=p_IdCredit and status not in ('d','t','x');
       v_Seq:=v_Seq + 1;

       --客户在申请此合同时前面一张拒绝的合同的申请时间（状态为d）
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            select p_IdCredit,'HardCheck','*','RejectPrevCommitTime',to_char(max(commit_time),'yyyy-MM-dd HH24:mi:ss'),v_Seq+1 from cs_credit
             where id_person=v_IdPerson and commit_time<=v_CommitTime and (credit_type in('SS','SC','MQ') or (credit_type='QB' and id_sa is not null)) and id!=p_IdCredit and status='d';
       v_Seq:=v_Seq + 1;

       --RejectSSPrevCommitTime:客户在申请此合同时前面一张消费贷拒绝的合同的申请时间（状态为d）
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            select p_IdCredit,'HardCheck','*','RejectSSPrevCommitTime',to_char(max(commit_time),'yyyy-MM-dd HH24:mi:ss'),v_Seq+1 from cs_credit
             where id_person=v_IdPerson and commit_time<=v_CommitTime and credit_type='SS' and id!=p_IdCredit and status='d';
       v_Seq:=v_Seq + 1;

       --RejectSCPrevCommitTime:客户在申请此合同时前面一张现金贷拒绝的合同的申请时间（状态为d）
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            select p_IdCredit,'HardCheck','*','RejectSCPrevCommitTime',to_char(max(commit_time),'yyyy-MM-dd HH24:mi:ss'),v_Seq+1 from cs_credit
             where id_person=v_IdPerson and commit_time<=v_CommitTime and credit_type!='SS' and id!=p_IdCredit and status='d';
       v_Seq:=v_Seq + 1;

       --客户在申请此合同时前面一张合同的状态
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            select p_IdCredit,'HardCheck','*','PrevStatus',status,v_Seq+1 from cs_credit where id_person=v_IdPerson
               and id=(select max(id) from cs_credit where id_person=v_IdPerson and id!=p_IdCredit) and commit_time<v_CommitTime;--2017-09-22增加时间范围
       v_Seq:=v_Seq + 1;

       for pre_credit in (select to_char(max(commit_time),'yyyy-MM-dd HH24:mi:ss') commit_time,count(1) sumdue,sum(annuity) annuity from cs_credit where id_person=v_IdPerson and commit_time<=v_CommitTime and id!=p_IdCredit and status ='a')
       loop
           --客户在申请此合同时前面一张现行的合同的申请时间（状态为a)
           insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                values(p_IdCredit,'HardCheck','*','PrevApproveTime',pre_credit.commit_time,v_Seq+1);
           v_Seq:=v_Seq + 1;
           --客户在申请此合同时现行状态的合同数量(状态为a）
           --select count(sum(1)) into v_Count from v_previous_contract where prev_status='a' and id_credit=p_IdCredit group by id_credit;
           insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                values(p_IdCredit,'HardCheck','*','SumDue',pre_credit.sumdue,v_Seq+1);
           v_Seq:=v_Seq + 1;
           --客户在申请此合同时现行状态的合同的每期期款之和(状态为a）
           --select count(sum(prev_annuity)) into v_Count from v_previous_contract where prev_status='a' and id_credit=p_IdCredit group by id_credit;
           insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                values(p_IdCredit,'HardCheck','*','SumSurplusValueInstalment',pre_credit.annuity,v_Seq+1);
           v_Seq:=v_Seq + 1;
       end loop;
       --客户在申请此合同时通过状态的合同数量（状态为a/k/p）
       for pre_credit in (select count(1) sumdue,sum(credit_amount) sumamount from cs_credit where id_person=v_IdPerson and id!=p_IdCredit and status in ('a','k','p'))
       loop
           insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                values(p_IdCredit,'HardCheck','*','SumPassContract',pre_credit.sumdue,v_Seq+1);
           v_Seq:=v_Seq + 1;
           --客户在申请此合同时通过状态的合同贷款额之和（状态为a/k/p）
           --select count(sum(prev_credit_amount)) into v_Count from v_previous_contract where prev_status in ('a','k','p') and id_credit=p_IdCredit group by id_credit;
           insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                values(p_IdCredit,'HardCheck','*','SumPassCreditAmount',pre_credit.sumamount,v_Seq+1);
           v_Seq:=v_Seq + 1;
       end loop;

       --1. SumAgrSameOffPhoneLast6M:客户在申请此合同时，客户办公号码在过去6个月被其他客户（作为申请人办公号码）
       --使用过的可衡量30天逾期的合同数( select sum(agr_fpd30) from risk_control.df_pd_sum_gl)
       --2. SumDefSameOffPhoneLast6M:客户在申请此合同时，客户办公号码在过去6个月被其他客户（作为申请人办公号码）
       --使用过的出现30天逾期的合同数( select sum(fpd30) from risk_control.df_pd_sum_gl)
       for cs in(select nvl(sum(decode(a.agr_fpd30,null,0,a.agr_fpd30)),0) agr_fpd30,
                 nvl(sum(decode(a.fpd30,null,0,a.fpd30)),0) fpd30
                 from mv_df_pd_sum_gl a
                 join cs_contact b on b.id_credit=a.id_credit
                 where b.contact_type='3'
                 and b.contact_value in(select contact_value from cs_contact c
                                      where c.contact_type='3' and c.person_type='1' and c.id_credit=p_IdCredit)
                 and b.update_time>=trunc(v_CommitTime-180) and b.update_time<=v_CommitTime)
       loop
         insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                values(p_IdCredit,'HardCheck','*','SumAgrSameOffPhoneLast6M',cs.agr_fpd30,v_Seq+1);
           v_Seq:=v_Seq + 1;
         insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                values(p_IdCredit,'HardCheck','*','SumDefSameOffPhoneLast6M',cs.fpd30,v_Seq+1);
           v_Seq:=v_Seq + 1;
       end loop;

       --客户在申请此合同时，非客户本人的手机号码在过去6个月被其他客户用作非本人的手机号码相同且姓名不同的次数（除状态为t，r的合同）
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'HardCheck','*','MobileUseDiffNameCountLast6M',count(1),v_Seq+1
       from cs_credit t
       join cs_contact a on a.id_credit=t.id and a.person_type!='1' and a.contact_type='2'
       join cs_other_person b on b.id_credit=a.id_credit and b.person_type=a.person_type
       join (select e.name,g.contact_value from cs_contact g
            join cs_other_person e on e.id_credit=g.id_credit and e.person_type=g.person_type
            where g.person_type!='1' and g.contact_type='2' and g.id_credit=p_IdCredit
            ) c on c.contact_value=a.contact_value and b.name!=c.name
       where t.id_person!=v_IdPerson and t.status not in('t','r')
       and t.id_sa not in ('800079','888888','300079') and t.credit_type='SS'
       and t.commit_time>v_CommitTime-180 and t.commit_time<v_CommitTime;

       --BlackListCateFraudMetrix:同盾黑名单分类 2015/07/07 wangxiaofeng 2017/06/22由rule_name改为rule_no
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select  p_IdCredit,'HardCheck','*','BlackListCateFraudMetrix',substr(max(case when rule_no in (
          840098,2900153,2901749,2992525,840072,891780,891784,2900089,840080,840116,2992509,2992523,2992511,2901741,840076,
          891788,2901719,2992521,891804,840106,2901711,2992507,840096,891814,2901715,11532,14130,840100,78586,891806,891824,891808,
          5638201,5640421,5640431,5640411) then '9失信名单'
          when rule_no in (840086,2901725,891794,891816,2901743,840108,840118,2901751,891826) then '8灰名单'
          when rule_no in (2900149,891792,2901723,840084,584894) then '7已结案名单'
          when rule_no in (2900083,2901761,2901759,891782,840074,2901713,840082,891790,891802,840094,891812,891832,891834,891836,
            2901731,891828,840120,891830,840122,11534,840104,840126,44126,15726,840124,840128) then '6低风险失信名单'
          else '0其他' end),2,10) BlackListCateFraudMetrix,v_Seq+1
          from WFI_FRAUD_METRIX_RESULT a join WFI_FRAUD_METRIX_RULE t on a.id=t.fraud_metrix_result_id
          where a.event_name='Credit' and a.associated_id=p_IdCredit
          group by a.associated_id;

       /*鲁长江   2015-6-9*/ --2017/06/22由rule_name改为rule_no 确认不需要元素
       /*select count(1) into v_Count from WFI_FRAUD_METRIX_RESULT a,WFI_FRAUD_METRIX_RULE b where a.id = b.fraud_metrix_result_id and a.event_name = 'Credit' and a.associated_id=p_IdCredit
          and rule_no in (11544,2900431,2900433,2900429);
       if v_Count>0 then
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
              values(p_IdCredit,'HardCheck','*','MultiLoanFraudMetrix','1',1,v_Seq+1);
       else
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
              values(p_IdCredit,'HardCheck','*','MultiLoanFraudMetrix','0',1,v_Seq+1);
       end if;
       v_Seq:=v_Seq + 1;
       select count(1) into v_Count from WFI_FRAUD_METRIX_RESULT a,WFI_FRAUD_METRIX_RULE b where a.id = b.fraud_metrix_result_id and a.event_name = 'Credit' and a.associated_id=p_IdCredit
          and rule_no in (6826,6822,11534,2900145,2900147,2900097,2992521,2992507,2900105,2900083,2992525,2900089,2992511);
       if v_Count>0 then
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
              values(p_IdCredit,'HardCheck','*','BlackListFraudMetrix','1',1,v_Seq+1);
       else
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
              values(p_IdCredit,'HardCheck','*','BlackListFraudMetrix','0',1,v_Seq+1);
       end if;

       select nvl(max(b.extra_data),0) into v_Count
       from WFI_FRAUD_METRIX_RESULT a
       join WFI_FRAUD_METRIX_RULE b on a.id=b.fraud_metrix_result_id
       where b.rule_no in (2900439,2900433,2900437)
          and a.event_name='Credit' and a.associated_id=p_IdCredit;

       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
              values(p_IdCredit,'HardCheck','*','MultiLoanCountFraudMetrix',v_Count,1,v_Seq+1);
       v_Seq:=v_Seq + 1;
       v_Count:=0; */

       --1天内借款平台数MultiLoanTypeCountFraudMetrix1D: rule_name='新_1天内申请人身份证或手机在多个平台申请借款'，从extra_data中取值
       select nvl(max(b.extra_data),0) into v_Count
       from WFI_FRAUD_METRIX_RESULT a
       join WFI_FRAUD_METRIX_RULE b on a.id=b.fraud_metrix_result_id
       where b.rule_no in(1049650,1053410)
             and a.event_name='Credit' and a.associated_id=p_IdCredit;

       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
              values(p_IdCredit,'HardCheck','*','MultiLoanTypeCountFraudMetrix1D',v_Count,v_Seq+1);
       v_Seq:=v_Seq + 1;
       v_Count:=0;

       --1个月内借款平台数MultiLoanTypeCountFraudMetrix1M: rule_name='新_1个月内申请人身份证或手机在多个平台申请借款'，从extra_data中取值
       select nvl(max(b.extra_data),0) into v_Count
       from WFI_FRAUD_METRIX_RESULT a
       join WFI_FRAUD_METRIX_RULE b on a.id=b.fraud_metrix_result_id
       where b.rule_no in(1044438,1053414)
             and a.event_name='Credit' and a.associated_id=p_IdCredit;

       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
              values(p_IdCredit,'HardCheck','*','MultiLoanTypeCountFraudMetrix1M',v_Count,v_Seq+1);
       v_Seq:=v_Seq + 1;
       v_Count:=0;

       --3个月内借款平台数MultiLoanTypeCountFraudMetrix3M: rule_name='新_3个月内申请人身份证或手机在多个平台申请借款'，从extra_data中取值
       select nvl(max(b.extra_data),0) into v_Count
       from WFI_FRAUD_METRIX_RESULT a
       join WFI_FRAUD_METRIX_RULE b on a.id=b.fraud_metrix_result_id
       where b.rule_no in(1044388,1053416)
             and a.event_name='Credit' and a.associated_id=p_IdCredit;

       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
              values(p_IdCredit,'HardCheck','*','MultiLoanTypeCountFraudMetrix3M',v_Count,v_Seq+1);
       v_Seq:=v_Seq + 1;
       v_Count:=0;

       -- 1个月内借款平台类型MultiLoanTypeFraudMetrix1M: rule_name='新_1个月内申请人身份证或手机在多个平台申请借款', 根据rule_detail计算取值；
       --计算时排除本平台（本平台类型为'一般消费分期平台')，当命中多个平台类型时，只取一个，
       --按以下顺序优先(小额贷款:MC,一般消费:CFC_NL,大型消费:CFC,P2P网贷:P2P,其他:Z)
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'HardCheck','*','MultiLoanTypeFraudMetrix1M',
       case when replace(b.rule_detail,'一般消费分期平台:1','') like '%小额贷款%' then 'MC'
       when replace(b.rule_detail,'一般消费分期平台:1','') like '%一般消费分期平台%' then 'CFC_NL'
       when replace(b.rule_detail,'一般消费分期平台:1','') like '%消费金融%' then 'CFC'
       when replace(b.rule_detail,'一般消费分期平台:1','') like '%P2P%' then 'P2P'
       else 'Z' end,v_Seq+1
       from WFI_FRAUD_METRIX_RESULT a
       join WFI_FRAUD_METRIX_RULE b on a.id=b.fraud_metrix_result_id
       where b.rule_no in(1044438,1053414)
             and a.event_name='Credit' and a.associated_id=p_IdCredit;

       --3个月内借款平台类型MultiLoanTypeFraudMetrix3M: rule_name='新_3个月内申请人身份证或手机在多个平台申请借款', 根据rule_detail计算取值；
       --计算时排除本平台（本平台类型为'一般消费分期平台')，当命中多个平台类型时，只取一个，
       --按以下顺序优先(小额贷款:MC,一般消费:CFC_NL,大型消费:CFC,P2P网贷:P2P,其他:Z)
       --b.rule_name in ('新_3个月内申请人身份证或手机在多个平台申请借款')
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'HardCheck','*','MultiLoanTypeFraudMetrix3M',
       case when replace(b.rule_detail,'一般消费分期平台:1','') like '%小额贷款%' then 'MC'
       when replace(b.rule_detail,'一般消费分期平台:1','') like '%一般消费分期平台%' then 'CFC_NL'
       when replace(b.rule_detail,'一般消费分期平台:1','') like '%消费金融%' then 'CFC'
       when replace(b.rule_detail,'一般消费分期平台:1','') like '%P2P%' then 'P2P'
       else 'Z' end,v_Seq+1
       from WFI_FRAUD_METRIX_RESULT a
       join WFI_FRAUD_METRIX_RULE b on a.id=b.fraud_metrix_result_id
       where b.rule_no in(1044388,1053416)
             and a.event_name='Credit' and a.associated_id=p_IdCredit;

       --2017/03/23 wanxiaofeng 新增 HardCheck.MaxCpd,HardCheck.Last3mCpd
       for prev_instalment in
          (select to_char(min(date_due_first),'yyyy-MM-dd') as date_due_first,--客户最早的应还款日期
               max(cpd) as cpd,--客户在申请合同时其他合同的现在的未还的逾期天数，精确到天
               sum(remaining_amount) as remaining_amount, --客户在申请此合同时其他合同剩余的未还期金额（包含未到期的）
               sum(remaining_instal) as remaining_instal, --客户在申请此合同时其他合同剩余的未还期数之和（包含未到期的）
               max(max_dpd) as max_dpd,--客户在申请合同时历史上最大逾期天数，精确到天
               max(last_3m_dpd) as last_3m_dpd, --客户在申请合同时最近三个月（自然月）的最大逾期天数，精确到天
               max(max_cpd) as max_cpd,
               max(last_3m_cpd) as last_3m_cpd,
               to_char(to_date(substr(max(date_3m_dpd),4,8),'yyyy-MM-dd'),'yyyy-MM-dd') as date_3m_dpd,
               sum(m_paid_ndpd) as m_paid_ndpd,--客户在申请此合同前成功还款且没有逾期的期数总合
               sum(m_due) as m_due--客户在申请此合同时前面已经到期的期数之和
              from mv_DF_PD_SUM_GL where id_person=v_IdPerson)
       loop
            if prev_instalment.date_due_first is not null then
                insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                    values(p_IdCredit,'HardCheck','*','DateDueFirst',prev_instalment.date_due_first,v_Seq+1);
                v_Seq:=v_Seq + 1;

                insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                     values(p_IdCredit,'HardCheck','*','Cpd',prev_instalment.cpd,v_Seq+1);
                v_Seq:=v_Seq + 1;
                insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                     values(p_IdCredit,'HardCheck','*','RemainingAmount',prev_instalment.remaining_amount,v_Seq+1);
                v_Seq:=v_Seq + 1;
                insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                     values(p_IdCredit,'HardCheck','*','RemainingInstal',prev_instalment.remaining_instal,v_Seq+1);
                v_Seq:=v_Seq + 1;
                insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                     values(p_IdCredit,'HardCheck','*','MaxDpd',prev_instalment.max_dpd,v_Seq+1);
                v_Seq:=v_Seq + 1;
                insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                     values(p_IdCredit,'HardCheck','*','Last3mDpd',prev_instalment.last_3m_dpd,v_Seq+1);
                v_Seq:=v_Seq + 1;
                insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                     values(p_IdCredit,'HardCheck','*','MaxCpd',prev_instalment.max_cpd,v_Seq+1);
                v_Seq:=v_Seq + 1;
                insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                     values(p_IdCredit,'HardCheck','*','Last3mCpd',prev_instalment.last_3m_cpd,v_Seq+1);
                v_Seq:=v_Seq + 1;
                if prev_instalment.date_3m_dpd is not null then
                   insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                        values(p_IdCredit,'HardCheck','*','Date3mDpd',prev_instalment.date_3m_dpd,v_Seq+1);
                   v_Seq:=v_Seq + 1;
                end if;

                insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                     values(p_IdCredit,'HardCheck','*','MPaidNdpd',prev_instalment.m_paid_ndpd,v_Seq+1);
                v_Seq:=v_Seq + 1;
                insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                     values(p_IdCredit,'HardCheck','*','MDue',prev_instalment.m_due,v_Seq+1);
                v_Seq:=v_Seq + 1;
            end if;
       end loop;

       --2016/11/23 wangxiaofeng 在HardCheck类别里添加元素TdRateSaLAST1M：销售前一个月申请订单中命中同盾的占比 2017/06/22 添加rule_no wangxiaofeng
       if v_CreditType='SS' then
         for c in(with fraud_metrix as (
           select  a.associated_id as id_credit
           ,max(case when t.rule_no in(66218,66214,66222,66220,78586,15724,44140,11532,37334,44130,6826,6822,14128,44124,15728,14130,840080,840106,
                                         840098,2992507,840116,2992511,840072,840076,840096,2992509,840100,2900153,
                                        2901749,2992525,891780,891784,2900089,2992523,2901741,891808,891788,2901719,2992521,
                                        891804,2901711,891814,2901715,891806,891824,5638201,5640421,5640431,5640411)  then 1
           when t.rule_no in(1044388,1053416) and t.extra_data>1 then 1 else 0 end) as td_rule
           from wfi_fraud_metrix_result a
           join wfi_fraud_metrix_rule t on a.id=t.fraud_metrix_result_id
           where a.event_name='Credit' and a.update_time>=trunc(sysdate-30)
             and exists(select 1 from cs_credit cc where cc.commit_time>=trunc(sysdate-30) and cc.commit_time<v_CommitTime+10/24/60/60
             and cc.status not in('t','r')
                   and cc.credit_type='SS' and cc.id_sa=v_IdSa and cc.id=a.associated_id)
           group by a.associated_id)
           select round(sum(td.td_rule)/nvl(count(1),1),4) TdRateSaLAST1M
           from  cs_credit cc
           left join fraud_metrix td on cc.id=td.id_credit
           where cc.commit_time>=trunc(sysdate-30) and cc.commit_time<v_CommitTime+10/24/60/60 and cc.status not in('t','r')
           and cc.credit_type='SS' and cc.id_sa=v_IdSa
         )loop
           insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
           values( p_IdCredit,'HardCheck','*','TdRateSaLAST1M',c.TdRateSaLAST1M,v_Seq);
           v_Seq:=v_Seq + 1;
         end loop;

         --2018/05/29 majianfeng MultiLoanP2PCountFraudMetrix1M：近一个月命中同盾P2P网贷的次数元素代码
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
           SELECT p_IdCredit,'HardCheck','*','MultiLoanP2PCountFraudMetrix1M',nvl(
           (select MultiLoanP2PCountFraudMetrix1M from (SELECT a.ASSOCIATED_ID as id_credit,
               MAX(CASE WHEN INSTR(SUBSTR(RULE_DETAIL,instr(rule_detail, 'P2P网贷') + 6),',') > 0
               THEN SUBSTR(SUBSTR(RULE_DETAIL,instr(rule_detail, 'P2P网贷') + 6),1,instr(SUBSTR(RULE_DETAIL,instr(rule_detail, 'P2P网贷') + 6),',') - 1)
               ELSE SUBSTR(RULE_DETAIL, instr(rule_detail, 'P2P网贷') + 6, 3)END) AS MultiLoanP2PCountFraudMetrix1M
          from WFI_FRAUD_METRIX_RESULT a
          left join WFI_FRAUD_METRIX_RULE t
            on a.id = t.fraud_metrix_result_id
         where  a.ASSOCIATED_ID=p_IdCredit  and  A.EVENT_NAME = 'Credit'  AND T.RULE_NAME = '新_1个月内申请人身份证或手机在多个平台申请借款' and rule_detail like '%P2P网贷%'
         GROUP BY a.ASSOCIATED_ID) ), 0),v_Seq
          from dual;

         v_Seq:=v_Seq + 1;


         --2016/11/23 wangxiaofeng 在HardCheck类别里添加元素InterCodeRateSaLast1M：销售前一个月申请订单中内部代码拒绝的占比
         for c in(with all_list as (
                select case when b.status not in('t','r') then 1 else 0 end as app_num
                ,case when b.status not in('t','r') and b.inter_code in (3,4) then 1 else 0 end as rej_intercode
                from  cs_credit b
                where b.commit_time>=trunc(sysdate-30) and b.commit_time<=v_CommitTime and  b.credit_type='SS'
                and b.status not in('t','r') and b.id_sa=v_IdSa
                )
                select round(sum(rej_intercode)/nvl(sum(app_num),1),4) InterCodeRateSaLast1M
                from all_list a
         )loop
           insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
           values( p_IdCredit,'HardCheck','*','InterCodeRateSaLast1M',c.InterCodeRateSaLast1M,v_Seq);
           v_Seq:=v_Seq + 1;
         end loop;


        ---2017/10/27 machaochun    增加元素HardCheck. SameContactAppr /*客户申请合同填写的非本人联系方式在过去180天对应通过的合同数量*/
        /*2017/11/24 yangzhenxian   当前合同联系人180天内未被使用过则为空，当前合同联系人180天内被使用但使用的合同未被通过则为0
        ，被通过则累计通过次数,需要把0和null的情况区分开来*/
        insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
        select p_IdCredit,'HardCheck','*','SameContactAppr'
        ,sum(case when status in('a','p','k') then 1 when status is not null then 0 end),v_Seq+1 from
        (
        select distinct a.id curId,b.id ConId,b.status from
          (
          --合同联系人
          select c.id,c.commit_time,c.id_person,ct.contact_value from cs_credit c, cs_contact ct
          where c.id=ct.id_credit and ct.contact_type='2' and c.id=p_IdCredit--指定合同ID
          ) a
          left join
          (
          --合同联系人的订单
          select c.id,c.commit_time,c.id_person,ct.contact_value,c.status  from  cs_contact ct , cs_credit c
          where c.id=ct.id_credit and ct.contact_type='2'/* and c.status in ('a','p','k') */
          and c.id_sa not in (300079,800079,899999)--排除 id_sa in (300079,800079,899999)
          ) b
          on a.contact_value=b.contact_value and b.commit_time>a.commit_time-180 and b.commit_time<a.commit_time and a.id_person<>b.id_person
        );


          v_Seq:=v_Seq + 1;
       end if;


       if v_CreditType in ('CY','SC','POS') then
        ---2017/10/30 machaochun
          ---   添加元素HardCheck.MaxPrevSS_Payment_Num:客户在申请此合同时前面一张消费贷通过的合同的期数（状态为a/p/k的合同）
          ---   添加元素HardCheck.MaxPrevSS_Annuity：客户在申请此合同时前面一张消费贷通过的合同的期款，包含各种费用（状态为a/p/k的合同）
          for c in(with base as(
                select  max(a.id) as max_id_ss
                from cs_credit a
                where a.id_person=v_IdPerson and a.commit_time<v_CommitTime
                and  a.credit_type='SS' and a.status in ('a','p','k')  --获取前一张合同
              )
              ,element as(
              select distinct a.*,pr.payment_num as MaxPrevSS_Payment_Num
              ,c.annuity+nvl(c.power_fee,0)+nvl(ce.insurance_fee,0)-nvl(ce.COUPON_AMOUNT,0)+nvl(cg.BROKEN_SCREEN_SERVICE,0)+nvl(cg.STAG_INSURANCE_SERVICE,0)
               as MaxPrevSS_Annuity
              from base a
              join cs_credit c on c.id=a.max_id_ss
              join product pr on c.id_product=pr.id
              left join cs_experience ce on a.max_id_ss=ce.id_credit
              left join (select id_credit,sum(BROKEN_SCREEN_SERVICE) as BROKEN_SCREEN_SERVICE,sum(STAG_INSURANCE_SERVICE) as STAG_INSURANCE_SERVICE
                         from cs_goods
                         group by id_credit) cg on a.max_id_ss=cg.id_credit
              )
              select * from element  where rownum=1  --异常时如有多个cs_experience，取最新的
          )loop
             insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'HardCheck','*','MaxPrevSS_Payment_Num',c.MaxPrevSS_Payment_Num,v_Seq);
             v_Seq:=v_Seq + 1;
             insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'HardCheck','*','MaxPrevSS_Annuity',c.MaxPrevSS_Annuity,v_Seq);
             v_Seq:=v_Seq + 1;
          end loop;

          ---2017/10/30 machaochun
          ---   添加元素HardCheck.MaxPrevSS_RiskCate:客户在申请此合同时前面一张消费贷通过的合同的GSPN（状态为a/p/k的合同）
          ---   添加元素HardCheck.MaxPrevSS_PreRG：客户在申请此合同时前面一张消费贷通过的合同的PreRG（状态为a/p/k的合同）
          for c in(
              with base as(
                      select max(a.id) as max_id_ss
                      from cs_credit a
                      where a.id_person=v_IdPerson and a.commit_time<v_CommitTime
                      and  a.credit_type='SS' and a.status in ('a','p','k') --获取前一张合同
              )

              ,element as(
              select a.*
              ,case when u.RiskCate is null and u.RiskCate_Challenge is null   then 'new_pos'
                    when u.commit_time<date'2016-02-24' then u.RiskCate---16年2月24号之前在uw_info的表中只有一个字段riskcate
                    when u.commit_time<date'2016-07-20' then u.RiskCate_Challenge
                    else u.RiskCate end MaxPrevSS_RiskCate
              ,u.pre_rg as MaxPrevSS_PreRG
              from base a
              join mv_df_uw_info_gl u on a.max_id_ss=u.id
              )
              select * from element where rownum=1
          )loop
             insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'HardCheck','*','MaxPrevSS_RiskCate',c.MaxPrevSS_RiskCate,v_Seq);
             v_Seq:=v_Seq + 1;
             insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'HardCheck','*','MaxPrevSS_PreRG',c.MaxPrevSS_PreRG,v_Seq);
             v_Seq:=v_Seq + 1;
          end loop;
       end if;


       --2016/11/23 wangxiaofeng 在Credit类别里添加元素limit12:白名单销售内部代码12单量上限来自risk_control.df_uw_sa_whitelist的limit12字段
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'Credit','*','limit12',nvl(max(t.limit12),0),v_Seq
       from mv_df_uw_sa_whitelist t
       where t.status=1 and t.sa_id=v_IdSa;
       v_Seq:=v_Seq + 1;

       --2016/09/05 wangxiaofeng
       --是否查得同盾数据FraudMetrixActive (1, 查得; 0, 未查得)
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'HardCheck','*','FraudMetrixActive',decode(count(1),0,0,1),v_Seq+1
       from wfi_fraud_metrix_result t where t.event_name='Credit' and t.associated_id=p_IdCredit;
       v_Seq:=v_Seq + 1;
       -- 过去半小时内同盾未查得合同数FraudMetrixFailedCount 2017/03/03 update
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'HardCheck','*','FraudMetrixFailedCount',count(1),v_Seq+1
       from cs_credit a where not exists(select 1 from wfi_fraud_metrix_result b
                                           where b.event_name='Credit'  and b.associated_id=a.id)
                         and a.status not in('r','t') and nvl(a.inter_code,0) not in(3,4)
                         and a.credit_type=decode(v_CreditType,'SC','SC','SS')
                         and a.commit_time>=v_CommitTime-35/24/60 and a.commit_time<=v_CommitTime-5/24/60;
       v_Seq:=v_Seq + 1;

      /*ORG180D：最近180天查询机构数    yangzhenxian   2018-03-23*/
      for d in (
          with temp as(
          select ORG_CNT_RECENT_180_DAYS as ORG180D from sauron_history a where id_credit=p_IdCredit order by a.create_time desc)
          select * from temp where rownum=1
        )loop
        insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         values( p_IdCredit,'External','SauRon','ORG180D',d.ORG180D,v_Seq+1 );
        v_Seq:=v_Seq + 1;
        end loop;
      if v_CreditType in('SC','POS') then
        /*MaxPrevSS_FraudScoreCate：客户申请此合同时前面一张消费贷的前期评分卡得分50等分  yangzhenxian    2018-03-23*/
        for d in (
            with temp as(
            select c.id,u.prefraudscorecate as MaxPrevSS_FraudScoreCate from cs_credit c--消费贷
            left join mv_df_uw_info_gl u on c.id=u.id
            where c.id_person=v_IdPerson and c.credit_type='SS' and c.status in ('a','p','k')
            and c.app_date<v_AppDate and c.commit_time<v_CommitTime order by c.commit_time desc )
            select MaxPrevSS_FraudScoreCate from temp where rownum=1
          )loop
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
           values( p_IdCredit,'HardCheck','*','MaxPrevSS_FraudScoreCate',d.MaxPrevSS_FraudScoreCate,v_Seq+1 );
          v_Seq:=v_Seq + 1;
          end loop;

         /*MaxPrevSS_GrayScore：客户申请此合同时前面一张消费贷的前期评分卡得分50等分  yangzhenxian    2018-03-23*/
        for d in (
            with temp as(
            select c.id,mi.USER_GRAY_SCORE as USER_GRAY_SCORE from cs_credit c--消费贷
            left join (select id_credit,user_name
            ,nvl(A.USER_GRAY_SCORE,0) as USER_GRAY_SCORE
            ,row_number()over (partition by id_credit order by create_time desc) as rnk
            from external_miguan_basic_info a ) mi
            on c.id=mi.id_credit
            where c.id_person=v_IdPerson and c.credit_type='SS' and c.status in ('a','p','k')
            and c.app_date<v_AppDate and c.commit_time<v_CommitTime and mi.rnk=1 order by c.commit_time desc )
            select USER_GRAY_SCORE from temp where rownum=1
          )loop
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
           values( p_IdCredit,'External','JuxinliMiguan','MaxPrevSS_GrayScore',d.USER_GRAY_SCORE,v_Seq+1 );
          v_Seq:=v_Seq + 1;
          end loop;

        /*Last3mCpd_Cnt：最近3个月cpd>0的次数  yangzhenxian    2018-03-23*/
          select count(1) into v_Count from cs_credit c
          join df_pd_detail_gl pd on c.contract_no=pd.contract_no
          where c.id_person=v_IdPerson and c.CREDIT_TYPE in ('SS','SC','POS') and c.status in ('a','p','k')
          and c.app_date<v_AppDate and date_due>=add_months(v_AppDate,-3) and date_due < v_AppDate and  max_cpd>0 ;

          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
           values( p_IdCredit,'HardCheck','*','Last3mCpd_Cnt',v_Count,v_Seq+1 );
          v_Seq:=v_Seq + 1;
      end if;

       --蜜罐元素数据 2016/06/23 wangxiaofeng
       for mi in(select user_gray_score,contacts_one_blacklist_cnt,contacts_two_blacklist_cnt,
                  blacklist_category,user_register_cnt,iwop_susp_phone
                  from(
                  select nvl(a.user_gray_score,0) user_gray_score,nvl(a.contacts_one_blacklist_cnt,0) contacts_one_blacklist_cnt,
                  nvl(a.contacts_two_blacklist_cnt,0) contacts_two_blacklist_cnt,nvl(a.blacklist_category,'其他') blacklist_category,
                  nvl(a.user_register_cnt,0) user_register_cnt,decode(a.iwop_susp_phone,null,'否','是') iwop_susp_phone
                  from external_miguan_basic_info a
                  where a.create_time>=trunc(sysdate-1) and a.id_credit=p_IdCredit order by user_id desc
                  ) where rownum=1)
       loop
         --用户黑中介评分
         insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         values( p_IdCredit,'External','JuxinliMiguan','GrayScore',mi.user_gray_score,v_Seq + 1);
         --一阶联系人黑名单人数
         insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         values( p_IdCredit,'External','JuxinliMiguan','PhoneBlackCNTOne',mi.contacts_one_blacklist_cnt,v_Seq + 2);
         --二阶联系人黑名单人数
         insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         values( p_IdCredit,'External','JuxinliMiguan','PhoneBlackCNTTwo',mi.contacts_two_blacklist_cnt,v_Seq + 3);
         --黑名单类型
         insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         values( p_IdCredit,'External','JuxinliMiguan','BlackType',mi.blacklist_category,v_Seq + 4);
         --注册机构个数
         insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         values( p_IdCredit,'External','JuxinliMiguan','RegisterCNT',mi.user_register_cnt,v_Seq + 5);
         --身份证是否组合过其他电话号码 返回结果为是否
         insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         values( p_IdCredit,'External','JuxinliMiguan','SameIdentDiffPhone',mi.iwop_susp_phone,v_Seq + 6);
         v_Seq:=v_Seq + 7;
       end loop;

       -- /*蜜罐一介联系人总数*/ 2017/10/27 machaochun   增加元素External. JuxinliMiguan. ContactOneCNT
      insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
      select p_IdCredit,'External','JuxinliMiguan','ContactOneCNT', t.contacts_class1_cnt ,v_Seq+1
      from (  select contacts_class1_cnt from EXTERNAL_MIGUAN_BASIC_INFO  where id_credit=p_IdCredit  order by create_time ) t where rownum=1;
      v_Seq:=v_Seq + 1;


      -------begin 2016/08/31 wangxiaofeng-----
      if v_City is not null then
        --CityFirstAppDate 消费贷开业城市提交第一单申请的时间，status<>'r'
        insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         select p_IdCredit,'SellerPlace','*','CityFirstAppDate',to_char(nvl(min(trunc(a.commit_time)),trunc(sysdate)),'yyyy-mm-dd'),v_Seq+1
         from cs_credit a,sellerplace b
         where a.id_sellerplace=b.id and a.id_sa not in(800079,300079)
         and a.commit_time>to_date('2014-09-01','yyyy-mm-dd') and a.status!='r' and b.province=v_Province and b.city=v_City;
        v_Seq:=v_Seq + 1;
        --NewSARateSameDSM: 销售经理名下入职未满一个月的销售人数占比, 销售入职时间用销售提交第一单申请的时间SaFirstAppDate
        insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
        select p_IdCredit,'Credit','*','NewSARateSameDSM',round(max(t.newsacnt)/nvl(max(t.sacnt),1),3),v_Seq+1
        from mv_uw_newsarate_1d t where t.id_dsm=v_IdDsm;
        v_Seq:=v_Seq + 1;
        --SAQuitRateSameDSM60D: 销售经理名下最近60天做单的销售中，离职人数/总人数
        insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
        select p_IdCredit,'Credit','*','SAQuitRateSameDSM60D',round(max(t.sa_quit)/nvl(max(t.sa_cnt),1),3),v_Seq+1
        from mv_uw_saquitrate_60d t where t.id_dsm=v_IdDsm;
        v_Seq:=v_Seq + 1;
      end if;

      --BRMultiLoanCountNotBank12M: 最近12个月身份证或手机在非银行借款次数，排除本机构，取ident_notbank,mobilephone_notbank的较大值
      insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
      select p_IdCredit,'External','BaiRong','BRMultiLoanCountNotBank12M',
      case when (nvl(t1.al_m12_id_notbank_allnum,0)-nvl(t1.al_m12_id_notbank_selfnum,0))-
      (nvl(t1.al_m12_cell_notbank_allnum,0)-nvl(t1.al_m12_cell_notbank_selfnum,0))>0 then
      (nvl(t1.al_m12_id_notbank_allnum,0)-nvl(t1.al_m12_id_notbank_selfnum,0)) else
      (nvl(t1.al_m12_cell_notbank_allnum,0)-nvl(t1.al_m12_cell_notbank_selfnum,0)) end,
      v_Seq+1
      from external_br_applyloan t1 where t1.id_credit=p_IdCredit;
      v_Seq:=v_Seq + 1;
      --BRMultiLoanCountBank12M: 最近12个月身份证或手机在银行借款次数，取ident_bank,mobilephone_bank较大值
      insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
      select p_IdCredit,'External','BaiRong','BRMultiLoanCountBank12M',
      case when nvl(t1.al_m12_id_bank_allnum,0)-nvl(t1.al_m12_cell_bank_allnum,0)>0 then
      nvl(t1.al_m12_id_bank_allnum,0) else
      nvl(t1.al_m12_cell_bank_allnum,0) end,
      v_Seq+1
      from external_br_applyloan t1 where t1.id_credit=p_IdCredit;
      v_Seq:=v_Seq + 1;
      --BRCreditcardDef3M: 最近3个月信用卡是否逾期
      select count(1) into v_Count
      from external_br_accountchangemonth t
      where t.acm_m1_credit_def is not null and t.acm_m2_credit_def is not null
       and t.acm_m3_credit_def is not null and t.id_credit=p_IdCredit;
      if v_Count>=1 then
        --BRCreditcardDef3M: 最近3个月信用卡是否逾期
        insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
        select p_IdCredit,'External','BaiRong','BRCreditcardDef3M',
        nvl(t.acm_m1_credit_def,0)+nvl(t.acm_m2_credit_def,0)+nvl(t.acm_m3_credit_def,0),v_Seq+1
        from external_br_accountchangemonth t where t.id_credit=p_IdCredit;
        v_Seq:=v_Seq + 1;
      end if;
      --BRScorecardActive: 是否命中百融评分卡(1,命中; 0,未命中)，满足以下条件之一即命中
      insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
      select p_IdCredit,'External','BaiRong','BRScorecardActive',decode(count(1),0,0,1),v_Seq+1
      from external_br_accountchangemonth t2
      join external_br_applyloan t1 on t1.id_credit=t2.id_credit
      where ((nvl(t1.al_m12_id_notbank_allnum,0)-nvl(t1.al_m12_id_notbank_selfnum,0)>0
           or nvl(t1.al_m12_cell_notbank_allnum,0)-nvl(t1.al_m12_cell_notbank_selfnum,0)>0
           or nvl(t1.al_m12_id_bank_allnum,0)>0 or nvl(t1.al_m12_cell_bank_allnum,0)>0
           or nvl(t2.flag_accountchangemonth,0)=1))
           and t2.id_credit=p_IdCredit;
      v_Seq:=v_Seq + 1;
     -------end 2016/08/31 wangxiaofeng-----

    --百融评分 External. BaiRong. BRScore 2016/11/03 wangxiaofeng --
    insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
      select p_IdCredit,'External','BaiRong','BRScore',t.scoreconsoffv2,v_Seq+1
      from external_br_rules t
      where t.scoreconsoffv2 is not null and t.id_credit=p_IdCredit;
      v_Seq:=v_Seq + 1;

     -------begin 2017/11/02 machaochun-----
      -------1.增加元素External. BaiRong. IdentNBankIteDay/*按身份证号查询，距最近在非银行机构申请的间隔天数*/
    insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select ID_CREDIT,'External','BaiRong','IdentNBankIteDay',nvl(als_lst_id_nbank_inteday,0),v_Seq+1
       from (select ID_CREDIT,t.als_lst_id_nbank_inteday from external_br_applyloan t
       where t.id_credit=p_IdCredit order by t.create_time desc) where rownum=1 ;

      v_Seq:=v_Seq + 1;
      -------2.增加元素External. BaiRong. FlagSpeciallist/*稳定性评估产品输出标识*/
    insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select ID_CREDIT,'External','BaiRong','FlagSpeciallist',flag_speciallist_c,v_Seq+1
       from (select ID_CREDIT,t.flag_speciallist_c from external_br_speciallist_c t
       where t.id_credit=p_IdCredit order by t.create_time desc) where rownum=1 ;

      v_Seq:=v_Seq + 1;

    for d in (
        select * from (select t.flag_stability_c,STAB_AUTH_NAME from external_br_stability_c t
       where t.id_credit=p_IdCredit order by t.create_time desc) where rownum=1
      )loop
      -------3.增加元素External. BaiRong. FlagStability/*特殊名单核查产品输出标识*/
      insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       values( p_IdCredit,'External','BaiRong','FlagStability',d.flag_stability_c,v_Seq+1 );
      v_Seq:=v_Seq + 1;

      -------增加元素External. BaiRong. AuthName  百融稳定性库中姓名是否匹配  2018-04-18 yangzhenxian
      insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       values( p_IdCredit,'External','BaiRong','AuthName',d.stab_auth_name,v_Seq+1 );
      v_Seq:=v_Seq + 1;
    end loop;
      -------4.增加元素External. BaiRong. MobChangeIteDay/*身份证关联的手机号最近一次变动距今天数*/
    insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select ID_CREDIT,'External','BaiRong','MobChangeIteDay',nvl(ir_id_x_cell_lastchg_days,0),v_Seq+1
       from (select ID_CREDIT,t.ir_id_x_cell_lastchg_days from external_br_inforelation t
       where t.id_credit=p_IdCredit order by t.create_time desc) where rownum=1 ;
      v_Seq:=v_Seq + 1;

      --------2017/11/29  machaochun----
      --------1.增加元素External. BaiRong. RecentYearDeal /*近十二个月发生交易月份数*/
      insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select ID_CREDIT,'External','BaiRong','RecentYearDeal',RecentYearDeal,v_Seq+1
       from (select ID_CREDIT,t.MON_12_VAR1 RecentYearDeal from external_br_pay_behavior t
       where t.id_credit=p_IdCredit order by t.create_time desc) where rownum=1 ;

      v_Seq:=v_Seq + 1;

      --------------------按身份证号查询，近12个月在非银机构-消费类分期申请机构数 yangzhenxian   2017-12-06
      insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'External','BaiRong','IdentNBank12M',IdentNBank12M,v_Seq+1
       from (select t.ALS_M12_ID_NBANK_CF_ORGNUM IdentNBank12M from external_br_applyloan t
       where t.id_credit=p_IdCredit order by t.create_time desc) where rownum=1 ;
      v_Seq:=v_Seq + 1;

      --------------------按身份证号查询，近12个月在非银机构-消费类分期申请机构数 yangzhenxian   2017-12-06
      insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'External','BaiRong','IdentNBank1M',IdentNBank1M,v_Seq+1
       from (select t.ALS_M1_ID_NBANK_CF_ORGNUM IdentNBank1M from external_br_applyloan t
       where t.id_credit=p_IdCredit order by t.create_time desc) where rownum=1 ;
      v_Seq:=v_Seq + 1;

      --------------------按身份证号查询，近6个月在非银机构-其他申请次数 yangzhenxian   2017-12-06
      insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'External','BaiRong','IdentNBank6M',IdentNBank6M,v_Seq+1
       from (select t.ALS_M6_ID_NBANK_OTH_ALLNUM IdentNBank6M from external_br_applyloan t
       where t.id_credit=p_IdCredit order by t.create_time desc) where rownum=1 ;
      v_Seq:=v_Seq + 1;

      --------------------近3个月最大单类目消费金额的类目 yangzhenxian   2017-12-06
      insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'External','BaiRong','MaxPayCate3M',MaxPayCate3M,v_Seq+1
       from (select t.CONS_MAX_M3_PAYCATE MaxPayCate3M from external_br_consumption_c t
       where t.id_credit=p_IdCredit order by t.create_time desc) where rownum=1 ;
      v_Seq:=v_Seq + 1;

     --------------------身份证关联的手机号个数 yangzhenxian   2017-12-06
      for d in(
        with temp as(select t.IR_ID_X_CELL_CNT IdentRelateCell,t.IR_ID_IS_REABNORMAL as IsIdentAbnormal
        ,t.IR_M3_CELL_X_BIZ_ADDR_CNT as MobRelateAddr3M ,t.IR_CELL_X_ID_CNT as MobRelateIdCnt,t.IR_M6_CELL_X_BIZ_ADDR_CNT MobRelateAddr6M
        from external_br_inforelation t where t.id_credit=p_IdCredit order by t.create_time desc)
          select * from temp where rownum=1
        )
      loop
        insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         values(p_IdCredit,'External','BaiRong','IdentRelateCell',d.IdentRelateCell,v_Seq+1);
        v_Seq:=v_Seq + 1;

        ------------------身份证号是否关联异常 yangzhenxian    2018-01-15
        insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         values(p_IdCredit,'External','BaiRong','IsIdentAbnormal',d.IsIdentAbnormal,v_Seq+1);
        v_Seq:=v_Seq + 1;

        ------------------MobRelateAddr3M:近三个月手机号关联公司地址个数 yangzhenxian    2018-03-23
        insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         values(p_IdCredit,'External','BaiRong','MobRelateAddr3M',d.MobRelateAddr3M,v_Seq+1);
        v_Seq:=v_Seq + 1;
        ------------------MobRelateAddr6M:近六个月手机号关联公司地址个数 马剑锋    2018-05-31
         insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         values(p_IdCredit,'External','BaiRong','MobRelateAddr6M',d.MobRelateAddr6M,v_Seq+1);
        v_Seq:=v_Seq + 1;

        ------------------MobRelateIdCnt：手机号关联身份证个数 yangzhenxian    2018-03-23
        if d.MobRelateIdCnt is not null
        then
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
           values(p_IdCredit,'External','BaiRong','MobRelateIdCnt',d.MobRelateIdCnt,v_Seq+1);
          v_Seq:=v_Seq + 1;
        end if;
      end loop;
     -------end machaochun-----


      --------------------近6个月身份证在百融非银合作机构申请机构数 yangzhenxian   2017-12-21
      for d in (
          with temp as(
          select t.AL_M6_ID_NOTBANK_ORGNUM as IdentNBankORG6M from external_br_applyloan t
          where t.id_credit=p_IdCredit order by t.create_time desc)
          select  IdentNBankORG6M from temp where rownum=1
        )loop
        insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         values( p_IdCredit,'External','BaiRong','IdentNBankORG6M',d.IdentNBankORG6M,v_Seq+1 );
        v_Seq:=v_Seq + 1;
        end loop;

      --------------------商品消费模块最近12个月最大单类目消费次数 yangzhenxian   2017-12-21
      for d in (
          with temp as(
          select t.CONS_MAX_M12_NUM as MaxPayCate12M from external_br_consumption_c t
          where t.id_credit=p_IdCredit order by t.create_time desc)
          select  MaxPayCate12M from temp where rownum=1
        )loop
        insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         values( p_IdCredit,'External','BaiRong','MaxPayCate12M',d.MaxPayCate12M,v_Seq+1 );
        v_Seq:=v_Seq + 1;
        end loop;

      ------------------------外部数据是否查询正常  yangzhenxian  2018-02-06
      /*表external_br_applyloan是否正常*/
      insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'External','BaiRong','IsApplyLoan',case when nvl(v_InterCode,'1') in('3','4') then 1 when IsApplyLoan >0 then 1 else 0 end,v_Seq+1
       from (select count(1) IsApplyLoan from external_br_applyloan t where t.id_credit=p_IdCredit) ;
      v_Seq:=v_Seq + 1;

      /*表external_br_speciallist_c是否正常*/
      insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'External','BaiRong','IsSpecialList',case when nvl(v_InterCode,'1') in('3','4') then 1 when IsSpecialList>0 then 1 else 0 end,v_Seq+1
       from (select count(1) IsSpecialList from external_br_speciallist_c t where t.id_credit=p_IdCredit) ;
      v_Seq:=v_Seq + 1;

      /*表external_br_stability_c是否正常*/
      insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'External','BaiRong','IsStability',case when nvl(v_InterCode,'1') in('3','4') then 1 when IsStability >0 then 1 else 0 end,v_Seq+1
       from (select count(1) IsStability from external_br_stability_c t where t.id_credit=p_IdCredit) ;
      v_Seq:=v_Seq + 1;

      /*表external_br_inforelation是否正常*/
      insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'External','BaiRong','IsInforelation',case when nvl(v_InterCode,'1') in('3','4') then 1 when IsInforelation >0 then 1 else 0 end,v_Seq+1
       from (select count(1) IsInforelation from external_br_inforelation t where t.id_credit=p_IdCredit) ;
      v_Seq:=v_Seq + 1;

      /*表external_br_pay_behavior是否正常*/
      insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'External','BaiRong','IsBehavior',case when nvl(v_InterCode,'1') in('3','4') then 1 when IsBehavior >0 then 1 else 0 end,v_Seq+1
       from (select count(1) IsBehavior from external_br_pay_behavior t where t.id_credit=p_IdCredit) ;
      v_Seq:=v_Seq + 1;

      /*表external_br_consumption_c是否正常*/
      insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'External','BaiRong','IsConsumption',case when nvl(v_InterCode,'1') in('3','4') then 1 when IsConsumption >0 then 1 else 0 end,v_Seq+1
       from (select count(1) IsConsumption from external_br_consumption_c t where t.id_credit=p_IdCredit) ;
      v_Seq:=v_Seq + 1;

      /*百融表是否查询成功*/
      insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'External','BaiRong','IsBr',case when nvl(v_InterCode,'1') in('3','4') then 1 when is_applyloan>0 and is_speciallist>0 and is_stability>0 and is_inforelation>0
       and is_pay_behavior>0 and is_consumption_c>0 then 1 else 0 end,v_Seq+1
       from (
            select
            (select count(1)  from external_br_applyloan where id_credit=p_IdCredit ) is_applyloan,
            (select count(1)  from external_br_speciallist_c where id_credit=p_IdCredit ) is_speciallist,
            (select count(1)  from external_br_stability_c where id_credit=p_IdCredit ) is_stability,
            (select count(1)  from external_br_inforelation where id_credit=p_IdCredit ) is_inforelation,
            (select count(1)  from external_br_pay_behavior where id_credit=p_IdCredit ) is_pay_behavior,
            (select count(1)  from external_br_consumption_c where id_credit=p_IdCredit ) is_consumption_c
            from dual
       ) ;
      v_Seq:=v_Seq + 1;

       /*过去半个小时内百融多次借贷未查得合同数BRApplyLoanFailedCount           yangzhenxian   2018/04/27 add*/
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'External','BaiRong','BRApplyLoanFailedCount',count(1),v_Seq+1
       from cs_credit a where not exists(select 1 from external_br_applyloan b
                                           where b.id_credit=a.id)
                         and a.status not in('r','t') and nvl(a.inter_code,0) not in(3,4)
                         and a.credit_type=decode(v_CreditType,'SC','SC','SS')
                         and a.commit_time>=v_CommitTime-35/24/60 and a.commit_time<=v_CommitTime-5/24/60;
       v_Seq:=v_Seq + 1;


      /*蜜罐是否查询成功*/
      insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'External','JuxinliMiguan','IsMG',case when nvl(v_InterCode,'1') in('3','4') then 1 when IsMG >0 then 1 else 0 end,v_Seq+1
       from (select count(1) IsMG from external_miguan_basic_info t where t.id_credit=p_IdCredit
       and (remark is null or remark='MIGUAN_SEARCH_SUCCESS[获取蜜罐查询成功]')) ;
      v_Seq:=v_Seq + 1;


      -----灰猫begin yangzhenxian     2017-12-21-----------
      --在元素类比External下面添加元素子类=HuiMao，元素名称FlagOverDue(是否命中逾期平台数据)
      for d in (
          with temp as(
          select sum(case when c2.QUERY_REPORT_ID is not null then 1 when c1.order_no is not null then 0 else null end) as FlagOverDue,
          min(case when instr(c2.map_key,'DAY30')>0 then '1'
              when instr(c2.map_key,'DAY60')>0 then '2'
              when instr(c2.map_key,'DAY90')>0 then '3'
              when instr(c2.map_key,'DAY180')>0 then '4'
              when instr(c2.map_key,'DAY365')>0 then '5'
              when instr(c2.map_key,'HISTORY')>0 then '6'
              else null end) OverDueLineCate
          from GREYCAT_APPLY_REPORT c
          left join GREYCAT_QUERY_REPORT c1 on c.order_no=c1.order_no
          left join GREYCAT_OVERDUE_DETAIL c2 on c1.id=c2.QUERY_REPORT_ID
          where c.id_credit=p_IdCredit)
          select * from temp where FlagOverDue is not null
        )loop
        insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         values( p_IdCredit,'External','HuiMao','FlagOverDue',case when d.FlagOverDue>1 then 1 else d.FlagOverDue end,v_Seq+1 );
        v_Seq:=v_Seq + 1;

        ---OverDueLineCate：客户逾期情况  yangzhenxian  2018-03-28
        if d.OverDueLineCate is not null
          then
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
           values( p_IdCredit,'External','HuiMao','OverDueLineCate',d.OverDueLineCate,v_Seq+1 );
          v_Seq:=v_Seq + 1;
          end if;
        end loop;

      --在元素类比External下面添加元素子类=HuiMao，元素名称FlagApply(是否命中申请平台数据)
      for d in (
          with temp as(
          select sum(case when c2.QUERY_REPORT_ID is not null then 1 when c1.order_no is not null then 0 else null end) as FlagApply
          from GREYCAT_APPLY_REPORT c
          left join GREYCAT_QUERY_REPORT c1 on c.order_no=c1.order_no
          left join GREYCAT_APPLY_LOAN_DETAIL c2 on c1.id=c2.QUERY_REPORT_ID
          where c.id_credit=p_IdCredit)
          select * from temp where FlagApply is not null
        )loop
        insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         values( p_IdCredit,'External','HuiMao','FlagApply',case when d.FlagApply>1 then 1 else d.FlagApply end,v_Seq+1 );
        v_Seq:=v_Seq + 1;
        end loop;

      --在元素类比External下面添加元素子类=HuiMao，元素名称FlagPay(是否命中还款平台数据)
      for d in (
          with temp as(
          select sum(case when c2.QUERY_REPORT_ID is not null then 1 when c1.order_no is not null then 0 else null end) as FlagPay
          from GREYCAT_APPLY_REPORT c
          left join GREYCAT_QUERY_REPORT c1 on c.order_no=c1.order_no
          left join GREYCAT_APPLY_LOAN_DETAIL c2 on c1.id=c2.QUERY_REPORT_ID and c2.apply_sum_money='0.00'
          where c.id_credit=p_IdCredit)
          select * from temp where FlagPay is not null
        )loop
        insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         values( p_IdCredit,'External','HuiMao','FlagPay',case when d.FlagPay>1 then 1 else d.FlagPay end,v_Seq+1 );
        v_Seq:=v_Seq + 1;
        end loop;


      --在元素类比External下面添加元素子类=HuiMao，元素名称Score(灰猫评分)
      for d in (
          with temp as(
          select c1.score
          from GREYCAT_APPLY_REPORT c
          join GREYCAT_QUERY_REPORT c1 on c.ORDER_NO=c1.ORDER_NO
          where c.id_credit=p_IdCredit order by c1.create_time desc)
          select * from temp where rownum=1
        )loop
        insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         values( p_IdCredit,'External','HuiMao','Score',d.Score,v_Seq+1 );
        v_Seq:=v_Seq + 1;
        end loop;

      -----灰猫end---------------
      -----SauRon  begin yangzhenxian     2017-12-21-----------

      --BlackListIDent:身份证是否命中黑名单
      for d in (
          with temp as(
          select IDCARD_IN_BLACKLIST as BlackListIDent from sauron_risk c
          where c.id_credit=p_IdCredit order by c.create_time desc)
          select * from temp where rownum=1
        )loop
        insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         values( p_IdCredit,'External','SauRon','BlackListIDent',d.BlackListIDent,v_Seq+1 );
        v_Seq:=v_Seq + 1;
        end loop;

      --BlackListMobile：手机号是否命中黑名单
      for d in (
          with temp as(
          select PHONE_IN_BLACKLIST as BlackListMobile from sauron_risk c
          where c.id_credit=p_IdCredit order by c.create_time desc)
          select * from temp where rownum=1
        )loop
        insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         values( p_IdCredit,'External','SauRon','BlackListMobile',d.BlackListMobile,v_Seq+1 );
        v_Seq:=v_Seq + 1;
        end loop;

      --BlackListP2P：是否命中网贷黑名单
      for d in (
          with temp as(
          select IN_P2P_BLACKLIST as BlackListP2P from sauron_risk c
          where c.id_credit=p_IdCredit order by c.create_time desc)
          select * from temp where rownum=1
        )loop
        insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         values( p_IdCredit,'External','SauRon','BlackListP2P',d.BlackListP2P,v_Seq+1 );
        v_Seq:=v_Seq + 1;
        end loop;
      -----SauRon  end---------------

      --DeductDate:首次还款日 yangzhenxian     2017-12-21-----------
      for d in (
          with temp as(
          select DEDUCT_DATE as DeductDate from cs_credit c
          where c.id=p_IdCredit)
          select * from temp where DeductDate is not null
        )loop
        insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         values( p_IdCredit,'Credit','*','DeductDate',to_char(d.DeductDate,'yyyy-MM-dd HH24:mi:ss'),v_Seq+1 );
        v_Seq:=v_Seq + 1;
        end loop;



    begin --2016/11/03 wangxiaofeng 芝麻信用分--
      --芝麻信用分, ZhimaCreditScore 元素类别External.ZhiMa
      for c in(select t.score from zhima_credit_score t
                where t.id_credit=p_IdCredit
        )loop
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            values(p_IdCredit,'External','ZhiMa','ZhimaCreditScore',c.score,v_Seq+1);
          v_Seq:=v_Seq + 1;
        end loop;

      --芝麻反欺诈分, ZhimaIvsScore 元素类别External.ZhiMa
      for c in(select t.score from zhima_credit_ivs t
                where t.id_credit=p_IdCredit
        )loop
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            values(p_IdCredit,'External','ZhiMa','ZhimaIvsScore',c.score,v_Seq+1);
          v_Seq:=v_Seq + 1;
        end loop;

      --是否关注行业名单, CreditWatchList 元素类别External.ZhiMa
      for c in(select t.matched from zhima_credit_watch t
                where t.id_credit=p_IdCredit
        )loop
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            values(p_IdCredit,'External','ZhiMa','CreditWatchList',c.matched,v_Seq+1);
          v_Seq:=v_Seq + 1;
        end loop;
    end;

    --External.ZhiMa.MultiLoan1D 返回以下规则元素值为1，否则为0 2017-10-09 yangzhenxian
    insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
    select p_IdCredit,'External','ZhiMa','MultiLoan1D',case when count(1)>0 then 1 else 0 end,v_Seq+1
    from zhima_antifraud_risk_hit h
    join ZHIMA_ANTIFRAUD_RISK_DETAIL d
    on h.id=d.risk_id
    where h.id_credit=p_IdCredit and d.code in ('R_CN_JJ_01','R_PH_JJ_01');
    v_Seq:=v_Seq + 1;

    --External.ZhiMa.MultiLoan1W 返回以下规则元素值为1，否则为0 2017-10-09 yangzhenxian
    insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
    select p_IdCredit,'External','ZhiMa','MultiLoan1W',case when count(1)>0 then 1 else 0 end,v_Seq+1
    from zhima_antifraud_risk_hit h
    join ZHIMA_ANTIFRAUD_RISK_DETAIL d
    on h.id=d.risk_id
    where h.id_credit=p_IdCredit and d.code in ('R_CN_JJ_02','R_PH_JJ_02');
    v_Seq:=v_Seq + 1;

    --External.ZhiMa.MultiLoan1M 返回以下规则元素值为1，否则为0 2017-10-09 yangzhenxian
    insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
    select p_IdCredit,'External','ZhiMa','MultiLoan1M',case when count(1)>0 then 1 else 0 end,v_Seq+1
    from zhima_antifraud_risk_hit h
    join ZHIMA_ANTIFRAUD_RISK_DETAIL d
    on h.id=d.risk_id
    where h.id_credit=p_IdCredit and d.code in ('R_CN_JJ_03','R_PH_JJ_03');
    v_Seq:=v_Seq + 1;

    --External.ZhiMa.CnResult 2017-10-09 yangzhenxian
    for c in(select * from(select a.id,b.verify_id,code
      ,decode(description,'姓名与身份证号匹配','匹配'
      ,'姓名与身份证号不匹配','不匹配'
      ,'查询不到身份证信息','无信息','') description
              from zhima_antifraud_verify a
              join zhima_antifraud_verify_detail b on a.id=b.verify_id
              where a.ID_CREDIT=p_IdCredit and instr(code,'V_CN')>0 order by a.create_time desc) b where rownum=1
      )loop
        insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
          values(p_IdCredit,'External','ZhiMa','CnResult',c.description,v_Seq+1);
        v_Seq:=v_Seq + 1;
      end loop;

    --External.ZhiMa.PhResult 2017-10-09 yangzhenxian
    for c in(select * from(select a.id,b.verify_id,code
      ,decode(description,'查询不到电话号码信息','无信息'
      ,'电话号码与本人不匹配','不匹配'
      ,'电话号码与本人匹配，180天内没有使用','匹配未使用180D'
      ,'电话号码与本人匹配，180天内有使用','匹配使用180D'
      ,'电话号码与本人匹配，30天内有使用','匹配使用30D'
      ,'电话号码与本人匹配，90天内有使用','匹配使用90D'
      ,'电话号码与姓名不匹配','姓名不匹配'
      ,'电话号码与姓名匹配，180天内没有使用','姓名匹配未使用180D'
      ,'电话号码与姓名匹配，180天内有使用','姓名匹配使用180D'
      ,'电话号码与姓名匹配，30天内有使用','姓名匹配使用30D'
      ,'电话号码与姓名匹配，90天内有使用','姓名匹配使用90D','') description
              from zhima_antifraud_verify a
              join zhima_antifraud_verify_detail b on a.id=b.verify_id
              where a.ID_CREDIT=p_IdCredit and instr(code,'V_PH')>0 order by a.create_time desc) b where rownum=1
      )loop
        insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
          values(p_IdCredit,'External','ZhiMa','PhResult',c.description,v_Seq+1);
        v_Seq:=v_Seq + 1;
      end loop;


  --External.zhongzhicheng.ConfirmBlackList 中智城 客户命中中智诚黑名单 2018-05-09 majianfeng
  insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
    select p_IdCredit,'External','ZhongZhiCheng','ConfirmBlackList',nvl(substr(max(case when qr.confirm_type='overdue' then '4overdue'
        when qr.confirm_type='reject' then '3reject'
        when qr.confirm_type='fraud' then '2fraud'
        else '0other'end ),2,10),'0other') as ConfirmBlackList,v_Seq+1
    from external_intelli_bl_query bq
  left join external_intelli_bl_q_records qr on bq.id=qr.bl_q_id
  where bq.id_credit=p_IdCredit;
    v_Seq:=v_Seq + 1;


    --内部员工等级 2017/01/19
    insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
    select p_IdCredit,'Career','Title',t.position,v_Seq+1
    from mv_df_wallet_emplist_abby t
    where months_between(sysdate,start_date)>3 and rownum=1 and t.ident=v_Ident;
    v_Seq:=v_Seq + 1;

    --鹏元电话验证 元素External.PengYuan 电话核查-PhoneResult 姓名核查-NameResult 身份证核查-IdentResult 2016/11/03 wangxiaofeng
    for c in(select t.nameresult,t.phoneresult,t.identresult from cs_pyphone_data t
              where t.event_name=0 and t.person_type='1' and rownum=1 and t.id_credit=p_IdCredit
    )loop
      if c.nameresult is null then
        insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
          values(p_IdCredit,'External','PengYuan','NameResult','未查得',v_Seq+1);
        v_Seq:=v_Seq + 1;
      else
        insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
          values(p_IdCredit,'External','PengYuan','NameResult',c.nameresult,v_Seq+1);
        v_Seq:=v_Seq + 1;
      end if;

      if c.phoneresult is null then
        insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
          values(p_IdCredit,'External','PengYuan','PhoneResult','未查得',v_Seq+1);
        v_Seq:=v_Seq + 1;
      else
        insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
          values(p_IdCredit,'External','PengYuan','PhoneResult',c.phoneresult,v_Seq+1);
        v_Seq:=v_Seq + 1;
      end if;

      if c.identresult is null then
        insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
          values(p_IdCredit,'External','PengYuan','IdentResult','未查得',v_Seq+1);
        v_Seq:=v_Seq + 1;
      else
        insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
          values(p_IdCredit,'External','PengYuan','IdentResult',c.identresult,v_Seq+1);
        v_Seq:=v_Seq + 1;
      end if;
    end loop;

    --钱包面签 HardCheck.SumApprovedSameFactory，客户所在工厂历史面签通过的合同数 2016/11/03 wangxiaofeng --
    if v_CreditType='MQ' then
     ---------------聚信立授权是否成功  JxlGrant -------------------------by yangzhenxian 2017-08-30
     for ca in(select collected from
       (select collected from ca_collect where id_credit=p_IdCredit order by update_time desc) a where rownum=1)
     loop
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
        values( p_IdCredit,'External','JuxinliMiguan','JxlGrant',ca.collected,v_Seq + 1);
        v_Seq:=v_Seq + 1;
     end loop;
      ---------------手机三项验证----NameResultQB-----IdentrResultQB---------------by yangzhenxian 2017-08-30
      for py in(select nameresult,Identresult from
                  (select phone.nameresult,phone.Identresult
                         from cs_pyphone_data phone,Wallet_Apply_Info wa
                         where phone.id_credit=wa.id and wa.id_credit=p_IdCredit and phone.event_name=1
                         and (phone.person_type='1' or phone.person_type is null)  order by phone.update_time desc) a
                  where rownum=1)
      loop
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
        values( p_IdCredit,'External','PengYuan','NameResultQB',py.nameresult,v_Seq + 1 );
        v_Seq:=v_Seq + 1;

       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
        values( p_IdCredit,'External','PengYuan','IdentResultQB',py.Identresult,v_Seq + 1 );
        v_Seq:=v_Seq + 1;
      end loop;

      select count(1) into v_Count from cs_credit a
      join wallet_apply_info b on b.id_person=a.id_person
      where a.status in('m','i') and a.credit_type='MQ' and a.commit_time<=v_CommitTime and b.status=3
      and b.factory_id in(select c.factory_id from wallet_apply_info c where c.id_person=v_IdPerson);

      insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
        values(p_IdCredit,'HardCheck','*','SumApprovedSameFactory',v_Count,v_Seq+1);
      v_Seq:=v_Seq + 1;

      --2017/03/21 wanxiaofeng
      for qb in(select a.factory_id,a.recommend_type,a.recommend_person
              from wallet_apply_info a
              join cs_person b on b.id=a.id_person
              join wallet_factory_info c on c.id=a.factory_id
              join cs_credit d on d.id=a.id_credit
              where d.id=p_IdCredit
       )loop
         insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            values(p_IdCredit,'Wallet','*','FactoryId',qb.factory_id,v_Seq+1);
         v_Seq:=v_Seq + 1;
         insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            values(p_IdCredit,'Wallet','*','RecommendType',qb.recommend_type,v_Seq+1);
         v_Seq:=v_Seq + 1;
         insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            values(p_IdCredit,'Wallet','*','RecommendPerson',qb.recommend_person,v_Seq+1);
         v_Seq:=v_Seq + 1;
       end loop;
    end if;

    --银行卡三要素验证结果 2017/03/17 wangxiaofeng
    for c in(select status from(select t.status,row_number() over(order by update_time desc) nums
              from bank_account_verify t
              where t.update_time>=trunc(sysdate) and t.verify_type=0
                     and t.ident=v_Ident and t.account_name=v_PersonName) b where nums=1
      )loop
        insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
          values(p_IdCredit,'External','BankVerify','ThreeFactorStatus',c.status,v_Seq+1);
        v_Seq:=v_Seq + 1;
      end loop;

    --银行卡四要素验证结果 2017/03/17 wangxiaofeng
    for c in(select status from(select t.status,row_number() over(order by update_time desc) nums
              from bank_account_verify t
              where t.update_time>=trunc(sysdate) and t.verify_type=1
                     and t.ident=v_Ident and t.account_name=v_PersonName) b where nums=1
      )loop
        insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
          values(p_IdCredit,'External','BankVerify','FourFactorStatus',c.status,v_Seq+1);
        v_Seq:=v_Seq + 1;
      end loop;

    --交叉现金贷元素
    if v_ProdType in(6,7) then
       --客户第一次参加活动的活动开始时间
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
          select p_IdCredit,'Credit','*','ValidFromFirst',to_char(min(b.start_date),'yyyy-mm-dd'),v_Seq+1
          from cross_active_detail a,cross_active_list b where a.active_id=b.active_id and a.id_person=v_IdPerson;
       v_Seq:=v_Seq + 1;

       --客户正在参加的活动相关信息
       for active in(select a.max_amount,b.start_date,b.end_date,b.active_type from cross_active_detail a,cross_active_list b
       where a.active_id=b.active_id and b.status=1 and a.id_person=v_IdPerson)
       loop
         --当前活动最大额度
         insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
          values(p_IdCredit,'Credit','*','Limit',active.max_amount,v_Seq+1);
         v_Seq:=v_Seq + 1;
         --当前活动开始时间
         insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
          values(p_IdCredit,'Credit','*','ValidFrom',to_char(active.start_date,'yyyy-mm-dd'),v_Seq+1);
         v_Seq:=v_Seq + 1;
         --当前活动结束时间
         insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
          values(p_IdCredit,'Credit','*','ValidTo',to_char(active.end_date,'yyyy-mm-dd'),v_Seq+1);
         v_Seq:=v_Seq + 1;
         --当前活动类型
         insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
          values(p_IdCredit,'Credit','*','ActiveType',active.active_type,v_Seq+1);
         v_Seq:=v_Seq + 1;
       end loop;

       --2017/05/24 wangxiaofeng MaxPrevSS_LLLM:客户在申请此合同时前面一张消费贷通过的合同的地址，除拒绝和取消的合同外（状态为d/t/r的除外）
        for c in(with reg as(
          select a.province reg_province,a.city reg_city,id_credit
          from cs_address a where a.id_credit=
          (select max(id) id_credit from cs_credit t
          where t.credit_type='SS' and t.status not in ('t','d','r') and t.id_person=v_IdPerson)
          and a.address_type=1
          ),
         cur as(
          select a.province cur_province,a.city cur_city,id_credit
          from cs_address a where a.id_credit=
          (select max(id) id_credit from cs_credit t
          where t.credit_type='SS' and t.status not in ('t','d','r') and t.id_person=v_IdPerson)
          and a.address_type=2
          )
         select case when reg_province=cur_province and reg_city=cur_city then 'LL'
                when reg_province=cur_province and reg_city<>cur_city then 'LLM'
                when reg_province<>cur_province then 'LM'
                else 'NO' end  MaxPrevSS_LLLM from cur c,reg d
          where c.id_credit=d.id_credit
        )loop
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
          values(p_IdCredit,'HardCheck','*','MaxPrevSS_LLLM',c.MaxPrevSS_LLLM,v_Seq+1);
          v_Seq:=v_Seq + 1;
        end loop;
        --2017/05/24 wangxiaofeng
        --HardCheck FamilyPhoneUpdateCount:客户在申请此合同时该客户之前更改了家庭联系人电话的次数
        --HardCheck ThirdPhoneUpdateCount:客户在申请此合同时该客户之前更改了第三方联系人电话的次数
        for c in(select count(distinct case when person_type in ('其他亲戚','配偶','父母','兄弟姐妹','儿女') then t.contact_value else null end) familyphoneupdatecount
                ,count(distinct case when person_type='第三方' then t.contact_value else null end) thirdphoneupdatecount
                from cs_contact_portion t
                where t.status in(1,3) and t.contact_type='移动电话'
                and t.person_type in('其他亲戚','配偶','父母','兄弟姐妹','儿女','第三方') and t.id_person=v_IdPerson and t.update_time<v_CommitTime--2017-09-22增加时间范围
        )loop
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
           values(p_IdCredit,'HardCheck','*','FamilyPhoneUpdateCount',c.familyphoneupdatecount,v_Seq+1);
          v_Seq:=v_Seq + 1;
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
           values(p_IdCredit,'HardCheck','*','ThirdPhoneUpdateCount',c.thirdphoneupdatecount,v_Seq+1);
          v_Seq:=v_Seq + 1;
        end loop;

        --2017-09-07 yangzhenxian
        --HardCheck TotalPhoneUpdateCount:客户在申请此合同时该客户之前所有移动电话总次数
        for c in(select count(distinct contact_value) TotalPhoneUpdateCount
                from cs_contact_portion t
                where t.id_person=v_IdPerson and t.update_time<v_AppDate and t.contact_type='移动电话' and t.status in(1,3)
        )loop
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
           values(p_IdCredit,'HardCheck','*','TotalPhoneUpdateCount',c.totalphoneupdatecount,v_Seq+1);
          v_Seq:=v_Seq + 1;
        end loop;
     end if;

       -----------黑名单客户------------------------------------
       --如果客户存在黑名单有效期限里,则创建拒绝原因"黑名单."
       --客户身份证黑名单
       select count(1) into v_Count from customer_blacklist where ident=v_Ident;
       if v_Count>0 then
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
              values(p_IdCredit,'HardCheck','*','BlackListIDent','1',v_Seq+1);
          v_Seq:=v_Seq + 1;
       end if;
       --客户本人手机号码黑名单
       select count(1) into v_Count from customer_blacklist
       where mobile in(select contact_value from cs_contact where id_person=v_IdPerson and person_type='1' and contact_type in('2','3','18','19'));
       if v_Count>0 then
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
              values(p_IdCredit,'HardCheck','*','BlackListMobile','1',v_Seq+1);
          v_Seq:=v_Seq + 1;
       end if;
       --客户其它手机号码黑名单
       select count(1) into v_Count from customer_blacklist
       where mobile in(select contact_value from cs_contact where id_person=v_IdPerson and person_type<>'1' and contact_type in('2','3','18','19'));
       if v_Count>0 then
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
              values(p_IdCredit,'HardCheck','*','BlackListOtherMobile','1',v_Seq+1);
          v_Seq:=v_Seq + 1;
       end if;
       --客户家庭电话黑名单
       select count(1) into v_Count from customer_blacklist
       where home_num in(select contact_value from cs_contact where id_person=v_IdPerson and contact_type='18');
       if v_Count>0 then
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
              values(p_IdCredit,'HardCheck','*','BlackListHomePhone','1',v_Seq+1);
          v_Seq:=v_Seq + 1;
       end if;
       --客户QQ号码黑名单 2016/07/07 wangxiaofeng
       select count(1) into v_Count from cs_contact c
       where c.person_type='1' and c.contact_type='13' and c.id_credit=p_IdCredit
       and exists( select * from customer_blacklist b where b.qq=regexp_substr(c.contact_value,'[0-9]+'));
       if v_Count>0 then
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
              values(p_IdCredit,'HardCheck','*','BlackListQQ','1',v_Seq+1);
          v_Seq:=v_Seq + 1;
       end if;
       --公司工作电话黑名单
       select count(1) into v_Count from company_blacklist where office_num in(select contact_value from cs_contact where id_person=v_IdPerson and contact_type='3');
       if v_Count>0 then
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
              values(p_IdCredit,'HardCheck','*','BlackListOfficePhone','1',v_Seq+1);
          v_Seq:=v_Seq + 1;
       end if;
       --公司名称黑名单
       select count(1) into v_Count from company_blacklist where employer_name in(select company_name1 from cs_employer where id_person=v_IdPerson);
       if v_Count>0 then
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
              values(p_IdCredit,'HardCheck','*','BlackListCompanyName','1',v_Seq+1);
          v_Seq:=v_Seq + 1;
       end if;
       --客户在申请此合同时,历史其他客户使用过的银行账号（除本人外，除状态为t,d,r的合同）
       select count(1) into v_Count from cs_experience a,cs_credit b
       where a.id_credit=b.id and a.id_person<>v_IdPerson and b.status not in('d','t','r') and b.commit_time<=v_CommitTime
       and a.bank_no=(select distinct bank_no from cs_experience where id_credit=p_IdCredit and id_person=v_IdPerson);

       if v_Count>0 then
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
              values(p_IdCredit,'HardCheck','*','BankAccNo','1',v_Seq+1);
          v_Seq:=v_Seq + 1;
       end if;

       for phone_depository in (select relationship,contact_value,status,contact_type,id_sellerplace,city from v_phone_depository where id_credit=p_IdCredit)
       loop
          if phone_depository.relationship='client' and phone_depository.contact_type='2' then
              --客户在申请此合同时，前6个月内客户手机号码被使用过次数
              insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                   select p_IdCredit,'HardCheck','*','SameMobileLast6Month',count(1),v_Seq+1 from v_phone_depository
                    where contact_value=phone_depository.contact_value and contact_type='2' and relationship='client'
                    and id_person!=v_IdPerson and status not in('r','t') and commit_time>=sysdate-180 and commit_time<=v_CommitTime;
              v_Seq:=v_Seq + 1;
              --客户在申请此合同时，客户手机号码被历史其他客户（作为申请人移动电话）使用过的次数（除状态为t,d,r的合同）
              insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                   select p_IdCredit,'HardCheck','*','SameMobileHisCount',count(1),v_Seq+1 from v_phone_depository
                    where contact_value=phone_depository.contact_value and contact_type='2' and relationship='client'
                    and id_person!=v_IdPerson and status not in('d','t','r') and commit_time<=v_CommitTime;
              v_Seq:=v_Seq + 1;
              --客户办公电话在过去30天在同个城市被其他人重复使用为办公电话的情况；状态不等于tr 使用过的次数（除状态为t,r的合同）
              insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                   select p_IdCredit,'HardCheck','*','MobPhoneUseSameCityCount',count(1),v_Seq+1 from v_phone_depository
                    where contact_value=phone_depository.contact_value and id_person!=v_IdPerson and commit_time>=sysdate-30
                     and commit_time<=v_CommitTime and status not in('t','r') and city=phone_depository.city;
              v_Seq:=v_Seq + 1;
              --客户办公电话在过去30天在同个城市被其他人重复使用为办公电话的情况；状态不等于tr 使用过的次数（除状态为t,r的合同）
              insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                   select p_IdCredit,'HardCheck','*','MobPhoneUseSamePosCount',count(1),v_Seq+1 from v_phone_depository
                    where contact_value=phone_depository.contact_value and id_person!=v_IdPerson and commit_time>=sysdate-30
                     and commit_time<=v_CommitTime and status not in('t','r') and id_sellerplace=phone_depository.id_sellerplace;
              v_Seq:=v_Seq + 1;
              --客户在申请此合同时，客户手机号码存在，在职SA移动电话列表
              select count(1) into v_Count from sys_user_list a where upper(a.role_id)='SA' and a.phone=phone_depository.contact_value;
              if v_Count>0 then
                 insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                   values(p_IdCredit,'HardCheck','*','SAMobilelist','1',v_Seq+1);
                 v_Seq:=v_Seq + 1;
              end if;
          elsif phone_depository.relationship='client' and phone_depository.contact_type='18' then
              --客户在申请此合同时，客户家庭固话被历史其他客户（作为家庭固话）使用过的次数（除状态为t,d,r的合同）
              insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                   select p_IdCredit,'HardCheck','*','FamilyPhoneHisUseCount',count(1),v_Seq+1 from v_phone_depository
                    where contact_value=phone_depository.contact_value and contact_type='18' and relationship='client'
                     and commit_time<=v_CommitTime and id_person!=v_IdPerson and status not in('d','t','r');
              v_Seq:=v_Seq + 1;
          elsif phone_depository.relationship='family' then
              --家庭成员电话在最近180天被其他不同的客户用作其他所有电话（办公电话除外）的次数
              select count(distinct(id_credit||contact_value)) into v_Count from v_phone_depository
              where contact_value=phone_depository.contact_value and id_person!=v_IdPerson and commit_time>=sysdate-180 and commit_time<=v_CommitTime and status not in('t','r');
              v_FamilyPhoneUseCount:=v_FamilyPhoneUseCount+v_Count;
              --家庭成员电话在过去30天在同个城市被其他人重复使用的情况；状态不等于tr的次数
              select count(distinct(id_credit||contact_value)) into v_Count from v_phone_depository
              where contact_value=phone_depository.contact_value and id_person!=v_IdPerson and commit_time>=sysdate-30 and commit_time<=v_CommitTime and status not in('t','r') and city=phone_depository.city;
              v_FamilyPhoneUseSameCityCount:=v_FamilyPhoneUseSameCityCount+v_Count;
              --家庭成员电话在过去30天在同个门店被其他人重复使用的情况；状态不等于tr的次数
              select count(distinct(id_credit||contact_value)) into v_Count from v_phone_depository
              where contact_value=phone_depository.contact_value and id_person!=v_IdPerson and commit_time>=sysdate-30 and commit_time<=v_CommitTime and status not in('t','r') and id_sellerplace=phone_depository.id_sellerplace;
              v_FamilyPhoneUseSamePosCount:=v_FamilyPhoneUseSamePosCount+v_Count;
          elsif phone_depository.relationship='others' then
              --其他联系人电话在最近180天被其他不同的客户用作其他所有电话（办公电话除外）的次数
              select count(distinct(id_credit||contact_value)) into v_Count from v_phone_depository
              where contact_value=phone_depository.contact_value and id_person!=v_IdPerson and commit_time>=sysdate-180 and commit_time<=v_CommitTime and status not in('t','r');
              v_OtherPhoneUseCount:=v_OtherPhoneUseCount+v_Count;
              v_Seq:=v_Seq + 1;
              --其他联系人电话在过去30天在同个城市被其他人重复使用的情况；状态不等于tr的次数
              select count(distinct(id_credit||contact_value)) into v_Count from v_phone_depository
              where contact_value=phone_depository.contact_value and id_person!=v_IdPerson and commit_time>=sysdate-30 and commit_time<=v_CommitTime and status not in('t','r') and city=phone_depository.city;
              v_OtherPhoneUseSameCityCount:=v_OtherPhoneUseSameCityCount+v_Count;
              v_Seq:=v_Seq + 1;
              --其他联系人电话在过去30天在同个门店被其他人重复使用的情况；状态不等于tr的次数
              select count(distinct(id_credit||contact_value)) into v_Count from v_phone_depository
              where contact_value=phone_depository.contact_value and id_person!=v_IdPerson and commit_time>=sysdate-30 and commit_time<=v_CommitTime and status not in('t','r') and id_sellerplace=phone_depository.id_sellerplace;
              v_OtherPhoneUseSamePosCount:=v_OtherPhoneUseSamePosCount+v_Count;
              v_Seq:=v_Seq + 1;
          end if;
       end loop;

       --家庭成员电话在最近180天被其他不同的客户用作其他所有电话（办公电话除外）总的次数
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            values(p_IdCredit,'HardCheck','*','FamilyPhoneUseCount',v_FamilyPhoneUseCount,v_Seq+1);
       v_Seq:=v_Seq + 1;

       --家庭成员电话在过去30天在同个城市被其他人重复使用的情况；状态不等于tr（办公电话除外）总的次数
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            values(p_IdCredit,'HardCheck','*','FamilyPhoneUseSameCityCount',v_FamilyPhoneUseSameCityCount,v_Seq+1);
       v_Seq:=v_Seq + 1;

       --家庭成员电话在过去30天在同个门店被其他人重复使用的情况；状态不等于tr（办公电话除外）总的次数
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            values(p_IdCredit,'HardCheck','*','FamilyPhoneUseSamePosCount',v_FamilyPhoneUseSamePosCount,v_Seq+1);
       v_Seq:=v_Seq + 1;

       --其他联系人电话在最近180天被其他不同的客户用作其他所有电话（办公电话除外）总的次数
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            values(p_IdCredit,'HardCheck','*','OtherPhoneUseCount',v_OtherPhoneUseCount,v_Seq+1);
       v_Seq:=v_Seq + 1;

       --其他联系人电话在过去30天在同个城市被其他人重复使用的情况；状态不等于tr（办公电话除外）总的次数
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            values(p_IdCredit,'HardCheck','*','OtherPhoneUseSameCityCount',v_OtherPhoneUseSameCityCount,v_Seq+1);
       v_Seq:=v_Seq + 1;

       --其他联系人电话在过去30天在同个门店被其他人重复使用的情况；状态不等于tr（办公电话除外）总的次数
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            values(p_IdCredit,'HardCheck','*','OtherPhoneUseSamePosCount',v_OtherPhoneUseSamePosCount,v_Seq+1);
       v_Seq:=v_Seq + 1;

       --此门店历史上通过的合同数量
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         select p_IdCredit,'HardCheck','*','SumApprovedSamePos',count(1),v_Seq+1 from cs_credit
           where id_person!=v_IdPerson and commit_time<v_CommitTime and status in('a','b','m','n','y','k','p') and id_sellerplace=v_IdSellerplace;
       v_Seq:=v_Seq + 1;

       --客户办公电话在过去30天在同个城市被其他人重复使用为办公电话的情况；状态不等于tr，总的次数
       if nvl(v_IdSellerPlace,0) =0
       then
         select count(1) into v_Count from cs_address where id_credit=p_IdCredit and address_type=2;
         if v_Count >0
         then
           select city into v_UseCity  from cs_address where id_credit=p_IdCredit and address_type=2 and rownum=1;
         end if;
       end if;
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'HardCheck','*','OffPhoneUseSameCityCount',count(distinct a.id),v_Seq+1 from cs_credit a,cs_contact b,sellerplace c,cs_address ad
         where a.id=b.id_credit(+) and a.id_sellerplace=c.id(+) and b.contact_type='3' and a.id_person!=v_IdPerson
         and a.id=ad.id_credit(+) and ad.address_type=2
         and a.status not in('t','r') and a.commit_time>=sysdate-30  and a.commit_time<=v_CommitTime
         and b.contact_value=nvl(v_OfficeTel,'#') and nvl(c.city,ad.city)=v_UseCity;
       --and b.contact_value in(select t.contact_value from cs_contact t where t.contact_type='3' and t.id_credit=p_IdCredit) and c.city=v_UseCity;
       v_Seq:=v_Seq + 1;

       --客户办公电话在过去30天在同个门店被其他人重复使用为办公电话的情况；状态不等于tr,总的次数
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         select p_IdCredit,'HardCheck','*','OffPhoneUseSamePosCount',count(1),v_Seq+1 from cs_credit a,cs_contact b,sellerplace c
           where a.id=b.id_credit(+) and a.id_sellerplace=c.id(+) and b.contact_type='3' and a.id_person!=v_IdPerson
           and a.status not in('t','r') and a.commit_time>=sysdate-30  and commit_time<=v_CommitTime
           and b.contact_value=nvl(v_OfficeTel,'#') and a.id_sellerplace=v_IdSellerplace;
           --in(select t.contact_value from cs_contact t where t.contact_type='3' and t.id_credit=p_IdCredit)
       v_Seq:=v_Seq + 1;

       --客户此合同一共提供了多少个电话
       select count(1) into v_Count from cs_contact where contact_type in ('2','3','18','19') and id_credit=p_IdCredit;
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            values(p_IdCredit,'HardCheck','*','TotalPhoneCount',v_Count,v_Seq+1);
       v_Seq:=v_Seq + 1;

       --一共提供了多少个家庭联系人电话
       select count(1) into v_Count from cs_contact
       where person_type in(select reg_val_code from registers t where reg_number=265 and status='a' and reg_val_code!='1') and contact_type in('2','3','18','19') and id_credit=p_IdCredit;
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            values(p_IdCredit,'HardCheck','*','TotalFamilyPhoneCount',v_Count,v_Seq+1);
       v_Seq:=v_Seq + 1;

       --一共提供了多少个其他联系人电话
       select count(1) into v_Count from cs_contact
       where person_type in(select reg_val_code from registers t where reg_number=396 and status='a') and contact_type in('2','3','18','19') and id_credit=p_IdCredit;
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            values(p_IdCredit,'HardCheck','*','TotalOtherPhoneCount',v_Count,v_Seq+1);
       v_Seq:=v_Seq + 1;

       --一共提供了多少个家庭联系人电话和其他联系人中亲人的电话
       select count(1) into v_Count from cs_contact a
       where a.contact_type in(2,3,18,19)
        and a.person_type!='1'
        and (a.person_type in('BA','BB','BC','SA','SB','SC','5A','5B','5C')
            or a.person_type in(select reg_val_code from registers b where b.reg_number=265))
        and a.id_credit=p_IdCredit;
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            values(p_IdCredit,'HardCheck','*','TotalRelativePhoneCount',v_Count,v_Seq+1);
       v_Seq:=v_Seq + 1;

       if v_CreditType='SS' then
         --2016/12/02 wangxiaofeng 在hardcheck类别添加元素IsFpd10SamePhoneLast6M
         --客户在申请合同时，客户号码（不包含办公电话号码）在过去6个月被其他申请人使用时是否出现fpd10 逾期
         insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         select p_IdCredit,'HardCheck','*','IsFpd10SamePhoneLast6M',decode(nvl(sum(m.fpd10),0),0,0,1),v_Seq+1
         from v_phone_depository a
         join mv_df_pd_sum_gl m on m.contract_no=a.contract_no
         where a.credit_type='SS' and a.status in('a','p','k')
         and a.contact_type in('2','18','19') and a.commit_time>=trunc(sysdate-180)
         and a.contact_value in(select b.contact_value from cs_contact b where b.contact_type in('2','18','19') and b.id_credit=p_IdCredit);
         v_Seq:=v_Seq + 1;
       end if;

       --2016/12/13 wangxiaofeng 在HardCheck类别里添加元素系统提单查询SysNciic结果
       for c in(select decode(t.result,null,'无法访问',t.result) results from cs_nciic_data t
                where t.local_flag=0 and t.event_name=0 and t.id_credit=p_IdCredit and rownum=1
        )loop
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            values(p_IdCredit,'HardCheck','*','SysNciicResult',trim(c.results),v_Seq+1);
          v_Seq:=v_Seq + 1;
        end loop;

       --2016/12/02 wangxiaofeng 在HardCheck类别里添加元素MYST_LEVEL暗访人员级别
       for c in(select t.approve from mv_whitelist_myst_inve t
         where trim(status)='a' and t.ident=v_Ident and rownum=1
        )loop
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            values(p_IdCredit,'HardCheck','*','MYST_LEVEL',c.approve,v_Seq+1);
          v_Seq:=v_Seq + 1;
        end loop;

       --在HardCheck类别下面添加元素InterCodeRateSamePos。同一个门店再过去90天的内部代码(3,4)占总申请量的比率，status not in（‘t’,‘r’）;
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'HardCheck','*','InterCodeRateSamePos',round(nvl(sum(decode(t.inter_code,3,1,4,1,0)),0)/decode(count(1),0,1,count(1)),6),v_Seq+1
       from cs_credit t
       where t.status not in('t','r') and t.commit_time>=trunc(sysdate-90) and t.commit_time<=v_CommitTime and t.id_sellerplace=v_IdSellerPlace;
       v_Seq:=v_Seq + 1;

       --在Credit类别下面添加元素SaFirstAppDate 销售第一张申请合同的时间，status not in（‘t’,‘r’）
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'Credit','*','SaFirstAppDate',to_char(min(t.commit_time),'yyyy-MM-dd'),v_Seq+1
       from cs_credit t where t.status not in('t','r') and t.id_sa=v_IdSa;
       v_Seq:=v_Seq + 1;

       --是否属于销售白名单SAWhiteList 2015/12/29 wangxiaofeng
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'Credit','*','SAWhiteList',decode(count(1),0,0,1),v_Seq+1
       from mv_df_uw_sa_whitelist t
       where t.status=1 and (case_type='UW' or (case_type<>'UW' and trunc(sysdate) between start_date and end_date)) and t.sa_id=v_IdSa;
       v_Seq:=v_Seq + 1;

       --同一个销售本月使用的特殊代码合同数量SumSpecialSameSALast1M(本月内部代码 =12的数量，status not in('t','r') 2015/12/29 wangxiaofeng
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'Credit','*','SumSpecialSameSALast1M',count(1),v_Seq+1
       from cs_credit t
       where t.status not in('t','r') and t.inter_code='12'
       and t.commit_time between trunc(sysdate,'mm') and trunc(sysdate+31,'mm') and t.id_sa=v_IdSa;
       v_Seq:=v_Seq + 1;

       --同一年龄下在过去3个月（<90天）的QQ平均长度
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'HardCheck','*','Last3MonthQQAvgLen',round(nvl(sum(qq_length),0)/decode(count(1),0,1,count(1)),4),v_Seq+1
       from mv_qq_length t where t.birth_year=substr(v_Ident,7,4);

       --同一年龄下在过去1个月（<30天）的QQ平均长度 2016/07/07 wangxiaofeng
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'HardCheck','*','Last1MonthQQAvgLen',round(nvl(sum(qq_length),0)/decode(count(1),0,1,count(1)),4),v_Seq+1
       from mv_qq_length_30 t where t.birth_year=substr(v_Ident,7,4);

       v_Seq:=v_Seq + 1;
       --客户本人手机号码所属城市
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'Other','*','PhoneNoCity',nvl(max(a.city),'null'),v_Seq+1
       from mv_df_phone_attribution_gl a where a.mobilenumber=substr(v_PersonMobile,1,7);
       --(select substr(contact_value,1,7) from cs_contact t where t.id_credit=p_IdCredit and t.person_type = '1' and t.contact_type='2');
       v_Seq:=v_Seq + 1;
       --FirstTmDate 客户首次电销时间,排除无接通和转接的情况 ,包括inbound和outbound 2016/05/04
       select count(1) into v_Count from tm_outbound_call_result t
       where t.call_result not in (5,6,7,10,11) and t.id_person=v_IdPerson;
       if v_Count>=1 then
         insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         select p_IdCredit,'Other','*','FirstTmDate',to_char(min(update_time),'yyyy-MM-dd HH24:mi:ss'),v_Seq+1
         from tm_outbound_call_result t
         where t.call_result not in (5,6,7,10,11) and t.id_person=v_IdPerson;
       end if;
       v_Count:=0;

       v_Seq:=v_Seq + 1;
       --该客户上一单拒绝原因
       select nvl(max(id),0) into v_IdCredit from cs_credit t where id_person=v_IdPerson and t.id!=p_IdCredit and t.status='d';
       if v_IdCredit!=0 then
         insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         select p_IdCredit,'HardCheck','*','PreRejectReason',case when c.event is null then fun_get_reject_reason(a.id) else replace(replace(fun_getreg_value(779,nvl(c.event,-1)),'[',''),']','') end,v_Seq+1
         from cs_credit a,wfi_final_decision c where a.id=c.id_credit(+) and a.id=v_IdCredit;
       end if;
       v_Seq:=v_Seq + 1;

       --HardCheck.Last1wAmountRate------贷款金额与同类商品过去7天平均贷款金额比值  2018-04-18  yangzhenxian
       if v_CreditType ='SS'
       then
        for d in (
            with base as--获取一周内(不含当天)的合同，包括当前合同
            (
            select id,commit_time,credit_amount from cs_credit cc where cc.status not in('t','r')
            and cc.id_sa not in ('800079','888888','300079') and cc.credit_type='SS'
            and cc.commit_time>=trunc(v_CommitTime-8) and cc.commit_time<trunc(v_CommitTime)
            union
            select id,commit_time,credit_amount from cs_credit where id=p_IdCredit
            ),
            new_base as--商品类目
            (
              select id,commit_time,min(goods_category_new) goods_category_new,credit_amount from
              (
                select cc.id,trunc(cc.commit_time) commit_time
                ,case when gc.name='手机' and (producer like '%苹果%' or upper(producer) like '%APPLE%' or upper(producer) like '%IPHONE%') then '1苹果'
                                  when gc.name='手机' then '2手机' when gc.name='电脑' then '3电脑' when gc.name='摩托车' then '4摩托车'
                                     when gc.name='电动车' then '5电动车'when gc.name='医美' then '6医美' else '7其他' end as goods_category_new
                ,cc.credit_amount
                from base cc
                join cs_goods cg on cc.id=cg.id_credit
                join goods_category gc on cg.id_goods_category =gc.id
              )
              group by id,commit_time ,credit_amount
            )

            select round(credit_amount/(select avg(v_before.credit_amount) from new_base v_before
            where v_before.id<>p_IdCredit and v_before.goods_category_new=cur.goods_category_new)--前一周的合同
            ,2) Last1mAmountRate
            from new_base cur where cur.id=p_IdCredit--当前合同
          )loop
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
           values( p_IdCredit,'HardCheck','*','Last1mAmountRate',d.Last1mAmountRate,v_Seq+1 );
          v_Seq:=v_Seq + 1;
          end loop;
        end if;

       for cs_exp in(select t.total_wk_exp,t.is_ssi,t.insurance_fee from cs_experience t where t.id_credit=p_IdCredit)
         loop
           --是否购买保险
           insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
           values(p_IdCredit,'Other','*','IsInsurance',cs_exp.is_ssi,v_Seq+1);
           v_Seq:=v_Seq + 1;

           --保险费用
           insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
           values(p_IdCredit,'Credit','*','InsuranceFee',cs_exp.insurance_fee,v_Seq+1);
           v_Seq:=v_Seq + 1;

           --距离毕业时间/现公司工作时间（月）
           insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
           values(p_IdCredit,'Career','*','CurrentMonth',cs_exp.total_wk_exp,v_Seq+1);
           v_Seq:=v_Seq + 1;
       end loop;
       /*鲁长江   2015-6-9*/
       select count(1) into v_Count from wechat_credit_address where id_credit=p_IdCredit;
       if v_Count>0 then
          select current_address_city,current_city into v_CurrentAddressCity,v_CurrentCity
            from wechat_credit_address where rownum=1 and id_credit=p_IdCredit;
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
           values(p_IdCredit,'Other','*','MobTrueCity',v_CurrentAddressCity,v_Seq+1);
          v_Seq:=v_Seq + 1;

          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
           values(p_IdCredit,'Other','*','MobSelectCity',v_CurrentCity,v_Seq+1);
       end if;
       delete decision_element_data_pa where id_credit=p_IdCredit and element_value is null;

       --2016/12/21 wanxgxiaofeng 24小时审核元素
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       values(p_IdCredit,'Credit','*','CreditAuto24Hour',pkg_decision.get_24hour_element(p_IdCredit),v_Seq+1);

      -------额度申请类型   2018-04-24 yangzhenxian
      insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         select p_IdCredit,'Credit','*','LimitType',nvl(LimitType,0),v_Seq+1
         from (select case when c.CY_LIMIT_TYPE='ER' then 'ER' else c.POS_LIMIT_TYPE end as LimitType from  giveu_credit_eligible c
         where status2 in (2,3,9)  and credit_channel='GIVEU'and id_person=v_IdPerson order by c.create_time desc) where rownum=1 ;
        v_Seq:=v_Seq + 1;

       --wangxiaofeng 2016-01-25 随机生成客户第一联系人拨打号码
       insert into cs_random_other_person
        (id, id_credit,contract_no,id_person,person_name,contacts_name,relation,contact_mode,contact_value,extension)
       select seq_cs_random_other_person.nextval,id_credit,contract_no,id_person,person_name,contacts_name,
              relation,contact_mode,contact_value,extension
        from (select a.id_credit,b.contract_no,b.id_person,c.name person_name,e.name contacts_name,
                     fun_getreg_value(396, a.person_type) relation,fun_getreg_value(395, a.contact_type) contact_mode,
                     a.contact_value,a.reg_person extension, row_number() over(order by dbms_random.value) rn
                from cs_contact a, cs_credit b, cs_person c, cs_other_person e
               where a.id_credit=b.id and b.id_person=c.id and a.id_credit=e.id_credit
                and a.person_Type=e.person_Type and length(a.person_type)=2 and a.id_credit=p_IdCredit) t
       where t.rn = 1;

       --luchangjiang 20180308
       v_Seq:=v_Seq + 1;
       select count(1) into v_Count from status_change_information where personname=v_PersonName and personident=v_Ident;
       if v_Count=0 then
          v_IsRecall:=0;
       else
          select credit_amount,goodsnewcategory into v_SCI_Amount,v_SCI_Category from status_change_information
           where rownum=1 and personname=v_PersonName and personident=v_Ident;
          if v_CreditAmount<=v_SCI_Amount and v_NewCategory=v_SCI_Category then
             v_IsRecall:=1;
          else
             v_IsRecall:=2;
          end if;
       end if;
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            values(p_IdCredit,'Credit','*','IsRecall',v_IsRecall,v_Seq+1);
       Update cs_credit  Set status='r',update_time=sysdate,update_user=100000,modify_comments='决策初审通过' Where id=p_IdCredit;
       insert into decision_element_pa_history select * from decision_element_data_pa where id_credit=p_IdCredit;
       delete decision_element_data_pa where id_credit=p_IdCredit;
       commit;

       p_ReturnCode:='A';
       return;
    exception
       When others Then
         error_info := sqlerrm;
         p_ReturnCode:='Z-'||error_info;
         rollback;
    end;
/

