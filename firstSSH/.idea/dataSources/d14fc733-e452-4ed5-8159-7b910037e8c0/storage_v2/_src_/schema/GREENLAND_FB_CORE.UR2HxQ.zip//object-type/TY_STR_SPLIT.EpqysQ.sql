create TYPE "TY_STR_SPLIT"                                          IS TABLE OF VARCHAR2 (1000)
/

