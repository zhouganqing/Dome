create function FUN_GET_YBSCITY(p_Code       registers.reg_number%type,
                                              p_IdCredit   cs_credit.id%type)
                                          return varchar2 is
  v_City    varchar2(100);
  v_Count   integer;
begin
   if p_Code is null then
     return '';
   end if;
   
   select nvl(t.version,0) into v_Count from cs_credit t where t.id=p_IdCredit;
   if v_Count>0 then     
      select nvl(city,'') into v_City from ybs_city where rownum=1 and id=to_number(p_Code);
   else
      select count(1) into v_Count from ybs_city where rownum=1 and code=p_Code;
      if v_Count>0 then
         select city into v_City from ybs_city where rownum=1 and code=p_Code;
      else
         v_City:='未找到';
      end if;
   end if;
   return(v_City);
exception
  When others Then
    return '';
end;
/

