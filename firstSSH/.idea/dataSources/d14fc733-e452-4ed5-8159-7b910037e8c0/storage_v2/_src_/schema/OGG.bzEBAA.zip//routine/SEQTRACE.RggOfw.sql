create PROCEDURE        seqTrace (
   traceStmt IN VARCHAR2,
   traceUser IN VARCHAR2)
AUTHID current_user
IS
BEGIN
    dbms_output.put_line(traceStmt);
    EXECUTE IMMEDIATE (traceStmt);
END;
/

