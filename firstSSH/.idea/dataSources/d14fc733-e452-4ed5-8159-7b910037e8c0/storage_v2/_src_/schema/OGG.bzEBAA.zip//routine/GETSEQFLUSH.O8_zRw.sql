create PROCEDURE        getSeqFlush (
   seqName IN VARCHAR2,
   isCycle IN NUMBER,
   flushStmt OUT VARCHAR2,
   isTrace IN NUMBER,
   traceUser IN VARCHAR2)
AUTHID current_user
IS
BEGIN
    IF isTrace = 1 THEN
       "OGG" .seqTrace ('BEGIN "' || traceUser || '".trace_put_line(''SEQUENCEREP'', ''before building flush''); END;', traceUser);
    END IF;
    SELECT 'ALTER SEQUENCE "' || seqName || '" ' ||  decode (isCycle, 1, 'CYCLE', ' NOCYCLE  /* GOLDENGATE_DDL_REPLICATION */')
    INTO flushStmt
    FROM DUAL;
    IF isTrace = 1 THEN
       "OGG" .seqTrace  ('BEGIN "' || traceUser || '".trace_put_line(''SEQUENCEREP'', ''flush stmt is ' || flushStmt || '''); END;', traceUser);
    END IF;
END;
/

