create PROCEDURE        updateSequence (
	schemaName IN VARCHAR2,
	seqName IN VARCHAR2,
	isTrace IN NUMBER,
	traceUser IN VARCHAR2,
    sessUser IN VARCHAR2)
AUTHID current_user
IS
	seqVal NUMBER;
    cyc VARCHAR2(100);
    lastN NUMBER;
    userN NUMBER;
    oraSeqName VARCHAR2(100);
BEGIN
	IF isTrace = 1 THEN
       "OGG" .seqTrace  ('BEGIN "' || traceUser || '".trace_put_line(''SEQUENCEUPD'', ''################ BEGIN bumping up HWM, schema='' || ''' ||  schemaName || ''' || '' seq '' || ''' || seqName || '''); END;', traceUser);
	END IF;
    -- replace OGG wildcards with SQLPLUS (do not change the meaning of % and _)
    -- we don't replace % with \% and _ with \_. We could but it's not done anywhere in OGG
    oraSeqName := seqName;
    IF oraSeqName IS NOT NULL THEN
        oraSeqName := REPLACE (oraSeqName, '*', '%');
        oraSeqName := REPLACE (oraSeqName, '?', '_');
    END IF;
    IF oraSeqName = '' OR oraSeqName IS NULL THEN
        oraSeqName := '%';
    END IF;
	IF isTrace = 1 THEN
       "OGG" .seqTrace  ('BEGIN "' || traceUser || '".trace_put_line(''SEQUENCEUPD'', ''new seqname '' || ''' ||  oraSeqName || '''); END;', traceUser);
	END IF;
    -- check if schema exists
    SELECT COUNT(*) INTO userN FROM SYS.DBA_USERS where USERNAME=schemaName;
    IF userN = 0 THEN
	    IF isTrace = 1 THEN
           "OGG" .seqTrace  ('BEGIN "' || traceUser || '".trace_put_line(''SEQUENCEUPD'', ''schema does not exist ='' || ''' ||  schemaName || '''); END;', traceUser);
    	END IF;
        RETURN;
    END IF;

	-- look for all sequences in schema in bring them to be last_number (HWM). This will work because
	-- if nextval reaches it, it will force an update. This update will move to the target system
	-- and bring sequences in "sync"
	FOR seq IN (SELECT sequence_owner, sequence_name, last_number, cycle_flag FROM DBA_SEQUENCES WHERE SEQUENCE_OWNER = schemaName AND SEQUENCE_NAME LIKE oraSeqName) LOOP
        IF seq.cycle_flag = 'Y' THEN
            cyc := 'CYCLE';
        ELSE
            cyc := 'NOCYCLE';
        END IF;
        -- use setting schema to avoid problems with table names equal to that of schema
    	EXECUTE IMMEDIATE ('ALTER SESSION SET CURRENT_SCHEMA="'||schemaName||'"');
    	IF isTrace = 1 THEN
           "OGG" .seqTrace  ('BEGIN "' || traceUser || '".trace_put_line(''SEQUENCEUPD'', ''set session schema='' || ''' ||  seq.sequence_owner || '''); END;', traceUser);
	    END IF;
		EXECUTE IMMEDIATE 'ALTER SEQUENCE "'|| seq.sequence_name || '" ' || cyc;
        BEGIN
	    EXECUTE IMMEDIATE 'SELECT "'|| seq.sequence_name || '".nextval FROM DUAL' INTO seqVal;
        EXCEPTION
        WHEN OTHERS THEN IF SQLCODE = -8004 THEN NULL; END IF; -- ignore going over MAXVALUE for NOCYCLE
        END;
	    SELECT last_number INTO lastN FROM DBA_SEQUENCES WHERE SEQUENCE_OWNER=seq.sequence_owner AND
               SEQUENCE_NAME=seq.sequence_name;

		IF isTrace = 1 THEN
			"OGG" .seqTrace  ('BEGIN "' || traceUser || '".trace_put_line(''SEQUENCEUPD'', ''seqName='' || ''' ||
				seq.sequence_name || ''' || '' old HWM = '' ||' || seq.last_number || ' || '' new HWM = '' ||' ||
				lastN || '); END;', traceUser);
		END IF;
    	EXECUTE IMMEDIATE ('ALTER SESSION SET CURRENT_SCHEMA="'||sessUser||'"');
    	IF isTrace = 1 THEN
           "OGG" .seqTrace  ('BEGIN "' || traceUser || '".trace_put_line(''SEQUENCEUPD'', ''restore  session schema to '' || ''' || sessUser || '''); END;', traceUser);
	    END IF;

	END LOOP;

	IF isTrace = 1 THEN
       "OGG" .seqTrace  ('BEGIN "' || traceUser || '".trace_put_line(''SEQUENCEUPD'', ''################ END schema='' || ''' ||  schemaName || '''); END;', traceUser);
	END IF;
END;
/

