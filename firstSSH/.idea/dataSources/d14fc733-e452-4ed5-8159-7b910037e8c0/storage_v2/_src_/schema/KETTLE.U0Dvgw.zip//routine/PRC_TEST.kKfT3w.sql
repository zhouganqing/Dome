create procedure prc_test as
v_date date;
begin
  select sysdate into v_date from dual;
  dbms_output.put_line('v_date');
end;
/

