create function fun_min(num1 number,num2 number) return number is
  Result number;
begin
  if num1<=num2 then
     return num1;
  else
     return num2;
  end if;
end;


/

