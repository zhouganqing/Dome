create procedure prc_save_contact_portion(p_IdCredit        number,
                                                     p_IdPerson        number,
                                                     p_ContactType     varchar2,
                                                     p_PersonType      varchar2,
                                                     p_ContactResult   varchar2,
                                                     p_Phone           varchar2,
                                                     p_Remark          varchar2,
                                                     p_UpdateUser      varchar2,
                                                     p_PTPType         varchar2,
                                                     p_CustomMoney     number,
                                                     p_ContractNo      varchar2,
                                                     p_ReturnCode      out varchar2) is
  error_info         varchar2(1000);
  v_Count            number;
  --v_Count1           number;
  --v_Result           number;
  --v_Date             date;
  --v_Date1            date;
  v_collection_days  varchar2(10);
--create user:WangXiaoFeng
--use: 催收员处理逾期合同结果
begin
  select para_value into v_collection_days from collection_parameters where para_id='NEXT_COLLECTION_DAYS';
  --p_PTPType 1-代扣PTP，2-PTP，3-其他备注
  if p_PTPType='1' then
    select nvl(max(ptp_time),trunc(sysdate)-2)-trunc(sysdate) into v_Count from collection_call where contract_no=p_ContractNo and status=1 and ptp_time>=trunc(sysdate);
    if v_Count<0 then
      insert into checkoff_process(id,idcredit,status,update_user,collection_date,custom_money,contract_no) values(seq_checkoff_process.nextval,p_IdCredit,'0',p_UpdateUser,trunc(sysdate)+v_collection_days,p_CustomMoney,p_ContractNo);

      insert into collection_call(id,id_credit,id_person,contact_type,person_type,contact_result,phone,remark,update_user,is_debit,update_time,ptp_time,ptp_type,custom_money,contract_no)
      values(seq_collection_call.nextval,p_IdCredit,p_IdPerson,p_ContactType,p_PersonType,'承诺还款',p_Phone,p_Remark,p_UpdateUser,'是',sysdate,trunc(sysdate)+v_collection_days,1,p_CustomMoney,p_ContractNo);

      update collection_data set stay_date=trunc(sysdate)+v_collection_days
      where contract_no=p_ContractNo and id=(select max(id) from collection_data where contract_no=p_ContractNo and stay_date>=trunc(sysdate));
    elsif v_Count=0 and p_ContactType='进线' then
      insert into checkoff_process(id,idcredit,status,update_user,collection_date,custom_money,contract_no) values(seq_checkoff_process.nextval,p_IdCredit,'0',p_UpdateUser,trunc(sysdate)+v_collection_days,p_CustomMoney,p_ContractNo);

      insert into collection_call(id,id_credit,id_person,contact_type,person_type,contact_result,phone,remark,update_user,is_debit,update_time,ptp_time,ptp_type,custom_money,contract_no)
      values(seq_collection_call.nextval,p_IdCredit,p_IdPerson,p_ContactType,p_PersonType,'承诺还款',p_Phone,p_Remark,p_UpdateUser,'是',sysdate,trunc(sysdate)+v_collection_days,1,p_CustomMoney,p_ContractNo);

      update collection_data set stay_date=trunc(sysdate)+v_collection_days
      where contract_no=p_ContractNo and id=(select max(id) from collection_data where contract_no=p_ContractNo and stay_date>=trunc(sysdate));
    else
      p_ReturnCode:='Z-还在PTP期间,请保存为其他备注';
        return;
    end if;
  elsif p_PTPType='2' then
    select nvl(max(ptp_time),trunc(sysdate)-2)-trunc(sysdate) into v_Count from collection_call where contract_no=p_ContractNo and status=1 and ptp_time>=trunc(sysdate);
    if v_Count<0 then
      insert into collection_call(id,id_credit,id_person,contact_type,person_type,contact_result,phone,remark,update_user,is_debit,update_time,ptp_time,ptp_type,custom_money,contract_no)
      values(seq_collection_call.nextval,p_IdCredit,p_IdPerson,p_ContactType,p_PersonType,'承诺还款',p_Phone,p_Remark,p_UpdateUser,'否',sysdate,trunc(sysdate)+v_collection_days,2,p_CustomMoney,p_ContractNo);

      update collection_data set stay_date=trunc(sysdate)+v_collection_days
      where contract_no=p_ContractNo and id=(select max(id) from collection_data where contract_no=p_ContractNo and stay_date>=trunc(sysdate));
    elsif v_Count=0 and p_ContactType='进线' then
      insert into collection_call(id,id_credit,id_person,contact_type,person_type,contact_result,phone,remark,update_user,is_debit,update_time,ptp_time,ptp_type,custom_money,contract_no)
      values(seq_collection_call.nextval,p_IdCredit,p_IdPerson,p_ContactType,p_PersonType,'承诺还款',p_Phone,p_Remark,p_UpdateUser,'否',sysdate,trunc(sysdate)+v_collection_days,2,p_CustomMoney,p_ContractNo);

      update collection_data set stay_date=trunc(sysdate)+v_collection_days
      where contract_no=p_ContractNo and id=(select max(id) from collection_data where id_credit=p_IdCredit and stay_date>=trunc(sysdate));
    else
      p_ReturnCode:='Z-还在PTP期间,请保存为其他备注';
        return;
    end if;
  else
    insert into collection_call(id,id_credit,id_person,contact_type,person_type,contact_result,phone,remark,update_user,is_debit,update_time,ptp_type,custom_money,contract_no)
     values(seq_collection_call.nextval,p_IdCredit,p_IdPerson,p_ContactType,p_PersonType,p_ContactResult,p_Phone,p_Remark,p_UpdateUser,'否',sysdate,3,p_CustomMoney,p_ContractNo);

    --添加为疑难案件
    if p_ContactResult='投诉' or p_ContactResult='客户死亡/被捕' or p_ContactResult='否认贷款' then
      pkg_collection.prc_add_coll_diffcult(p_ContractNo,p_UpdateUser,p_ContactResult,p_ReturnCode);
    end if;
  end if;
  /*
  if p_IsDebit = '是' then
    select count(1) into v_Count from checkoff_process where idcredit=p_IdCredit;
    v_Result:=3;
    if v_Count>0 then
      select status into v_Result from(select * from checkoff_process where idcredit=p_IdCredit order by update_time desc) a where rownum=1;
      select max(collection_date) into v_Date1 from checkoff_process where idcredit=p_IdCredit and status='2';
    end if;

    if v_Result=0 then
      p_ReturnCode:='Z-已发起代扣，不能再次发起';
      return;
    elsif v_Result=1 then
      p_ReturnCode:='Z-代扣正在处理，不能再次发起';
      return;
    else
      if trunc(v_Date1)-trunc(sysdate)>0 then
         p_ReturnCode:='Z-还在上次发起代扣有效期内，不能再次发起';
        return;
      end if;

      select count(1) into v_Count1 from collection_data where id_credit=p_IdCredit and stay_date>=trunc(sysdate);
      if v_Count1=0 then
         p_ReturnCode:='Z-未分配,不能发起代扣';
        return;
      end if;
      if v_Count1>0 then
        select max(stay_date) into v_Date from collection_data where id_credit=p_IdCredit and stay_date>=trunc(sysdate);

        if trunc(v_Date)=trunc(sysdate) then
          update collection_data set stay_date=trunc(sysdate)+v_collection_days
          where id_credit=p_IdCredit and id=(select max(id) from collection_data where id_credit=p_IdCredit and stay_date>=trunc(sysdate));

          insert into checkoff_process(id,idcredit,status,update_user,collection_date) values(seq_checkoff_process.nextval,p_IdCredit,'0',p_UpdateUser,trunc(v_Date)+v_collection_days);
        else
          insert into checkoff_process(id,idcredit,status,update_user,collection_date) values(seq_checkoff_process.nextval,p_IdCredit,'0',p_UpdateUser,trunc(v_Date));
        end if;
      end if;

      insert into collection_call(id,id_credit,id_person,contact_type,person_type,contact_result,phone,remark,update_user,is_debit,update_time)
      values(seq_collection_call.nextval,p_IdCredit,p_IdPerson,p_ContactType,p_PersonType,'承诺还款',p_Phone,p_Remark,p_UpdateUser,p_IsDebit,sysdate);
    end if;
   else
     insert into collection_call(id,id_credit,id_person,contact_type,person_type,contact_result,phone,remark,update_user,is_debit,update_time)
     values(seq_collection_call.nextval,p_IdCredit,p_IdPerson,p_ContactType,p_PersonType,p_ContactResult,p_Phone,p_Remark,p_UpdateUser,p_IsDebit,sysdate);

     if p_ContactResult='承诺还款' then
       select count(1) into v_Count1 from collection_data where id_credit=p_IdCredit and stay_date>=trunc(sysdate);
       if v_Count1>0 then
         select stay_date into v_Date from collection_data where id_credit=p_IdCredit and stay_date>=trunc(sysdate);

         if trunc(v_Date)=trunc(sysdate) then
           update collection_data set stay_date=trunc(sysdate)+v_collection_days
           where id_credit=p_IdCredit and id=(select max(id) from collection_data where id_credit=p_IdCredit and stay_date>=trunc(sysdate));
         end if;
       end if;
     else
       --添加为疑难案件
       if p_ContactResult='投诉' or p_ContactResult='客户死亡/被捕' or p_ContactResult='否认贷款' then
         pkg_collection.prc_add_coll_diffcult(p_IdCredit,p_UpdateUser,p_ContactResult,p_ReturnCode);
       end if;
     end if;
   end if;
 */
  commit;
  p_ReturnCode:='A';
  return;
Exception
  When others Then
    error_info := sqlerrm;
    Rollback;

    p_ReturnCode := 'Z-'||error_info;
end prc_save_contact_portion;
/

