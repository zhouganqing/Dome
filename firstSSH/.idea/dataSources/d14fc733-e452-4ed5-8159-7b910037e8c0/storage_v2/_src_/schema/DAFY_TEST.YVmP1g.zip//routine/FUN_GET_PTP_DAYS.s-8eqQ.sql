create function fun_get_ptp_days(p_id_credit cs_credit.id%type) return number is
  v_Days  number(2);
--create time;2015/02/05
--create user:WangXiaoFeng
--use:获取催收案件PTP 剩余天数
begin
  v_Days:=0;
  select nvl(max(ptp_time),trunc(sysdate))-trunc(sysdate) into v_Days from collection_call where id_credit=p_id_credit and status=1 and ptp_time>=trunc(sysdate);
  return(v_Days);
Exception
 When others Then
   return(v_Days);
end fun_get_ptp_days;


/

