create procedure prc_auto_collection_date_temp(p_ReturnCode  out varchar2) is

error_info  varchar2(1000);
begin
  delete from collection_data_temp;

  insert into collection_data_temp
  select id_credit,
       contract_no,
       person_name,
       ident,
       min(date_due) date_due,
       nvl(fun_get_dpd_overdue_days(id_credit),0) over_days,
       nvl(fun_get_overdue_amount(id_credit),0) over_amount,
       round(sum(value_instalment)) value_instalment,
       round(sum(amount_pay)) amount_pay,
       commit_time,
       loan_date,
       price,
       init_pay,
       credit_amount,
       fun_get_total_value_instalment(id_credit) - round(nvl(fun_get_total_value_pay(id_credit),0)) totalleft,
       round(annuity) annuity,
       collection_date,
       id_person,
       credit_type,
       credit_model
  from (select a.id_credit,
               b.contract_no,
               c.name person_name,
               c.ident,
               trunc(a.date_due) date_due,
               a.value_instalment,
               nvl(a.value_pay, 0) amount_pay,
               trunc(b.commit_time) commit_time,
               trunc(b.loan_date) loan_date,
               b.price,
               b.init_pay,
               b.credit_amount,
               b.annuity,
               b.collection_date,
               c.id id_person,
               b.credit_type,
               b.credit_model
         from instalment a, cs_credit b,cs_person c,instalment_overdue e,
                       (select a.id_credit,a.num_instalment from instalment a 
                        where a.status='a' and a.date_due<trunc(sysdate) and a.type_instalment<>'8' and a.paytype<>'2'
                        group by a.id_credit,a.num_instalment
                        having sum(a.value_instalment)-nvl(sum(a.value_pay),0)>=50) g
              where a.id_credit=g.id_credit 
              and a.status='a'
              and a.num_instalment=g.num_instalment
              and a.id_credit = b.id
              and b.id_person = c.id
              and a.id_credit = e.id_credit)
group by id_credit,
         contract_no,
         person_name,
         ident,
         commit_time,
         loan_date,
         price,
         init_pay,
         credit_amount,
         annuity,
         collection_date,
         id_person,
         credit_type,
         credit_model;

  commit;
  p_ReturnCode:='A';
  return;
Exception
  When others Then
    error_info := sqlerrm;
    Rollback;

    p_ReturnCode := 'Z-'||error_info;
end prc_auto_collection_date_temp;


/

