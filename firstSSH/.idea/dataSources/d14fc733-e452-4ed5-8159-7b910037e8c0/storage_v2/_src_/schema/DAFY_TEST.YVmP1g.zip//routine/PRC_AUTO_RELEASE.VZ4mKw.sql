create procedure PRC_AUTO_RELEASE(p_ReturnCode out varchar2) is
    error_info           varchar2(1000);
    v_count              integer:=0;
    --v_service_fee          number;

  --cursor cur is select para_value from sys_parameters where para_id='SELLER_SERVICE_FEE'; 
begin
   -- open cur;
   -- fetch cur into v_service_fee;
   
   
     ---遍历除了已支付的合同，更新
  for branch in(select a.contractno,a.bankname,a.accountname,a.accountno,b.bank_name as bankname1,b.account_name as accountname1,b.account_no as accountno1 from release_credit a,v_credit_release b
    where a.status<>'k' and a.contractno=b.contract_no)
    loop
      if branch.accountno<>branch.accountno1 or branch.bankname<>branch.bankname1 or branch.accountname<>branch.accountname1 then
        
      update release_credit set bankname=branch.bankname1,accountname=branch.accountname1,accountno=branch.accountno1,recentupdate=1 where contractno=branch.contractno;
      commit;
      
      end if;
    end loop;
    
   
   ---取得新的消费贷现行合同
    for branch in (select commit_time,loan_date,contract_no,retailer_code,seller_name,pos_code,dealer_name,city,bank_name,account_name,account_no,
    person_name,credit_amount,init_pay,price,prod_code,payment_num,eir from v_credit_release a where status='a' and credit_type='SS' and credit_model in 
    ('P2P','P2P_RRJC','XT-DF01','XT-DF02','P2P_SYD','P2P_PPM','XT') 
    and not exists(select 1 from release_credit t where t.contractno=contract_no)
    and loan_date between trunc(sysdate-7) and trunc(sysdate) )
  loop
    --select count(1) into v_count from release_credit where contractno=branch.contract_no; 
    
    if v_count=0 then
   
     insert into release_credit(id,committime,loandate,contractno,retailercode,sellername,
     poscode,dealername,city,bankname,accountname,accountno,personname,creditamount,initpay,price,prodcode,num_instalment,eir,status,service_fee)
     values(seq_release_credit.nextval,branch.commit_time,branch.loan_date,to_char(branch.contract_no),branch.retailer_code,branch.seller_name,
     branch.pos_code,branch.dealer_name,branch.city, branch.bank_name,branch.account_name,branch.account_no,branch.person_name,branch.credit_amount,branch.init_pay,
     branch.price,branch.prod_code,branch.payment_num,branch.eir,'a',0);
     commit;
     
     end if;
     
  end loop;
  
     ---取得新的现金贷现行合同
  /*  for branch in (select a.commit_time,a.loan_date,a.contract_no,a.retailer_code,a.seller_name,a.pos_code,a.dealer_name,a.city,a.account_name,
    a.person_name,a.credit_amount,a.init_pay,a.price,a.prod_code,a.payment_num,a.eir,fun_getreg_value(776,b.bank_name) bank_name,b.bank_no account_no from v_credit_release a,cs_experience b where a.id_credit=b.id_credit and a.status='a' and a.credit_type='SC' and trunc(a.loan_date) between trunc(sysdate-7) and trunc(sysdate) )
  loop
    select count(1) into v_count from release_credit where contractno=branch.contract_no; 
    
    if v_count=0 then
   
     insert into release_credit(id,committime,loandate,contractno,retailercode,sellername,
     poscode,dealername,city,bankname,accountname,accountno,personname,creditamount,initpay,price,prodcode,num_instalment,eir,status,service_fee)
     values(seq_release_credit.nextval,branch.commit_time,branch.loan_date,to_char(branch.contract_no),branch.retailer_code,branch.seller_name,
     branch.pos_code,branch.dealer_name,branch.city, branch.bank_name,branch.account_name,branch.account_no,branch.person_name,branch.credit_amount,branch.init_pay,
     branch.price,branch.prod_code,branch.payment_num,branch.eir,'a',0);
     
     end if;
     
  end loop;*/
  
 

Exception
   When others Then
     error_info := sqlerrm;
     p_ReturnCode:='Z-'||error_info;
     rollback;
end;


/

