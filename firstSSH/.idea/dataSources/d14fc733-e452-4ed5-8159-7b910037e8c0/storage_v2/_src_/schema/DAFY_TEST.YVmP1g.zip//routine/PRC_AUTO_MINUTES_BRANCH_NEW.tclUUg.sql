create procedure prc_auto_minutes_branch_new(p_RradomNum   number,
                                                           p_ReturnCode  out varchar2)
   is
   --wangxiaofeng
   --20160903
   v_IdCredit                 cs_credit.id%type;
   v_CreditModel              cs_credit.credit_model%type;
   v_CreditType               cs_credit.credit_type%type;
   v_IdPerson                 cs_credit.id_person%type;
   v_Formula                  decision_branch_list.formula%type;
   v_BranchId                 decision_branch_list.id%type:=-1;

   v_ProdType                 product.prod_type%type;

   v_AuditStage               cs_credit.audit_stage%type;
   v_RiskGroup                decision_risk_group.risk_group%type;
   v_Id                       decision_wfi_selection.id%type;
   v_WfiId                    decision_wfi_selection.wfi_id%type;
   v_FlowName                 decision_work_flow.flow_name%type;
   v_DelayMinutes             decision_wfi_selection.delay_minutes%type;
   v_ObjectStatus             decision_work_flow.object_status%type;
   v_CurrentStatus            cs_credit.status%type;
   --v_TencentNCheatStatus      sys_parameters.para_value%type;
   --v_TencentReportStatus      sys_parameters.para_value%type;
   v_TencentWaitMinutes       number:=1;
   --v_TencentNCheatFlag        integer:=1;
   --v_TencentReportFlag        integer:=1;
   v_FraudMetrixFlag          integer:=0;
   --v_MiGuanFlag               number:=0;

   v_Seq                      decision_element_data.seq%type;

   v_HardCheckFlag            integer;
   v_Score                    number;
   v_DefaultScore             number;
   v_FraudScore               number;
   v_ScoreCate                number;
   v_LimitRate                number(10,4);
   --v_CityScoreCate            number;

   v_MaxAmount                cross_active_detail.max_amount%type;
   v_CreditAmount             cs_credit.credit_amount%type;

   v_DecisionWaitMinutes      number;
   v_LeadTime                 number;
   v_NewStatus                cs_credit.status%type;
   exists_branch              integer;

   v_Found                    integer;
   v_Count                    integer;
   v_HoldFlag                 number:=0;
   error_info                 varchar2(1000);
   v_DecisionStage            varchar2(200);
   cursor curS is select id,id_person,status,round((sysdate-commit_time)*24*60) from cs_credit t
                   where t.decision_random=p_RradomNum and status='s' and decision_flag=1;
   cursor curF is select id,id_person,credit_type,credit_model,status,branch_id,round((sysdate-update_time)*24*60) from cs_credit t
                   where t.decision_random=p_RradomNum and status='f';
   cursor curV is select id,id_person,credit_type,credit_model,status,branch_id,round((sysdate-update_time)*24*60) from cs_credit t
                   where t.decision_random=p_RradomNum and status='v';
   cursor curX is select id,id_person from cs_credit t
                   where t.decision_random=p_RradomNum and status='x' and (sysdate-commit_time)*24*60>=nvl(delay_minutes,0) and decision_flag=1;
   cursor curM is select id,id_person,credit_amount from cs_credit t
                   where t.decision_random=p_RradomNum and status='m' and (sysdate-commit_time)*24*60>=nvl(delay_minutes,0);

   function GetFraudMetrixFlag return number is
      ret  number;
      --判断是否已获得同盾多平台借款数据
      v_Count    integer:=0;
   begin
     /*select count(1) into v_Count
     from WFI_FRAUD_METRIX_RESULT a
     join WFI_FRAUD_METRIX_RULE b on a.id=b.fraud_metrix_result_id
     where b.rule_name in  ('3个月内手机在多个平台借款','3个月内手机在多个平台借款','3个月内身份证借款平台数','3个月内手机借款平台数','借款时手机号命中全局欺诈证据库',
                      '借款时身份证命中全局欺诈证据库','借款时邮箱命中全局欺诈证据库','借款时座机命中全局欺诈证据库','借款手机号命中虚假号码',
                      '借款手机号命中失信名单','借款手机命中支付欺诈','借款时身份证命中法院执行','借款时座机命中失信名单证据库')
                      and a.event_name='Credit' and a.associated_id=v_IdCredit;*/
     select count(1) into v_Count
     from wfi_fraud_metrix_result a
     where a.event_name='Credit' and a.associated_id=v_IdCredit;

     if v_Count>0 then
       ret:=1;
     else
       if v_LeadTime>v_TencentWaitMinutes then
         ret:=1;
       else
         ret:=0;
       end if;
     end if;

     return ret;
   exception
       When others Then
        return 1;
   end;

   function GetMiGuanFlag return number is
      ret  number;
      --判断是否已获得蜜罐元素数据
      v_Count    integer:=0;
   begin
     select count(1) into v_Count from external_data_extraction a
     where a.interface_marking='MG' and a.create_time>=trunc(sysdate-1) and a.id_credit=v_IdCredit;

     if v_Count>0 then
       ret:=1;
     else
       if v_LeadTime>v_TencentWaitMinutes then
         ret:=1;
       else
         ret:=0;
       end if;
     end if;

     return ret;
   exception
       When others Then
        return 1;
   end;

begin
   select to_number(para_value) into v_DecisionWaitMinutes from sys_parameters where para_id='DECISION_WAIT_MINUTES';
   --select trim(para_value) into v_TencentNCheatStatus from sys_parameters where para_id='TENCENT_GET_NCHEAT_STATUS';
   --select trim(para_value) into v_TencentReportStatus from sys_parameters where para_id='TENCENT_GET_REPORT_STATUS';
   select to_number(para_value) into v_TencentWaitMinutes from sys_parameters where para_id='TENCENT_WAIT_MINUTES';

   v_FraudMetrixFlag:=1;
   --v_MiGuanFlag:=1;
   --status from s->f
   open curS;
   loop
      fetch curS into v_IdCredit,v_IdPerson,v_CurrentStatus,v_LeadTime;
      exit when curS%notfound;
      v_DecisionStage:='s';
      v_FraudMetrixFlag:=GetFraudMetrixFlag();
      --v_MiGuanFlag:=GetMiGuanFlag();

      if v_LeadTime>v_TencentWaitMinutes or v_FraudMetrixFlag=1 then
          select count(1) into v_Count from decision_log where id_credit=v_IdCredit    --解决因并发而引起的问题
             and status='s' and item_name='branch_id' and update_time>=sysdate-1/24/60;
          if v_Count=0 then
            pkg_decision.prc_collect_element(v_IdCredit, p_ReturnCode);
            if substr(p_ReturnCode,1,1)='A' then
                  exists_branch:=0;
                  v_Seq:=fun_get_element_maxseq(v_IdCredit);
                  v_BranchId:=pkg_decision.get_branchid(v_IdCredit);
                  v_NewStatus:='f';
                  update cs_credit set status=v_NewStatus,branch_id=v_BranchId,wfi_id=null,risk_group=null,delay_minutes=null,wfi_time=sysdate
                   where id=v_IdCredit and status='s';
                  if sql%rowcount=1 then
                      insert into decision_element_data(id_credit,element_type,element_name,element_value,value_index,seq)
                           select v_IdCredit,'preResult','BranchName',branch_name,1,v_Seq+1 from decision_branch_list where id=v_BranchId;
                      insert into decision_log(id,id_credit,status,item_name,result,remark,formula,update_time)
                           select seq_decision_log.nextval,v_IdCredit,'s','branch_id',id,branch_name,formula,sysdate from decision_branch_list where id=v_BranchId;

                      /*insert into cs_audit_log2(id,id_credit,from_status,to_status,begin_time,end_time,update_user,update_time)
                           values(seq_cs_audit_log2.nextval,v_IdCredit,'s',v_NewStatus,sysdate,sysdate,100000,sysdate);*/
                      insert into decision_log(id,id_credit,status,item_name,result,remark,formula,update_time)
                           values(seq_decision_log.nextval,v_IdCredit,'s','status',v_NewStatus,fun_getreg_value(15,v_NewStatus),'',sysdate);
                      --pre hard check
                      v_HardCheckFlag:=0;
                      delete wfi_ck_result where id_credit=v_IdCredit;
                      for hard_check_pre in (select b.id,formula,remark from decision_hard_check a,wfi_items_detail b where a.id_wfi_items_detail=b.id and b.id_wfi_items=1 and a.status=1 and a.branch_id=v_BranchId and a.stage='PRE' order by a.seq)
                      loop
                          --exit when v_HardCheckFlag=1;
                          if pkg_decision.fun_check_formula_data(v_IdCredit,hard_check_pre.formula)=true then   --Hard Check output reason
                              v_Seq:=fun_get_element_maxseq(v_IdCredit);
                              insert into decision_element_data(id_credit,element_type,element_name,element_value,value_index,seq)
                                   values(v_IdCredit,'preResult','HardCheckRemark',hard_check_pre.remark,1,v_Seq+1);
                              insert into wfi_ck_result(id,id_credit,id_wfi_items,id_wfi_result,user_name,comments,score,reject_flag)
                                   values(seq_wfi_ck_result.nextval,v_IdCredit,1,hard_check_pre.id,100000,hard_check_pre.remark,-100,1);
                              v_Seq:=v_Seq+1;
                              if v_HardCheckFlag=0 then
                                  insert into decision_element_data(id_credit,element_type,element_name,element_value,value_index,seq)
                                       values(v_IdCredit,'preResult','HardCheck','1',1,v_Seq+1);
                                  v_HardCheckFlag:=1;
                              end if;
                              insert into decision_log(id,id_credit,status,item_name,result,remark,formula,update_time)
                                   values(seq_decision_log.nextval,v_IdCredit,'s','preHardCheck','1',hard_check_pre.remark,hard_check_pre.formula,sysdate);
                          end if;
                          v_Seq:=v_Seq+1;
                      end loop;

                      delete decision_scorecard_data where id_credit=v_IdCredit;
                      for preScroeType in (select para_type,para_name from decision_scorecard_params where branch_id=v_BranchId and status=1 and stage='PRE')
                      loop
                          v_Found:=0;
                          for preScore in (select a.para_id,a.category,a.formula from decision_scorecard_formula a,decision_scorecard_params b
                                    where a.para_id=b.id and a.branch_id=v_BranchId and a.status=1 and b.status=1 and b.stage='PRE'
                                      and b.para_type=preScroeType.Para_Type and b.para_name=preScroeType.Para_Name order by a.seq)
                          loop
                             --v_Score:=get_scorecard_score(v_ParaId,v_Category,v_Formula);
                              exit when v_Found=1;
                              if pkg_decision.fun_check_formula_data(v_IdCredit,preScore.Formula) then
                                 v_Found:=1;
                                 select count(1) into v_Count from decision_scorecard_score where branch_id=v_BranchId and para_id=preScore.para_id and category=preScore.category;
                                 if v_Count=1 then
                                    select score into v_Score from decision_scorecard_score where branch_id=v_BranchId and para_id=preScore.para_id and category=preScore.category;
                                 else
                                    v_Score:=0;
                                 end if;
                                 insert into decision_scorecard_data(id_credit,para_id,category,score,update_time)
                                      values(v_IdCredit,preScore.Para_Id,preScore.Category,v_Score,sysdate);
                                 insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
                                      values(v_IdCredit,'preScore',preScroeType.Para_Type,preScroeType.Para_Name||'Category',preScore.category,1,v_Seq+1);
                                 insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
                                      values(v_IdCredit,'preScore',preScroeType.Para_Type,preScroeType.Para_Name||'Score',v_Score,1,v_Seq+2);
                                 v_Seq:=v_Seq + 2;
                              end if;
                          end loop;
                      end loop;
                  else
                      update cs_credit set f_log='Old status is not s!' where id=v_IdCredit;
                  end if;
               else
                 --异常发送邮件
                 insert into sys_email_list(email_boby,id,mail_type,key_word,from_user,mail_to,subject,status,create_time,plan_time)
                 values (p_ReturnCode,seq_sys_email_list.nextval,'DE','决策引擎报警','dafy@mail.dafycredit.com.cn','wangxiaofeng@dafycredit.com;luchangjiang@dafycredit.com;lixiaoxi@dafycredit.com;zhangjinwen@dafycredit.com;luojingna@dafycredit.com',v_IdCredit||'申请单号决策引擎计算元素运行异常',0,sysdate,sysdate);
                 --异常发送短信
                 insert into collection_auto_message(id,contract_no,cpd,phone_number,message,create_time,status,app_code)
                  values( seq_collection_auto_message.nextval,100000,0,'18218021986,13715085819,13828735725,13553835518,18566255697',v_IdCredit||'申请单号决策引擎计算元素运行异常',sysdate,0,'LV_COLL');
                 --判断是否是周六周日
                 if to_char(sysdate,'d') in(1,7) then
                   if v_LeadTime>v_DecisionWaitMinutes then
                      update cs_credit set decision_flag=0 where id=v_IdCredit;
                      insert into decision_log(id,id_credit,status,item_name,result,remark,formula,update_time)
                           values(seq_decision_log.nextval,v_IdCredit,'s','decision_flag','0','Decision wait minutes more than '||v_LeadTime,'',sysdate);
                   end if;
                 else
                   --异常合同暂时不决策
                   update cs_credit t set t.decision_random=-1,update_time=sysdate,f_log='决策异常!' where id=v_IdCredit;
                 end if;
               end if;
          end if;
       end if;
   end loop;
   close curS;
   commit;

   --pre total Score
   v_Score:=0;
   open curF;
   loop
      fetch curF into v_IdCredit,v_IdPerson,v_CreditType,v_CreditModel,v_CurrentStatus,v_BranchId,v_LeadTime;
      exit when curF%notfound;
      v_DecisionStage:='f';

      if v_BranchId is not null then

        for ParaType in (select reg_val_code from registers where reg_number=821 and status='a' order by reg_order)
        loop
            v_Score:=fun_get_totalscore(v_IdCredit, 'PRE',ParaType.Reg_Val_Code);
            if ParaType.Reg_Val_Code='Default' then
              v_DefaultScore:=v_Score;

              --在preResult元素类别中新增元素 DefaultScoreCate通过比较客户的实际得分与表df_UW_RG_score_cate中的Score，
              --取大于等于客户实际分数的最小等分作为ScoreCate 2016/07/18 wangxiaofeng
              select nvl(min(t.score_cate),50) into v_ScoreCate
              from df_uw_rg_score_cate t
              where t.status='a' and t.branch_id=v_BranchId and t.score_type like '%PreDefault%'
              and t.credit_type=v_CreditType and t.score>=v_DefaultScore;

              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
              values(v_IdCredit,'preResult','*','DefaultScoreCate',v_ScoreCate,1,999);
              insert into decision_log(id,id_credit,status,item_name,result,remark,formula,update_time)
              values(seq_decision_log.nextval,v_IdCredit,'f','DefaultScoreCate',v_ScoreCate,'','',sysdate);

            elsif ParaType.Reg_Val_Code='Fraud' then
              v_FraudScore:=v_Score;

              --在preResult元素类别中新增元素 FraudScoreCate通过比较客户的实际得分与表df_UW_RG_score_cate中的Score，
              --取大于等于客户实际分数的最小等分作为ScoreCate 2016/03/16 wangxiaofeng
              select nvl(min(t.score_cate),50) into v_ScoreCate
              from df_uw_rg_score_cate t
              where t.status='a' and t.branch_id=v_BranchId and t.score_type like '%PreFraud%'
              and t.credit_type=v_CreditType and t.score>=v_FraudScore;

              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
              values(v_IdCredit,'preResult','*','FraudScoreCate',v_ScoreCate,1,999);
              insert into decision_log(id,id_credit,status,item_name,result,remark,formula,update_time)
              values(seq_decision_log.nextval,v_IdCredit,'f','FraudScoreCate',v_ScoreCate,'','',sysdate);

            end if;

            v_Seq:=fun_get_element_maxseq(v_IdCredit);
            insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
                 values(v_IdCredit,'preResult','*',ParaType.Reg_Val_Code||'Score',v_Score,1,v_Seq+1);
            insert into decision_log(id,id_credit,status,item_name,result,remark,formula,update_time)
                 values(seq_decision_log.nextval,v_IdCredit,'f',ParaType.Reg_Val_Code||'Score',v_Score,'','',sysdate);
        end loop;

        if v_DefaultScore is not null and v_FraudScore is not null then
          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
                   values(v_IdCredit,'preResult','*','TotalScore',v_FraudScore+(1-v_FraudScore)*v_DefaultScore,1,v_Seq+2);
          insert into decision_log(id,id_credit,status,item_name,result,remark,formula,update_time)
                   values(seq_decision_log.nextval,v_IdCredit,'f','TotalScore',v_FraudScore+(1-v_FraudScore)*v_DefaultScore,'','',sysdate);

          --在preResult元素类别中新增元素 TotalScoreCate通过比较客户的实际得分与表df_UW_RG_score_cate中的Score，
          --取大于等于客户实际分数的最小等分作为ScoreCate 2016/03/16 wangxiaofeng
          select nvl(min(t.score_cate),50) into v_ScoreCate
          from df_uw_rg_score_cate t
          where  t.status='a' and t.branch_id=v_BranchId and t.score_type like '%PreTotal%'
          and t.credit_type=v_CreditType and t.score>=(v_FraudScore+(1-v_FraudScore)*v_DefaultScore);

          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
          values(v_IdCredit,'preResult','*','TotalScoreCate',v_ScoreCate,1,999);
          insert into decision_log(id,id_credit,status,item_name,result,remark,formula,update_time)
          values(seq_decision_log.nextval,v_IdCredit,'f','TotalScoreCate',v_ScoreCate,'','',sysdate);
        end if;

        commit;
     end if;
   end loop;
   close curF;

   --status from f->c
   open curF;
   loop
      fetch curF into v_IdCredit,v_IdPerson,v_CreditType,v_CreditModel,v_CurrentStatus,v_BranchId,v_LeadTime;
      exit when curF%notfound;
      v_DecisionStage:='fc';
      v_Formula:='';
      if v_BranchId is not null then
        v_Count:=1;
        if v_Count>=1 then
          v_Id:=pkg_decision.get_riskgroup(v_IdCredit,v_BranchId,'PRE');
          if v_Id=-1 then
             v_RiskGroup:=-1;
          else
             select risk_group,formula into v_RiskGroup,v_Formula from decision_risk_group where id=v_Id;
          end if;
          v_Seq:=fun_get_element_maxseq(v_IdCredit);
          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
               values(v_IdCredit,'preResult','*','CutOffId',v_Id,1,v_Seq+1);
          insert into decision_log(id,id_credit,status,item_name,result,remark,formula,update_time)
               values(seq_decision_log.nextval,v_IdCredit,'f','RiskGroup',v_RiskGroup,'PRE',v_Formula,sysdate);
          v_Id:=pkg_decision.get_wfiid(v_IdCredit,v_RiskGroup,v_BranchId,'PRE');

          v_Formula:='';
          if v_Id=-1 then
             v_WfiId:=fun_get_def_workflow(v_BranchId,'PRE');
             v_DelayMinutes:=0;
          else
             select a.wfi_id,b.flow_name,a.delay_minutes,a.formula into v_WfiId,v_FlowName,v_DelayMinutes,v_Formula
               from decision_wfi_selection a,decision_work_flow b where a.wfi_id=b.id and a.id=v_Id;
          end if;

          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
               values(v_IdCredit,'preResult','*','RiskGroup',v_RiskGroup,1,v_Seq+2);
          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
               values(v_IdCredit,'preResult','*','WfiId',v_WfiId,1,v_Seq+3);
          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
               values(v_IdCredit,'preResult','*','FlowName',v_FlowName,1,v_Seq+4);
          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
               values(v_IdCredit,'preResult','*','DelayMinutes',v_DelayMinutes,1,v_Seq+5);

          insert into decision_log(id,id_credit,status,item_name,result,remark,formula,update_time)
               values(seq_decision_log.nextval,v_IdCredit,'f','WfiId',v_WfiId,'PRE:'||v_FlowName,v_Formula,sysdate);
          insert into decision_log(id,id_credit,status,item_name,result,remark,formula,update_time)
               values(seq_decision_log.nextval,v_IdCredit,'f','DelayMinutes',v_DelayMinutes,'PRE',v_Formula,sysdate);

          select a.prod_type into v_ProdType from product a,cs_credit b where a.id=b.id_product and b.id=v_IdCredit;

          select object_status into v_ObjectStatus from decision_work_flow where id=v_WfiId;
          if v_ObjectStatus in ('c','d','n') then
             if v_ObjectStatus='d' then
                v_ObjectStatus:='x';
             elsif v_ObjectStatus='n' then
                 if v_CreditModel='P2P_HAIR' then
                     v_ObjectStatus:='w';
                 else
                     if v_ProdType=5 then
                        v_ObjectStatus:='b';
                     else
                        v_ObjectStatus:='m';
                     end if;
                 end if;
             end if;

             update cs_credit t
             set status=v_ObjectStatus,risk_group=v_RiskGroup,wfi_id=v_WfiId,wfi_time=sysdate,delay_minutes=v_DelayMinutes,t.holding_flag=v_HoldFlag
             where id=v_IdCredit and status='f';

             if sql%rowcount=1 then
                insert into decision_log(id,id_credit,status,item_name,result,remark,formula,update_time)
                     values(seq_decision_log.nextval,v_IdCredit,'f','status',v_ObjectStatus,fun_getreg_value(15,v_ObjectStatus),'ObjectStatus='||v_ObjectStatus,sysdate);
             else
                update cs_credit set f_log='Old status is not f!' where id=v_IdCredit;
             end if;
          else
             update cs_credit set f_log='Object status ['||v_ObjectStatus||'] is error!' where id=v_IdCredit;
          end if;
        end if;
      end if;
   end loop;
   close curF;
   commit;

   open curV;
   loop
      fetch curV into v_IdCredit,v_IdPerson,v_CreditType,v_CreditModel,v_CurrentStatus,v_BranchId,v_LeadTime;
      exit when curV%notfound;
      v_DecisionStage:='v';

      if v_BranchId is not null then
        --post hard check
        v_HardCheckFlag:=0;
        for hard_check_post in (select formula,remark from decision_hard_check where branch_id=v_BranchId and status=1 and stage='POST' order by seq)
        loop
            --exit when v_HardCheckFlag=1;
            if pkg_decision.fun_check_formula_data(v_IdCredit,hard_check_post.formula)=true then   --Hard Check output reason
                v_Seq:=fun_get_element_maxseq(v_IdCredit);
                insert into decision_element_data(id_credit,element_type,element_name,element_value,value_index,seq)
                     values(v_IdCredit,'postResult','HardCheckRemark',hard_check_post.remark,1,v_Seq+1);
                v_Seq:=v_Seq+1;
                if v_HardCheckFlag=0 then
                    insert into decision_element_data(id_credit,element_type,element_name,element_value,value_index,seq)
                         values(v_IdCredit,'postResult','HardCheck','1',1,v_Seq+1);
                    v_HardCheckFlag:=1;
                end if;
                insert into decision_log(id,id_credit,status,item_name,result,remark,formula,update_time)
                     values(seq_decision_log.nextval,v_IdCredit,'v','postHardCheck','1',hard_check_post.remark,hard_check_post.formula,sysdate);
            end if;
            v_Seq:=v_Seq+1;
        end loop;

        --post score
        --delete decision_scorecard_data where id_credit=p_IdCredit;
        for postScoreType in (select para_type,para_name from decision_scorecard_params where branch_id=v_BranchId and status=1 and stage='POST')
        loop
            v_Found:=0;
            for PostScore in (select a.para_id,a.category,a.formula from decision_scorecard_formula a,decision_scorecard_params b
                       where a.para_id=b.id and a.branch_id=v_BranchId and a.status=1 and b.status=1 and b.stage='POST'
                         and b.para_type=postScoreType.Para_Type and b.para_name=postScoreType.Para_Name order by a.seq)
            loop
                exit when v_Found=1;
                if pkg_decision.fun_check_formula_data(v_IdCredit, PostScore.Formula) then
                     v_Found:=1;
                     select count(1) into v_Count from decision_scorecard_score where branch_id=v_BranchId and para_id=PostScore.para_id and category=PostScore.category;
                     if v_Count=1 then
                        select score into v_Score from decision_scorecard_score where branch_id=v_BranchId and para_id=PostScore.para_id and category=PostScore.category;
                     else
                        v_Score:=0;
                     end if;
                     v_Seq:=fun_get_element_maxseq(v_IdCredit);
                     insert into decision_scorecard_data(id_credit,para_id,category,score,update_time)
                          values(v_IdCredit,PostScore.para_id,PostScore.category,v_Score,sysdate);
                     insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
                          values(v_IdCredit,'postScore',postScoreType.para_type,postScoreType.para_name||'Category',PostScore.category,1,v_Seq+1);
                     insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
                          values(v_IdCredit,'postScore',postScoreType.para_type,postScoreType.para_name||'Score',v_Score,1,v_Seq+2);
                end if;
            end loop;
          end loop;
        --post total score
        for ParaType in (select reg_val_code from registers where reg_number=821 and status='a' order by reg_order)
        loop
            v_Score:=fun_get_totalscore(v_IdCredit, 'POST',ParaType.Reg_Val_Code);
            v_Seq:=fun_get_element_maxseq(v_IdCredit);
            insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
                 values(v_IdCredit,'postResult','*',ParaType.Reg_Val_Code||'Score',v_Score,1,v_Seq+1);
            insert into decision_log(id,id_credit,status,item_name,result,remark,formula,update_time)
                 values(seq_decision_log.nextval,v_IdCredit,'v',ParaType.Reg_Val_Code||'Score',v_Score,'','',sysdate);
            if ParaType.Reg_Val_Code='Fraud' then
              --在postResult元素类别中新增元素 FraudScoreCate通过比较客户的实际得分与表df_UW_RG_score_cate中的Score，
              --取大于等于客户实际分数的最小等分作为ScoreCate 2016/03/16 wangxiaofeng
              select nvl(min(t.score_cate),50) into v_ScoreCate
              from df_uw_rg_score_cate t
              where t.status='a' and t.branch_id=v_BranchId and t.score_type like '%PostFraud%'
              and t.credit_type=v_CreditType and t.score>=v_Score;

              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
              values(v_IdCredit,'postResult','*','FraudScoreCate',v_ScoreCate,1,v_Seq+2);
              insert into decision_log(id,id_credit,status,item_name,result,remark,formula,update_time)
              values(seq_decision_log.nextval,v_IdCredit,'v','FraudScoreCate',v_ScoreCate,'','',sysdate);
            end if;
        end loop;
        commit;
      end if;
   end loop;
   close curV;

   --status from v->e
   open curV;
   loop
      fetch curV into v_IdCredit,v_IdPerson,v_CreditType,v_CreditModel,v_CurrentStatus,v_BranchId,v_LeadTime;
      exit when curV%notfound;
      v_DecisionStage:='ve';
      v_Formula:='';
      if v_BranchId is not null then
        v_Count:=1;
        if v_Count>=1 then
          v_Id:=pkg_decision.get_riskgroup(v_IdCredit,v_BranchId,'POST');
          if v_Id=-1 then
             v_RiskGroup:=-1;
          else
             select risk_group,formula into v_RiskGroup,v_Formula from decision_risk_group where id=v_Id;
          end if;
          v_Seq:=fun_get_element_maxseq(v_IdCredit);
          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
               values(v_IdCredit,'postResult','*','CutOffId',v_Id,1,v_Seq+1);
          insert into decision_log(id,id_credit,status,item_name,result,remark,formula,update_time)
               values(seq_decision_log.nextval,v_IdCredit,'v','RiskGroup',v_RiskGroup,'POST',v_Formula,sysdate);
          v_Id:=pkg_decision.get_wfiid(v_IdCredit,v_RiskGroup,v_BranchId,'POST');

          v_Formula:='';
          if v_Id=-1 then
             v_WfiId:=fun_get_def_workflow(v_BranchId,'POST');
             v_DelayMinutes:=0;
          else
             select a.wfi_id,b.flow_name,a.delay_minutes,a.formula into v_WfiId,v_FlowName,v_DelayMinutes,v_Formula
               from decision_wfi_selection a,decision_work_flow b where a.wfi_id=b.id and a.id=v_Id;
          end if;

          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
               values(v_IdCredit,'postResult','*','RiskGroup',v_RiskGroup,1,v_Seq+2);
          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
               values(v_IdCredit,'postResult','*','WfiId',v_WfiId,1,v_Seq+3);
          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
               values(v_IdCredit,'postResult','*','FlowName',v_FlowName,1,v_Seq+4);
          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
               values(v_IdCredit,'postResult','*','DelayMinutes',v_DelayMinutes,1,v_Seq+5);

          insert into decision_log(id,id_credit,status,item_name,result,remark,formula,update_time)
               values(seq_decision_log.nextval,v_IdCredit,'v','WfiId',v_WfiId,'POST:'||v_FlowName,v_Formula,sysdate);
          insert into decision_log(id,id_credit,status,item_name,result,remark,formula,update_time)
               values(seq_decision_log.nextval,v_IdCredit,'v','DelayMinutes',v_DelayMinutes,'POST',v_Formula,sysdate);

          select object_status into v_ObjectStatus from decision_work_flow where id=v_WfiId;
          if v_ObjectStatus in ('e','d','n') then
             if v_ObjectStatus='d' then
                v_ObjectStatus:='x';
             elsif v_ObjectStatus='n' then
                if v_CreditModel='P2P_HAIR' then
                    v_ObjectStatus:='w';
                else
                    select a.prod_type into v_ProdType from product a,cs_credit b where a.id=b.id_product and b.id=v_IdCredit;
                    if v_ProdType=5 then
                        v_ObjectStatus:='b';
                    else
                        v_ObjectStatus:='m';
                    end if;
                end if;
             elsif v_ObjectStatus='e' then
               v_AuditStage:=pkg_decision.get_credit_grant_group(v_IdCredit,'POST');
             end if;

             update cs_credit set status=v_ObjectStatus,risk_group=v_RiskGroup,wfi_id=v_WfiId,wfi_time=sysdate,delay_minutes=v_DelayMinutes,audit_stage=v_AuditStage
              where id=v_IdCredit and status='v';
             if sql%rowcount=1 then
                insert into decision_log(id,id_credit,status,item_name,result,remark,formula,update_time)
                     values(seq_decision_log.nextval,v_IdCredit,'v','status',v_ObjectStatus,fun_getreg_value(15,v_ObjectStatus),'ObjectStatus='||v_ObjectStatus,sysdate);
             else
                update cs_credit set f_log='Old status is not v!' where id=v_IdCredit;
             end if;
          else
             update cs_credit set f_log='Object status ['||v_ObjectStatus||'] is error!' where id=v_IdCredit;
          end if;
          commit;
        end if;
      end if;
   end loop;
   close curV;

   --status from x->d
   open curX;
   loop
      fetch curX into v_IdCredit,v_IdPerson;
      exit when curX%notfound;
      v_DecisionStage:='x';
      update cs_credit set status='d',update_time=sysdate where id=v_IdCredit and status='x';
      if sql%rowcount=1 then
          insert into decision_log(id,id_credit,status,item_name,result,remark,formula,update_time)
                  values(seq_decision_log.nextval,v_IdCredit,'x','status','d',fun_getreg_value(15,'d'),'x->d',sysdate);
          delete decision_element_data_history where id_credit=v_IdCredit;
          insert into decision_element_data_history select * from decision_element_data where id_credit=v_IdCredit;
          delete decision_element_data where id_credit=v_IdCredit;

          select a.prod_type into v_ProdType from product a,cs_credit b where a.id=b.id_product and b.id=v_IdCredit;
          --申请循环贷修改循环贷资质状态
          if v_ProdType=8 then
             update cycle_eligible
             set status=5,update_time=sysdate
             where id_person=v_IdPerson and status=0 and trunc(sysdate)>=start_date and trunc(sysdate)<=end_date;
          else
             --申请其他贷修改循环贷资质状态
             update cycle_eligible
             set status=6,update_time=sysdate
             where id_person=v_IdPerson and status=0 and trunc(sysdate)>=start_date and trunc(sysdate)<=end_date;
          end if;
      else
          update cs_credit set f_log='Old status is not x!' where id=v_IdCredit;
      end if;
      commit;
   end loop;
   close curX;

   --status from m->n
   open curM;
   loop
      fetch curM into v_IdCredit,v_IdPerson,v_CreditAmount;
      exit when curM%notfound;
      v_DecisionStage:='m';
      select a.prod_type into v_ProdType from product a,cs_credit b where a.id=b.id_product and b.id=v_IdCredit;
      if v_ProdType in(6,7) then
        v_ObjectStatus:='h';
      elsif v_ProdType=8 then
        v_ObjectStatus:='i';
      else
        v_ObjectStatus:='n';
      end if;

      update cs_credit set status=v_ObjectStatus,update_time=sysdate where id=v_IdCredit and status='m';
      if sql%rowcount=1 then
        --申请循环贷修改循环贷资质状态
        if v_ProdType=8 then
          update cycle_eligible
          set active_amount=max_amount,available_amount=max_amount,status=1,update_time=sysdate,
              active_date=trunc(sysdate),end_date=to_date('2050-01-01','yyyy-MM-dd')
          where id_person=v_IdPerson and status=0 and trunc(sysdate)>=start_date and trunc(sysdate)<=end_date;
        end if;

        --学生POS贷通过发送短信
        if v_ProdType=1 then
          insert into collection_auto_message(id,contract_no,cpd,phone_number,message,create_time,status,app_code)
          select seq_collection_auto_message.nextval,id_credit,0,contact_value,'您已通过审批，我司从未委托任何中介或个人以兼职或冲销量等为由办理分期，请谨防受骗！如有疑问请拨打客服4008075546',sysdate,0,'LV_COLL'
          from (select regexp_replace(t.contact_value,'^0','') contact_value,t.id_credit from cs_contact t where t.person_type='1' and t.contact_type='2' and t.id_credit=v_IdCredit) a;
        end if;

        --申请交叉贷修改循环贷资质状态
        if v_ProdType in(6,7) then
          select count(1) into v_Count from cross_active_detail a,cross_active_list b
           where a.active_id=b.active_id and trunc(sysdate)>=b.start_date and trunc(sysdate)<=b.end_date and a.id_person=v_IdPerson;

          if v_Count>0 then
             --2016/04/25 wangxiaofeng
             select nvl(max(to_number(t.element_value)),50) into v_Score
             from decision_element_data t
             where element_type='preResult' and t.element_name='FraudScoreCate' and t.id_credit=v_IdCredit;
             --2016/09/2 wangxiaofeng
             select nvl(max(a.max_amount),1) into v_MaxAmount from cross_active_detail a,cross_active_list b
                where rownum=1 and a.active_id=b.active_id and trunc(sysdate)>=b.start_date and trunc(sysdate)<=b.end_date and a.id_person=v_IdPerson;

             v_LimitRate:=round(v_CreditAmount/v_MaxAmount,3);

             if (v_Score<=35 and v_LimitRate<=0.4) or(v_Score<=19 and v_LimitRate>0.4) then
               update cycle_eligible set active_amount=fun_min(max_amount，fun_max(min_amount，v_MaxAmount-v_CreditAmount)),
                     available_amount=fun_min(max_amount，fun_max(min_amount，v_MaxAmount-v_CreditAmount)),
                     status=1,active_date=trunc(sysdate),end_date=to_date('2050-01-01','yyyy-MM-dd')
               where id_person=v_IdPerson and status=0 and trunc(sysdate)>=start_date and trunc(sysdate)<=end_date;
            end if;
          end if;
        end if;

        insert into decision_log(id,id_credit,status,item_name,result,remark,formula,update_time)
             values(seq_decision_log.nextval,v_IdCredit,'m','status','n',fun_getreg_value(15,'n'),'m->n',sysdate);

        delete decision_element_data_history where id_credit=v_IdCredit;
        insert into decision_element_data_history select * from decision_element_data where id_credit=v_IdCredit;
        delete decision_element_data where id_credit=v_IdCredit;
      else
        update cs_credit set f_log='Old status is not m!' where id=v_IdCredit;
      end if;
      commit;
   end loop;
   close curM;
   p_ReturnCode:='A';
   return;
Exception
   When others Then
     error_info := sqlerrm;
     rollback;
     p_ReturnCode:='Z-['||v_IdCredit||']'||error_info;
     --异常发送邮件
     insert into sys_email_list(email_boby,id,mail_type,key_word,from_user,mail_to,subject,status,create_time,plan_time)
     values (p_ReturnCode,seq_sys_email_list.nextval,'DE','决策引擎报警','dafy@mail.dafycredit.com.cn','wangxiaofeng@dafycredit.com;luchangjiang@dafycredit.com;lixiaoxi@dafycredit.com;zhangjinwen@dafycredit.com;luojingna@dafycredit.com',v_DecisionStage||'决策引擎运行异常',0,sysdate,sysdate);
     --异常发送短信
     insert into collection_auto_message(id,contract_no,cpd,phone_number,message,create_time,status,app_code)
      values( seq_collection_auto_message.nextval,100000,0,'18218021986,13715085819,13828735725,13553835518,18566255697',v_IdCredit||'申请单号决策引擎运行异常',sysdate,0,'LV_COLL');
     --判断是否是周六周日
     if to_char(sysdate,'d') in(1,7) then
       select count(1) into v_Count from cs_credit t where t.f_log='决策异常' and t.commit_time>=trunc(sysdate);
       if v_Count<3 then
         --异常合同暂时拒绝
         update cs_credit set status='d',update_time=sysdate,f_log='决策异常!' where id=v_IdCredit;

         delete decision_element_data_history where id_credit=v_IdCredit;
         insert into decision_element_data_history select * from decision_element_data where id_credit=v_IdCredit;
         delete decision_element_data where id_credit=v_IdCredit;
       else
         --异常合同暂时不决策
         update cs_credit t set t.decision_random=-1,update_time=sysdate,f_log='决策异常!' where id=v_IdCredit;
       end if;
     else
       --异常合同暂时不决策
       update cs_credit t set t.decision_random=-1,update_time=sysdate,f_log='决策异常!' where id=v_IdCredit;
     end if;
     commit;
end;
/

