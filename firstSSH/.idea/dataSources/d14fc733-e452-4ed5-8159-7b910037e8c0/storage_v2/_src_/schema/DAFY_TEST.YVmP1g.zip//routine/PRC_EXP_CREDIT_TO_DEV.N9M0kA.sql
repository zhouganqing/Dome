create procedure PRC_EXP_CREDIT_TO_DEV(p_IdCredit        cs_credit.id%type,
                                                p_ReturnCode      out varchar2) is
  -- Author  : Luchangjiang
  -- Create Date : 2015-2-10
  -- Purpose : 将本库的合同数据导入到测试库，并置状态为 S, 主要应用于决策引擎的测试;
  error_info           varchar2(1000);
  v_Count              integer;
begin
  delete instalment@dbl_dev_db where id_credit=p_IdCredit;
  delete wfi_ck_result@dbl_dev_db where id_credit=p_IdCredit;
  delete wfi_final_decision@dbl_dev_db where id_credit=p_IdCredit;
  delete wfi_transfer_log@dbl_dev_db where id_credit=p_IdCredit;
  delete cs_audit_log2@dbl_dev_db where id_credit=p_IdCredit;
  delete decision_log@dbl_dev_db where id_credit=p_IdCredit;
  delete decision_element_data_history@dbl_dev_db where id_credit=p_IdCredit;
  delete decision_element_data@dbl_dev_db where id_credit=p_IdCredit;

  delete cs_client_photo@dbl_dev_db where id_credit=p_IdCredit;
  delete cs_goods@dbl_dev_db where id_credit=p_IdCredit;
  delete cs_goods@dbl_dev_db where id in (select id from cs_goods where id_credit=p_IdCredit);
  delete cs_family_info@dbl_dev_db where id_credit=p_IdCredit;
  delete cs_family_info@dbl_dev_db where id in (select id from cs_family_info where id_credit=p_IdCredit);
  delete cs_employer@dbl_dev_db where id_credit=p_IdCredit;
  delete cs_employer@dbl_dev_db where id in (select id from cs_employer where id_credit=p_IdCredit);
  delete cs_experience@dbl_dev_db where id_credit=p_IdCredit;
  delete cs_experience@dbl_dev_db where id in (select id from cs_experience where id_credit=p_IdCredit);
  delete cs_contact@dbl_dev_db where id_credit=p_IdCredit;
  delete cs_contact@dbl_dev_db where id in (select id from cs_contact where id_credit=p_IdCredit);
  delete cs_address@dbl_dev_db where id_credit=p_IdCredit;
  delete cs_address@dbl_dev_db where id in (select id from cs_address where id_credit=p_IdCredit);
  delete cs_other_person@dbl_dev_db where id_credit=p_IdCredit;
  delete cs_other_person@dbl_dev_db where id in (select id from cs_other_person where id_credit=p_IdCredit);
  delete cs_credit@dbl_dev_db where id=p_IdCredit;

  select count(1) into v_Count from cs_person@dbl_dev_db where id =(select id_person from cs_credit where id=p_IdCredit);
  if v_Count=0 then
     insert into cs_person@dbl_dev_db select * from cs_person
      where id=(select id_person from cs_credit where id=p_IdCredit);
  end if;
  insert into cs_credit@dbl_dev_db select * from cs_credit where id=p_IdCredit;
  insert into cs_other_person@dbl_dev_db select * from cs_other_person where id_credit=p_IdCredit;
  insert into cs_address@dbl_dev_db select * from cs_address where id_credit=p_IdCredit;
  insert into cs_contact@dbl_dev_db select * from cs_contact where id_credit=p_IdCredit;
  insert into cs_experience@dbl_dev_db select * from cs_experience where id_credit=p_IdCredit;
  insert into cs_employer@dbl_dev_db select * from cs_employer where id_credit=p_IdCredit;
  insert into cs_family_info@dbl_dev_db select * from cs_family_info where id_credit=p_IdCredit;
  insert into cs_goods@dbl_dev_db select * from cs_goods where id_credit=p_IdCredit;
  insert into cs_client_photo@dbl_dev_db select * from cs_client_photo where id_credit=p_IdCredit;

  update cs_credit@dbl_dev_db set status='s' where id=p_IdCredit;
  commit;
  p_ReturnCode:='A';
  return;
Exception
   When others Then
     error_info := sqlerrm;
     rollback;
     p_ReturnCode:='Z-'||error_info;
end;


/

