create procedure prc_call_service_user_log(p_UserId       number,
                                                      p_roles        varchar2,
                                                      p_status       number,
                                                      p_ReturnCode   out varchar2) is
  error_info         varchar2(1000);
  v_Count            number;
--create user:WangXiaoFeng
--use: 记录使用呼叫中心用户的上班状态等
--date:2015-03-30
begin
  select count(1) into v_Count from call_service_user_log t where t.end_time is null and t.user_id=p_UserId;

  if v_Count>=1 then
    update call_service_user_log a
    set end_time=sysdate 
     where  a.end_time is null and a.user_id=p_UserId 
     and a.start_time=(select max(start_time) from call_service_user_log where end_time is null and user_id=p_UserId);
                  
    insert into call_service_user_log(user_id,roles,status,start_time)
    values(p_UserId,p_roles,p_status,sysdate);
    
  else
    insert into call_service_user_log(user_id,roles,status,start_time)
    values(p_UserId,p_roles,p_status,sysdate);
  end if;

  commit;
  p_ReturnCode:='A';
  return;
Exception
  When others Then
    error_info := sqlerrm;
    Rollback;

    p_ReturnCode := 'Z-'||error_info;
end prc_call_service_user_log;


/

