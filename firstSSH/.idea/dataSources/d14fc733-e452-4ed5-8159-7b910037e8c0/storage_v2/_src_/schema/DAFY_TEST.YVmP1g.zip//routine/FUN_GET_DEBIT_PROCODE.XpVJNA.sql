create function fun_get_debit_procode(p_procode checkoff_batch_detail.procode%type)
                                          return varchar2 is
--Create User:wangxiaofeng;
--Use:获取常用代扣放回代码对应得中文意义
begin
    if p_procode = 'FSBR0000' then
      return '处理成功';
    elsif p_procode = 'FSBR0010' then
      return '银行已受理';
    elsif p_procode = 'FSBR9999' then
      return '通用失败';
    elsif p_procode = 'FSBR9998' then
      return '通用拒绝';
    elsif p_procode = 'FSBR6017' then
      return '帐户质押额度不足或可用额度不足';
    elsif p_procode = 'FSBR6018' then
      return '帐户授信额度不足或可用额度不足';
    elsif p_procode = 'FSBR6019' then
      return '帐户圈存额度不足或可用额度不足';
    elsif p_procode = 'FSBR6037' then
      return '账号或卡号不存在';
    elsif p_procode = 'FSBR6038' then
      return '户名不符';
    elsif p_procode = 'FSBR6039' then
      return '账户被冻结，无法入账';
    elsif p_procode = 'FSBR6040' then
      return '金额不足';
    elsif p_procode = 'FSBR6041' then
      return '账户状态错误';
    elsif p_procode = 'FSBR6042' then
      return '账户密码错误';
    elsif p_procode = 'FSBR6043' then
      return '当日通兑业务累计金额超过规定金额';
    elsif p_procode = 'FSBR6044' then
      return '币种不支持';
    elsif p_procode = 'FSBR6045' then
      return '金额大于单笔业务限额';
    elsif p_procode = 'FSBR6046' then
      return '证件号码不符';
    elsif p_procode = 'FSBR6047' then
      return '手机号码不符';
    elsif p_procode = 'FSBR6051' then
      return '已收妥未入账';
    elsif p_procode = 'FSBR6999' then
      return '其他原因';
    elsif p_procode = 'FSBR6052' then
      return '缴费协议号不存在';
    elsif p_procode = 'FSBR6053' then
      return '欠费信息不存在';
    elsif p_procode = 'FSBR6054' then
      return '欠费信息不正确';
    elsif p_procode = 'FSBR6055' then
      return '缴费金额不符';
    elsif p_procode = 'FSBR6056' then
      return '手续费不符';
    elsif p_procode = 'FSBR6057' then
      return '主动缴费处理失败';
    else
      return p_procode;
    end if;
end fun_get_debit_procode;


/

