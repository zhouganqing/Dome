create procedure PRC_AUTO_RESTOREINSURANCE(p_ReturnCode    out varchar2) is
/*恢复保险-庾文峰*/
error_info            varchar2(1000);
v_idCredit            insurance_process.id_credit%type;
v_restoreDate         date;

   
   cursor cur is select id_credit,restore_date from insurance_process where status=0 and restore_date is not null;

begin
  open cur;
    loop
    fetch cur into v_idCredit,v_restoreDate;
      exit when cur%notfound;
      
      update instalment set status='a' where type_instalment=70 and status='n' and date_due>=v_restoreDate and id_credit=v_idCredit;
      
      update insurance_process set status=1 where id_credit=v_idCredit and status=0;
      
      
    end loop;
commit;
   p_ReturnCode:='A';
   return;
Exception
   When others Then
     error_info := sqlerrm;
     p_ReturnCode:='Z-'||error_info;
     rollback;
end;


/

