create function fun_get_current_debit(p_id_credit cs_credit.id%type)
                                          return number is
  --获取当前逾期期款
  --create use:wangxiaofeng
  
  v_value_instalment   number;
begin
  select nvl(sum(t.value_instalment)-sum(t.value_pay),0) into v_value_instalment from instalment t 
  where t.id_credit=p_id_credit and t.date_due<trunc(sysdate) and t.status='a' and t.paystatus in('a','u') and t.type_instalment!=8
  ;--group by t.id_credit;
  return(v_value_instalment);
end fun_get_current_debit;


/

