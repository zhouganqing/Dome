create procedure PRC_COLLECTION_DISTRIBUTION(p_StageId         collection_stage.id%type,
                                                        p_UserList        varchar2,
                                                        p_UpdateUser      collection_data.update_user%type,
                                                        p_StayDays       number,
                                                        p_ReturnCode      out varchar2) is
   error_info            varchar2(1000);
   spltUserList          ty_str_split;
   v_DateDue             collection_data.date_due%type;
   v_IdCredit            cs_credit.id%type;
   v_AmountLeft          number;
   v_Ident               cs_person.ident%type;
   v_IdentOld            cs_person.ident%type;

   v_EpibolyFlag         collection_stage.epiboly_flag%type;
   v_StartDate           date;
   v_EndDate             date;

   --v_CreditCount         integer;
   --v_AvgCount            integer;

   v_CurrUserId          collection_data.collector_id%type;
   v_UserIdx             integer:=1;

   type ref_cur_type is ref cursor;
   cur               ref_cur_type;
   curCredit         ref_cur_type;

begin
   spltUserList:=fun_split(p_UserList,',');

   select epiboly_flag,trunc(sysdate)-max_days,trunc(sysdate)-min_days into v_EpibolyFlag,v_StartDate,v_EndDate
   from collection_stage where id=p_StageId;

   if v_StartDate>v_EndDate then
     open cur for select ident,sum(value_instalment-amount_pay) amount_left from v_collection_data a where 1=1 and a.date_due<=v_EndDate
                  and not exists (select '#' from collection_data where id_credit=a.id_credit and stay_date>=trunc(sysdate))
                  and a.id_credit not in (select t.contractno from checkoff_batch_detail t where t.procode=(decode(fun_get_collection_parameters('DEBIT_FLAG'),'1','代扣中','')))
                  group by ident order by sum(value_instalment-amount_pay) desc;
     loop
        fetch cur into v_Ident,v_AmountLeft;
        exit when cur%notfound;

        --同一个IDENT只能分配给一个催收员;
        --在此前提下进行人员轮排;
        if v_IdentOld is not null and v_IdentOld<>v_Ident then
           v_UserIdx:=v_UserIdx+1;
           if v_UserIdx>spltUserList.Count then
              v_UserIdx:=1;
           end if;
        end if;
        v_CurrUserId:=spltUserList(v_UserIdx);

        open curCredit for select id_credit,date_due,value_instalment-amount_pay from v_collection_data a where 1=1 and a.date_due<=v_EndDate
                           and not exists (select '#' from collection_data where id_credit=a.id_credit and stay_date>=trunc(sysdate))
                           and a.id_credit not in (select t.contractno from checkoff_batch_detail t where t.procode=(decode(fun_get_collection_parameters('DEBIT_FLAG'),'1','代扣中','')))
                           and ident=v_Ident;
        loop
            fetch curCredit into v_IdCredit,v_DateDue,v_AmountLeft;
            exit when curCredit%notfound;

            delete from collection_data where id_credit = v_IdCredit  and collection_date=trunc(sysdate);
            insert into collection_data(id,id_credit,date_due,epiboly_flag,collector_id,collection_date,amount_left,update_user,update_time,stay_date)
                 values(seq_collection_data.nextval,v_IdCredit,v_DateDue,v_EpibolyFlag,v_CurrUserId,trunc(sysdate),v_AmountLeft,p_UpdateUser,sysdate,trunc(sysdate)+p_StayDays);
        end loop;
        close curCredit;

        v_IdentOld:=v_Ident;
     end loop;
   else
     open cur for select ident,sum(value_instalment-amount_pay) amount_left from v_collection_data a where 1=1 and a.date_due>=v_StartDate and a.date_due<=v_EndDate
                  and not exists (select '#' from collection_data where id_credit=a.id_credit and stay_date>=trunc(sysdate))
                  and a.id_credit not in (select t.contractno from checkoff_batch_detail t where t.procode=(decode(fun_get_collection_parameters('DEBIT_FLAG'),'1','代扣中','')))
                  group by ident order by sum(value_instalment-amount_pay) desc;
     loop
        fetch cur into v_Ident,v_AmountLeft;
        exit when cur%notfound;

        --同一个IDENT只能分配给一个催收员;
        --在此前提下进行人员轮排;
        if v_IdentOld is not null and v_IdentOld<>v_Ident then
           v_UserIdx:=v_UserIdx+1;
           if v_UserIdx>spltUserList.Count then
              v_UserIdx:=1;
           end if;
        end if;
        v_CurrUserId:=spltUserList(v_UserIdx);

        open curCredit for select id_credit,date_due,value_instalment-amount_pay from v_collection_data a where 1=1 and a.date_due>=v_StartDate and a.date_due<=v_EndDate
                           and not exists (select '#' from collection_data where id_credit=a.id_credit and stay_date>=trunc(sysdate))
                           and a.id_credit not in (select t.contractno from checkoff_batch_detail t where t.procode=(decode(fun_get_collection_parameters('DEBIT_FLAG'),'1','代扣中','')))
                           and ident=v_Ident;
        loop
            fetch curCredit into v_IdCredit,v_DateDue,v_AmountLeft;
            exit when curCredit%notfound;

            delete from collection_data where id_credit = v_IdCredit and collection_date=trunc(sysdate);
            insert into collection_data(id,id_credit,date_due,epiboly_flag,collector_id,collection_date,amount_left,update_user,update_time,stay_date)
                 values(seq_collection_data.nextval,v_IdCredit,v_DateDue,v_EpibolyFlag,v_CurrUserId,trunc(sysdate),v_AmountLeft,p_UpdateUser,sysdate,trunc(sysdate)+p_StayDays);
        end loop;
        close curCredit;

        v_IdentOld:=v_Ident;
     end loop;
   end if;

   commit;
   p_ReturnCode:='A';
   return;
Exception
   When others Then
     error_info := sqlerrm;
     p_ReturnCode:='Z-'||error_info;
     rollback;
end;


/

