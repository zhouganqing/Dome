create procedure SAVE_TASK_GRANT(p_RoleId       varchar2,
                                            p_SubsysName   varchar2,
                                            p_TaskList     varchar2,
                                            p_UpdateUser   varchar2,
                                            p_ReturnCode   out varchar2) is
  /*2014-8-15  鲁长江
    按角色保存权限*/
  error_info      varchar2(1000);
  spltTaskList    ty_str_split;
  idx             integer:=0;
begin
  delete sys_task_grant where role_id=p_RoleId and task_code in (select task_code from sys_task_list where subsys_name=p_SubsysName);
  if p_TaskList is not null then
     spltTaskList:=fun_split(p_TaskList,',');
     for idx in 1..spltTaskList.Count loop
        delete sys_task_grant where task_code=spltTaskList(idx) and role_id in
        (select to_char(id) from sys_user_list where role_id=p_RoleId);

        insert into sys_task_grant(role_id,task_code,update_user,update_time)
             values(p_RoleId,spltTaskList(idx),p_UpdateUser,sysdate);
     end loop;
  end if;
  commit;
  p_ReturnCode:='A';
  return;
Exception
  When others Then
    error_info := sqlerrm;
    Rollback;

    p_ReturnCode := 'Z-'||error_info;
end SAVE_TASK_GRANT;


/

