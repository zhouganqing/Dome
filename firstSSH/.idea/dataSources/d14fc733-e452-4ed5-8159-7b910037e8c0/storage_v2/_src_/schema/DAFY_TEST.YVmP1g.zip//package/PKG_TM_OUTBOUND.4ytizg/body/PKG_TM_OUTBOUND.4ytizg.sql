create package body PKG_TM_OUTBOUND is

  error_info  varchar2(1000);
  v_Count     number(4);
  --更改交叉现金贷活动表及客户活动信息表状态
  procedure prc_auto_active_status(p_ReturnCode out varchar2)
    is
    begin
      --启用活动
      update cross_active_list t set t.status=1,t.update_time=sysdate where t.status=0 and trunc(t.start_date)=trunc(sysdate);
      --禁用活动  
      update cross_active_list t set t.status=2,t.update_time=sysdate where trunc(t.end_date+1)=trunc(sysdate);
      --将活动到期客户状态改为已申请
      update cross_active_detail t set t.status=1,t.update_time=sysdate where t.active_id in(select a.active_id from cross_active_list a 
                                                        where a.status=2 and trunc(a.end_date+1)=trunc(sysdate));
      commit;
      p_ReturnCode := 'A';
      return;
    exception
      When others Then
        error_info := sqlerrm;
        Rollback;
    
      p_ReturnCode := 'Z-' || error_info;
    end prc_auto_active_status;
  
  
  --生成电销等待拨打列表
  procedure prc_get_tm_wait_call_list( p_ReturnCode   out varchar2)
    is
    
    v_IdCredit             cs_credit.id%type;
    v_ContractNo           cs_credit.contract_no%type;
    v_IdPerson             cs_person.id%type; 
    v_Name                 cs_person.name%type; 
    v_Sex                  varchar2(4);
    v_Ident                cs_person.ident%type;
    v_Age                  number(3);   
    v_Birthdate            date; 
    v_Phone                varchar2(20);
    v_OtherPhone           varchar2(20); 
    v_OtherPhoneName       varchar2(30);
    v_OtherPhoneRelation   varchar2(30); 
    v_CurrentCity          varchar2(30);
    v_CurrentAddress       varchar2(200); 
    v_ActiveId             cross_active_list.active_id%type; 
    v_MaxAmount            number(8); 
    v_EndureAmount         number(8); 
    v_IsDd                 number(2);
    v_BankName             cs_experience.bank_name%type;
    v_BankNo               cs_experience.bank_no%type;
    v_CallStage            number(2):=1;
    v_WaitCallDate         date; 
    v_Age55Date            date;
    v_AppDate              date;
    v_ProductName          varchar(200);
    v_CreditAmount         number(10,2);
    v_PaymentNum           number(3);
    v_SellerAddress        varchar(200);
    v_Nums                 number(2);
    
    cursor curActiveUser is select a.id_person,b.name,decode(b.sex,'f','女','男') sex,b.ident,
      to_date(substr(b.ident,7,4)||'-'||substr(b.ident,11,2)||'-'||substr(b.ident,13,2),'yyyy-mm-dd') birthdate,
      a.active_id,a.max_amount,a.endure_amount,trunc(sysdate)+ntile(7) over(order by a.id_person) wait_call_date,
      add_months(to_date(substr(b.ident,7,4)||'-'||substr(b.ident,11,2)||'-'||substr(b.ident,13,2),'yyyy-mm-dd'),55*12) age_55_date
      from cross_active_detail a,cs_person b
      where a.id_person=b.id and a.active_id=v_ActiveId;
    begin
      --生成电销Call 1阶段
      --查找即将活动开始的活动ID
      for activeList in(select t.active_id from cross_active_list t where t.status=1 and trunc(t.start_date)=trunc(sysdate))
      loop
        v_ActiveId:=activeList.Active_Id;
        --查找是否已添加到待拨打列表中
        select count(1) into v_Count from tm_outbound_call_list a where a.active_id=v_ActiveId;
        if v_Count<= 0 then
          open curActiveUser;
          loop
            fetch curActiveUser into v_IdPerson,v_Name,v_Sex,v_Ident,v_Birthdate,v_ActiveId,v_MaxAmount,v_EndureAmount,v_WaitCallDate,v_Age55Date;
            exit when curActiveUser%notfound;
            v_Age:=trunc(months_between(trunc(sysdate),v_Birthdate)/12);
            
            --获取客户最近一个有效合同的基本信息
            select a.id,a.contract_no,trunc(a.app_date) app_date,a.credit_amount,c.payment_num,b.address,row_number() over(order by a.id desc) nums 
            into v_IdCredit,v_ContractNo,v_AppDate,v_CreditAmount,v_PaymentNum,v_SellerAddress,v_Nums
            from cs_credit a,sellerplace b,product c 
            where a.id_sellerplace=b.id and a.id_product=c.id and a.status in('a','p','k') and a.id_person=v_IdPerson and rownum=1;
            
            --获取客户最近一个合同购买的产品名称
            select b.name||':'||a.producer||' '||a.brand product_name,row_number() over(order by a.goods_price desc) goods_price 
            into v_ProductName,v_Nums
            from cs_goods a,goods_type b 
            where a.id_goods_type=b.id and a.id_credit=v_IdCredit and rownum=1;

            --获取当前居住城市和居住地址
            select c.city,c.province||' '||c.city||' '||c.region||' '||c.town||' '||c.street||' '||c.building||' '||c.room  
            into v_CurrentCity,v_CurrentAddress from cs_address c where c.address_type=2 and c.id_credit=v_IdCredit;
            
            --获取合同的银行账号信息及还款方式
            select t.bank_name,t.bank_no,t.is_dd into v_BankName,v_BankNo,v_IsDd from cs_experience t where t.id_credit=v_IdCredit;
            
            --获取最近一个本人的手机号码
            select count(1) into v_Count from cs_contact_portion t 
            where t.contact_type='移动电话' and t.person_type='本人' and (t.status='1' or t.status is null) and t.id_person=v_IdPerson;
            if v_Count>=1 then
              select contact_value into v_Phone from
              (select t.contact_value,row_number() over(order by update_time desc,status) nums from cs_contact_portion t 
              where t.contact_type='移动电话' and t.person_type='本人' and (t.status='1' or t.status is null) and t.id_person=v_IdPerson)
              where nums=1;
            else
              select contact_value into v_Phone from cs_contact t where t.person_type='1' and t.contact_type=2 and t.id_credit=v_IdCredit;
            end if;
            
            --获取最近一个家属联系人的号码
            select count(1) into v_Count from cs_contact_portion t 
              where t.contact_type='移动电话' and t.person_type in('父母','配偶','兄弟姐妹','儿女','其他亲戚') 
              and (t.status='1' or t.status is null) and t.id_person=v_IdPerson;
            if v_Count>=1 then  
              select person_type,name,contact_value into v_OtherPhoneRelation,v_OtherPhoneName,v_OtherPhone from
              (select t.person_type,t.name,t.contact_value,row_number() over(order by update_time desc,person_type,status) nums from cs_contact_portion t 
              where t.contact_type='移动电话' and t.person_type in('父母','配偶','兄弟姐妹','儿女','其他亲戚') 
              and (t.status='1' or t.status is null) and t.id_person=v_IdPerson)
              where nums=1;
            else
              select reg_val_name,name,contact_value into v_OtherPhoneRelation,v_OtherPhoneName,v_OtherPhone from
              (select c.reg_val_name,b.name,a.contact_value,row_number() over(order by a.person_type desc) nums from cs_contact a,cs_other_person b,registers c
              where a.id_credit=b.id_credit and a.person_type=b.person_type
              and a.person_type=c.reg_val_code and c.reg_number=265 and c.status='a'
              and a.contact_type=2 and a.person_type!='1' and a.id_credit=v_IdCredit)
              where nums=1;
            end if;
            
            --插入等待呼叫列表
            insert into tm_outbound_call_list
              (id,id_person,sex,ident,age,birthdate,phone,other_phone,other_phone_name,other_phone_relation,
               current_city,current_address,active_id,max_amount,endure_amount,is_dd,call_stage,age_55_date,
               wait_call_date,name,contract_no,id_credit,app_date,product_name,credit_amount,payment_num,
               seller_address,bank_name,bank_no)
            values
              (seq_tm_outbound_call_list.nextval,v_IdPerson,v_Sex,v_Ident,v_Age,v_Birthdate,v_Phone,v_OtherPhone,
               v_OtherPhoneName,v_OtherPhoneRelation,v_CurrentCity,v_CurrentAddress,v_ActiveId,v_MaxAmount,
               v_EndureAmount,v_IsDd,v_CallStage,v_Age55Date,v_WaitCallDate,v_Name,v_ContractNo,v_IdCredit,
               v_AppDate,v_ProductName,v_CreditAmount,v_PaymentNum,v_SellerAddress,v_BankName,v_BankNo);
          end loop;
          close curActiveUser;
          commit;
        end if;        
      end loop;
      
      --客户当前逾期合同已还款，不存在已呼叫结果
      update tm_outbound_call_list t set t.status=0,t.wait_call_date=trunc(sysdate) 
      where not exists(select '#' from collection_data_temp a where a.ident=t.ident)
            and not exists(select 1 from tm_outbound_call_result c where c.id_person=t.id_person)
            and exists(select 1 from cross_active_list d where d.active_id=t.active_id and t.status=1)
            and t.status=5;
            
      --生成电销Call 2阶段
      update tm_outbound_call_list t set t.call_stage=2,t.update_time=sysdate
      where exists(select 1 from cross_active_list a where a.active_id=t.active_id and a.status=1 and trunc(a.start_date+15)=trunc(sysdate));
      
      --生成电销Call 3阶段
      update tm_outbound_call_list t set t.call_stage=3,t.update_time=sysdate
      where exists(select 1 from cross_active_list a where a.active_id=t.active_id and a.status=1 and trunc(a.start_date+64)=trunc(sysdate));
      commit;
           
      --生成电销Call 2阶段有效拨打List
      for activeList in(select t.start_date,t.active_id from cross_active_list t where t.status=1 and t.active_id not in(361,381,382)
                    and trunc(sysdate) between t.start_date+15 and t.start_date+29)
      loop
        for tm in(select t.id_person,t.call_result,t.call_result_type,t.update_user from 
        (
        select a.id_person,a.call_result,a.call_result_type,a.update_user,row_number() over(partition by a.id_person order by a.update_time desc) nums
        from tm_outbound_call_result a 
        where a.update_time>=trunc(sysdate-14) and a.update_time<trunc(sysdate-13)) t
        where t.nums=1 
        and t.call_result_type in('R1','R2','R3','R4')
        and not exists(select '#' from 
        (
        select a.id_person,a.call_result_type,row_number() over(partition by a.id_person order by a.update_time desc) nums
        from tm_outbound_call_result a 
        where a.update_time>=trunc(sysdate-14) and a.update_time<trunc(sysdate-13)) b 
        where b.id_person=t.id_person and b.call_result_type in('R5','R6') and b.nums=2 and t.call_result_type='R3')
        and not exists (select '#' from tm_outbound_call_result c where c.update_time>=trunc(sysdate)-7 and c.id_person=t.id_person)
        and not exists (select '#' from tm_outbound_call_result c 
                       where c.update_time>=trunc(activeList.Start_Date) and c.update_time=trunc(sysdate-14) and c.id_person=t.id_person) 
        ) loop
          update tm_outbound_call_list k set k.call_result=tm.call_result,k.call_result_type=tm.call_result_type,
          k.wait_call_date=trunc(sysdate),k.call_user=tm.update_user,k.update_time=sysdate
          where k.active_id=activeList.Active_Id and k.id_person=tm.id_person and k.status=0
           and exists(select '#' from cross_active_detail c where c.id_person=k.id_person and c.active_id=k.active_id and c.status=0);
        end loop;
        commit;
      end loop;            
        
      --生成电销Call 3阶段有效拨打List
      for activeList in(select t.start_date,t.active_id from cross_active_list t where t.status=1 and trunc(t.start_date+64)=trunc(sysdate))
      loop
        for tm in(select t.id_person,t.call_result,t.call_result_type,t.update_user from 
        (
        select a.id_person,a.call_result,a.call_result_type,a.update_user,row_number() over(partition by a.id_person order by a.update_time desc) nums
        from tm_outbound_call_result a 
        where a.update_time>=trunc(activeList.Start_Date+16) and a.update_time<trunc(activeList.Start_Date+65)) t
        where t.nums=1 
        and t.call_result_type in('R1','R2','R3','R4')
        and not exists(select '#' from 
        (
        select a.id_person,a.call_result_type,row_number() over(partition by a.id_person order by a.update_time desc) nums
        from tm_outbound_call_result a 
        where a.update_time>=trunc(activeList.Start_Date+16) and a.update_time<trunc(activeList.Start_Date+65)) b 
        where b.id_person=t.id_person and b.call_result_type in('R5','R6') and b.nums=2)
        and not exists (select '#' from tm_outbound_call_result c where c.update_time>=trunc(sysdate)-10 and c.id_person=t.id_person) 
        ) loop
          update tm_outbound_call_list k set k.call_result=tm.call_result,k.call_result_type=tm.call_result_type,
            k.wait_call_date=trunc(sysdate),k.call_user=tm.update_user,k.update_time=sysdate 
          where k.active_id=activeList.Active_Id and k.id_person=tm.id_person and k.status=0
           and exists(select '#' from cross_active_detail c where c.id_person=k.id_person and c.active_id=k.active_id and c.status=0);
        end loop;
        --平均分配成7份
        update tm_outbound_call_list a set a.wait_call_date=(
         select wait_call_date from (select b.id,trunc(sysdate)+ntile(7) over(order by b.id_person) wait_call_date 
           from tm_outbound_call_list b 
           where b.call_stage=3 and b.status=0 and b.wait_call_date>=trunc(sysdate) and b.active_id=activeList.Active_Id)c 
         where c.id=a.id)
        where a.call_stage=3 and a.status=0 and a.wait_call_date>=trunc(sysdate) and a.active_id=activeList.Active_Id;
        
        commit;
      end loop;
      
      --保存user call 到日志表
      insert into tm_outbound_user_call_log
      (id_person,active_id,call_stage,call_user,status,update_user,update_time)
      select t.id_person,t.active_id,t.call_stage,t.call_user,t.status,t.update_user,t.update_time from tm_outbound_user_call t;

      --未分配的Call list 回收
      update tm_outbound_call_list t set t.wait_call_date=trunc(sysdate),t.update_time=sysdate
      where exists(select '#' from tm_outbound_day_call_list a where a.id_person=t.id_person and a.active_id=t.active_id and a.status=0)
      and t.status=0;
      --未呼叫和已预约的Call list 回收
      update tm_outbound_call_list t set t.wait_call_date=trunc(sysdate),t.update_time=sysdate
      where exists(select '#' from tm_outbound_user_call a where a.id_person=t.id_person and a.active_id=t.active_id and a.status in(0,2))
      and t.status=0;

      delete from tm_outbound_day_call_list t;
      delete from tm_outbound_user_call t;
      
      --剔除历史上最后一个呼叫结果为R5、R6的客户
      update tm_outbound_call_list t set t.status=9,t.update_time=sysdate
      where exists(select 1 from 
      (select a.id_person,a.call_result_type,row_number() over(partition by a.id_person order by a.update_time desc) nums
      from tm_outbound_call_result a 
      where a.update_time>=trunc(sysdate-1)) b 
      where b.id_person=t.id_person and b.call_result_type in('R5','R6') and b.nums=1);
      
      --去除7天内有呼叫结果的客户
      update tm_outbound_call_list k set k.wait_call_date=trunc(sysdate-1),k.update_time=sysdate  
      where k.status=0 and k.wait_call_date=trunc(sysdate) 
      and exists
      (select '#' from tm_outbound_call_result a 
       where a.id_person=k.id_person and a.update_time>=trunc(sysdate-decode(k.call_stage,3,10,7)) and a.update_time<=trunc(sysdate));
      
      --生成无人接听重复拨打数据(最多重复拨打2天)
      for tm in(select id_person,call_result,call_result_type,active_id,update_user from 
        (
        select a.id_person,a.active_id,a.call_result,a.call_result_type,a.update_user,row_number() over(partition by a.id_person order by a.update_time desc) nums
        from tm_outbound_call_result a 
        where a.update_time>=trunc(sysdate-1) and a.update_time<trunc(sysdate)) t
        where t.nums=1 
        and t.call_result_type='R4'
        and not exists
        (select '#' from tm_outbound_call_result b 
         where b.call_result_type='R4' and b.update_time>=trunc(sysdate-3) and b.update_time<trunc(sysdate-2) and b.id_person=t.id_person)
         )loop
           update tm_outbound_call_list k set k.wait_call_date=trunc(sysdate),k.call_result=tm.call_result,
             k.call_result_type=tm.call_result_type,k.call_user=tm.update_user,k.update_time=sysdate  
           where k.active_id=tm.Active_Id and k.id_person=tm.id_person and k.status=0
            and exists(select '#' from cross_active_detail c where c.id_person=k.id_person and c.active_id=k.active_id and c.status=0);
         end loop; 
         
      --生成Follow Up 最后拨打结果为R1,4天后重拨
      for tm in(select id_person,call_result,call_result_type,active_id,update_user from 
        (
        select a.id_person,a.active_id,a.call_result,a.call_result_type,a.update_user,row_number() over(partition by a.id_person order by a.update_time desc) nums
        from tm_outbound_call_result a 
        where a.update_time>=trunc(sysdate-4) and a.update_time<trunc(sysdate-3)) t
        where t.nums=1 
        and t.call_result_type='R1'
        and not exists
        (select '#' from tm_outbound_call_result b 
         where b.update_time>=trunc(sysdate-3) and b.update_time<trunc(sysdate) and b.id_person=t.id_person)
         )loop
           update tm_outbound_call_list k set k.wait_call_date=trunc(sysdate),k.call_result=tm.call_result,
             k.call_result_type=tm.call_result_type,k.call_user=tm.update_user,k.update_time=sysdate  
           where k.active_id=tm.Active_Id and k.id_person=tm.id_person and k.status=0
            and exists(select '#' from cross_active_detail c where c.id_person=k.id_person and c.active_id=k.active_id and c.status=0);
         end loop;              
         
      --插入每天拨打列表中                                        
      prc_tm_day_call_list(trunc(sysdate),p_ReturnCode);
       
      commit;
      p_ReturnCode := 'A';
      return;
    exception
      When others Then
        error_info := sqlerrm;
        Rollback;
    
      p_ReturnCode := 'Z-' || error_info;   
  end prc_get_tm_wait_call_list;
  
  --生成每天拨打列表                                   
  procedure prc_tm_day_call_list(p_CallWaitDate   date,
                                 p_ReturnCode     out varchar2)
                                 is
    begin
      for crossList in(select a.active_id from cross_active_list a 
        where a.status=1 and a.start_date<=trunc(sysdate) and a.end_date>=trunc(sysdate))
        loop
          --年龄大于55周岁
          update tm_outbound_call_list t set t.status=1 
          where t.age_55_date<=trunc(sysdate) and t.active_id=crossList.Active_Id and t.status=0;
          --客户黑名单
          update tm_outbound_call_list t set t.status=2 
          where exists(select '#' from customer_blacklist a 
                       where a.update_time>=trunc(sysdate-90) and a.ident=t.ident)
                 and t.active_id=crossList.Active_Id and t.status=0;
          --拒绝营销客户
          update tm_outbound_call_list t set t.status=3 
          where exists(select '#' from tm_outbound_call_result b 
                      where b.call_result in(9,10) and b.update_time>=trunc(sysdate-90) and b.id_person=t.id_person)
                and t.active_id=crossList.Active_Id and t.status=0;
          --投诉、不希望收到我司短信或电话
          update tm_outbound_call_list t set t.status=4 
          where exists(select '#' from cus_consult_event_info c 
                       where c.consult_event_id in('S','E9','F10') and c.update_time>=trunc(sysdate-90) and c.id_person=t.id_person)
                and t.active_id=crossList.Active_Id and t.status=0;
          --3个月内客户合同最大逾期天数大于8天
          update tm_outbound_call_list t set t.status=6 
          where exists(select '#' from mv_df_pd_sum_gl f 
                       where f.insert_time>=trunc(sysdate-90) and f.max_dpd>=8 and f.id_person=t.id_person)
                and t.active_id=crossList.Active_Id and t.status in(0,5);
                
          --客户当前逾期合同已还款，不存在已呼叫结果
          update tm_outbound_call_list t set t.status=0,t.wait_call_date=trunc(sysdate) 
          where not exists(select '#' from collection_data_temp a where a.ident=t.ident)
                and not exists(select 1 from tm_outbound_call_result c where c.id_person=t.id_person)
                and t.active_id=crossList.Active_Id
                and t.status=5;
                             
          --客户当前有逾期合同
          update tm_outbound_call_list t set t.status=5 
          where exists(select '#' from collection_data_temp e where e.ident=t.ident)
                and t.active_id=crossList.Active_Id and t.status=0;
        end loop;
        
      --插入每天分配拨打列表
      insert into tm_outbound_day_call_list
        (call_list_id,id_person,sex,ident,age,birthdate,phone,other_phone,other_phone_name,other_phone_relation,
        current_city,current_address,active_id,max_amount,endure_amount,is_dd,call_stage,update_time,name,
        contract_no,bank_name,bank_no,call_result,call_result_type,call_result_user,app_date,product_name,credit_amount,
        payment_num,seller_address)
      select t.id,t.id_person,t.sex,t.ident,trunc(months_between(trunc(sysdate),t.birthdate)/12) age,t.birthdate,
             t.phone,t.other_phone,t.other_phone_name,t.other_phone_relation,t.current_city,t.current_address,
             t.active_id,g.max_amount,g.endure_amount,t.is_dd,t.call_stage,sysdate,t.name,t.contract_no,
             t.bank_name,t.bank_no,t.call_result,t.call_result_type,t.call_user,t.app_date,t.product_name,
             t.credit_amount,t.payment_num,t.seller_address
      from tm_outbound_call_list t,cross_active_list h,cross_active_detail g
      where t.active_id=h.active_id and t.status=0 and h.status=1 --活动正在进行中
      and t.active_id=g.active_id and t.id_person=g.id_person and g.status=0--客户未申请合同
      and t.wait_call_date=p_CallWaitDate;--等待分配日期
      
      --生成today+1天的call1 smslist
      insert into tm_outbound_sms_list
        (id,id_person,client_name,client_phone,max_amount,sms_template_id,status,update_user,update_time)
      select seq_tm_outbound_sms_list.nextval,t.id_person,t.name,t.phone,t.max_amount,
        decode(g.active_type,'FO',1,'SO',10,'TO',12,1),0,100000,sysdate
      from tm_outbound_call_list t
      join cross_active_list g on g.active_id=t.active_id 
      where t.wait_call_date=trunc(sysdate+1) and t.status=0 and t.call_stage=1
      and exists(select '#' from cross_active_detail c where c.id_person=t.id_person and c.active_id=t.active_id and c.status=0);
      --生成today+1天的call3 smslist
      insert into tm_outbound_sms_list
        (id,id_person,client_name,client_phone,max_amount,sms_template_id,status,update_user,update_time)
      select seq_tm_outbound_sms_list.nextval,t.id_person,t.name,t.phone,t.max_amount,3,0,100000,sysdate
      from tm_outbound_call_list t
      join cross_active_list g on g.active_id=t.active_id and g.active_type='FO' 
      where t.wait_call_date=trunc(sysdate+1) and t.status=0 and t.call_stage=3
      and exists(select '#' from cross_active_detail c where c.id_person=t.id_person and c.active_id=t.active_id and c.status=0);
      --生成call2smslist
      insert into tm_outbound_sms_list
        (id,id_person,client_name,client_phone,max_amount,sms_template_id,status,update_user,update_time)
      select seq_tm_outbound_sms_list.nextval,tm.id_person,tm.name,tm.phone,tm.max_amount,
        decode(g.active_type,'FO',2,'SO',11,'TO',13,2),0,100000,sysdate 
      from tm_outbound_call_list tm,cross_active_list g,
      (select a.id_person,a.active_id,a.call_result,a.call_result_type,a.update_user,row_number() over(partition by a.id_person order by a.update_time asc) nums
            from tm_outbound_call_result a where a.update_time>=trunc(sysdate-7) and a.update_time<trunc(sysdate-6)) t
      where tm.active_id=g.active_id and tm.id_person=t.id_person and tm.active_id=t.active_id and tm.status=0 and t.nums=1 
      and t.call_result_type in('R1','R2','R4')
      and not exists
      (select '#' from tm_outbound_call_result b 
      where b.update_time>=trunc(sysdate-6) and b.update_time<trunc(sysdate) and b.id_person=t.id_person)
      and not exists
      (select '#' from tm_outbound_call_result b 
      where b.update_time>=trunc(g.start_date) and b.update_time<trunc(sysdate-7) and b.id_person=t.id_person)
      and exists(select '#' from cross_active_detail c where c.id_person=t.id_person and c.active_id=t.active_id and c.status=0)
      and tm.call_stage=1;

      commit;
      p_ReturnCode := 'A';
      return;
    exception
      When others Then
        error_info := sqlerrm;
        Rollback;
    
      p_ReturnCode := 'Z-' || error_info; 
    end prc_tm_day_call_list;
  
  --保存拨打结果
  procedure prc_save_tm_call_result(p_IdPerson           number,
                                    p_ClientIdent        varchar2,
                                    p_ClientName         varchar2,
                                    p_ClientSex          varchar2,
                                    p_ClientPhone        varchar2,
                                    P_CallResult         number,
                                    p_CallDetailResult   number,
                                    p_CallResultType     varchar2,
                                    p_ActiveId           number,
                                    p_Remark             varchar2,
                                    p_IsReservation      number,
                                    p_ReservatioTime     date,
                                    p_UpdateUser         number,
                                    p_CallType           number,
                                    p_CallStage          varchar2,
                                    p_ReturnCode         out varchar2)
    is
    begin
      if p_IsReservation=1 then
        update tm_outbound_user_call t set t.status=2,t.update_time=trunc(p_ReservatioTime,'mi'),t.update_user=p_UpdateUser where t.id_person=p_IdPerson;
      else
        update tm_outbound_user_call t set t.status=1,t.update_time=sysdate,t.update_user=p_UpdateUser where t.id_person=p_IdPerson;
      end if;
      
      insert into tm_outbound_call_result
        (id_person,client_ident,client_name,client_sex,client_phone,call_result,call_detail_result,
         call_result_type,active_id,remark,is_reservation,update_user,call_type,call_stage)
      values
        (p_IdPerson,p_ClientIdent,p_ClientName,p_ClientSex,p_ClientPhone,P_CallResult,p_CallDetailResult,
         p_CallResultType,p_ActiveId,p_Remark,p_IsReservation,p_UpdateUser,p_CallType,p_CallStage);

      commit;
      p_ReturnCode := 'A';
      return;
    exception
      When others Then
        error_info := sqlerrm;
        Rollback;
    
      p_ReturnCode := 'Z-' || error_info;   
  end prc_save_tm_call_result;
  
  -- author  : wangxiaofeng
  -- created : 2015/08/10
  -- purpose : 验证是否意向客户
  function fun_tm_check_R1(p_IdPerson  number)
    return number
    is
    v_Count number;
  begin
    select count(1) into v_Count from tm_outbound_call_result t 
    where t.call_result_type='R1' and t.update_time>=trunc(sysdate-7) and t.id_person=p_IdPerson;
    return v_Count;
  exception
  When others Then
    return 0;
  end fun_tm_check_R1;

end PKG_TM_OUTBOUND;
/

