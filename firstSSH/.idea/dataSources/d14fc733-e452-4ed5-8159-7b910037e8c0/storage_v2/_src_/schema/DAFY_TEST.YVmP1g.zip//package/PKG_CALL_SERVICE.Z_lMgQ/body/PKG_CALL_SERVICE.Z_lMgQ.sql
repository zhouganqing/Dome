create package body pkg_call_service is

  -- Author  : wangxiaofeng
  -- Create Date : 2015-08-10
  -- Purpose : 客户身份验证
  procedure prc_check_user_ident(p_Ident       varchar2,
                                 p_Result      out number, 
                                 p_ReturnCode  out varchar2)
    is
    error_info  varchar2(4000);
    v_Count      number;
 begin
    select count(1) into v_Count from cs_person a where a.ident=upper(p_Ident) or a.ident=lower(p_Ident);
    --0未在公司有过申请的客户，1在公司有过申请的客户 
    if v_Count<=0 then
      p_Result:= 0;
    else
      p_Result:= 1;
    end if;
    
    commit;
    p_ReturnCode := 'A';
    return;
  exception
    When others Then
      error_info := sqlerrm;
      Rollback;
    
      p_ReturnCode := 'Z-' || error_info;  
 end prc_check_user_ident;
 
  -- Author  : wangxiaofeng
  -- Create Date : 2015-08-10
  -- Purpose : 客户是否逾期验证
  procedure prc_check_user_overdue(p_Ident       varchar2,
                                   p_Result      out number,
                                   p_ReturnCode  out varchar2)
                                   is
    error_info  varchar2(4000);
    v_Count      number;
  begin
    select count(1) into v_Count
    from collection_data_temp a 
    where a.ident=upper(p_Ident) or a.ident=lower(p_Ident);
    --返回值 0当前未逾期，1当前有逾期
    if v_Count<=0 then
      p_Result:= 0;
    else
      p_Result:= 1;
    end if;

    commit;
    p_ReturnCode := 'A';
    return;
  exception
    When others Then
      error_info := sqlerrm;
      Rollback;
    
      p_ReturnCode := 'Z-' || error_info;  
 end prc_check_user_overdue;
 
  -- Author  : wangxiaofeng
  -- Create Date : 2015-08-10
  -- Purpose : 公司销售验证
  procedure prc_check_user_sa(p_Ident       varchar2,
                              p_Result      out number,
                              p_ReturnCode  out varchar2)
                              is
    error_info  varchar2(4000);
    v_Count      number;
  begin
    select count(1) into v_Count from sys_user_list a 
    where a.status in(1,3,5) and a.role_id in('SA','DSM','CM','SCM','PH','BH') and a.ident=upper(p_Ident) or a.ident=lower(p_Ident);
    --返回值 0离职或者不是公司销售，1是公司在职销售
    if v_Count<=0 then
      p_Result:= 0;
    else
      p_Result:= 1;
    end if;

    commit;
    p_ReturnCode := 'A';
    return;
  exception
    When others Then
      error_info := sqlerrm;
      Rollback;
    
      p_ReturnCode := 'Z-' || error_info;  
  end prc_check_user_sa;
  
  -- Author  : wangxiaofeng
  -- Create Date : 2015-08-13
  -- Purpose : 催收查询当前现行合同数，最大逾期天数，总欠款金额
  procedure prc_collection_query(p_Ident             varchar2,
                                 p_ContractNum       out varchar2,
                                 p_MaxOverDay        out varchar2,
                                 p_TotalDebt         out varchar2,
                                 p_ReturnCode        out varchar2)
                              is
    error_info         varchar2(4000);

  begin
    --当前现行合同数
    select count(1) into p_ContractNum
    from cs_credit a
    join cs_person b on b.id=a.id_person 
    where a.status='a' and (b.ident=upper(p_Ident) or b.ident=lower(p_Ident));
    --当前现行合同最大逾期天数
    select nvl(max(a.over_days),0) into p_MaxOverDay
    from collection_data_temp a 
    where a.ident=upper(p_Ident) or a.ident=lower(p_Ident);
    --当前现行合同总欠款金额
    select nvl(sum(a.value_instalment)-sum(a.value_pay),0) into p_TotalDebt from instalment a
    join cs_credit b on b.id=a.id_credit 
    join cs_person c on c.id=b.id_person 
    where a.status='a' and a.paystatus!='k'
    and b.status='a'and (c.ident=upper(p_Ident) or c.ident=lower(p_Ident));
     
    commit;
    p_ReturnCode := 'A';
    return;
  exception
    When others Then
      error_info := sqlerrm;
      Rollback;
    
      p_ReturnCode := 'Z-' || error_info;  
  end prc_collection_query;
  
  -- Author  : wangxiaofeng
  -- Create Date : 2015-08-13
  -- Purpose : 查询客户现行合同到期还款日
  procedure prc_person_duedate_query(p_Ident         varchar2,
                                     p_DueDate       out varchar2,
                                     p_ReturnCode    out varchar2)
  is
    error_info  varchar2(4000);
  begin
    select to_char(max(a.date_due),'dd') into p_DueDate from instalment a
    join cs_credit b on b.id=a.id_credit 
    join cs_person c on c.id=b.id_person 
    where a.status='a' and a.type_instalment!=8
    and b.status='a' and (c.ident=upper(p_Ident) or c.ident=lower(p_Ident));

    commit;
    p_ReturnCode := 'A';
    return;
  exception
    When others Then
      error_info := sqlerrm;
      Rollback;
    
      p_ReturnCode := 'Z-' || error_info;  
  end prc_person_duedate_query;
  
  -- Author  : wangxiaofeng
  -- Create Date : 2015-08-13
  -- Purpose : 查询客户个人还款账号
  procedure prc_person_repayment_no_query(p_Ident         varchar2,
                                          p_RepaymentNo   out varchar2,
                                          p_ReturnCode    out varchar2)
                                          is
    error_info  varchar2(4000);
  begin
    select nvl(replace(fun_get_person_assign_account(min(a.id)),' ',''),'1') into p_RepaymentNo from cs_credit a 
    join cs_person b on b.id=a.id_person 
    where a.credit_model like '%XT%' and a.status='a' and (b.ident=upper(p_Ident) or b.ident=lower(p_Ident));

    commit;
    p_ReturnCode := 'A';
    return;
  exception
    When others Then
      error_info := sqlerrm;
      Rollback;
    
      p_ReturnCode := 'Z-' || error_info;  
  end prc_person_repayment_no_query;
  
  -- Author  : wangxiaofeng
  -- Create Date : 2015-08-14
  -- Purpose : 查询客户是否申请15天只还本金
  procedure prc_person_er15_query(p_Ident         varchar2,
                                  p_Result        out varchar2,
                                  p_ReturnCode    out varchar2)
                                  is
    error_info  varchar2(4000);
    v_Count     number;
  begin
    select count(1) into v_Count
    from instalment a
    join cs_credit b on b.id=a.id_credit 
    join cs_person c on c.id=b.id_person 
    where a.status='a' and a.paystatus!='k' and a.paytype=4
    and b.status='a' and (c.ident=upper(p_Ident) or c.ident=lower(p_Ident));
    
    if v_Count<=0 then
      p_Result:= 0;
    else
      p_Result:= 1;
    end if;
    
    commit;
    p_ReturnCode := 'A';
    return;
  exception
    When others Then
      error_info := sqlerrm;
      Rollback;
    
      p_ReturnCode := 'Z-' || error_info;  
  end prc_person_er15_query;
  
  -- Author  : wangxiaofeng
  -- Create Date : 2015-08-14
  -- Purpose : 查询客户是否申请提前还款
  procedure prc_person_forward_query(p_Ident         varchar2,
                                     p_Result        out varchar2,
                                     p_DueDate       out varchar2,
                                     p_TotalMoney    out varchar2,
                                     p_ReturnCode    out varchar2)
                                     is
    error_info  varchar2(4000);
    v_Count     number;
  begin
    select count(1),to_char(min(a.date_due),'mm-dd'),nvl(sum(a.value_instalment)-sum(a.value_pay),0) 
           into v_Count,p_DueDate,p_TotalMoney 
    from instalment a
    join cs_credit b on b.id=a.id_credit 
    join cs_person c on c.id=b.id_person 
    where a.status='a' and a.paystatus!='k' and a.paytype=2
    and b.status='a' and (c.ident=upper(p_Ident) or c.ident=lower(p_Ident));
    
    if v_Count<=0 then
      p_Result:= 0;
    else
      p_Result:= 1;
    end if;
    
    commit;
    p_ReturnCode := 'A';
    return;
  exception
    When others Then
      error_info := sqlerrm;
      Rollback;
    
      p_ReturnCode := 'Z-' || error_info;  
  end prc_person_forward_query;
  
  -- Author  : wangxiaofeng
  -- Create Date : 2015-08-14
  -- Purpose : 查询客户到期还款金额
  procedure prc_person_due_query(p_Ident         varchar2,
                                 p_DueDate       out varchar2,
                                 p_TotalMoney    out varchar2,
                                 p_ReturnCode    out varchar2)
                                 is
    error_info           varchar2(4000);
    v_MinDueDate         date;
    v_ValueInstalment    number;
    v_Overdue            number;
  begin
    select min(a.date_due) into v_MinDueDate
    from instalment a
    join cs_credit b on b.id=a.id_credit 
    join cs_person c on c.id=b.id_person 
    where a.status='a' and a.paystatus!='k' and a.type_instalment!=8
    and b.status='a' and (c.ident=upper(p_Ident) or c.ident=lower(p_Ident));
    
    select nvl(sum(a.value_instalment)-sum(a.value_pay),0) into v_ValueInstalment
    from instalment a
    join cs_credit b on b.id=a.id_credit 
    join cs_person c on c.id=b.id_person 
    where a.status='a' and a.paystatus!='k' and a.type_instalment!=8 and a.date_due=trunc(v_MinDueDate)
    and b.status='a' and (c.ident=upper(p_Ident) or c.ident=lower(p_Ident));
    
    select nvl(sum(a.value_instalment)-sum(a.value_pay),0) into v_Overdue
    from instalment a
    join cs_credit b on b.id=a.id_credit 
    join cs_person c on c.id=b.id_person 
    where a.status='a' and a.paystatus!='k' and a.type_instalment=8
    and b.status='a' and (c.ident=upper(p_Ident) or c.ident=lower(p_Ident));
    
    p_DueDate:=to_char(v_MinDueDate,'dd');
    p_TotalMoney:=to_char(v_ValueInstalment+v_Overdue);
    
    commit;
    p_ReturnCode := 'A';
    return;
  exception
    When others Then
      error_info := sqlerrm;
      Rollback;
    
      p_ReturnCode := 'Z-' || error_info;  
  end prc_person_due_query;
  
  -- Author  : wangxiaofeng
  -- Create Date : 2015-08-14
  -- Purpose : 查询客户剩余还款金额
  procedure prc_person_debt_query(p_Ident         varchar2,
                                  p_TotalDebt     out varchar2,
                                  p_ReturnCode    out varchar2)
                                 is
    error_info  varchar2(4000);
  begin
    select nvl(sum(a.value_instalment)-sum(a.value_pay),0) into p_TotalDebt from instalment a
    join cs_credit b on b.id=a.id_credit 
    join cs_person c on c.id=b.id_person 
    where a.status='a' and a.paystatus!='k'
    and b.status='a'and (c.ident=upper(p_Ident) or c.ident=lower(p_Ident));
    
    commit;
    p_ReturnCode := 'A';
    return;
  exception
    When others Then
      error_info := sqlerrm;
      Rollback;
    
      p_ReturnCode := 'Z-' || error_info;  
  end prc_person_debt_query;
  
  -- Author  : wangxiaofeng
  -- Create Date : 2015-08-14
  -- Purpose : 查询客户还款到账记录
  procedure prc_person_payin_query(p_Ident         varchar2,
                                   p_Result        out varchar2,
                                   p_DatePay       out varchar2,
                                   p_ValuePay      out varchar2,
                                   p_ReturnCode    out varchar2)
                                   is
    error_info  varchar2(4000);
    v_Count     number;
  begin
    select count(1) into v_Count
      from payin a
      join cs_credit b on b.id=a.id_credit 
      join cs_person c on c.id=b.id_person 
      where a.status='a'
      and (c.ident=upper(p_Ident) or c.ident=lower(p_Ident));
      
    if v_Count<=0 then
      p_Result:= 0;
    else
      p_Result:= 1;
      
      select to_char(date_pay,'yyyy-mm-dd'),nvl(value_pay,0) into p_DatePay,p_ValuePay
      from
        (select trunc(a.date_pay) date_pay,nvl(sum(a.value_pay),0) value_pay,row_number() over(order by trunc(a.date_pay) desc) nums
        from payin a
        join cs_credit b on b.id=a.id_credit 
        join cs_person c on c.id=b.id_person 
        where a.status='a'
        and (c.ident=upper(p_Ident) or c.ident=lower(p_Ident))
        group by trunc(a.date_pay)
      ) where nums=1;
    end if;
        
    commit;
    p_ReturnCode := 'A';
    return;
  exception
    When others Then
      error_info := sqlerrm;
      Rollback;
    
      p_ReturnCode := 'Z-' || error_info;  
  end prc_person_payin_query;
                                   

end pkg_call_service;
/

