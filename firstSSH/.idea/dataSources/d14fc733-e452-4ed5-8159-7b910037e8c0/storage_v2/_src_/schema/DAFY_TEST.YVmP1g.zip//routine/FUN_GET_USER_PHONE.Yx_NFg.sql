create function fun_get_user_phone(id_cs_person cs_person.id%type)
  return varchar2 is
  v_phone cs_contact_portion.contact_value%type := '';

  /*
   *  获取用户唯一、有效的手机号码
   *
   *  @author 王晓锋 & 周帆
   *  @date 2015-9-8
   */

begin

  select contact_value into v_phone from (
         select t.contact_value, row_number() over(order by update_time desc, status) nums
         from cs_contact_portion t
         where t.id_person = id_cs_person
               and t.contact_type = '移动电话'
               and t.person_type = '本人'

               and (t.status = '1' or t.status is null)
               )
     where nums = 1;

  if v_phone is null or v_phone='' then
    select contact_value into v_phone from cs_contact t
    where t.person_type = '1' and t.contact_type = 2 and t.id_credit = id_cs_person;
  end if;

  return(v_phone);
end fun_get_user_phone;


/

