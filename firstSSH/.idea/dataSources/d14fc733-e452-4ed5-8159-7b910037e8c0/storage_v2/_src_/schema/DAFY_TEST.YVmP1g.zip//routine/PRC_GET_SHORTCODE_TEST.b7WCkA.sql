create procedure PRC_GET_SHORTCODE_TEST(p_IdCredit   cs_credit.id%type,
                                              p_ReturnCode out varchar2) is

v_shortcode    varchar2(10);

begin
     
     select shortcode into v_shortcode from instalment_shortcode where status=0 and rownum=1;

   if v_shortcode is not null then
    update instalment_shortcode set status=1 where shortcode=v_shortcode;
    update cs_credit set shortcode=v_shortcode where id=p_IdCredit;
   end if ;

   p_ReturnCode:=v_shortcode;
   commit;
     
end;


/

