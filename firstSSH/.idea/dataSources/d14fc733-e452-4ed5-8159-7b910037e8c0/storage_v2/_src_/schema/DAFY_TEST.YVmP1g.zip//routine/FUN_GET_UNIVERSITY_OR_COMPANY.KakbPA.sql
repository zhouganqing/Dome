create function fun_get_university_or_company(p_id_credit   cs_credit.id%type)
                                              return varchar2 is

v_Name  varchar2(100);

begin
  select a.position into v_Name from cs_employer a where a.id_credit=p_id_credit and rownum=1 order by a.update_time desc;
  if v_Name='9' then
    select b.university into v_Name from cs_employer a,university b where a.company_name=b.id and a.id_credit=p_id_credit and rownum=1 order by a.update_time desc;
  else
    select a.company_name1 into v_Name from cs_employer a where a.id_credit=p_id_credit and rownum=1 order by a.update_time desc;
  end if;

  return(v_Name);
end fun_get_university_or_company;


/

