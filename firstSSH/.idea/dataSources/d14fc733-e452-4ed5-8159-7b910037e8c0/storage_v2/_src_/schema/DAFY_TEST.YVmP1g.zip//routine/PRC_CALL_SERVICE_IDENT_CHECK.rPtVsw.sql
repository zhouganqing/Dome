create procedure prc_call_service_ident_check(p_Ident         varchar2,
                                                         p_Phone         varchar2,
                                                         p_ReturnCode    out varchar2) is
  error_info   varchar2(1000);
  v_Count      number;
begin
  if p_Phone='4008075546' or p_Phone='88695588' or p_Phone='23672388' or p_Phone='84367878' then
    select count(1) into v_Count from cs_person a where a.ident=upper(p_Ident) or a.ident=lower(p_Ident);
    if v_Count<=0 then
      p_ReturnCode:= 'A-44'; --用户不存在
      return;
    else
      select nvl(count(1),0) into v_Count from instalment a,cs_credit b
      where a.id_credit=b.id
      and a.status='a'
      and trunc(a.date_due)<trunc(sysdate)
      and a.value_instalment>a.value_pay
      and a.type_instalment<>'8'
      and b.id_person in (select id from cs_person where ident=upper(p_Ident) or ident=lower(p_Ident));
      --group by a.id_credit;

      if v_Count<=0 then
        p_ReturnCode:= 'A-1'; --老客户进入客服
        return;
      else
        p_ReturnCode:= 'A-2';--逾期客户进入催收
        return;
      end if;
    end if;
  else
    select count(1) into v_Count from sys_user_list a where a.ident=upper(p_Ident) or a.ident=lower(p_Ident);
    if v_Count<=0 then
      p_ReturnCode:= 'A-44';--用户不存在
      return;
    else
      p_ReturnCode:= 'A-3';--公司员工进入客服
      return;
    end if;
  end if;
  
Exception
  When others Then
    error_info := sqlerrm;
    Rollback;

    p_ReturnCode := 'Z-'||error_info;
end prc_call_service_ident_check;


/

