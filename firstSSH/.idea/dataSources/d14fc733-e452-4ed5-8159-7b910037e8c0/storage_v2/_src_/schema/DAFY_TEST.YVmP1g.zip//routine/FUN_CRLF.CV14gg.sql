create function Fun_CRLF return varchar2 is
  Result varchar2(10);
begin
  Result := chr(13) || chr(10);
  return(Result);
end Fun_CRLF;


/

