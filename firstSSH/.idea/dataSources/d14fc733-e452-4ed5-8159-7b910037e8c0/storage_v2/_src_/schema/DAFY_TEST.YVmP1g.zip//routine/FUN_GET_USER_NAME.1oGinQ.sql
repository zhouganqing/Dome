create function fun_get_user_name(p_UserId sys_user_list.id%type)
                                          return varchar2 is
  v_Count      integer;
  v_UserName   sys_user_list.user_name%type:='';
begin
   if p_UserId is null then
     return(v_UserName);
   else
     select count(1) into v_Count from sys_user_list where id=p_UserId;
     if v_Count>0 then
        select user_name into v_UserName from sys_user_list where id=p_UserId;
     end if;
     return(v_UserName);
   end if;
Exception
When others Then
   return (v_UserName);
end fun_get_user_name;


/

