create function fun_person_goods_vin(p_Id_Credit cs_credit.id%type)
                                                  return varchar2 is
  --获取苹果手机VIN号码
  --2015/07/16
  --wangxiaofeng
  v_VIN   varchar2(2000);
begin
  select listagg(to_char(b.vin),',') within group(order by b.goods_price desc) into v_VIN from cs_credit a,cs_goods b
  where a.id=b.id_credit and a.id=p_Id_Credit;
  return(v_VIN);
end;


/

