create procedure PRC_AUTO_SCHEDULING_NEW(p_ReturnCode   out varchar2) is
   -- Author  : wangxiaofeng
   -- Create Date : 2016-9-3
   -- Purpose : entrance of hard check or decision system
  v_DecisionUsageRatio     number;
  v_WaitMinutes            number:=1;
  v_Rand                   number;
  v_DecsionRradom          number;

  error_info               varchar2(1000);
begin
  select to_number(para_value) into v_DecisionUsageRatio from sys_parameters where para_id='DECISION_USAGE_RATIO';
  select to_number(para_value) into v_WaitMinutes from sys_parameters where para_id='TENCENT_WAIT_MINUTES';

  for credit in (select a.id,trunc((sysdate-a.commit_time)*24*60,1) wait_minutes,nvl(b.associated_id,1) td_risk,
                  nvl(c.id_credit,1) br_rule,nvl(c.id_credit,1) mi_guang
                  from cs_credit a
                  left join wfi_fraud_metrix_result b on b.associated_id=a.id and b.event_name='Credit'
                  left join external_br_rules c on c.id_credit=a.id
                  left join external_data_extraction d on d.id_credit=a.id
                  where a.status='s' and a.decision_flag is null)
  loop
    v_Rand:=dbms_random.value();

    --设置决策随机线程数
    if v_Rand<=0.25 then
      v_DecsionRradom:=0;
    elsif v_Rand>0.25 and v_Rand<=0.5 then
      v_DecsionRradom:=1;
    elsif v_Rand>0.5 and v_Rand<=0.75 then
      v_DecsionRradom:=2;
    else
      v_DecsionRradom:=3;
    end if;

    if v_Rand<v_DecisionUsageRatio then
      if (credit.id=credit.td_risk and credit.id=credit.br_rule and credit.id=credit.mi_guang) or credit.wait_minutes>v_WaitMinutes then
        update cs_credit set decision_flag=1,decision_random=v_DecsionRradom where id=credit.id;
        insert into decision_log(id,id_credit,status,item_name,result,remark,formula,update_time)
        values(seq_decision_log.nextval,credit.id,'s','decision_flag',1,'','Random='||round(v_Rand,2),sysdate);
      end if;
    else
      update cs_credit set decision_flag=0,decision_random=v_DecsionRradom where id=credit.id;
      insert into decision_log(id,id_credit,status,item_name,result,remark,formula,update_time)
        values(seq_decision_log.nextval,credit.id,'s','decision_flag',0,'','Random='||round(v_Rand,2),sysdate);
    end if;

  end loop;
  commit;

  PRC_AUTO_MINUTES(p_ReturnCode);
  return;
Exception
   When others Then
     error_info := sqlerrm;
     rollback;
     --异常发送邮件
     insert into sys_email_list
        (email_boby,id,mail_type,key_word,from_user,mail_to,subject,status,create_time,plan_time)
     values
        (error_info,seq_sys_email_list.nextval,'DE','决策引擎报警','dafy@mail.dafycredit.com.cn','wangxiaofeng@dafycredit.com;luchangjiang@dafycredit.com;lixiaoxi@dafycredit.com;zhangjinwen@dafycredit.com;luojingna@dafycredit.com','决策引擎运行异常(PRC_AUTO_SCHEDULING_NEW)',0,sysdate,sysdate);
     --异常发送短信
     insert into collection_auto_message(id,contract_no,cpd,phone_number,message,create_time,status,app_code)
      values( seq_collection_auto_message.nextval,100000,0,'18218021986,13715085819,13828735725,13553835518,18566255697','决策引擎运行异常(PRC_AUTO_SCHEDULING_NEW)',sysdate,0,'LV_COLL');

     p_ReturnCode:='Z-'||error_info;
end;
/

