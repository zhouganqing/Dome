create procedure PRC_AUTO_RELEASE_REBATES(p_ReturnCode out varchar2) is
  /*2015-6-2  庾文峰
    生成商家返点*/
error_info    varchar2(1000);  
v_fee         cs_credit.credit_amount%type;
v_fee_rate    number(1);
v_str         varchar2(50);
v_t           ty_str_split;
v_date        date;
begin
    for branch in(select distinct a.id_credit,a.contract_no,a.loan_date,a.status,a.commit_time,a.credit_model,
                  a.id_sa,a.retailer_code,a.seller_name,a.pos_code,a.dealer_name,a.city,
                  a.bank_name,a.account_name,a.account_no,a.person_name,a.credit_amount,a.init_pay,
                  a.price,a.prod_code,a.payment_num,a.goodstype,a.update_time,
                  sum(case when b.paytype=2 and b.status='a' then 1 else 0 end) as advance_over,
                  sum(case when b.paytype=4 and b.status='a' then 1 else 0 end) as advance_inner,
                  trunc(max(case when b.paytype=2 and b.status='a' then b.date_pay when b.paytype=4 and b.status='a' then b.date_pay end)) as date_pay  
                  from v_credit_release a,instalment b,product c where a.id_credit=b.id_credit and a.credit_type='SS' and a.status in('a','p','t','k') 
                  and a.prod_code=c.prod_code and c.prod_code like 'RB%'                                             

                  --and a.loan_date between to_date('2015-7-1','yyyy-MM-dd') and to_date('2015-7-31','yyyy-MM-dd')+1-1/24/60/60
                  and a.loan_date between trunc(add_months(sysdate,-1),'mm') and trunc(last_day(add_months(sysdate,-1)))+1-1/24/60/60
                  
                  --and a.update_time between to_date('2015-7-1','yyyy-MM-dd') and to_date('2015-8-1','yyyy-MM-dd')+3/24 
                  and a.update_time between trunc(add_months(sysdate,-1),'mm') and trunc(last_day(add_months(sysdate,-1)))+1+4/24
                  
                  group by a.id_credit,a.contract_no,a.loan_date,a.status,a.commit_time,a.credit_model,
                  a.id_sa,a.retailer_code,a.seller_name,a.pos_code,a.dealer_name,a.city,
                  a.bank_name,a.account_name,a.account_no,a.person_name,a.credit_amount,a.init_pay,
                  a.price,a.prod_code,a.payment_num,a.goodstype,a.update_time)
    loop
      
      v_str:=FUN_GET_RELEASE_REBATES(branch.credit_amount,branch.payment_num);
      if v_str<>'NULL' then
        v_t:=fun_split(v_str,',');
        v_fee:=to_number(v_t(1));
        v_fee_rate:=to_number(v_t(2));
      else
        v_fee:=0;
        v_fee_rate:=0;
      end if;
    
    if branch.status='a' or branch.status='k' then
      v_fee:=v_fee;
      v_fee_rate:=v_fee_rate;
     end if;
     
     if branch.status='p' then
       if to_char(branch.loan_date,'mm')=to_char(branch.date_pay,'mm') then
           if branch.advance_over>0 then
             v_fee:=v_fee;
             v_fee_rate:=v_fee_rate;
           end if;
           if branch.advance_inner>0 then
             v_fee:=0;
             v_fee_rate:=0;
           end if;
        else
             v_fee:=-v_fee;
             v_fee_rate:=v_fee_rate;
        end if;
       
     end if;
     
     if branch.status='t' then
       if to_char(branch.loan_date,'mm')=to_char(branch.update_time,'mm') then
         v_fee:=0;
         v_fee_rate:=0;
       else
         v_fee:=-v_fee;
         v_fee_rate:=v_fee_rate;
       end if;
     end if;
     
     if branch.date_pay is null then
       v_date:=null;
     else
       v_date:=branch.date_pay;
     end if;

    insert into release_rebates(id,id_credit,contract_no,rebates_fee,rebates_rate,loan_date,status,commit_time,
    credit_model,id_sa,retailer_code,seller_name,dealer_name,pos_code,city,bank_name,account_name,account_no,person_name,
    credit_amount,init_pay,price,prod_code,payment_num,goodstype,update_time,advance_over,advance_inner,date_pay)
     values(seq_release_rebates.nextval,branch.id_credit,branch.contract_no,v_fee,v_fee_rate,branch.loan_date,
     branch.status,branch.commit_time,branch.credit_model,branch.id_sa,branch.retailer_code,branch.seller_name,branch.dealer_name,
     branch.pos_code,branch.city,branch.bank_name,branch.account_name,branch.account_no,branch.person_name,branch.credit_amount,
     branch.init_pay,branch.price,branch.prod_code,branch.payment_num,branch.goodstype,branch.update_time,branch.advance_over,
     branch.advance_inner,v_date);
     
     
     insert into RELEASE_REBATES_EMAIL(id,id_credit,contract_no,rebates_fee,rebates_rate,loan_date,status,commit_time,
    credit_model,id_sa,retailer_code,seller_name,dealer_name,pos_code,city,bank_name,account_name,account_no,person_name,
    credit_amount,init_pay,price,prod_code,payment_num,goodstype,update_time,advance_over,advance_inner,date_pay)
     values(SEQ_RELEASE_REBATES_EMAIL.nextval,branch.id_credit,branch.contract_no,v_fee,v_fee_rate,branch.loan_date,
     branch.status,branch.commit_time,branch.credit_model,branch.id_sa,branch.retailer_code,branch.seller_name,branch.dealer_name,
     branch.pos_code,branch.city,branch.bank_name,branch.account_name,branch.account_no,branch.person_name,branch.credit_amount,
     branch.init_pay,branch.price,branch.prod_code,branch.payment_num,branch.goodstype,branch.update_time,branch.advance_over,
     branch.advance_inner,v_date);

    end loop;
    
    
     for branch in(select distinct a.id_credit,a.contract_no,a.loan_date,a.status,a.commit_time,a.credit_model,
                  a.id_sa,a.retailer_code,a.seller_name,a.pos_code,a.dealer_name,a.city,
                  a.bank_name,a.account_name,a.account_no,a.person_name,a.credit_amount,a.init_pay,
                  a.price,a.prod_code,a.payment_num,a.goodstype,a.update_time,
                  sum(case when b.paytype=2 and b.status='a' then 1 else 0 end) as advance_over,
                  sum(case when b.paytype=4 and b.status='a' then 1 else 0 end) as advance_inner,
                  trunc(max(case when b.paytype=2 and b.status='a' then b.date_pay when b.paytype=4 and b.status='a' then b.date_pay end)) as date_pay  
                  from v_credit_release a,instalment b,product c where a.id_credit=b.id_credit and a.credit_type='SS' and a.status in('p','t') 
                  and a.prod_code=c.prod_code and c.prod_code like 'RB%' 
                  
                  --and a.loan_date < to_date('2015-7-1','yyyy-MM-dd')
                  and a.loan_date < trunc(add_months(sysdate,-1),'mm')
                  --and a.update_time between to_date('2015-7-1','yyyy-MM-dd') and to_date('2015-8-1','yyyy-MM-dd')+3/24 
                  and a.update_time between trunc(add_months(sysdate,-1),'mm') and trunc(last_day(add_months(sysdate,-1)))+1+4/24
                  
                  group by a.id_credit,a.contract_no,a.loan_date,a.status,a.commit_time,a.credit_model,
                  a.id_sa,a.retailer_code,a.seller_name,a.pos_code,a.dealer_name,a.city,
                  a.bank_name,a.account_name,a.account_no,a.person_name,a.credit_amount,a.init_pay,
                  a.price,a.prod_code,a.payment_num,a.goodstype,a.update_time)
    loop
      v_str:=FUN_GET_RELEASE_REBATES(branch.credit_amount,branch.payment_num);
      if v_str<>'NULL' then
        v_t:=fun_split(v_str,',');
        v_fee:=to_number(v_t(1));
        v_fee_rate:=to_number(v_t(2));
      else
        v_fee:=0;
        v_fee_rate:=0;
      end if;
      
       if branch.status='p' then
       if branch.advance_over>0 then
         v_fee:=0;
         v_fee_rate:=0;
       end if;
       if branch.advance_inner>0 then
         v_fee:=-v_fee;
         v_fee_rate:=v_fee_rate;
       end if;
     end if;
     
     if branch.status='t' then
         v_fee:=-v_fee;
         v_fee_rate:=v_fee_rate;
     end if;
     
     if branch.date_pay is null then
       v_date:=null;
     else
       v_date:=branch.date_pay;
     end if;
    
     if branch.status='p' and branch.advance_over>0 then
       v_str:='';
     else
       
    insert into release_rebates(id,id_credit,contract_no,rebates_fee,rebates_rate,loan_date,status,commit_time,
    credit_model,id_sa,retailer_code,seller_name,dealer_name,pos_code,city,bank_name,account_name,account_no,person_name,
    credit_amount,init_pay,price,prod_code,payment_num,goodstype,update_time,advance_over,advance_inner,date_pay)
     values(seq_release_rebates.nextval,branch.id_credit,branch.contract_no,v_fee,v_fee_rate,branch.loan_date,
     branch.status,branch.commit_time,branch.credit_model,branch.id_sa,branch.retailer_code,branch.seller_name,branch.dealer_name,
     branch.pos_code,branch.city,branch.bank_name,branch.account_name,branch.account_no,branch.person_name,branch.credit_amount,
     branch.init_pay,branch.price,branch.prod_code,branch.payment_num,branch.goodstype,branch.update_time,branch.advance_over,
     branch.advance_inner,v_date);
     
     insert into RELEASE_REBATES_EMAIL(id,id_credit,contract_no,rebates_fee,rebates_rate,loan_date,status,commit_time,
    credit_model,id_sa,retailer_code,seller_name,dealer_name,pos_code,city,bank_name,account_name,account_no,person_name,
    credit_amount,init_pay,price,prod_code,payment_num,goodstype,update_time,advance_over,advance_inner,date_pay)
     values(SEQ_RELEASE_REBATES_EMAIL.nextval,branch.id_credit,branch.contract_no,v_fee,v_fee_rate,branch.loan_date,
     branch.status,branch.commit_time,branch.credit_model,branch.id_sa,branch.retailer_code,branch.seller_name,branch.dealer_name,
     branch.pos_code,branch.city,branch.bank_name,branch.account_name,branch.account_no,branch.person_name,branch.credit_amount,
     branch.init_pay,branch.price,branch.prod_code,branch.payment_num,branch.goodstype,branch.update_time,branch.advance_over,
     branch.advance_inner,v_date);
     
     end if;
    end loop;
    
   commit;
   p_ReturnCode:='A';
   return;
Exception
   When others Then
     error_info := sqlerrm;
     p_ReturnCode:='Z-'||error_info;
     rollback;
end;


/

