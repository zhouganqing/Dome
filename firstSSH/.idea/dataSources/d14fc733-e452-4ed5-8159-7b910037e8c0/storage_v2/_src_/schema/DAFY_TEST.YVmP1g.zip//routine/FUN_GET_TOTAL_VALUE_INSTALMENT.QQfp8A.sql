create function fun_get_total_value_instalment(p_id_credit payin.id_credit%type)
                                          return number is
  v_value_instalment   payin.value_pay%type;
begin
   select sum(t.value_instalment) into v_value_instalment from instalment t
   where t.id_credit = p_id_credit and t.status='a';
  return(v_value_instalment);
end fun_get_total_value_instalment;


/

