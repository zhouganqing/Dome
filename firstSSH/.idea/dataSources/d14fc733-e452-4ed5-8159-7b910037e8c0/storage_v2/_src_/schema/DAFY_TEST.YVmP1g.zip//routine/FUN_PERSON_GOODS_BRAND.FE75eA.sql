create function fun_person_goods_brand(p_Id_Credit cs_credit.id%type)
                                                  return varchar2 is
  v_Brand   varchar2(100);
begin
  select listagg(to_char(a.brand),',') within group(order by a.goods_price desc) into v_Brand from cs_goods a where a.id_credit=p_Id_Credit;
  return(v_Brand);
end;


/

