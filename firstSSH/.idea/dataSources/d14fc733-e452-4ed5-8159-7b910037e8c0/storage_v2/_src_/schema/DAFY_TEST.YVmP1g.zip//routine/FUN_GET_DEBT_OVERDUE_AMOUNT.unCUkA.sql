create function fun_get_debt_overdue_amount(p_id_credit cs_credit.id%type)
                                          return number is
  v_overdue_amount   number;
--Create User:wangxiaofeng;
--Use:获取合同未还滞纳金总额
begin
  select nvl(sum(a.value_instalment),0) into v_overdue_amount
         from instalment a
         where a.id_credit=p_id_credit
         and a.type_instalment=8
         and a.paystatus<>'k'
   group by a.id_credit;
   return(v_overdue_amount);
end fun_get_debt_overdue_amount;


/

