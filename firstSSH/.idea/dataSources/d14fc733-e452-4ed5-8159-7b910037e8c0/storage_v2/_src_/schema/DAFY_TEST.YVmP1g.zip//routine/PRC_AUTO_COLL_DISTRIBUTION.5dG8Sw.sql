create procedure PRC_AUTO_COLL_DISTRIBUTION(p_ReturnCode      out varchar2) is
   error_info            varchar2(1000);

begin

   delete from collection_data where collection_date=trunc(sysdate);

   insert into collection_data(id,id_credit,date_due,epiboly_flag,collector_id,collection_date,amount_left,update_user,update_time,stay_date)
   select seq_collection_data.nextval,id_credit,date_due,0,100070,trunc(sysdate),value_instalment-amount_pay,100000,sysdate,trunc(sysdate)
   from v_collection_data a
     where a.over_days>=2 and a.over_days<=30
     and not exists (select '#' from collection_data where id_credit=a.id_credit and stay_date>=trunc(sysdate))
     and a.id_credit
     not in (select t.contractno from checkoff_batch_detail t where t.procode=(decode(fun_get_collection_parameters('DEBIT_FLAG'),'1','代扣中','')));

   commit;
   p_ReturnCode:='A';
   return;
Exception
   When others Then
     error_info := sqlerrm;
     p_ReturnCode:='Z-'||error_info;
     rollback;
end;


/

