create function fun_get_current_repayment(p_id_credit cs_credit.id%type)
                                          return number is
/*
  获取【本期应还】

  author: 王晓锋 & 周帆 
  date:   2015-08-05
*/

  v_value_instalment   number;
  v_num_instalment     number;
begin

  select min(i.num_instalment) into v_num_instalment from instalment i where date_due>=trunc(sysdate) and status = 'a' and type_instalment != 8 and id_credit = p_id_credit;

  -- 合同期款 + 保险金
  select ROUND((
    (
      (select sum(t.value_instalment) from instalment t where t.num_instalment = v_num_instalment and id_credit = p_id_credit and status = 'a')     -- 期款
       -
      (select sum(value_pay) from instalment t where t.num_instalment >= v_num_instalment and id_credit = p_id_credit and status = 'a')             -- 多还款
    )
    +
    -- 合同逾期
    （select nvl(fun_get_overdue_amount(cc.id), 0) from cs_credit cc where cc.id = p_id_credit ）), 2) into v_value_instalment
  from dual;

  /*
  -- 合同期款 + 保险金
  select
    ((select sum(t.value_instalment)-sum(value_pay) from instalment t
    where t.num_instalment = (
      select min(i.num_instalment) from instalment i
      where date_due>=trunc(sysdate)  and status = 'a' and type_instalment != 8 and id_credit = p_id_credit )
    and id_credit = p_id_credit and status = 'a' )
    +
    -- 合同逾期
    （select nvl(fun_get_overdue_amount(cc.id), 0) from cs_credit cc where cc.id = p_id_credit ）) into v_value_instalment
  from dual;
  */

  return(v_value_instalment);
end fun_get_current_repayment;


/

