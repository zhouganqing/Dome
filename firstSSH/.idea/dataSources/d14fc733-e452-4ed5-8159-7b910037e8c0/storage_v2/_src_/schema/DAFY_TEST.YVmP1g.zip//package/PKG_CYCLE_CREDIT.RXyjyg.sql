create package PKG_CYCLE_CREDIT is

  -- Author  : 100009  鲁长江
  -- Created : 2015/8/11 11:17:18
  -- Purpose : 循环现金贷

  --状态逻辑处理
  procedure PRC_DAILY_CYCLE_STATUS(p_CalcDate     date,
                                       p_ReturnCode   out varchar2);

  --还款计划表
  procedure PRC_DAILY_CYCLE_INSTALMENT(p_CalcDate     date,
                                       p_ReturnCode   out varchar2);



end;


/

