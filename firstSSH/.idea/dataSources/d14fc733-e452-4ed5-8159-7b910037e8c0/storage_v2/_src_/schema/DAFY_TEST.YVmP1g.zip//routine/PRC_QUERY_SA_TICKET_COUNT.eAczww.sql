create PROCEDURE PRC_QUERY_SA_TICKET_COUNT(
in_userid IN NUMBER,
out_daily_ticket OUT NUMBER,
out_daily_amount OUT NUMBER,
out_month_ticket OUT NUMBER,
out_month_amount OUT NUMBER
) IS
BEGIN
  SELECT COUNT(*) INTO out_daily_ticket  FROM (select Count(1) as total,C.Name,A.CONTRACT_NO,A.CREDIT_AMOUNT AS LOAN_AMOUNT,A.APP_DATE,A.Status,A.Id_sa,B.user_name
  from Cs_credit A join sys_user_list B on A.Id_sa=B.id join sellerplace C on C.Id=A.Id_sellerplace
  where A.id_sa=in_userid AND round(to_number(sysdate-A.APP_DATE))<1 AND( A.STATUS='a' OR a.STATUS='n' OR a.STATUS='y')
  group by A.CONTRACT_NO,A.CREDIT_AMOUNT,A.APP_DATE,A.Status,A.Id_sa,B.user_name,C.Name order by Status);

  SELECT SUM(LOAN_AMOUNT) INTO out_daily_amount  FROM (select Count(1) as total,C.Name,A.CONTRACT_NO,A.CREDIT_AMOUNT AS LOAN_AMOUNT,A.APP_DATE,A.Status,A.Id_sa,B.user_name
  from Cs_credit A join sys_user_list B on A.Id_sa=B.id join sellerplace C on C.Id=A.Id_sellerplace
  where A.id_sa=in_userid AND round(to_number(sysdate-A.APP_DATE))<1 AND( A.STATUS='a' OR a.STATUS='n' OR a.STATUS='y')
  group by A.CONTRACT_NO,A.CREDIT_AMOUNT,A.APP_DATE,A.Status,A.Id_sa,B.user_name,C.Name order by Status);

  SELECT COUNT(*) INTO out_month_ticket FROM ( select Count(1) as total,C.Name,A.CONTRACT_NO,A.CREDIT_AMOUNT AS LOAN_AMOUNT,A.APP_DATE,A.Status,A.Id_sa,B.user_name
  from Cs_credit A join sys_user_list B on A.Id_sa=B.id join sellerplace C on C.Id=A.Id_sellerplace
  where A.id_sa=in_userid AND A.APP_DATE>=trunc(sysdate, 'MONTH') AND A.APP_DATE<=SYSDATE  AND( A.STATUS='a' OR a.STATUS='n' OR a.STATUS='y')
  group by A.CONTRACT_NO,A.CREDIT_AMOUNT,A.APP_DATE,A.Status,A.Id_sa,B.user_name,C.Name order by Status);

  SELECT SUM(LOAN_AMOUNT) INTO out_month_amount FROM ( select Count(1) as total,C.Name,A.CONTRACT_NO,A.CREDIT_AMOUNT AS LOAN_AMOUNT,A.APP_DATE,A.Status,A.Id_sa,B.user_name
  from Cs_credit A join sys_user_list B on A.Id_sa=B.id join sellerplace C on C.Id=A.Id_sellerplace
  where A.id_sa=in_userid AND A.APP_DATE>=trunc(sysdate, 'MONTH') AND A.APP_DATE<=SYSDATE  AND( A.STATUS='a' OR a.STATUS='n' OR a.STATUS='y')
  group by A.CONTRACT_NO,A.CREDIT_AMOUNT,A.APP_DATE,A.Status,A.Id_sa,B.user_name,C.Name order by Status);
  RETURN;
END;


/

