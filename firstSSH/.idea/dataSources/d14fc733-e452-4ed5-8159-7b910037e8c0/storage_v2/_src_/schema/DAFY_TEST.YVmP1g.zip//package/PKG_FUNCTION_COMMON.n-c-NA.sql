create package pkg_function_common is
  -- author  : wangxiaofeng
  -- created : 2015/6/19
  -- purpose : 公共函数管理
  
  -- 分割后的字符串临时存储类型  
  type type_split is table of varchar2(2048);
  
  -- author  : wangxiaofeng
  -- created : 2015/7/3
  -- purpose : 获取销售上级用户ID
  function fun_get_superior_userid(p_UserId  number)
    return number;
  
  -- author  : wangxiaofeng
  -- created : 2015/6/19
  -- purpose : 分割函数,默认逗号分割  
  function fun_split(p_list varchar2,p_sep varchar2:=',')  
    return type_split pipelined;  
  
  -- author  : wangxiaofeng
  -- created : 2015/6/19
  -- purpose : 获取注册审查状态描述
  function fun_Reg_check_status_desc(p_status varchar2,p_flag number:=1)
    return varchar2;
    
  -- author  : wangxiaofeng
  -- created : 2015/7/8
  -- purpose : 获取注册审查最近一次的检查结果
  function fun_Reg_check_result(p_IdCredit  number)
    return varchar2;
    
  -- author  : wangxiaofeng
  -- created : 2015/6/19
  -- purpose : 获取考勤状态描述
  function fun_call_service_status_desc(p_status varchar2)
    return varchar2;
    
  -- author  : wangxiaofeng
  -- created : 2015/9/29
  -- purpose : 获取循环贷当前逾期总欠款
  function fun_cycle_current_total_debit(p_id_credit number)
    return number;
  
  -- author  : wangxiaofeng
  -- created : 2015/9/29
  -- purpose : 获取循环贷当前逾期期款
  function fun_cycle_current_debit(p_id_credit number)
    return number;
    
  -- author  : wangxiaofeng
  -- created : 2015/9/29
  -- purpose : 获取循环贷合同逾期未还滞纳金欠款
  function fun_cycle_overdue_debit(p_id_credit number)
    return number;
    
  -- author  : wangxiaofeng
  -- created : 2015/9/29
  -- purpose : 获取循环贷合同逾期滞纳金
  function fun_cycle_overdue_amount(p_id_credit number)
    return number;
       
  -- author  : wangxiaofeng
  -- created : 2015/9/29
  -- purpose : 获取最早逾期的到期还款日期
  function fun_min_overdue_date(p_id_credit number)
    return date;
    
  -- author  : wangxiaofeng
  -- created : 2015/9/29
  -- purpose : 获取客户现行合同总数量
  function fun_person_due_contract_no(p_id_person number)
    return number;   
    
  -- author  : wangxiaofeng
  -- created : 2015/9/29
  -- purpose : 获取现行合同数量
  function fun_due_contract_no(p_id_person number)
    return number;
    
  -- author  : wangxiaofeng
  -- created : 2015/9/29
  -- purpose : 获取循环贷现行合同数量
  function fun_due_cycle_contract_no(p_id_person number)
    return number;
  
  -- author  : wangxiaofeng
  -- created : 2015/9/29
  -- purpose : 获取客户合同总欠款
  function fun_person_total_debit(p_id_person number)
    return number;
    
  -- author  : wangxiaofeng
  -- created : 2015/9/29
  -- purpose : 获取客户合同总的滞纳金
  function fun_total_overdue_amounnt(p_id_person number)
    return number;
    
end pkg_function_common;


/

