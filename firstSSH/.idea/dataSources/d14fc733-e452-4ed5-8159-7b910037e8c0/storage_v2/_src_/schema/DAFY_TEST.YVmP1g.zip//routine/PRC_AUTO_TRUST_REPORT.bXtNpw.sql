create procedure PRC_AUTO_TRUST_REPORT(p_ReturnCode  out varchar2) is

  error_info               varchar2(1000);
   idx                     integer;
  v_DeductPrincipal        number:=0;
  v_DeductInterest         number:=0;
  v_DeductPunishMoney      number:=0;
  v_RepayGuaranteeFee      number:=0;
  v_RepayServiceFee        number:=0;
  v_DeductPenaltyInterest  number:=0;
  v_FreeFee                number:=0;
  v_OverFee                number:=0;
  v_fee1                   number:=0;
  v_total                  number:=0;
  
  v_deduct_mode            varchar2(50);
  v_deduct_type            varchar2(50);
  v_date_due               date;
  v_i                      integer:=0;
  v_PeriodStatus           varchar2(50);
  
  
  v_name                   varchar2(100);
  v_ident                  varchar2(100);
  v_accountno              varchar2(100);
  v_contractno             varchar2(100);  
  v_freeFeeFlag            varchar2(50);
  v_overday                integer:=0;
  v_num                    integer:=0;
  v_cur                    date;
  v_maxnum                 integer:=0;
  
  v_lastmoney              number:=0;
  
begin
  
  v_cur:=trunc(sysdate-1);
  
  for branch in(
select distinct b.id_credit from payinstalment a,instalment b,cs_credit c 
where a.id_instalment=b.id and b.id_credit=c.id and c.credit_model in('XT','XT-DF01','XT-DF02') 
and a.date_pay between trunc(v_cur) and trunc(v_cur)+1-1/24/60/60
        )
        
        loop
         
        idx:=0; 
        
        
  
select nvl(
(select nvl(sum(a.amount_pay),0) v_DeductPenaltyInterest 
from  instalment ins,payinstalment a,cs_credit cd where ins.id=a.id_instalment and ins.id_credit=cd.id 
and a.date_pay between trunc(v_cur) and trunc(v_cur)+1-1/24/60/60 
and cd.credit_model in('XT','XT-DF01','XT-DF02') 
and ins.id_credit=branch.id_credit and a.status='a' and ins.num_instalment>99 and ins.num_instalment<200 
),0) into v_DeductPenaltyInterest from dual;


select nvl(
(select nvl(sum(a.amount_pay),0) v_DeductPenaltyInterest 
from  instalment ins,payinstalment a,cs_credit cd where ins.id=a.id_instalment and ins.id_credit=cd.id 
and a.date_pay between trunc(v_cur) and trunc(v_cur)+1-1/24/60/60 
and cd.credit_model in('XT','XT-DF01','XT-DF02') 
and ins.id_credit=branch.id_credit and a.status='a' and ins.num_instalment=200 
),0) into v_OverFee from dual;
      
select max(num_instalment) into v_maxnum from instalment where status='a' and id_credit=branch.id_credit and type_instalment not in(8,100);

for bb in(
select distinct  ins.id_credit,ins.num_instalment,ins.date_due,ins.paytype,cd.status,'q' v_deduct_mode,
nvl(sum(case when b.trans_type='m' then a.amount_pay end),0) v_FreeFee,
nvl(sum(case when ins.type_instalment=1 then a.amount_pay end),0) v_DeductPrincipal,
nvl(sum(case when ins.type_instalment=2 then a.amount_pay end),0) v_DeductInterest,
nvl(sum(case when ins.type_instalment=60 then a.amount_pay end),0) v_DeductPunishMoney,
nvl(sum(case when ins.type_instalment=70 then a.amount_pay end),0) v_RepayGuaranteeFee,
nvl(sum(case when ins.type_instalment=46 then a.amount_pay end),0) v_fee1,
nvl(sum(case when ins.type_instalment=13 or ins.type_instalment=51 then a.amount_pay end),0) v_RepayServiceFee 
from  instalment ins,payinstalment a,cs_credit cd,payin b where ins.id=a.id_instalment and ins.id_credit=cd.id and a.id_payin=b.id 
and a.date_pay between trunc(v_cur) and trunc(v_cur)+1-1/24/60/60  
and cd.credit_model in('XT','XT-DF01','XT-DF02') 
and ins.id_credit=branch.id_credit and a.status='a' and ins.num_instalment<99 
group by ins.id_credit,ins.num_instalment,ins.date_due,ins.paytype,cd.status
)
loop
  
idx:=idx+1;

           v_DeductPrincipal:=bb.v_DeductPrincipal;
           v_DeductInterest:=bb.v_DeductInterest;
           v_DeductPunishMoney:=bb.v_DeductPunishMoney;
           v_RepayGuaranteeFee:=bb.v_RepayGuaranteeFee;
           v_RepayServiceFee:=bb.v_RepayServiceFee;
           v_fee1:=bb.v_fee1;
           v_deduct_type:=to_char(bb.paytype);
           v_deduct_mode:=bb.v_deduct_mode;
           v_date_due:=bb.date_due;
           v_num:=bb.num_instalment;
           v_FreeFee:=bb.v_FreeFee;

           v_total:=v_DeductPrincipal+v_DeductInterest+v_DeductPunishMoney+v_RepayGuaranteeFee+v_RepayServiceFee+v_fee1;


       for cc in(
         select distinct a.contract_no, b.name,b.ident,c.bank_no from cs_credit a,cs_person b,cs_experience c where a.id_person=b.id and a.id=c.id_credit 
         and a.id=branch.id_credit
         )
       loop
           v_contractno:=cc.contract_no;
           v_name:=cc.name;
           v_ident:=cc.ident;
           v_accountno:=cc.bank_no;
       end loop;
       
       
      select (select nvl(sum(value_instalment),0) from instalment  where status='a' and id_credit=bb.id_credit and num_instalment=bb.num_instalment) -(select nvl(sum(amount_pay),0) 
      from payinstalment where status='a' and  trunc(date_pay)<=trunc(v_cur) and id_instalment in(select id from instalment where id_credit=bb.id_credit and num_instalment=bb.num_instalment and status='a')) 
      into v_lastmoney
      from dual; 
       
       


           if bb.paytype=1 then
          select v_cur-v_date_due into v_i from dual;
          if v_i>0 then
            v_overday:=v_i;
            v_deduct_type:='3';
          else
            v_deduct_type:='1';
            v_overday:=0;
          end if;
          end if;
          
/*          if (bb.status='k' or bb.status='p') and v_num=v_maxnum then
            v_PeriodStatus:='3';
          elsif v_lastmoney>0.05 then
            v_PeriodStatus:='2';
          else
            v_PeriodStatus:='1';
          end if;*/
          
          if v_lastmoney>0.05 then
            v_PeriodStatus:='2';
          else
            if (bb.status='k' or bb.status='p') and v_num=v_maxnum then
               v_PeriodStatus:='3';
            else
               v_PeriodStatus:='1';
             end if;
          end if;
          
        
        if bb.v_FreeFee>0 then
          v_freeFeeFlag:=1;
          else
          v_freeFeeFlag:=0;
          end if;
          

          
          
         if  idx=1  then
          insert into trust_daily_report(id,org_code,contract_no,deduct_mode,deductt_ype,derate_flag,cust_name,cust_identity_no,repaya_ccount,period_status,period_num,deduct_amount,deduct_principal,deduct_interest,deduct_penalty_interest,deduct_punish_money,deduct_procedure_fee,repay_guarantee_fee,repay_service_fee,overdue_days,deduct_date,fee1,fee2,send_time)
          values(seq_trust_daily_report.nextval,'027',v_contractno,v_deduct_mode,v_deduct_type,v_freeFeeFlag,v_name,v_ident,v_accountno,v_PeriodStatus,v_num,v_total+v_DeductPenaltyInterest+v_OverFee,v_DeductPrincipal,
          v_DeductInterest,v_DeductPenaltyInterest,v_DeductPunishMoney,0,v_RepayGuaranteeFee,v_RepayServiceFee,v_overday,v_date_due,v_fee1,v_FreeFee+v_OverFee,trunc(sysdate));
        else
          insert into trust_daily_report(id,org_code,contract_no,deduct_mode,deductt_ype,derate_flag,cust_name,cust_identity_no,repaya_ccount,period_status,period_num,deduct_amount,deduct_principal,deduct_interest,deduct_penalty_interest,deduct_punish_money,deduct_procedure_fee,repay_guarantee_fee,repay_service_fee,overdue_days,deduct_date,fee1,fee2,send_time)
          values(seq_trust_daily_report.nextval,'027',v_contractno,v_deduct_mode,v_deduct_type,v_freeFeeFlag,v_name,v_ident,v_accountno,v_PeriodStatus,v_num,v_total,v_DeductPrincipal,
          v_DeductInterest,0,v_DeductPunishMoney,0,v_RepayGuaranteeFee,v_RepayServiceFee,v_overday,v_date_due,v_fee1,v_FreeFee,trunc(sysdate));
        end if;

        
          commit;

     end loop;
        
     end loop;
  

   p_ReturnCode:='A';
   return;
Exception
   When others Then
     error_info := sqlerrm;
     p_ReturnCode:='Z-'||error_info;
     rollback;

  
end;


/

