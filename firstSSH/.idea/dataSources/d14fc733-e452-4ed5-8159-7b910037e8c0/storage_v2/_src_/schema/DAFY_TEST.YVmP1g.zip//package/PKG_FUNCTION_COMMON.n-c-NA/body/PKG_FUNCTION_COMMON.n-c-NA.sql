create package body pkg_function_common is

  -- author  : wangxiaofeng
  -- created : 2015/6/19
  -- purpose : 分割函数,默认逗号分割 
  function fun_split(p_list varchar2, p_sep varchar2:=',')  
    return type_split  
    pipelined is  
    l_idx  pls_integer;  
    v_list varchar2(4000) := p_list;  
  begin  
    loop  
      l_idx := instr(v_list, p_sep);  
      if l_idx > 0 then  
        pipe row(substr(v_list, 1, l_idx - 1));  
        v_list := substr(v_list, l_idx + length(p_sep));  
      else  
        pipe row(v_list);  
        exit;  
      end if;  
    end loop;
  exception
    When others Then
      return;  
  end fun_split; 
  
  -- author  : wangxiaofeng
  -- created : 2015/7/3
  -- purpose : 获取销售上级用户ID
  function fun_get_superior_userid(p_UserId  number)
    return number
    is
    v_UserId number(10);
  begin
    select b.user_id into v_UserId from sys_user_organize b,
    (select c.pid,d.user_id from sys_user_organize d, sys_organize c where d.org_id = c.id and d.user_id=p_UserId) c 
    where rownum=1 and b.org_id = c.pid;
    
    if v_UserId>0 then
      return v_UserId;
    else
      return p_UserId;
    end if;
  exception
    When others Then
      return p_UserId;
  end fun_get_superior_userid;
  
  function fun_Reg_check_status_desc(p_status varchar2,p_flag number:=1)
    return varchar2
    is
  begin
    --审核端显示状态
    if p_flag=1 then
      -- 扫描-y，初查-f，复查-s，返回门店-r,终查-m,审核结束-e,本公司盖章-c，信托公司盖章-t，完成-a
      if p_status='f' then
        return '初查';
      elsif p_status='s' then
        return '复查';
      elsif p_status='r' then
        return '返回门店';
      elsif p_status='m' then
        return '终查';
      elsif p_status='e' then
        return '审核结束';
      elsif p_status='c' then
        return '本公司盖章';  
      elsif p_status='t' then
        return '信托公司盖章';
      elsif p_status='y' then
        return '扫描';
      elsif p_status='a' then
        return '完成';
      else
        return '';
      end if;   
    else
      --销售端显示状态
      if p_status in('f','s','m') then
        return '检查中';
      elsif p_status='r' then
        return '关键错误';
      elsif p_status in('e','c','y','t','a') then
        return '完成';
      else
        return '';
      end if;
    end if;  
  exception
    When others Then
      return '';
  end fun_Reg_check_status_desc;
  
  -- author  : wangxiaofeng
  -- created : 2015/7/8
  -- purpose : 获取注册审查最近一次的检查结果
  function fun_Reg_check_result(p_IdCredit  number)
    return varchar2
     is
     v_CommitTime    date;
     v_Status        varchar(2);
     v_ErrorLevel    varchar(2);
     v_Date          date:=to_date('2015/07/07','yyyy/mm/dd');
  begin
    --查询是否到公司
    select a.commit_time,b.status into v_CommitTime,v_Status from cs_credit a,reg_check_contract b
    where a.id=b.id_credit(+) and a.id=p_IdCredit;
    
    if v_Status is null and trunc(v_CommitTime)<v_Date then
      return '';
    elsif v_Status is null and trunc(v_CommitTime)>=v_Date then
      return '未到公司';
    elsif v_Status='f' then
      return '检查中';
    else
      --查询最近一次，最大错误层级
      select error_level into v_ErrorLevel
      from (select t.error_level,row_number() over(partition by t.id_credit order by t.version desc,t.error_level desc) nums
            from reg_check_result t where t.id_credit=p_IdCredit)
      where nums=1;
      if v_ErrorLevel=1 then
        return '正确';
      elsif v_ErrorLevel=2 then
        return '小错';
      elsif v_ErrorLevel=3 then
        return '关键错误';
      else
        return '';
      end if;
    end if;
    
  exception
    When others Then
      return '';
  end fun_Reg_check_result;
  
  -- author  : wangxiaofeng
  -- created : 2015/6/19
  -- purpose : 获取考勤状态描述
  function fun_call_service_status_desc(p_status varchar2)
    return varchar2
    is
  begin
    if p_status=0 then
        return '就绪';
    elsif p_status=1 then
        return '上班';
    elsif p_status=2 then
        return '下班';
    elsif p_status=3 then
        return '未就绪';
    elsif p_status=4 then
        return '备注';
    elsif p_status=5 then
        return '小休';
    elsif p_status=6 then
        return '会议';
    elsif p_status=7 then
        return '培训';
    elsif p_status=8 then
        return '就餐';
    elsif p_status=9 then
        return '辅导';
    elsif p_status=10 then
        return '欢迎电话';
    elsif p_status=11 then
        return '支援其他部门';
    elsif p_status=12 then
        return '初查';
    elsif p_status=13 then
        return '复查';
    elsif p_status=14 then
        return '扫描';
    elsif p_status=15 then
        return '调档';
    elsif p_status=16 then
        return '归档';
    else
        return p_status;
    end if;
 
  exception
    When others Then
      return '';
  end fun_call_service_status_desc;
    
  -- author  : wangxiaofeng
  -- created : 2015/9/29
  -- purpose : 获取循环贷当前逾期总欠款
  function fun_cycle_current_total_debit(p_id_credit number)
    return number
    is
   v_value_instalment   number;
  begin
    select nvl(sum(sum(a.ad_flag*(a.principal_amount+a.interest_amount+a.service_amount+a.finance_amount+a.over_amount))),0) into v_value_instalment 
    from cycle_instalment a,cycle_credit b
    where a.id_credit=b.id and b.date_due<trunc(sysdate) and a.id_credit=p_id_credit
    group by a.id_credit;
    return(v_value_instalment);
  Exception
   When others Then
     return(0);
  end fun_cycle_current_total_debit;
  
  -- author  : wangxiaofeng
  -- created : 2015/9/29
  -- purpose : 获取循环贷当前逾期期款
  function fun_cycle_current_debit(p_id_credit number)
    return number
    is
   v_value_instalment   number;
  begin
    select nvl(sum(sum(a.ad_flag*(a.principal_amount+a.interest_amount+a.service_amount+a.finance_amount))),0) into v_value_instalment 
    from cycle_instalment a,cycle_credit b
    where a.id_credit=b.id and b.date_due<trunc(sysdate) and a.id_credit=p_id_credit
    group by a.id_credit;
    return(v_value_instalment);
  Exception
   When others Then
     return(0);
  end fun_cycle_current_debit;
  
  -- author  : wangxiaofeng
  -- created : 2015/9/29
  -- purpose : 获取循环贷合同逾期未还滞纳金欠款
  function fun_cycle_overdue_debit(p_id_credit number)
    return number
    is
    v_overdue_amount   number;
  begin
     select nvl(sum(a.ad_flag*a.over_amount),0) into v_overdue_amount 
     from cycle_instalment a 
     where a.id_credit=p_id_credit;

     return(v_overdue_amount);
  Exception
   When others Then
     return(0);
  end fun_cycle_overdue_debit;
  
  -- author  : wangxiaofeng
  -- created : 2015/9/29
  -- purpose : 获取循环贷合同逾期滞纳金
  function fun_cycle_overdue_amount(p_id_credit number)
    return number
    is
    v_overdue_amount   number;
  begin
     select nvl(sum(a.over_amount),0) into v_overdue_amount 
     from cycle_instalment a 
     where a.ad_flag=1 and a.id_credit=p_id_credit;

     return(v_overdue_amount);
  Exception
   When others Then
     return(0);
  end fun_cycle_overdue_amount;
 
  -- author  : wangxiaofeng
  -- created : 2015/9/29
  -- purpose : 获取最早逾期的到期还款日期
  function fun_min_overdue_date(p_id_credit number)
    return date
    is
    v_date date; 
  begin
    select min(a.date_due) into v_date from instalment a
    where a.type_instalment<>'8' and a.status='a' and a.paystatus in('a','u') and a.id_credit=p_id_credit;
    
    return(v_date);
  Exception
   When others Then
     return(null);
  end fun_min_overdue_date;
  
  -- author  : wangxiaofeng
  -- created : 2015/9/29
  -- purpose : 获取客户现行合同总数量
  function fun_person_due_contract_no(p_id_person number)
    return number
  is
    v_Count number;
    v_Count1 number;
  begin
    select count(1) into v_Count from cs_credit t where t.status='a' and t.id_person=p_id_person;
    select count(1) into v_Count1 from cycle_credit t where t.status='a' and t.id_person=p_id_person;
    
    return(v_Count+v_Count1);
  Exception
   When others Then
     return(0);
  end fun_person_due_contract_no;
  
  -- author  : wangxiaofeng
  -- created : 2015/9/29
  -- purpose : 获取现行合同数量
  function fun_due_contract_no(p_id_person number)
    return number
  is
    v_Count number;
  begin
    select count(1) into v_Count from cs_credit t where t.status='a' and t.id_person=p_id_person;
    return(v_Count);
  Exception
   When others Then
     return(0);
  end fun_due_contract_no;
    
  -- author  : wangxiaofeng
  -- created : 2015/9/29
  -- purpose : 获取循环贷现行合同数量
  function fun_due_cycle_contract_no(p_id_person number)
    return number
  is
    v_Count number;
  begin
    select count(1) into v_Count from cycle_credit t where t.status='a' and t.id_person=p_id_person;
    return(v_Count);
  Exception
   When others Then
     return(0);
  end fun_due_cycle_contract_no;
  
  -- author  : wangxiaofeng
  -- created : 2015/9/29
  -- purpose : 获取客户合同总欠款
  function fun_person_total_debit(p_id_person number)
    return number
  is
    v_Count number;
    v_Count1 number;
  begin
    select nvl(sum(a.value_instalment),0)-nvl(sum(nvl(a.value_pay,0)),0) into v_Count from instalment a,cs_credit b
    where b.id=a.id_credit and a.status='a' and b.status='a' and b.id_person=p_id_person;
    
    select nvl(sum(sum(a.ad_flag*(a.principal_amount+a.interest_amount+a.service_amount+a.finance_amount+a.over_amount))),0) into v_Count1 
    from cycle_instalment a,cycle_credit b
    where b.id=a.id_credit and b.status='a' and b.id_person=p_id_person
    group by a.id_credit;
    
    return(v_Count+v_Count1);
  Exception
   When others Then
     return(0);
  end fun_person_total_debit;
  
  -- author  : wangxiaofeng
  -- created : 2015/9/29
  -- purpose : 获取客户合同总的滞纳金
  function fun_total_overdue_amounnt(p_id_person number)
    return number
  is
    v_Count number;
    v_Count1 number;
  begin
    select nvl(sum(b.value_instalment),0) into v_Count from cs_credit a,instalment b 
    where a.id=b.id_credit and b.status='a' and b.type_instalment='8' and a.status='a' and a.id_person=p_id_person;
    
    select nvl(sum(b.ad_flag*b.over_amount),0) into v_Count1 from cycle_credit a,cycle_instalment b 
    where a.id=b.id_credit and b.ad_flag=1 and a.status='a' and a.id_person=p_id_person;
    
    return(v_Count+v_Count1);
  Exception
   When others Then
     return(0);
  end fun_total_overdue_amounnt;
   
end pkg_function_common;
/

