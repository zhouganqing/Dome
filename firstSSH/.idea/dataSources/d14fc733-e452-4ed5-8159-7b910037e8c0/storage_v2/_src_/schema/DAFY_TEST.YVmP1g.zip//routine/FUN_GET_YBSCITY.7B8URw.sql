create function FUN_GET_YBSCITY(p_Code    registers.reg_number%type)
                                          return varchar2 is
  v_City    varchar2(100);
  v_Count   integer;
begin
   select count(1) into v_Count from ybs_city where code=p_Code;
   if v_Count>0 then
      select city into v_City from ybs_city where rownum=1 and code=p_Code;
   else
      v_City:='';
   end if;
   return(v_City);
end;


/

