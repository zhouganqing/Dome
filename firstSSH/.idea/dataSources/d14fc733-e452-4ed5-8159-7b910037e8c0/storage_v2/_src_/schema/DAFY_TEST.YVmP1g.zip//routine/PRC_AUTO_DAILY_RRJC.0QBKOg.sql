create procedure PRC_AUTO_DAILY_RRJC(p_ReturnCode   out varchar2) is
   /*人人聚财数据明细 -庾文峰*/
   error_info            varchar2(1000);
   
   v_CreditAmount        cs_credit.credit_amount%type;
   v_PaymentNum          product.payment_num%type;
   v_MonthIr             number:=0.015;--product.month_ir%type;   
   
   v_count               number:=0;
   v_Idx                 integer;
   v_loanDate            varchar2(20);
   v_DueDate             varchar2(20);
   v_ReleaseDate         varchar2(20);
   v_Principal           number;
   v_Interest            number;
   v_pi                  number;
   v_lastPrincipal       number;
   
   v_day                 number;
   v_lastDay             number;
   v_num                 number;
   v_checkDate           varchar2(20);
   
   v_status              varchar2(10);
   v_nochargeDate        varchar2(20);

   

   function GetDuePrinciple(n integer) return number is
        ret  number;
   begin
      ret := (v_CreditAmount * v_MonthIr * power(1 + v_MonthIr, n)) / (power(1 + v_MonthIr, v_PaymentNum) - 1);
      return Round(ret,3);
   end;

   function GetDueInterest(n integer) return number is
        ret  number;
   begin
      ret := (v_CreditAmount * v_MonthIr * power(1 + v_MonthIr, v_PaymentNum)) / (power(1 + v_MonthIr, v_PaymentNum) - 1)
            - (v_CreditAmount * v_MonthIr * power(1 + v_MonthIr, n)) / (power(1 + v_MonthIr, v_PaymentNum) - 1);
      return Round(ret,3);
   end;
   
   function GetDate(n varchar2) return varchar2 is
       ret varchar2(20);
    begin
      v_lastDay:=to_number(to_char(last_day(add_months(to_date(n,'yyyy-MM-dd'),1)),'dd'));
      v_day:=to_number(to_char(to_date(n,'yyyy-MM-dd'),'dd'));
      if v_lastDay>=v_day then
        ret:= to_char(v_day,'00');
      else
        ret:= to_char(v_lastDay,'00');
      end if;
      return replace(ret,' ','');
    end;

begin

  for branch in(
     select a.contract_no,a.loan_date,a.credit_amount,a.status,b.name,c.payment_num,d.city 
                from cs_credit a 
                join cs_person b on a.id_person=b.id 
                join product c on a.id_product=c.id 
                left join sellerplace d on a.id_sellerplace=d.id 
                where a.status in('a','k') 
                and not exists(select 1 from instalment_p2p_rrjc t where t.pay_type=1 and t.contract_no=a.contract_no)
                and a.loan_date<=to_date((select max(loan_date) from instalment_p2p_rrjc_match where credit_model='P2P_RRJC'),'yyyy-mm-dd')
                and a.credit_model='P2P_RRJC'
    )
   loop
     
     --select count(1) into v_count from instalment_p2p_rrjc where contract_no=branch.contract_no;
     
     if v_count=0 then
       
     v_loanDate:='0';
     v_DueDate:='0';
     v_ReleaseDate:='0';
     v_pi:=0;
     
     
       v_CreditAmount:=branch.credit_amount;
       v_PaymentNum:=branch.payment_num;
       v_loanDate:=to_char(branch.loan_date,'yyyy-MM-dd');
       v_lastPrincipal:=branch.credit_amount;
       
       for match in(select release_contract from instalment_p2p_rrjc_match where contract_no=branch.contract_no and credit_model='P2P_RRJC')
         loop
           v_ReleaseDate:=match.release_contract;
         end loop;
        if v_ReleaseDate='0' then 
          for match in(select release_loan from instalment_p2p_rrjc_match where loan_date=v_loanDate and credit_model='P2P_RRJC')
           loop
             v_ReleaseDate:=match.release_loan;
           end loop;
         end if;
         if v_ReleaseDate='0' then
            v_ReleaseDate:=v_loanDate;     
         end if;
          v_DueDate:=to_char(add_months(to_date(v_ReleaseDate,'yyyy-MM-dd'),1),'yyyy-MM-')||GetDate(v_ReleaseDate);
          v_nochargeDate:=v_ReleaseDate;
          

      for v_Idx in 1..v_PaymentNum loop
        if v_Idx=1 then          
          v_DueDate:=v_DueDate;
          --v_ReleaseDate:=v_ReleaseDate; 
        else           
          v_DueDate:=to_char(add_months(to_date(v_DueDate,'yyyy-MM-dd'),1),'yyyy-MM-')||GetDate(v_DueDate);
          --v_ReleaseDate:=to_char(add_months(to_date(v_ReleaseDate,'yyyy-MM-dd'),1),'yyyy-MM-')||GetDate(v_ReleaseDate); 
        end if;

          
          v_Interest:=GetDueInterest(v_Idx-1);
          v_Principal:=GetDuePrinciple(v_Idx-1);
          v_pi:=v_pi+v_Interest+v_Principal;
          v_lastPrincipal:=v_lastPrincipal-v_Principal;
          
          
          insert into instalment_p2p_rrjc(id,release_date,loan_date,date_due,contract_no,name,status,overpay_year,need_principal,need_interest,need_pi,has_pi,last_principal,credit_amount,payment_num,margin,city,update_time,update_user,pay_type,num_instalment,credit_model)
          values(seq_instalment_p2p_rrjc.nextval,v_nochargeDate,v_loanDate,v_DueDate,branch.contract_no,branch.name,branch.status,'18%',v_Principal,v_Interest,v_pi,v_pi,v_lastPrincipal,v_CreditAmount,v_PaymentNum,'6%',branch.city,sysdate,100000,1,v_Idx,'P2P_RRJC');

      end loop;
      
      end if;
      
       commit;

end loop;

for branch in(
  select a.contract_no,a.loan_date,a.credit_amount,a.status,b.name,c.payment_num,d.city,a.update_time,
  max(decode(e.paytype,2,e.date_due,4,e.date_due)) date_due,
  min(e.date_due) date_due_1,
  max(
  case when e.paytype=2 and e.status='a' then e.num_instalment 
       when e.paytype=4 and e.status='a' then e.num_instalment 
       else 1 
  end) num_instalment 
  from cs_credit a 
  join cs_person b on a.id_person=b.id 
  join product c on a.id_product=c.id 
  left join sellerplace d on a.id_sellerplace=d.id 
  join instalment e on a.id=e.id_credit 
  where a.status in('p','t') --p 提前还款  t-撤销
  and not exists(select 1 from instalment_p2p_rrjc t where t.pay_type=2 and t.contract_no=a.contract_no) 
  and a.loan_date<=to_date((select max(loan_date) from instalment_p2p_rrjc_match where credit_model='P2P_RRJC'),'yyyy-mm-dd')
  and a.credit_model='P2P_RRJC'
  group by a.contract_no,a.loan_date,a.credit_amount,b.name,c.payment_num,d.city,a.status,a.update_time
  )
  loop
  
   v_loanDate:='0';
   v_DueDate:='0';
   v_ReleaseDate:='0';
   v_pi:=0;
   v_num:=0;
     
     
       v_CreditAmount:=branch.credit_amount;
       v_PaymentNum:=branch.payment_num;
       v_loanDate:=to_char(branch.loan_date,'yyyy-MM-dd');
       v_lastPrincipal:=branch.credit_amount;
       v_Principal:=0;
       v_Interest:=0;
       
       for match in(select release_contract from instalment_p2p_rrjc_match where contract_no=branch.contract_no and credit_model='P2P_RRJC')
         loop
           v_ReleaseDate:=match.release_contract;
         end loop;
        if v_ReleaseDate='0' then 
          for match in(select release_loan from instalment_p2p_rrjc_match where loan_date=v_loanDate and credit_model='P2P_RRJC')
           loop
             v_ReleaseDate:=match.release_loan;
           end loop;
         end if;
         if v_ReleaseDate='0' then
            v_ReleaseDate:=v_loanDate;     
         end if;
          v_DueDate:=to_char(add_months(to_date(v_ReleaseDate,'yyyy-MM-dd'),1),'yyyy-MM-')||GetDate(v_ReleaseDate);
          v_nochargeDate:=v_ReleaseDate;
          
  if branch.status='t' then
    
    
    if to_char(branch.date_due_1,'yyyy-MM-dd')>=v_DueDate or to_char(branch.update_time,'yyyy-MM-dd')>=v_DueDate then  --取消合同修改状态在和放款时间同一天
      v_num:=2;
    else
      v_num:=1;
    end if;
    
    delete instalment_p2p_rrjc where contract_no=branch.contract_no;
    for v_Idx in 1..v_num loop
      
        if v_Idx<>v_num then
          v_status:='a';
        else
          v_status:=branch.status;
        end if;
      
        if v_Idx=1 then          
          v_DueDate:=v_DueDate;
          --v_ReleaseDate:=v_ReleaseDate; 
        else           
          v_DueDate:=to_char(add_months(to_date(v_DueDate,'yyyy-MM-dd'),1),'yyyy-MM-')||GetDate(v_DueDate);
          --v_ReleaseDate:=to_char(add_months(to_date(v_ReleaseDate,'yyyy-MM-dd'),1),'yyyy-MM-')||GetDate(v_ReleaseDate); 
        end if;

          
          v_Interest:=GetDueInterest(v_Idx-1);
          v_Principal:=GetDuePrinciple(v_Idx-1);
          v_pi:=v_pi+v_Interest+v_Principal;
          v_lastPrincipal:=v_lastPrincipal-v_Principal;
      
    if v_Idx<v_num then 
    
          insert into instalment_p2p_rrjc(id,release_date,loan_date,date_due,contract_no,name,status,overpay_year,need_principal,need_interest,need_pi,has_pi,last_principal,credit_amount,payment_num,margin,city,update_time,update_user,pay_type,num_instalment,credit_model)
          values(seq_instalment_p2p_rrjc.nextval,v_nochargeDate,v_loanDate,v_DueDate,branch.contract_no,branch.name,v_status,'18%',v_Principal,v_Interest,v_pi,v_pi,v_lastPrincipal,v_CreditAmount,v_PaymentNum,'6%',branch.city,sysdate,100000,1,v_Idx,'P2P_RRJC');

    else

          insert into instalment_p2p_rrjc(id,release_date,loan_date,date_due,contract_no,name,status,overpay_year,need_principal,need_interest,need_pi,has_pi,last_principal,credit_amount,payment_num,margin,city,update_time,update_user,pay_type,num_instalment,compensation,credit_Model)
          values(seq_instalment_p2p_rrjc.nextval,v_nochargeDate,v_loanDate,v_DueDate,branch.contract_no,branch.name,v_status,'18%',v_Principal,v_Interest,v_pi,v_pi,v_lastPrincipal,v_CreditAmount,v_PaymentNum,'6%',branch.city,sysdate,100000,2,v_Idx,Round(v_lastPrincipal*3/100,3),'P2P_RRJC');
            
    end if;
      
      
      
    end loop;
  
  
  
  else
    
     v_checkDate:=to_char(add_months(to_date(v_DueDate,'yyyy-MM-dd'),branch.num_instalment-1),'yyyy-MM-')||GetDate(v_DueDate); 
    
    if to_char(branch.date_due,'yyyy-MM-dd')>=v_checkDate or to_char(branch.update_time,'yyyy-MM-dd')>=v_checkDate then  --提前还款修改状态和放款时间在同一天
      v_num:=branch.num_instalment+1;
    else
      v_num:=branch.num_instalment;
    end if;
    
    delete instalment_p2p_rrjc where contract_no=branch.contract_no;
    
    for v_Idx in 1..v_num loop
      
        if v_Idx<>v_num then
          v_status:='a';
        else
          v_status:=branch.status;
        end if;
      
        if v_Idx=1 then          
          v_DueDate:=v_DueDate;
          --v_ReleaseDate:=v_ReleaseDate; 
        else           
          v_DueDate:=to_char(add_months(to_date(v_DueDate,'yyyy-MM-dd'),1),'yyyy-MM-')||GetDate(v_DueDate);
          --v_ReleaseDate:=to_char(add_months(to_date(v_ReleaseDate,'yyyy-MM-dd'),1),'yyyy-MM-')||GetDate(v_ReleaseDate); 
        end if;

          
          v_Interest:=GetDueInterest(v_Idx-1);
          v_Principal:=GetDuePrinciple(v_Idx-1);
          v_pi:=v_pi+v_Interest+v_Principal;
          v_lastPrincipal:=v_lastPrincipal-v_Principal;
      
    if v_Idx<v_num then 
    
          insert into instalment_p2p_rrjc(id,release_date,loan_date,date_due,contract_no,name,status,overpay_year,need_principal,need_interest,need_pi,has_pi,last_principal,credit_amount,payment_num,margin,city,update_time,update_user,pay_type,num_instalment,credit_model)
          values(seq_instalment_p2p_rrjc.nextval,v_nochargeDate,v_loanDate,v_DueDate,branch.contract_no,branch.name,v_status,'18%',v_Principal,v_Interest,v_pi,v_pi,v_lastPrincipal,v_CreditAmount,v_PaymentNum,'6%',branch.city,sysdate,100000,1,v_Idx,'P2P_RRJC');

    else

          insert into instalment_p2p_rrjc(id,release_date,loan_date,date_due,contract_no,name,status,overpay_year,need_principal,need_interest,need_pi,has_pi,last_principal,credit_amount,payment_num,margin,city,update_time,update_user,pay_type,num_instalment,compensation,credit_model)
          values(seq_instalment_p2p_rrjc.nextval,v_nochargeDate,v_loanDate,v_DueDate,branch.contract_no,branch.name,v_status,'18%',v_Principal,v_Interest,v_pi,v_pi,v_lastPrincipal,v_CreditAmount,v_PaymentNum,'6%',branch.city,sysdate,100000,2,v_Idx,Round(v_lastPrincipal*3/100,3),'P2P_RRJC');
            
    end if;
      
      
      
    end loop;
     

  end if;
    
  commit;
  
  end loop;

  
   p_ReturnCode:='A';
   return;
Exception
   When others Then
     error_info := sqlerrm;
     p_ReturnCode:='Z-'||error_info;
     rollback;
end;


/

