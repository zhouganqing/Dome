create procedure PRC_UPDATE_CREDITSTATUS(p_ReturnCode out varchar2) is
---修改完全付清的现行合同为完结状态 -庾文峰
  error_info      varchar2(1000);
  v_count         integer:=0;
begin
  
  for branch in(select distinct id_credit from instalment a,cs_credit b where a.id_credit=b.id and b.status='a' and a.status='a' and paytype in(2,4))
    loop
      select count(1) into v_count from instalment where status='a' and paystatus<>'k' and id_credit=branch.id_credit;
      if v_count=0 then
        update cs_credit set status='p',update_time=sysdate where id=branch.id_credit;
      end if;
    end loop;
    
    
     for branch in(select distinct id_credit from instalment a,cs_credit b where a.id_credit=b.id and b.status='a' and a.status='a' and paytype in(1,3))
    loop
      select count(1) into v_count from instalment where status='a' and paystatus<>'k' and id_credit=branch.id_credit;
      if v_count=0 then
        update cs_credit set status='k',update_time=sysdate where id=branch.id_credit;
      end if;
    end loop;
    
  commit;
  p_ReturnCode:='A';
  return;
Exception
  When others Then
    error_info := sqlerrm;
    Rollback;

    p_ReturnCode := 'Z-'||error_info;
end PRC_UPDATE_CREDITSTATUS;


/

