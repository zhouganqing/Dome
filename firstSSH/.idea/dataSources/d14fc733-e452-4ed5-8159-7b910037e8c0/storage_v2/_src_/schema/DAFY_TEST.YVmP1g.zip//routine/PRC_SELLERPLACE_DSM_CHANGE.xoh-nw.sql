create procedure PRC_SELLERPLACE_DSM_CHANGE(p_TryFlag         integer,
                                                       p_ReturnCode      out varchar2) is
   error_info            varchar2(1000);

begin
   for changeList in (select id,pos_code,old_dsm_id,new_dsm_id from sellerplace_dsm_change where active_flag=0 and plan_date<=trunc(sysdate))
   loop
       update sellerplace set dsm_id=changeList.New_Dsm_Id where pos_code=changeList.Pos_Code;
       update sellerplace_dsm_change set active_flag=1,active_time=sysdate where id=changeList.id;

   end loop;
   if p_TryFlag=1 then
      rollback;
   else
      commit;
   end if;
   p_ReturnCode:='A';
   return;
Exception
   When others Then
     error_info := sqlerrm;
     rollback;
     p_ReturnCode:='Z-'||error_info;
end;


/

