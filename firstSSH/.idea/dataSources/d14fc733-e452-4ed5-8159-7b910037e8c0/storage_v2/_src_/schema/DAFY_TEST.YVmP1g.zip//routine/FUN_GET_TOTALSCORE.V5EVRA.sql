create function fun_get_totalscore(p_IdCredit    decision_scorecard_data.id_credit%type,
                                              p_Stage       decision_scorecard_params.stage%type,
                                              p_ParaType    decision_scorecard_params.para_type%type) return number is
  v_TotalScore   number:=0;
begin
  for scorecard in (select a.score from decision_scorecard_data a,decision_scorecard_params b
                     where a.para_id=b.id and b.stage=p_Stage and a.id_credit=p_IdCredit and b.para_type=p_ParaType)
  loop
      v_TotalScore:=v_TotalScore+scorecard.score;
  end loop;

  v_TotalScore:=round(1 / (1+exp(-v_TotalScore)),6);
  return(v_TotalScore);
end;


/

