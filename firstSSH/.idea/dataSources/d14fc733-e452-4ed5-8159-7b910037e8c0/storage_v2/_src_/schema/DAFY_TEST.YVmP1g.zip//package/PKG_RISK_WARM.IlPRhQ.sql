create package PKG_RISK_WARM is

  -- Author  : 100064
  -- Created : 2015/4/7 10:47:41
  -- Purpose : 
  
  --查询与计算各种风险提示信息
  procedure prc_add_risk_warm(p_IdCredit      cs_credit.id%type,
                              p_UpdateUser    number,
                              p_ReturnCode    out varchar2);
  
  procedure prc_uw_office_call(p_IdCredit     cs_credit.id%type,
                               p_UpdateUser   number,
                               p_RiskWarmId   number,
                               p_Flag         number,
                               p_ReturnCode   out varchar2);

end PKG_RISK_WARM;


/

