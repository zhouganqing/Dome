create package body PKG_REGISTER is
  error_info  varchar2(1000);
  v_Count     number(4);
  
  -- author  : wangxiaofeng
  -- created : 2015/6/20
  -- purpose : 获取最后一次hold备注
  function fun_reg_hold_remark(p_ContractNo varchar2)
    return varchar2
    is
    v_Remark varchar2(200);
  begin
     select remark into v_Remark
     from(select contract_no,remark,row_number() over(order by create_time desc) nums from reg_check_log a
          where hold_flag=1 and a.contract_no=p_ContractNo) b where nums=1;
     return(v_Remark);
  exception
    When others Then
      return '';
  end fun_Reg_hold_remark;
  
  --注册扫描合同
  procedure prc_scan_contract(p_ContractNo   varchar2,
                              p_UpdateUser   number,
                              p_ReturnCode   out varchar2)
  is 
  v_IdCredit     number(10);
  v_IdPerson     number(10);
  v_PersonType   number(4);
  v_P2P       number(4);
  
  v_MaxSecond    number(4):=0;
  v_Second       number(4):=0;
  v_Third        number(3):=0;
  v_CreditModel  number(2);
  v_FileAddress  varchar(30);
  begin
    --查看合同是否满足扫描条件
    select count(1) into v_Count from cs_credit t where t.status in('a','p','y') and t.contract_no=p_ContractNo;
    if v_Count<=0 then
      p_ReturnCode:='Z-当前合同状态不满足扫描条件！';
      return;
    end if;
    --查看合同是否已经扫描
    select count(1) into v_Count from reg_check_contract t where t.contract_no=p_ContractNo;
    if v_Count>=1 then
      p_ReturnCode:='Z-扫描无效,合同已有扫描数据！';
      return;
    end if;
    
    --查询所需合同信息
    select a.id id_credit,a.id_person,decode(a.credit_model,'P2P_SYD',5,'P2P_PPM',6,'P2P_RRJC',7,0),
      case when a.credit_model like '%P2P%' and b.position=9 then 1 
      when a.credit_model like '%XT%' and b.position=9 then 2 
      when a.credit_model like '%P2P%' and b.position!=9 then 3 else 4 end 
      into v_IdCredit,v_IdPerson,v_P2P,v_PersonType
    from cs_credit a,cs_employer b
    where a.id=b.id_credit and a.contract_no=p_ContractNo;
             
    select nvl(max(t.credit_model),0) into v_CreditModel from reg_serial_number t where t.first=trunc(sysdate) and t.update_user=p_UpdateUser;
    --判断合同模式 P2P、XT,搜易贷
    if v_CreditModel=3 then 
      if v_P2P in(0,6,7) then
        p_ReturnCode:='Z-扫描无效,您之前扫描的为搜易贷合同，请扫描搜易贷合同！';
        return;
      end if;
    elsif v_CreditModel=4 then
      if v_P2P in(0,5,7) then
        p_ReturnCode:='Z-扫描无效,您之前扫描的为PP_Money合同，请扫描PP_Money合同！';
        return;
      end if;
    elsif v_CreditModel=5 then
      if v_P2P in(0,5,6) then
        p_ReturnCode:='Z-扫描无效,您之前扫描的为人人聚财合同，请扫描人人聚财合同！';
        return;
      end if;
    elsif v_CreditModel=1 then
      if v_PersonType in(2,4) or v_P2P in(5,6,7) then
        p_ReturnCode:='Z-扫描无效,您之前扫描的为P2P合同，请扫描P2P合同！';
        return;
      end if;
    elsif v_CreditModel=2 then
      if v_PersonType in(1,3) or v_P2P in(5,6,7) then
        p_ReturnCode:='Z-扫描无效,您之前扫描的为XT合同，请扫描XT合同！';
        return;
      end if;
    else 
      if v_P2P=5 then
        v_CreditModel:=3;
      elsif v_P2P=6 then
        v_CreditModel:=4;
      elsif v_P2P=7 then
        v_CreditModel:=5;
      elsif v_PersonType in(1,3) then
        v_CreditModel:=1;
      elsif v_PersonType in(2,4) then
        v_CreditModel:=2;
      end if;
    end if;
    
    --获取更新合同存档地址
    select nvl(max(t.second),0) into v_MaxSecond from reg_serial_number t where t.first=trunc(sysdate);     
    if v_MaxSecond>=1 then
      --查看该用户是否有已用存单地址
      select nvl(max(t.second),0),nvl(max(t.third),0) into v_Second,v_Third from reg_serial_number t where t.update_user=p_UpdateUser;
      if v_Third=0 then
        --插入存档地址
        insert into reg_serial_number(first,second,third,update_user,credit_model)
        values(trunc(sysdate),v_MaxSecond+1,1,p_UpdateUser,v_CreditModel); 
        v_FileAddress:=to_char(sysdate,'yyyymmdd')||'-'||(v_MaxSecond+1)||'-1';
      elsif v_Third=100 then
        --更新存档地址
        update reg_serial_number t set t.second=v_MaxSecond+1,t.third=1 where t.update_user=p_UpdateUser;
        v_FileAddress:=to_char(sysdate,'yyyymmdd')||'-'||(v_MaxSecond+1)||'-1';
      else
        --更新存档地址
        update reg_serial_number t set t.third=v_Third+1 where t.update_user=p_UpdateUser;
        v_FileAddress:=to_char(sysdate,'yyyymmdd')||'-'||v_Second||'-'||(v_Third+1);
      end if;
    else
      --删除历史记录
      delete from reg_serial_number t where t.first<trunc(sysdate);
      --插入存档地址
      insert into reg_serial_number(first,second,third,update_user,credit_model)
      values(trunc(sysdate),1,1,p_UpdateUser,v_CreditModel); 
      v_FileAddress:=to_char(sysdate,'yyyymmdd')||'-1-1';
    end if;
      
    --插入合同扫描表
    if v_P2P=5 then
      insert into reg_check_contract
      (id_credit,contract_no,id_person,person_type,product_type,status,file_address,hold_flag,create_user,create_time,update_user,update_time)
      values(v_IdCredit,p_ContractNo,v_IdPerson,v_PersonType||','||v_P2P,0,'f',v_FileAddress,0,p_UpdateUser,sysdate,p_UpdateUser,sysdate); 
    else
      insert into reg_check_contract
       (id_credit,contract_no,id_person,person_type,product_type,status,file_address,hold_flag,create_user,create_time,update_user,update_time)
      values(v_IdCredit,p_ContractNo,v_IdPerson,v_PersonType,0,'f',v_FileAddress,0,p_UpdateUser,sysdate,p_UpdateUser,sysdate); 
    end if;
    --插入日志表  
    insert into reg_check_log(contract_no,status,revoke_flag,hold_flag,create_user)
    values(p_ContractNo,'y',0,0,p_UpdateUser);
  
    commit;
    p_ReturnCode:='A';
    return;
  exception
    When others Then
      error_info:=sqlerrm;
      Rollback;
    
    p_ReturnCode:='Z-' || error_info;
  end prc_scan_contract;
  
  -- author  : wangxiaofeng
  -- created : 2015/6/21
  -- purpose : 注册部hold 记录  多个合同号以逗号隔开 
  procedure prc_set_hold(p_ContractNo  clob,
                         p_Remark      varchar2,
                         p_Flag        number,
                         p_UpdateUser  number,
                         p_ReturnCode  out varchar2)
    is
  begin
    if p_Flag=1 then
      --更新hold_flag
      update reg_check_contract t set t.hold_flag=1,t.update_user=p_UpdateUser,t.update_time=sysdate 
      where t.hold_flag=0 and t.contract_no in(select distinct * from table(pkg_function_common.fun_split(p_ContractNo)));
      --写入日志
      insert into reg_check_log(contract_no,status,remark,hold_flag,create_user)
      select t.contract_no,t.status,p_Remark,1,p_UpdateUser from reg_check_contract t 
      where t.hold_flag=1 and t.contract_no in(select distinct * from table(pkg_function_common.fun_split(p_ContractNo)));
    else
      --更新hold_flag
      update reg_check_contract t set t.hold_flag=0,t.update_user=p_UpdateUser,t.update_time=sysdate 
      where t.hold_flag=1 and t.contract_no in(select distinct * from table(pkg_function_common.fun_split(p_ContractNo)));
      --写入日志
      insert into reg_check_log(contract_no,status,remark,hold_flag,create_user)
      select t.contract_no,t.status,p_Remark||' 取消hold单',1,p_UpdateUser from reg_check_contract t 
      where t.hold_flag=0 and t.contract_no in(select distinct * from table(pkg_function_common.fun_split(p_ContractNo)));
    end if;
    commit;
    p_ReturnCode:='A';
    return;  
  exception
    When others Then
      error_info:=sqlerrm;
      Rollback;
    
    p_ReturnCode:='Z-' || error_info; 
  end prc_set_hold;
  
  -- author  : wangxiaofeng
  -- created : 2015/6/21
  -- purpose : 接单检查                           
  procedure prc_process_check_contract(p_ContractNo   number,
                                       p_CheckStatus  varchar2,
                                       p_Flag         number,
                                       p_UpdateUser   number,
                                       p_ReturnCode   out varchar2) 
    is
    v_CheckStatus varchar2(20):='#';
  begin 
     if p_CheckStatus='初查' then 
       v_CheckStatus:='f';
     elsif p_CheckStatus='复查' then
       v_CheckStatus:='s';
     elsif p_CheckStatus='终查' then
       --v_CheckStatus:='m';
       v_CheckStatus:='r';
     end if;  
  
     --查看是否有单正在检查
     select count(1) into v_Count from reg_inprogress t where t.create_user=p_UpdateUser;
     if v_Count>=1 then
       p_ReturnCode:='Z-您还有合同没有检查完毕，请检查完在接单！';
       return;
     end if;
     
     --p_Flag=1表示指定合同检查
     if p_Flag=1 then
       for reg in(select t.id_credit,t.contract_no,t.status,t.hold_flag from reg_check_contract t where t.contract_no=p_ContractNo)
        loop
          --查看是否有此检查状态的合同
          if reg.status not in('f','s','r') or reg.hold_flag=1 then
            p_ReturnCode:='Z-此合同状态不满足检查条件！';
            return; 
          end if; 
          
          --如果此单是复查状态，查看初查是不是当前用户审查提交
          if reg.status='s' then
            select count(1) into v_Count from reg_check_result t 
            where t.version=1 and t.id_credit=reg.id_credit and t.create_user=p_UpdateUser;
            if v_Count>=1 then
              p_ReturnCode:='Z-此合同初查是您审查的，不能再对此合同做复查！';
              return;
            end if;
          end if;
          
          --查看是否有其他人在审查此合同
          select count(1) into v_Count from reg_inprogress t where t.id_credit=reg.id_credit;
          if v_Count>=1 then
            p_ReturnCode:='Z-此合同其他人在审查，请重新接单！';
            return;
          end if;
     
          --插入待审池
          insert into reg_inprogress(id_credit,status,create_user)
          values(reg.id_credit,reg.status,p_UpdateUser);
          --写入日志
          insert into reg_check_log(contract_no,status,remark,create_user)
          values(reg.contract_no,reg.status,'开始',p_UpdateUser);
        end loop;

     else   
       --初查、终查 直接接单 
       if v_CheckStatus in('f','r') then
         --查看是否有此检查状态的合同
         select count(1) into v_Count from reg_check_contract t where t.hold_flag=0 and t.status=v_CheckStatus;
         if v_Count<=0 then
           p_ReturnCode:='Z-没有满足条件的合同可以检查！';
           return; 
         end if;
         
         for reg in(select t.id_credit,t.contract_no,t.status from reg_check_contract t where t.status=v_CheckStatus 
                    and not exists(select '#' from reg_inprogress a where a.id_credit=t.id_credit)
                    and not exists(select '#' from reg_check_log a where a.contract_no=t.contract_no and a.create_user=p_UpdateUser and a.revoke_flag=1)
                    and t.hold_flag=0 and rownum=1)
          loop
            --插入待审池
            insert into reg_inprogress(id_credit,status,create_user)
            values(reg.id_credit,reg.status,p_UpdateUser);
            --写入日志
            insert into reg_check_log(contract_no,status,remark,create_user)
            values(reg.contract_no,reg.status,'开始',p_UpdateUser);
          end loop;
        else --复查排除自己初查检查过的单
          
          --查看是否有此检查状态的合同
          select count(1) into v_Count from reg_check_contract t 
          where t.status=v_CheckStatus and t.hold_flag=0
          and not exists(select '#' from reg_check_log a where a.contract_no=t.contract_no and (a.status='f' or a.revoke_flag=1) and a.create_user=p_UpdateUser);
          
          if v_Count<=0 then
            p_ReturnCode:='Z-没有满足条件的合同可以检查！';
            return; 
          end if;
          
          for reg in(select id_credit,contract_no,status from 
                      (select t.id_credit,t.contract_no,t.status from reg_check_contract t,
                      (select a.id_credit,max(a.error_level) error_level from reg_check_result a
                       where not exists(select 1 from reg_check_result b where b.id_credit=a.id_credit and b.version>=2)
                       and a.version=1 group by a.id_credit) k
                      where t.id_credit=k.id_credit
                      and t.status=v_CheckStatus
                      and t.hold_flag=0
                      and not exists(select 1 from reg_inprogress a where a.id_credit = t.id_credit)
                      and not exists(select '#' from reg_check_log a where a.contract_no=t.contract_no and (a.status='f' or a.revoke_flag=1) and a.create_user=p_UpdateUser) 
                      order by k.error_level desc
                      )where rownum<=1
                     )
            loop
              --插入待审池
              insert into reg_inprogress(id_credit,status,create_user)
              values(reg.id_credit,reg.status,p_UpdateUser);
              --写入日志
              insert into reg_check_log(contract_no,status,remark,create_user)
              values(reg.contract_no,reg.status,'开始',p_UpdateUser);
            end loop;
        end if;
      end if;   
    commit;
    p_ReturnCode:='A';
    return;  
  exception
    When others Then
      error_info:=sqlerrm;
      Rollback;
    
    p_ReturnCode:='Z-' || error_info;    
  end prc_process_check_contract;
  
  -- author  : wangxiaofeng
  -- created : 2015/6/21
  -- purpose : 保存检查结果                           
  procedure prc_save_check_result(p_Xml          clob,
                                  p_IdCredit     number,
                                  p_ContractNo   number,
                                  p_CheckStatus  varchar2,
                                  p_ProductType  varchar2,
                                  p_UpdateUser   number,
                                  p_ReturnCode   out varchar2)
    is
    v_Version  number(2):=0;
    v_Status   varchar2(10);
  begin
    if p_CheckStatus='初查' then 
      v_Status:='f';
      v_Version:=1;
    elsif p_CheckStatus='复查' then
      v_Status:='s';
      v_Version:=2;
    else
      select nvl(max(t.version),0) into v_Version from reg_check_result t where t.id_credit=p_IdCredit;
      --if v_Version<=2 then 
        --v_Version:=3;
      --else  
        v_Version:=v_Version+1;
      --end if;
      --v_Status:='m';
      v_Status:='r';
    end if;
    
    --保存检查结果
    insert into reg_check_result(id_credit,reg_type_id,reg_result_id,error_level,remark,version,create_user,create_time,check_classify)
    select distinct p_IdCredit,a.check_type_id,a.check_result_id,a.error_level,chcek_remark,v_Version,p_UpdateUser,sysdate,p_ProductType 
    from xmltable('$B/reg_check_result_info/reg_check_result' passing
    xmltype(p_Xml) as b columns 
    check_type_id number(10) path '/reg_check_result/check_type_id',
    check_result_id number(10) path '/reg_check_result/check_result_id',
    error_level number(2) path '/reg_check_result/error_level',
    chcek_remark varchar2(500) path '/reg_check_result/chcek_remark') a;   

    --判断结果后 更新状态
    select max(error_level) into v_Count 
    from xmltable('$B/reg_check_result_info/reg_check_result' passing
    xmltype(p_Xml) as b columns 
    check_type_id number(10) path '/reg_check_result/check_type_id',
    check_result_id number(10) path '/reg_check_result/check_result_id',
    error_level number(2) path '/reg_check_result/error_level',
    chcek_remark varchar2(500) path '/reg_check_result/chcek_remark') a;
    if v_Count=3 then --关键错误返回门店
      update reg_check_contract t set t.status='r',t.product_type=p_ProductType,t.update_user=p_UpdateUser,t.update_time=sysdate 
      where t.id_credit=p_IdCredit;
    else
      --初查直接更新状态
      if p_CheckStatus='初查' then
        update reg_check_contract t set t.status='s',t.product_type=p_ProductType,t.update_user=p_UpdateUser,t.update_time=sysdate 
        where t.id_credit=p_IdCredit;
      else 
        --复查、终查(正确、小错)结束检查
        update reg_check_contract t set t.status='e',t.product_type=p_ProductType,t.update_user=p_UpdateUser,t.update_time=sysdate 
        where t.id_credit=p_IdCredit;
      end if;
    end if;
    
    --删除当前再审合同
    delete from reg_inprogress t where t.id_credit=p_IdCredit;
    
    --写入日志
    insert into reg_check_log(contract_no,status,remark,create_user)
    values(p_ContractNo,v_Status,'结束',p_UpdateUser);
    
    commit;
    p_ReturnCode:='A';
    return;  
  exception
    When others Then
      error_info:=sqlerrm;
      Rollback;
    
    p_ReturnCode:='Z-' || error_info; 
  end prc_save_check_result; 
  
  -- author  : wangxiaofeng
  -- created : 2015/6/21
  -- purpose : 合同问题，或者检查者问题，合同返回待审池                      
  procedure prc_return_check_contract(p_ContractNo   number,
                                      p_CheckStatus  varchar2,
                                      p_Remark       varchar2,
                                      p_UpdateUser   number,
                                      p_ReturnCode   out varchar2)                 
   is
   v_CheckStatus varchar2(20):='#';
  begin
    if p_CheckStatus='初查' then 
      v_CheckStatus:='f';
    elsif p_CheckStatus='复查' then
      v_CheckStatus:='s';
    else
      --v_CheckStatus:='m';
      v_CheckStatus:='r';
    end if;  
  
    --查看正审查合同
    select count(1) into v_Count from reg_inprogress t where t.create_user=p_UpdateUser; 
    if v_Count<=0 then
      p_ReturnCode:='Z-您没有接单处理此合同！';
      return;
    end if;  
  
    --删除在审合同
    delete from reg_inprogress t where t.create_user=p_UpdateUser;
    --写入日志
    insert into reg_check_log(contract_no,status,revoke_flag,remark,create_user)
    values(p_ContractNo,v_CheckStatus,1,p_Remark,p_UpdateUser);
    
    commit;
    p_ReturnCode:='A';
    return;  
  exception
    When others Then
      error_info:=sqlerrm;
      Rollback;
    
  end prc_return_check_contract;
  
  -- author  : wangxiaofeng
  -- created : 2015/6/23
  -- purpose : 注册复查状态变更为结束状态                      
  procedure prc_auto_change_status(p_ReturnCode  out varchar2)
    is
    v_Days        number(10);
    v_ErrorLevel  number(2);
  begin
    --查询参数值
    select to_number(t.para_value) into v_Days from sys_parameters t where t.para_id='REG_CHECK_STATUS';
    
    --查找所有满足条件的合同
    for cs in(select t.id_credit,t.contract_no,t.status from reg_check_contract t 
              where t.status='s' and t.update_time<trunc(sysdate-v_Days) 
              and not exists(select '#' from reg_inprogress a where a.id_credit=t.id_credit))
      loop
        --初查最终结果为正确、小错的合同
        select nvl(max(t.error_level),0) into v_ErrorLevel from reg_check_result t where t.version=1 and t.id_credit=cs.id_credit;
        if v_ErrorLevel in(1,2) then
          --更新状态
          update reg_check_contract t set t.status='e',t.update_user=100000,t.update_time=sysdate 
          where t.id_credit=cs.id_credit;
          --写入日志
          insert into reg_check_log(contract_no,status,remark,create_user)
          values(cs.contract_no,cs.status,'系统自动结束审查',100000);  
        end if;    
      end loop;
      
    --将合作模式为非XT合同变更为审查完成状态
    --写入日志
    insert into reg_check_log(contract_no,status,remark,create_user)
    select a.contract_no,'a','非XT合同系统自动完成e->a',100000 from reg_check_contract a,cs_credit b
    where a.id_credit=b.id and b.credit_model!='XT' and a.status='e';
    --更改状态
    update reg_check_contract t set t.status='a',t.update_user=100000,t.update_time=sysdate 
    where exists(select '#' from cs_credit a where a.id=t.id_credit and a.credit_model!='XT') and t.status='e';
    
    commit;
    p_ReturnCode:='A';
    return;  
  exception
    When others Then
      error_info:=sqlerrm;
      Rollback;
      
  end prc_auto_change_status;
                        
end PKG_REGISTER;
/

