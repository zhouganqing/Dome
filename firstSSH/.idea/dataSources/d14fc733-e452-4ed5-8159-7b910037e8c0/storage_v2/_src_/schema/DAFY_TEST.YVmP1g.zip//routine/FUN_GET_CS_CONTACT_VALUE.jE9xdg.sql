create function fun_get_cs_contact_value(p_id_credit   cs_credit.id%type,
                                                    p_person_type cs_contact.person_type%type,
                                                    p_contact_type cs_contact.contact_type%type)
                                                    return varchar2 is
v_Count          number;
v_Contact_value  varchar2(50);
--Create User:王晓锋;
--Use:根据客户联系类型获取对应的联系号码
begin
  select count(1) into v_Count from cs_contact a where a.id_credit=p_id_credit and a.person_type=p_person_type and a.contact_type=p_contact_type;  
  if v_Count<=0 then
    v_Contact_value:='';
  else
    select a.contact_value into v_Contact_value from cs_contact a where a.id_credit=p_id_credit and a.person_type=p_person_type and a.contact_type=p_contact_type and rownum=1;
  end if;

  return(v_Contact_value);
end fun_get_cs_contact_value;


/

