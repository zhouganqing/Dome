create function fun_get_bank_name(p_bankNo checkoff_batch_detail.bankno%type)
                                          return varchar2 is
  v_bank_name   varchar2(50);
--Create User:wangxiaofeng;
--Use:银行清算行号转换为银行名称;
begin
                if p_bankNo='102584000002'then v_bank_name := '中国工商银行';
                elsif p_bankNo='105584000005'then v_bank_name := '中国建设银行';
                elsif p_bankNo='104584000003'then v_bank_name := '中国银行';
                elsif p_bankNo='103584099993'then v_bank_name := '中国农业银行';
                elsif p_bankNo='403584099005'then v_bank_name := '中国邮政储蓄银行';
                elsif p_bankNo='308584001016'then v_bank_name := '招商银行';
                elsif p_bankNo='303584000004'then v_bank_name := '中国光大银行';
                elsif p_bankNo='306584001261'then v_bank_name := '广发银行';
                elsif p_bankNo='302584043105'then v_bank_name := '中信银行';
                elsif p_bankNo='309584000000'then v_bank_name := '兴业银行';
                elsif p_bankNo='305584000002'then v_bank_name := '中国民生银行';
                elsif p_bankNo='307584007998'then v_bank_name := '平安银行';
                elsif p_bankNo='310584000006'then v_bank_name := '浦发银行';
                elsif p_bankNo='301584000016'then v_bank_name := '交通银行';
                elsif p_bankNo='304584040898'then v_bank_name := '华夏银行';
                else
                  v_bank_name := '';
                end if;
  return(v_bank_name);
end fun_get_bank_name;


/

