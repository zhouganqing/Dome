create function fun_person_goods_type(p_Id_Credit cs_credit.id%type)
                                                  return varchar2 is
  vName   varchar2(2000);
begin
  select listagg(to_char(c.name),',') within group(order by b.goods_price desc) into vName from cs_credit a,cs_goods b,goods_type c
  where a.id=b.id_credit and b.id_goods_type=c.id and a.id=p_Id_Credit;
  return(vName);
end;


/

