create procedure prc_auto_audit_report(p_ReturnCode  out varchar2)
    is
    --edited by jallon on 2015-05-21
    -- Author  : 王晓锋
    -- Created : 2015/2/28 16:10:11
    -- Purpose : 审核每小时是自动报表过程
    error_info         varchar2(1000);
    v_date             date;
    v_minute           number;
    v_hour             number;
    v_content          clob;--varchar(4000);
    v_content1         varchar(3000);
    v_content2         varchar(3000);
    v_body_header      nvarchar2(2000);
    v_table_header     nvarchar2(800);
  begin
    v_body_header:='<meta name=''viewport'' content=''width=device-width, minimum-scale=1, maximum-scale=1''><style type=''text/css''>
                      table{
                          font: normal 9pt auto ''Trebuchet MS'', Verdana, Arial, Helvetica, sans-serif;
                          color: #4f6b72;
                          padding: 2px 10px;
                          margin: 0;
                          border:1px;cellspacing:0;cellpadding:0;align:center;border-collapse:collapse;
                          width:420px;
                      }
                      table.th{height:22px;background-color:#ECECE6}
                      td,th {
                          border-right: 1px solid #C1DAD7;
                          border-bottom: 1px solid #C1DAD7;
                          height:20px;
                          color: #000;
                      }
                      tr.alt {
                          background: #F5FAFA;
                          color: #797268;
                      }
                      </style>';
    v_table_header:='<tr><th width=''100px''>统计项</th><th width=''80px''>商品贷</th><th width=''80px''>交叉现金贷</th><th width=''80px''>其他</th><th width=''80px''>总计</th></tr>';
    select to_number(to_char(sysdate,'HH24')) into v_hour from dual;
    if v_hour>9 and v_hour<=22 then
      select to_number(to_char(sysdate,'mi')) into v_minute from dual;

      if v_minute>=50 then
        v_date:=to_date(to_char(sysdate+1/24,'hh24')||':00','hh24:mi');
      else
        v_date:=to_date(to_char(sysdate,'hh24')||':00','hh24:mi');
      end if;

      --v_date:=to_date('2015-3-18 09:23:25','yyyy-MM-dd HH:mi:ss');

      v_content:=v_body_header;
      v_content:=v_content||'<table><tr><td colspan=5 align=''left'' style=''border-right:none;''>'||to_char(sysdate,'yyyy/mm/dd')||' 9:00-'||to_char(v_date,'HH24:mi')||'统计</td></tr>';
      v_content:=v_content||v_table_header;
      for ce in(
        select
        sum(totals) totals,
        round(sum(ce_waiting_time_pos)/decode(sum(postotal),0,1,sum(postotal)),2) ce_waiting_time_pos,
        round(sum(ce_waiting_time_cash)/decode(sum(cashtotal),0,1,sum(cashtotal)),2) ce_waiting_time_cash,
        round(sum(ce_waiting_time_other)/decode(sum(othertotal),0,1,sum(othertotal)),2) ce_waiting_time_other,
        round(sum(ce_waiting_time_total)/decode(sum(totals),0,1,sum(totals)),2) ce_waiting_time_total,
        
        round(sum(ce_time_pos)/decode(sum(postotal),0,1,sum(postotal)),2) ce_processing_time_pos,
        round(sum(ce_time_cash)/decode(sum(cashtotal),0,1,sum(cashtotal)),2) ce_processing_time_cash,
        round(sum(ce_time_other)/decode(sum(othertotal),0,1,sum(othertotal)),2) ce_processing_time_other,
        round(sum(ce_time_total)/decode(sum(totals),0,1,sum(totals)),2) ce_processing_time_total
        from(
        select 1 totals,
        decode(prod_mix_type,1,1,0) postotal,
        decode(prod_mix_type,2,1,0) cashtotal,
        decode(prod_mix_type,3,1,0) othertotal,
        t.prod_mix_type,
        t.ce_waiting_time ce_waiting_time_total,
        decode(prod_mix_type,1,ce_waiting_time,0) ce_waiting_time_pos,
        decode(prod_mix_type,2,ce_waiting_time,0) ce_waiting_time_cash,
        decode(prod_mix_type,3,ce_waiting_time,0) ce_waiting_time_other,
        t.ce_time ce_time_total,
        decode(prod_mix_type,1,ce_time,0) ce_time_pos,
        decode(prod_mix_type,2,ce_time,0) ce_time_cash,
        decode(prod_mix_type,3,ce_time,0) ce_time_other
        from v_ce_daily_report t
        where trunc(t.in_ce_list_time)=trunc(sysdate) and to_date(t.in_ce_list_timecate,'hh24:mi')<=trunc(sysdate,'hh24')))
      loop
        if nvl(ce.totals,0)=0 then
          v_content1:='<tr><td>信用专家的平均等待时长：</td><td>0分</td><td>0分</td><td>0分</td><td>0分</td></tr>';
          v_content1:=v_content1||'<tr class=''alt''><td>信用专家的平均审核时长：</td><td>0分</td><td>0分</td><td>0分</td><td>0分</td></tr>';
        else
          v_content1:='<tr><td>信用专家的平均等待时长：</td><td>'||ce.ce_waiting_time_pos||'分</td><td>'||ce.ce_waiting_time_cash||'分</td><td>'||ce.ce_waiting_time_other||'分</td><td>'||ce.ce_waiting_time_total||'分</td></tr>';
          v_content1:=v_content1||'<tr class=''alt''><td>信用专家的平均审核时长：</td><td>'||ce.ce_processing_time_pos||'分</td><td>'||ce.ce_processing_time_cash||'分</td><td>'||ce.ce_processing_time_other||'分</td><td>'||ce.ce_processing_time_total||'分</td></tr>';
        end if;
      end loop;

      for cs in(
        select
        --edity by jallon on 2015-05-20
        sum(postotal) postotal,
        sum(cashtotal) cashtotal,
        sum(othertotal) othertotal,
        sum(postotal+cashtotal+othertotal) totals,

        sum(approved_pos) approved_pos,
        sum(approved_cash) approved_cash,
        sum(approved_other) approved_other,
        sum(approved_totals) approved_totals,

        sum(rejected_pos) rejected_pos,
        sum(rejected_cash)  rejected_cash,
        sum(rejected_other)  rejected_other,
        sum(rejected_totals) rejected_totals,

        round(sum(approved_pos)/decode(sum(approved_pos+rejected_pos),0,1,sum(approved_pos+rejected_pos)),4)*100  passing_rate_pos,
        round(sum(approved_cash)/decode(sum(approved_cash+rejected_cash),0,1,sum(approved_cash+rejected_cash)),4)*100  passing_rate_cash,
        round(sum(approved_other)/decode(sum(approved_other+rejected_other),0,1,sum(approved_other+rejected_other)),4)*100  passing_rate_other,
        round(sum(approved_totals)/decode(sum(approved_totals+rejected_totals),0,1,sum(approved_totals+rejected_totals)),4)*100  passing_rate_totals,
        
        round(sum(uw_waitting_time_pos)/decode(sum(uw_process_pos),0,1,sum(uw_process_pos)),2) uw_waitting_time_pos,
        round(sum(uw_waitting_time_cash)/decode(sum(uw_process_cash),0,1,sum(uw_process_cash)),2) uw_waitting_time_cash,
        round(sum(uw_waitting_time_other)/decode(sum(uw_process_other),0,1,sum(uw_process_other)),2) uw_waitting_time_other,
        round(sum(uw_waitting_time_totals)/decode(sum(uw_process_totals),0,1,sum(uw_process_totals)),2) uw_waitting_time_totals,
        
        round(sum(uw_processing_time_pos)/decode(sum(uw_process_pos),0,1,sum(uw_process_pos)),2) uw_processing_time_pos,
        round(sum(uw_processing_time_cash)/decode(sum(uw_process_cash),0,1,sum(uw_process_cash)),2) uw_processing_time_cash,
        round(sum(uw_processing_time_other)/decode(sum(uw_process_other),0,1,sum(uw_process_other)),2) uw_processing_time_other,
        round(sum(uw_processing_time_totals)/decode(sum(uw_process_totals),0,1,sum(uw_process_totals)),2) uw_processing_time_totals,
        
        round(sum(uw_handle_time_pos)/decode(sum(uw_process_pos),0,1,sum(uw_process_pos)),2) uw_handle_time_pos,
        round(sum(uw_handle_time_cash)/decode(sum(uw_process_cash),0,1,sum(uw_process_cash)),2) uw_handle_time_cash,
        round(sum(uw_handle_time_other)/decode(sum(uw_process_other),0,1,sum(uw_process_other)),2) uw_handle_time_other,
        round(sum(uw_handle_time_totals)/decode(sum(uw_process_totals),0,1,sum(uw_process_totals)),2) uw_handle_time_totals,
        
        round(sum(process_time_pos)/decode(sum(postotal),0,1,sum(postotal)),2) process_time_pos,
        round(sum(process_time_cash)/decode(sum(cashtotal),0,1,sum(cashtotal)),2) process_time_cash,
        round(sum(process_time_other)/decode(sum(othertotal),0,1,sum(othertotal)),2) process_time_other,
        round(sum(process_time_totals)/decode(sum(totals),0,1,sum(totals)),2) process_time_totals,
        
        round(sum(tsf_pos_15)/decode(sum(postotal),0,1,sum(postotal)),4)*100 tsf_pos_15,
        round(sum(tsf_cash_15)/decode(sum(cashtotal),0,1,sum(cashtotal)),4)*100 tsf_cash_15,
        round(sum(tsf_other_15)/decode(sum(othertotal),0,1,sum(othertotal)),4)*100 tsf_other_15,
        round(sum(tsf_total_15)/decode(sum(totals),0,1,sum(totals)),4)*100 tsf_total_15,
        
        round(sum(tsf_pos_30)/decode(sum(postotal),0,1,sum(postotal)),4)*100 tsf_pos_30,
        round(sum(tsf_cash_30)/decode(sum(cashtotal),0,1,sum(cashtotal)),4)*100 tsf_cash_30,
        round(sum(tsf_other_30)/decode(sum(othertotal),0,1,sum(othertotal)),4)*100 tsf_other_30,
        round(sum(tsf_total_30)/decode(sum(totals),0,1,sum(totals)),4)*100 tsf_total_30,
        
        round(sum(tsf_pos_45)/decode(sum(postotal),0,1,sum(postotal)),4)*100 tsf_pos_45,
        round(sum(tsf_cash_45)/decode(sum(cashtotal),0,1,sum(cashtotal)),4)*100 tsf_cash_45,
        round(sum(tsf_other_45)/decode(sum(othertotal),0,1,sum(othertotal)),4)*100 tsf_other_45,
        round(sum(tsf_total_45)/decode(sum(totals),0,1,sum(totals)),4)*100 tsf_total_45,
        
        round(sum(tsf_pos_60)/decode(sum(postotal),0,1,sum(postotal)),4)*100 tsf_pos_60,
        round(sum(tsf_cash_60)/decode(sum(cashtotal),0,1,sum(cashtotal)),4)*100 tsf_cash_60,
        round(sum(tsf_other_60)/decode(sum(othertotal),0,1,sum(othertotal)),4)*100 tsf_other_60,
        round(sum(tsf_total_60)/decode(sum(totals),0,1,sum(totals)),4)*100 tsf_total_60
        from(
        select distinct
        t.prod_mix_type,
        t.id_credit,
        1 totals,
        decode(prod_mix_type,1,1,0) postotal,
        decode(prod_mix_type,2,1,0) cashtotal,
        decode(prod_mix_type,3,1,0) othertotal,
        decode(prod_mix_type,3,0,1,0,2,0,1) other,
        case when t.status is null and t.user_name is null then 0 else 1 end process_totals,
        case when t.user_name is null then 0 else 1 end uw_process_totals,
        case when t.user_name is not null and t.prod_mix_type=1 then 1 else 0 end uw_process_pos,
        case when t.user_name is not null and t.prod_mix_type=2 then 1 else 0 end uw_process_cash,
        case when t.user_name is not null and t.prod_mix_type=3 then 1 else 0 end uw_process_other,
        case when t.status='approved' then 1 else 0 end approved_totals,
        case when t.status='approved' and t.prod_mix_type=1 then 1 else 0 end approved_pos,
        case when t.status='approved' and t.prod_mix_type=2 then 1 else 0 end approved_cash,
        case when t.status='approved' and t.prod_mix_type=3 then 1 else 0 end approved_other,
        case when t.status='rejected' then 1 else 0 end rejected_totals,
        case when t.status='rejected' and t.prod_mix_type=1 then 1 else 0 end rejected_pos,
        case when t.status='rejected' and t.prod_mix_type=2 then 1 else 0 end rejected_cash,
        case when t.status='rejected' and t.prod_mix_type=3 then 1 else 0 end rejected_other,
        case when t.user_name is not null then t.process_time else 0 end process_time_totals,
        case when t.user_name is not null and t.prod_mix_type=1 then t.process_time else 0 end process_time_pos,
        case when t.user_name is not null and t.prod_mix_type=2 then t.process_time else 0 end process_time_cash,
        case when t.user_name is not null and t.prod_mix_type=3 then t.process_time else 0 end process_time_other,
        t.uw_waitting_time uw_waitting_time_totals,
        decode(prod_mix_type,1,t.uw_waitting_time,0) uw_waitting_time_pos,
        decode(prod_mix_type,2,t.uw_waitting_time,0) uw_waitting_time_cash,
        decode(prod_mix_type,3,t.uw_waitting_time,0) uw_waitting_time_other,
        t.uw_processing_time uw_processing_time_totals,
        decode(prod_mix_type,1,t.uw_processing_time,0) uw_processing_time_pos,
        decode(prod_mix_type,2,t.uw_processing_time,0) uw_processing_time_cash,
        decode(prod_mix_type,3,t.uw_processing_time,0) uw_processing_time_other,
        t.uw_handle_time uw_handle_time_totals,
        decode(prod_mix_type,1,t.uw_handle_time,0) uw_handle_time_pos,
        decode(prod_mix_type,2,t.uw_handle_time,0) uw_handle_time_cash,
        decode(prod_mix_type,3,t.uw_handle_time,0) uw_handle_time_other,
        case when t.TSF='15' then 1 else 0 end tsf_total_15,
        case when t.TSF='15' or t.TSF='30' then 1 else 0 end tsf_total_30,
        case when t.TSF='15' or t.TSF='30' or t.TSF='45' then 1 else 0 end tsf_total_45,
        case when t.TSF='15' or t.TSF='30' or t.TSF='45' or t.TSF='60' then 1 else 0 end tsf_total_60,
        case when t.TSF='15' and t.prod_mix_type=1 then 1 else 0 end tsf_pos_15,
        case when (t.TSF='15' or t.TSF='30') and t.prod_mix_type=1 then 1 else 0 end tsf_pos_30,
        case when (t.TSF='15' or t.TSF='30' or t.TSF='45') and t.prod_mix_type=1 then 1 else 0 end tsf_pos_45,
        case when (t.TSF='15' or t.TSF='30' or t.TSF='45' or t.TSF='60') and t.prod_mix_type=1 then 1 else 0 end tsf_pos_60,
        case when t.TSF='15' and t.prod_mix_type=2 then 1 else 0 end tsf_cash_15,
        case when (t.TSF='15' or t.TSF='30') and t.prod_mix_type=2 then 1 else 0 end tsf_cash_30,
        case when (t.TSF='15' or t.TSF='30' or t.TSF='45') and t.prod_mix_type=2 then 1 else 0 end tsf_cash_45,
        case when (t.TSF='15' or t.TSF='30' or t.TSF='45' or t.TSF='60') and t.prod_mix_type=2 then 1 else 0 end tsf_cash_60,
        case when t.TSF='15' and t.prod_mix_type=3 then 1 else 0 end tsf_other_15,
        case when (t.TSF='15' or t.TSF='30') and t.prod_mix_type=3 then 1 else 0 end tsf_other_30,
        case when (t.TSF='15' or t.TSF='30' or t.TSF='45') and t.prod_mix_type=3 then 1 else 0 end tsf_other_45,
        case when (t.TSF='15' or t.TSF='30' or t.TSF='45' or t.TSF='60') and t.prod_mix_type=3 then 1 else 0 end tsf_other_60
        from v_uw_daily_report_summary t,(select id_credit,max(begin_time) begin_time from cs_audit_log2 where from_status='s' group by id_credit) a
        where a.id_credit=t.id_credit(+) and trunc(a.begin_time)=trunc(sysdate) and a.begin_time>=trunc(sysdate)+9/24 and a.begin_time<=trunc(sysdate,'hh24')))
      loop
       /* 
          
        where a.id_credit=t.id_credit(+) and trunc(a.begin_time)=trunc(sysdate) and a.begin_time>=trunc(sysdate)+9/24 and a.begin_time<=trunc(sysdate,'hh24'))
          1. 总进单量
          2. 审批通过单量
          3. 拒绝单量
          4. 通过率  =通过单量/(通过单量+拒绝单量)    ***不用总进单量是因为有些单可能还未来的及处理
          5. 审核部的平均等待时长
          6. 审核部的平均审核时长
          7. 审核部的平均总处理时长 （等待+审核）
          8. 信用专家的平均等待时长
          9. 信用专家的平均审核时长
          10.平均总处理时长 （审核部等待+审核部审核+信用专家等待+信用专家审核）
          11.60分钟服务水平
          12.45分钟服务水平
          13.30分钟服务水平
          14.15分钟服务水平*/

        if nvl(cs.totals,0)=0 then
          v_content:=v_content||'<tr><td>总进单量：</td><td>0</td><td>0</td></tr>';
          v_content:=v_content||'<tr class=''alt''><td>审批通过单量  ：</td><td>0</td><td>0</td><td>0</td><td>0</td></tr>';
          v_content:=v_content||'<tr><td>拒绝单量：</td><td>0</td><td>0</td><td>0</td><td>0</td></tr>';
          v_content:=v_content||'<tr class=''alt''><td>通过率：</td><td>0%</td><td>0%</td><td>0%</td><td>0%</td></tr>';
          v_content:=v_content||'<tr><td>审核部的平均等待时长：</td><td>0分</td><td>0分</td><td>0分</td><td>0分</td></tr>';
          v_content:=v_content||'<tr class=''alt''><td>审核部的平均审核时长：</td><td>0分</td><td>0分</td><td>0分</td><td>0分</td></tr>';
          v_content:=v_content||v_content1;
          v_content:=v_content||'<tr><td>审核部的平均总处理时长：</td><td>0分</td><td>0分</td><td>0分</td><td>0分</td></tr>';
          v_content:=v_content||'<tr class=''alt''><td>平均总处理时长：</td><td>0分</td><td>0分</td><td>0分</td><td>0分</td></tr>';
          v_content:=v_content||'<tr><td>15分钟服务水平：</td><td>0%</td><td>0%</td><td>0%</td><td>0%</td></tr>';
          v_content:=v_content||'<tr class=''alt''><td>30分钟服务水平：</td><td>0%</td><td>0%</td><td>0%</td><td>0%</td></tr>';
          v_content:=v_content||'<tr><td>45分钟服务水平：</td><td>0%</td><td>0%</td><td>0%</td><td>0%</td></tr>';
          v_content:=v_content||'<tr class=''alt''><td>60分钟服务水平：</td><td>0%</td><td>0%</td><td>0%</td><td>0%</td></tr></table>';
        else
          v_content:=v_content||'<tr><td>总进单量：</td><td>'||cs.postotal||'</td><td>'||cs.cashtotal||'</td><td>'||cs.othertotal||'</td><td>'||cs.totals||'</td></tr>';
          v_content:=v_content||'<tr class=''alt''><td>审批通过单量  ：</td><td>'||cs.approved_pos||'</td><td>'||cs.approved_cash||'</td><td>'||cs.approved_other||'</td><td>'||cs.approved_totals||'</td></tr>';
          v_content:=v_content||'<tr><td>拒绝单量：</td><td>'||cs.rejected_pos||'</td><td>'||cs.rejected_cash||'</td><td>'||cs.rejected_other||'</td><td>'||cs.rejected_totals||'</td></tr>';
          v_content:=v_content||'<tr class=''alt''><td>通过率：</td><td>'||cs.passing_rate_pos||'%</td><td>'||cs.passing_rate_cash||'%</td><td>'||cs.passing_rate_other||'%</td><td>'||cs.passing_rate_totals||'%</td></tr>';
          v_content:=v_content||'<tr><td>审核部的平均等待时长：</td><td>'||cs.uw_waitting_time_pos||'分</td><td>'||cs.uw_waitting_time_cash||'分</td><td>'||cs.uw_waitting_time_other||'分</td><td>'||cs.uw_waitting_time_totals||'分</td></tr>';
          v_content:=v_content||'<tr class=''alt''><td>审核部的平均审核时长：</td><td>'||cs.uw_processing_time_pos||'分</td><td>'||cs.uw_processing_time_cash||'分</td><td>'||cs.uw_processing_time_other||'分</td><td>'||cs.uw_processing_time_totals||'分</td></tr>';
          v_content:=v_content||v_content1;
          v_content:=v_content||'<tr><td>审核部的平均总处理时长：</td><td>'||cs.uw_handle_time_pos||'分</td><td>'||cs.uw_handle_time_cash||'分</td><td>'||cs.uw_handle_time_other||'分</td><td>'||cs.uw_handle_time_totals||'分</td></tr>';
          v_content:=v_content||'<tr class=''alt''><td>平均总处理时长：</td><td>'||cs.process_time_pos||'分</td><td>'||cs.process_time_cash||'分</td><td>'||cs.process_time_other||'分</td><td>'||cs.process_time_totals||'分</td></tr>';
          v_content:=v_content||'<tr><td>15分钟服务水平：</td><td>'||cs.tsf_pos_15||'%</td><td>'||cs.tsf_cash_15||'%</td><td>'||cs.tsf_other_15||'%</td><td>'||cs.tsf_total_15||'%</td></tr>';
          v_content:=v_content||'<tr class=''alt''><td>30分钟服务水平：</td><td>'||cs.tsf_pos_30||'%</td><td>'||cs.tsf_cash_30||'%</td><td>'||cs.tsf_other_30||'%</td><td>'||cs.tsf_total_30||'%</td></tr>';
          v_content:=v_content||'<tr><td>45分钟服务水平：</td><td>'||cs.tsf_pos_45||'%</td><td>'||cs.tsf_cash_45||'%</td><td>'||cs.tsf_other_45||'%</td><td>'||cs.tsf_total_45||'%</td></tr>';
          v_content:=v_content||'<tr class=''alt''><td>60分钟服务水平：</td><td>'||cs.tsf_pos_60||'%</td><td>'||cs.tsf_cash_60||'%</td><td>'||cs.tsf_other_60||'%</td><td>'||cs.tsf_total_60||'%</td></tr></table>';
          --end by edit
        end if;
      end loop;

      v_content:=v_content||'<br/><br/><table><tr><td colspan=5 align=''left'' style=''border-right:none;''>'||to_char(sysdate,'yyyy/mm/dd')||' '||to_char(v_date-1/24,'HH24:mi')||'-'||to_char(v_date,'HH24:mi')||'统计</td></tr>';
      v_content:=v_content||v_table_header;
      for ce in(
          select
          sum(totals) totals,
          round(sum(ce_waiting_time_pos)/decode(sum(postotal),0,1,sum(postotal)),2) ce_waiting_time_pos,
          round(sum(ce_waiting_time_cash)/decode(sum(cashtotal),0,1,sum(cashtotal)),2) ce_waiting_time_cash,
          round(sum(ce_waiting_time_other)/decode(sum(othertotal),0,1,sum(othertotal)),2) ce_waiting_time_other,
          round(sum(ce_waiting_time_total)/decode(sum(totals),0,1,sum(totals)),2) ce_waiting_time_total,
          
          round(sum(ce_time_pos)/decode(sum(postotal),0,1,sum(postotal)),2) ce_processing_time_pos,
          round(sum(ce_time_cash)/decode(sum(cashtotal),0,1,sum(cashtotal)),2) ce_processing_time_cash,
          round(sum(ce_time_other)/decode(sum(othertotal),0,1,sum(othertotal)),2) ce_processing_time_other,
          round(sum(ce_time_total)/decode(sum(totals),0,1,sum(totals)),2) ce_processing_time_total
          from(
          select 1 totals,
          decode(prod_mix_type,1,1,0) postotal,
          decode(prod_mix_type,2,1,0) cashtotal,
          decode(prod_mix_type,3,1,0) othertotal,
          t.prod_mix_type,
          t.ce_waiting_time ce_waiting_time_total,
          decode(prod_mix_type,1,ce_waiting_time,0) ce_waiting_time_pos,
          decode(prod_mix_type,2,ce_waiting_time,0) ce_waiting_time_cash,
          decode(prod_mix_type,3,ce_waiting_time,0) ce_waiting_time_other,
          t.ce_time ce_time_total,
          decode(prod_mix_type,1,ce_time,0) ce_time_pos,
          decode(prod_mix_type,2,ce_time,0) ce_time_cash,
          decode(prod_mix_type,3,ce_time,0) ce_time_other
          from v_ce_daily_report t
          where trunc(t.in_ce_list_time)=trunc(sysdate) and to_date(t.in_ce_list_timecate,'hh24:mi')>=trunc(sysdate-1/24,'hh24') and to_date(t.in_ce_list_timecate,'hh24:mi')<=trunc(sysdate,'hh24')))
      loop
        if nvl(ce.totals,0)=0 then
          v_content2:='<tr><td>信用专家的平均等待时长：</td><td>0分</td><td>0分</td><td>0分</td><td>0分</td></tr>';
          v_content2:=v_content2||'<tr class=''alt''><td>信用专家的平均审核时长：</td><td>0分</td><td>0分</td><td>0分</td><td>0分</td></tr>';
        else
          v_content2:='<tr><td>信用专家的平均等待时长：</td><td>'||ce.ce_waiting_time_pos||'分</td><td>'||ce.ce_waiting_time_cash||'分</td><td>'||ce.ce_waiting_time_other||'分</td><td>'||ce.ce_waiting_time_total||'分</td></tr>';
          v_content2:=v_content2||'<tr class=''alt''><td>信用专家的平均审核时长：</td><td>'||ce.ce_processing_time_pos||'分</td><td>'||ce.ce_processing_time_cash||'分</td><td>'||ce.ce_processing_time_other||'分</td><td>'||ce.ce_processing_time_total||'分</td></tr>';
        end if;
      end loop;

      for cs in(
        select
        --edity by jallon on 2015-05-20
        sum(postotal) postotal,
        sum(cashtotal) cashtotal,
        sum(othertotal) othertotal,
        sum(totals) totals,

        sum(approved_pos) approved_pos,
        sum(approved_cash) approved_cash,
        sum(approved_other) approved_other,
        sum(approved_totals) approved_totals,

        sum(rejected_pos) rejected_pos,
        sum(rejected_cash)  rejected_cash,
        sum(rejected_other)  rejected_other,
        sum(rejected_totals) rejected_totals,

        round(sum(approved_pos)/decode(sum(approved_pos+rejected_pos),0,1,sum(approved_pos+rejected_pos)),4)*100  passing_rate_pos,
        round(sum(approved_cash)/decode(sum(approved_cash+rejected_cash),0,1,sum(approved_cash+rejected_cash)),4)*100  passing_rate_cash,
        round(sum(approved_other)/decode(sum(approved_other+rejected_other),0,1,sum(approved_other+rejected_other)),4)*100  passing_rate_other,
        round(sum(approved_totals)/decode(sum(approved_totals+rejected_totals),0,1,sum(approved_totals+rejected_totals)),4)*100  passing_rate_totals,
        
        round(sum(uw_waitting_time_pos)/decode(sum(uw_process_pos),0,1,sum(uw_process_pos)),2) uw_waitting_time_pos,
        round(sum(uw_waitting_time_cash)/decode(sum(uw_process_cash),0,1,sum(uw_process_cash)),2) uw_waitting_time_cash,
        round(sum(uw_waitting_time_other)/decode(sum(uw_process_other),0,1,sum(uw_process_other)),2) uw_waitting_time_other,
        round(sum(uw_waitting_time_totals)/decode(sum(uw_process_totals),0,1,sum(uw_process_totals)),2) uw_waitting_time_totals,
        
        round(sum(uw_processing_time_pos)/decode(sum(uw_process_pos),0,1,sum(uw_process_pos)),2) uw_processing_time_pos,
        round(sum(uw_processing_time_cash)/decode(sum(uw_process_cash),0,1,sum(uw_process_cash)),2) uw_processing_time_cash,
        round(sum(uw_processing_time_other)/decode(sum(uw_process_other),0,1,sum(uw_process_other)),2) uw_processing_time_other,
        round(sum(uw_processing_time_totals)/decode(sum(uw_process_totals),0,1,sum(uw_process_totals)),2) uw_processing_time_totals,
        
        round(sum(uw_handle_time_pos)/decode(sum(uw_process_pos),0,1,sum(uw_process_pos)),2) uw_handle_time_pos,
        round(sum(uw_handle_time_cash)/decode(sum(uw_process_cash),0,1,sum(uw_process_cash)),2) uw_handle_time_cash,
        round(sum(uw_handle_time_other)/decode(sum(uw_process_other),0,1,sum(uw_process_other)),2) uw_handle_time_other,
        round(sum(uw_handle_time_totals)/decode(sum(uw_process_totals),0,1,sum(uw_process_totals)),2) uw_handle_time_totals,
        
        round(sum(process_time_pos)/decode(sum(postotal),0,1,sum(postotal)),2) process_time_pos,
        round(sum(process_time_cash)/decode(sum(cashtotal),0,1,sum(cashtotal)),2) process_time_cash,
        round(sum(process_time_other)/decode(sum(othertotal),0,1,sum(othertotal)),2) process_time_other,
        round(sum(process_time_totals)/decode(sum(totals),0,1,sum(totals)),2) process_time_totals,
        
        round(sum(tsf_pos_15)/decode(sum(postotal),0,1,sum(postotal)),4)*100 tsf_pos_15,
        round(sum(tsf_cash_15)/decode(sum(cashtotal),0,1,sum(cashtotal)),4)*100 tsf_cash_15,
        round(sum(tsf_other_15)/decode(sum(othertotal),0,1,sum(othertotal)),4)*100 tsf_other_15,
        round(sum(tsf_total_15)/decode(sum(totals),0,1,sum(totals)),4)*100 tsf_total_15,
        
        round(sum(tsf_pos_30)/decode(sum(postotal),0,1,sum(postotal)),4)*100 tsf_pos_30,
        round(sum(tsf_cash_30)/decode(sum(cashtotal),0,1,sum(cashtotal)),4)*100 tsf_cash_30,
        round(sum(tsf_other_30)/decode(sum(othertotal),0,1,sum(othertotal)),4)*100 tsf_other_30,
        round(sum(tsf_total_30)/decode(sum(totals),0,1,sum(totals)),4)*100 tsf_total_30,
        
        round(sum(tsf_pos_45)/decode(sum(postotal),0,1,sum(postotal)),4)*100 tsf_pos_45,
        round(sum(tsf_cash_45)/decode(sum(cashtotal),0,1,sum(cashtotal)),4)*100 tsf_cash_45,
        round(sum(tsf_other_45)/decode(sum(othertotal),0,1,sum(othertotal)),4)*100 tsf_other_45,
        round(sum(tsf_total_45)/decode(sum(totals),0,1,sum(totals)),4)*100 tsf_total_45,
        
        round(sum(tsf_pos_60)/decode(sum(postotal),0,1,sum(postotal)),4)*100 tsf_pos_60,
        round(sum(tsf_cash_60)/decode(sum(cashtotal),0,1,sum(cashtotal)),4)*100 tsf_cash_60,
        round(sum(tsf_other_60)/decode(sum(othertotal),0,1,sum(othertotal)),4)*100 tsf_other_60,
        round(sum(tsf_total_60)/decode(sum(totals),0,1,sum(totals)),4)*100 tsf_total_60
        from(
        select distinct
        t.prod_mix_type,
        t.id_credit,
        1 totals,
        decode(prod_mix_type,1,1,0) postotal,
        decode(prod_mix_type,2,1,0) cashtotal,
        decode(prod_mix_type,3,1,0) othertotal,
        decode(prod_mix_type,3,0,1,0,2,0,1) other,
        case when t.status is null and t.user_name is null then 0 else 1 end process_totals,
        case when t.user_name is null then 0 else 1 end uw_process_totals,
        case when t.user_name is not null and t.prod_mix_type=1 then 1 else 0 end uw_process_pos,
        case when t.user_name is not null and t.prod_mix_type=2 then 1 else 0 end uw_process_cash,
        case when t.user_name is not null and t.prod_mix_type=3 then 1 else 0 end uw_process_other,
        case when t.status='approved' then 1 else 0 end approved_totals,
        case when t.status='approved' and t.prod_mix_type=1 then 1 else 0 end approved_pos,
        case when t.status='approved' and t.prod_mix_type=2 then 1 else 0 end approved_cash,
        case when t.status='approved' and t.prod_mix_type=3 then 1 else 0 end approved_other,
        case when t.status='rejected' then 1 else 0 end rejected_totals,
        case when t.status='rejected' and t.prod_mix_type=1 then 1 else 0 end rejected_pos,
        case when t.status='rejected' and t.prod_mix_type=2 then 1 else 0 end rejected_cash,
        case when t.status='rejected' and t.prod_mix_type=3 then 1 else 0 end rejected_other,
        case when t.user_name is not null then t.process_time else 0 end process_time_totals,
        case when t.user_name is not null and t.prod_mix_type=1 then t.process_time else 0 end process_time_pos,
        case when t.user_name is not null and t.prod_mix_type=2 then t.process_time else 0 end process_time_cash,
        case when t.user_name is not null and t.prod_mix_type=3 then t.process_time else 0 end process_time_other,
        t.uw_waitting_time uw_waitting_time_totals,
        decode(prod_mix_type,1,t.uw_waitting_time,0) uw_waitting_time_pos,
        decode(prod_mix_type,2,t.uw_waitting_time,0) uw_waitting_time_cash,
        decode(prod_mix_type,3,t.uw_waitting_time,0) uw_waitting_time_other,
        t.uw_processing_time uw_processing_time_totals,
        decode(prod_mix_type,1,t.uw_processing_time,0) uw_processing_time_pos,
        decode(prod_mix_type,2,t.uw_processing_time,0) uw_processing_time_cash,
        decode(prod_mix_type,3,t.uw_processing_time,0) uw_processing_time_other,
        t.uw_handle_time uw_handle_time_totals,
        decode(prod_mix_type,1,t.uw_handle_time,0) uw_handle_time_pos,
        decode(prod_mix_type,2,t.uw_handle_time,0) uw_handle_time_cash,
        decode(prod_mix_type,3,t.uw_handle_time,0) uw_handle_time_other,
        case when t.TSF='15' then 1 else 0 end tsf_total_15,
        case when t.TSF='15' or t.TSF='30' then 1 else 0 end tsf_total_30,
        case when t.TSF='15' or t.TSF='30' or t.TSF='45' then 1 else 0 end tsf_total_45,
        case when t.TSF='15' or t.TSF='30' or t.TSF='45' or t.TSF='60' then 1 else 0 end tsf_total_60,
        case when t.TSF='15' and t.prod_mix_type=1 then 1 else 0 end tsf_pos_15,
        case when (t.TSF='15' or t.TSF='30') and t.prod_mix_type=1 then 1 else 0 end tsf_pos_30,
        case when (t.TSF='15' or t.TSF='30' or t.TSF='45') and t.prod_mix_type=1 then 1 else 0 end tsf_pos_45,
        case when (t.TSF='15' or t.TSF='30' or t.TSF='45' or t.TSF='60') and t.prod_mix_type=1 then 1 else 0 end tsf_pos_60,
        case when t.TSF='15' and t.prod_mix_type=2 then 1 else 0 end tsf_cash_15,
        case when (t.TSF='15' or t.TSF='30') and t.prod_mix_type=2 then 1 else 0 end tsf_cash_30,
        case when (t.TSF='15' or t.TSF='30' or t.TSF='45') and t.prod_mix_type=2 then 1 else 0 end tsf_cash_45,
        case when (t.TSF='15' or t.TSF='30' or t.TSF='45' or t.TSF='60') and t.prod_mix_type=2 then 1 else 0 end tsf_cash_60,
        case when t.TSF='15' and t.prod_mix_type=3 then 1 else 0 end tsf_other_15,
        case when (t.TSF='15' or t.TSF='30') and t.prod_mix_type=3 then 1 else 0 end tsf_other_30,
        case when (t.TSF='15' or t.TSF='30' or t.TSF='45') and t.prod_mix_type=3 then 1 else 0 end tsf_other_45,
        case when (t.TSF='15' or t.TSF='30' or t.TSF='45' or t.TSF='60') and t.prod_mix_type=3 then 1 else 0 end tsf_other_60
        from v_uw_daily_report_summary t,(select id_credit,max(begin_time) begin_time from cs_audit_log2 where from_status='s' group by id_credit) a
        where a.id_credit=t.id_credit(+) and trunc(a.begin_time)=trunc(sysdate) and a.begin_time>=trunc(sysdate-1/24,'hh24') and a.begin_time<=trunc(sysdate,'hh24')))
      loop

        if nvl(cs.totals,0)=0 then
          v_content:=v_content||'<tr><td>总进单量：</td><td>0</td><td>0</td><td>0</td><td>0</td></tr>';
          v_content:=v_content||'<tr class=''alt''><td>审批通过单量  ：</td><td>0</td><td>0</td><td>0</td><td>0</td></tr>';
          v_content:=v_content||'<tr><td>拒绝单量：</td><td>0</td><td>0</td><td>0</td><td>0</td></tr>';
          v_content:=v_content||'<tr class=''alt''><td>通过率：</td><td>0%</td><td>0%</td><td>0%</td><td>0%</td></tr>';
          v_content:=v_content||'<tr><td>审核部的平均等待时长：</td><td>0分</td><td>0分</td><td>0分</td><td>0分</td></tr>';
          v_content:=v_content||'<tr class=''alt''><td>审核部的平均审核时长：</td><td>0分</td><td>0分</td><td>0分</td><td>0分</td></tr>';
          v_content:=v_content||v_content2;
          v_content:=v_content||'<tr><td>审核部的平均总处理时长：</td><td>0分</td><td>0分</td><td>0分</td><td>0分</td></tr>';
          v_content:=v_content||'<tr class=''alt''><td>平均总处理时长：</td><td>0分</td><td>0分</td><td>0分</td><td>0分</td></tr>';
          v_content:=v_content||'<tr><td>15分钟服务水平：</td><td>0%</td><td>0%</td><td>0%</td><td>0%</td></tr>';
          v_content:=v_content||'<tr class=''alt''><td>30分钟服务水平：</td><td>0%</td><td>0%</td><td>0%</td><td>0%</td></tr>';
          v_content:=v_content||'<tr><td>45分钟服务水平：</td><td>0%</td><td>0%</td><td>0%</td><td>0%</td></tr>';
          v_content:=v_content||'<tr class=''alt''><td>60分钟服务水平：</td><td>0%</td><td>0%</td><td>0%</td><td>0%</td></tr></table>';
        else
          v_content:=v_content||'<tr><td>总进单量：</td><td>'||cs.postotal||'</td><td>'||cs.cashtotal||'</td><td>'||cs.othertotal||'</td><td>'||cs.totals||'</td></tr>';
          v_content:=v_content||'<tr class=''alt''><td>审批通过单量  ：</td><td>'||cs.approved_pos||'</td><td>'||cs.approved_cash||'</td><td>'||cs.approved_other||'</td><td>'||cs.approved_totals||'</td></tr>';
          v_content:=v_content||'<tr><td>拒绝单量：</td><td>'||cs.rejected_pos||'</td><td>'||cs.rejected_cash||'</td><td>'||cs.rejected_other||'</td><td>'||cs.rejected_totals||'</td></tr>';
          v_content:=v_content||'<tr class=''alt''><td>通过率：</td><td>'||cs.passing_rate_pos||'%</td><td>'||cs.passing_rate_cash||'%</td><td>'||cs.passing_rate_other||'%</td><td>'||cs.passing_rate_totals||'%</td></tr>';
          v_content:=v_content||'<tr><td>审核部的平均等待时长：</td><td>'||cs.uw_waitting_time_pos||'分</td><td>'||cs.uw_waitting_time_cash||'分</td><td>'||cs.uw_waitting_time_other||'分</td><td>'||cs.uw_waitting_time_totals||'分</td></tr>';
          v_content:=v_content||'<tr class=''alt''><td>审核部的平均审核时长：</td><td>'||cs.uw_processing_time_pos||'分</td><td>'||cs.uw_processing_time_cash||'分</td><td>'||cs.uw_processing_time_other||'分</td><td>'||cs.uw_processing_time_totals||'分</td></tr>';
          v_content:=v_content||v_content1;
          v_content:=v_content||'<tr><td>审核部的平均总处理时长：</td><td>'||cs.uw_handle_time_pos||'分</td><td>'||cs.uw_handle_time_cash||'分</td><td>'||cs.uw_handle_time_other||'分</td><td>'||cs.uw_handle_time_totals||'分</td></tr>';
          v_content:=v_content||'<tr class=''alt''><td>平均总处理时长：</td><td>'||cs.process_time_pos||'分</td><td>'||cs.process_time_cash||'分</td><td>'||cs.process_time_other||'分</td><td>'||cs.process_time_totals||'分</td></tr>';
          v_content:=v_content||'<tr><td>15分钟服务水平：</td><td>'||cs.tsf_pos_15||'%</td><td>'||cs.tsf_cash_15||'%</td><td>'||cs.tsf_other_15||'%</td><td>'||cs.tsf_total_15||'%</td></tr>';
          v_content:=v_content||'<tr class=''alt''><td>30分钟服务水平：</td><td>'||cs.tsf_pos_30||'%</td><td>'||cs.tsf_cash_30||'%</td><td>'||cs.tsf_other_30||'%</td><td>'||cs.tsf_total_30||'%</td></tr>';
          v_content:=v_content||'<tr><td>45分钟服务水平：</td><td>'||cs.tsf_pos_45||'%</td><td>'||cs.tsf_cash_45||'%</td><td>'||cs.tsf_other_45||'%</td><td>'||cs.tsf_total_45||'%</td></tr>';
          v_content:=v_content||'<tr class=''alt''><td>60分钟服务水平：</td><td>'||cs.tsf_pos_60||'%</td><td>'||cs.tsf_cash_60||'%</td><td>'||cs.tsf_other_60||'%</td><td>'||cs.tsf_total_60||'%</td></tr></table>';
        end if;
      end loop;

      insert into sys_email_list(id,mail_type,key_word,from_user,mail_to,cc_to,subject,email_boby,status,create_time,plan_time)
          values(seq_sys_email_list.nextval,'UW','审核每小时自动发送报表','uw@dafycredit.com','zhucunqun@dafycredit.com;huangzhuowan@dafycredit.com;caimengyun@dafycredit.com;huangjinfeng@dafycredit.com','caocheng@dafycredit.com;zhuxiaolong@dafycredit.com;liguoliang@dafycredit.com;liuguohua@dafycredit.com;shenmengqi@dafycredit.com;sunhuawei@dafycredit.com;lingfei@dafycredit.com;jinlong@dafycredit.com;chenjianliang@dafycredit.com;wangyuan@dafycredit.com;zengfenfang@dafycredit.com;lixiaoxi@dafycredit.com;zhangjinwen@dafycredit.com;zhuanglihua@dafycredit.com;luchangjiang@dafycredit.com;wangxiaofeng@dafycredit.com','审核每小时自动发送报表','<h3>审核每小时自动发送报表:</h3>'|| v_content,0,sysdate,sysdate);
      --test
      --insert into sys_email_list(id,mail_type,key_word,from_user,mail_to,subject,email_boby,status,create_time,plan_time)
          --values(seq_sys_email_list.nextval,'UW','审核每小时自动发送报表','uw@dafycredit.com','wangxiaofeng@dafycredit.com;','审核每小时自动发送报表','<h3>审核每小时自动发送报表:</h3>'|| v_content,0,sysdate,sysdate);

    end if;
  commit;
    p_ReturnCode := 'A';
    return;
  exception
    When others Then
      error_info := sqlerrm;
      Rollback;

      p_ReturnCode := 'Z-' || error_info;
  end prc_auto_audit_report;


/

