create package body PKG_EDIT_PERSON_INFO is
  error_info  varchar2(1000);

  --修改客户姓名
  procedure prc_edit_person_name(p_IdCredit      cs_credit.id%type,
                                 p_IdPerson      cs_person.id%type,
                                 p_oldPersonName  varchar2,
                                 p_newPersonName  varchar2,
                                 p_Update_User    number,
                                 p_ReturnCode     out varchar2)
  is
  begin
    update cs_person set name=p_newPersonName where id=p_IdPerson;

    insert into cs_person_info_edit_log(id_credit,id_person,update_type,old_content,new_content,update_user,update_time)
    values(p_IdCredit,p_IdPerson,'本人姓名',p_oldPersonName,p_newPersonName,p_Update_User,sysdate);
  commit;
    p_ReturnCode := 'A';
    return;
  exception
    When others Then
      error_info := sqlerrm;
      Rollback;

      p_ReturnCode := 'Z-' || error_info;
  end prc_edit_person_name;

  --修改客户身份证信息
  procedure prc_edit_person_ident_info(p_IdCredit        cs_credit.id%type,
                                       p_IdPerson        cs_person.id%type,
                                       p_oldIdentAuth    varchar2,
                                       p_oldIdentExp     date,
                                       p_newIdentAuth    varchar2,
                                       p_newIdentExp     date,
                                       p_Update_User     number,
                                       p_ReturnCode      out varchar2)
  is
  begin
    update cs_person t set t.ident_auth=p_newIdentAuth,t.ident_exp=trunc(p_newIdentExp) where id=p_IdPerson;

    insert into cs_person_info_edit_log(id_credit,id_person,update_type,old_content,new_content,update_user,update_time)
    values(p_IdCredit,p_IdPerson,'身份证信息',p_oldIdentAuth||' '||p_oldIdentExp,p_newIdentAuth||' '||p_newIdentExp,p_Update_User,sysdate);

    commit;
    p_ReturnCode := 'A';
    return;
  exception
    When others Then
      error_info := sqlerrm;
      Rollback;

      p_ReturnCode := 'Z-' || error_info;
  end prc_edit_person_ident_info;


  --修改客户地址
  procedure prc_edit_person_address_info(p_IdCredit       cs_credit.id%type,
                                         p_IdPerson       cs_person.id%type,
                                         p_Id             number,
                                         p_OldProvince    varchar2,
                                         p_OldCity        varchar2,
                                         p_OldRegion      varchar2,
                                         p_OldTown        varchar2,
                                         p_OldStrret      varchar2,
                                         p_OldBuilding    varchar2,
                                         p_OldRoom        varchar2,
                                         p_OldAdress      varchar2,-----------------旧地址
                                         p_NewProvince    varchar2,
                                         p_NewCity        varchar2,
                                         p_NewRegion      varchar2,
                                         p_NewTown        varchar2,
                                         p_NewStrret      varchar2,
                                         p_NewBuilding    varchar2,
                                         p_NewRoom        varchar2,
                                         p_NewAdress      varchar2,-----------------新地址
                                         p_AddressType varchar2,
                                         p_Update_User    number,
                                         p_ReturnCode     out varchar2)
  is
  v_AddressType varchar2(100);

  begin
    update cs_address t set t.province=p_NewProvince,t.city=p_NewCity,t.region=p_NewRegion,t.town=p_NewTown,t.street=p_NewStrret,t.building=p_NewBuilding,t.room=p_NewRoom,t.detail_address=p_NewAdress
    where t.id=p_Id;

    if p_AddressType='2' then
      v_AddressType:='现居住地址';
    else
      v_AddressType:='工作单位/学校地址';
    end if;

    insert into cs_person_info_edit_log(id_credit,id_person,update_type,old_content,new_content,update_user,update_time)
    values(p_IdCredit,p_IdPerson,v_AddressType,p_OldProvince||p_OldCity||p_OldRegion||p_OldTown||p_OldStrret||p_OldBuilding||p_OldRoom||p_OldAdress,
           v_AddressType||p_NewProvince||p_NewCity||p_NewRegion||p_NewTown||p_NewStrret||p_NewBuilding||p_NewRoom||p_NewAdress,p_Update_User,sysdate);
  commit;
    p_ReturnCode := 'A';
    return;
  exception
    When others Then
      error_info := sqlerrm;
      Rollback;

      p_ReturnCode := 'Z-' || error_info;
  end prc_edit_person_address_info;

  --修改客户家庭联系人类型或者方式
  procedure prc_edit_person_family_contact(p_IdCredit        cs_credit.id%type,
                                           p_IdPerson        cs_person.id%type,
                                           p_Id              number,
                                           p_OldName         varchar2,
                                           p_OldPersonType   varchar2,
                                           p_NewName         varchar2,
                                           p_NewPersonType   varchar2,
                                           p_Update_User     number,
                                           p_ReturnCode      out varchar2)
  is
  begin
    if p_OldName!=p_NewName and p_OldPersonType!=p_NewPersonType then
      update cs_other_person t set t.name=p_NewName,t.person_type=p_NewPersonType where t.id=p_Id;
      update cs_contact t set t.person_type=p_NewPersonType where t.id_credit=p_IdCredit and t.id in(select id from cs_contact where person_type=p_OldPersonType);
    else
      if p_OldName=p_NewName then
        update cs_other_person t set t.person_type=p_NewPersonType where t.id=p_Id;
        update cs_contact t set t.person_type=p_NewPersonType
        where t.id_credit=p_IdCredit and t.id in(select id from cs_contact where person_type=p_OldPersonType);
      end if;

      if p_OldPersonType=p_NewPersonType then
        update cs_other_person t set t.name=p_NewName where t.id=p_Id;
      end if;
    end if;

    insert into cs_person_info_edit_log(id_credit,id_person,update_type,old_content,new_content,update_user,update_time)
     values(p_IdCredit,p_IdPerson,'家庭联系人信息',p_OldName||' '||fun_getreg_value(265,p_OldPersonType),p_NewName||' '||fun_getreg_value(265,p_NewPersonType),p_Update_User,sysdate);
  commit;
    p_ReturnCode := 'A';
    return;
  exception
    When others Then
      error_info := sqlerrm;
      Rollback;

      p_ReturnCode := 'Z-' || error_info;
  end prc_edit_person_family_contact;

end PKG_EDIT_PERSON_INFO;

/

