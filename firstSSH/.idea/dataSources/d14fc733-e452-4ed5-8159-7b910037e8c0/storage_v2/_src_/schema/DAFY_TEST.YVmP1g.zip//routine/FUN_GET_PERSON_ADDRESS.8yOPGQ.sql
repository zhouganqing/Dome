create function fun_get_person_address(p_id_credit cs_credit.id%type,p_address_type varchar2) return varchar2 is
  v_Address  varchar2(200);
--create time;2015/01/14
--create user:WangXiaoFeng
--use:获取客户的地址信息
begin
  v_Address:='';
  select t.province||' '||t.city||' '||t.detail_address||t.region||' '||t.town||' '||t.street||' '||t.building||' '||t.room into v_Address
  from cs_address t where t.id_credit=p_id_credit and t.address_type=p_address_type;
  return(v_Address);
Exception
 When others Then
   return(v_Address);
end fun_get_person_address;


/

