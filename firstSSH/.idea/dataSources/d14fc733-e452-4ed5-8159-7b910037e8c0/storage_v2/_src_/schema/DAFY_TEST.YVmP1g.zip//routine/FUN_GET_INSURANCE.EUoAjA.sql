create function fun_get_insurance(p_id_credit number)
/*
use：wangxiaofeng
date:2015-03-11
purpose:获取保险费
*/
return number
is
  v_insurance number;
begin
  select decode(t.is_ssi,0,0,t.insurance_fee) into v_insurance from cs_experience t where t.id_credit=p_id_credit;
  return v_insurance;
exception
   when others
   then
      return 0;
end;


/

