create procedure PRC_SA_PERFORMANCE(p_ReturnCode out varchar2) is
/*创建日期：  2015/5/14    作者： lishan  
  功能描述：  记录每日业绩
*/
   error_info     varchar2(1000);
begin
  
  for hard_check_pre in (select id,commit_time,id_sa
                           from cs_credit
                          where id_sa is not null and trunc(commit_time)=trunc(sysdate)
                         ) loop
    insert into SA_PERFORMANCE_RECORD
      (ID, ID_CREDIT, USER_ID, ROLE_ID, COMMIT_DATE)
      select SEQ_SA_PERFORMANCE_RECORD.NEXTVAL,
             hard_check_pre.id,
             u.parent_userid,
             u.parent_role_id,
             trunc(hard_check_pre.commit_time)
        from (select  p.parent_name, 
                      p.parent_role_id, 
                      p.parent_userid 
                  from sys_user_treepath p 
                  where p.user_id = hard_check_pre.id_sa
                  and p.parent_role_id <> 'PUB') u;
  end loop;
  commit;
  p_ReturnCode := 'A';
  return;
Exception
  When others Then
    error_info   := sqlerrm;
    p_ReturnCode := 'Z-' || error_info;
    rollback;
end;


/

