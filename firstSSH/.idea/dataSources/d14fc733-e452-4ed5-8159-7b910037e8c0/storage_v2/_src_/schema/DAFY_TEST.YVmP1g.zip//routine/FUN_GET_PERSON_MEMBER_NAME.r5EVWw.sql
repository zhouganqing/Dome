create function fun_get_person_member_name(p_id_credit cs_credit.id%type,
                                                      p_person_type cs_contact.person_type%type)
                                          return varchar2 is
  v_Count  number;
  v_Name   cs_other_person.name%type;
begin
   select count(1) into v_Count from cs_other_person a where a.id_credit=p_id_credit and a.person_type=p_person_type;
   if v_Count <= 0 then
     return '';
   else
     select a.name into v_Name from cs_other_person a where a.id_credit=p_id_credit and a.person_type=p_person_type and rownum=1 order by a.update_time desc;
   end if;

   return(v_Name);
end fun_get_person_member_name;


/

