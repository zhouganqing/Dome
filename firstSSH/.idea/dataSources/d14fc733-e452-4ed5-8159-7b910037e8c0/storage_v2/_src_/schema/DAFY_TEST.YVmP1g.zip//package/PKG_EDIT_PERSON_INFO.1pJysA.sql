create package PKG_EDIT_PERSON_INFO is

  -- Author  : 王晓锋
  -- Created : 2015/1/30 14:30:59
  -- Purpose : 修改用户姓名、地址，联系人等信息;

  --修改客户姓名
  procedure prc_edit_person_name(p_IdCredit        cs_credit.id%type,
                                 p_IdPerson        cs_person.id%type,
                                 p_oldPersonName   varchar2,
                                 p_newPersonName   varchar2,
                                 p_Update_User     number,
                                 p_ReturnCode      out varchar2);

  --修改客户身份证信息
  procedure prc_edit_person_ident_info(p_IdCredit        cs_credit.id%type,
                                       p_IdPerson        cs_person.id%type,
                                       p_oldIdentAuth    varchar2,
                                       p_oldIdentExp     date,
                                       p_newIdentAuth    varchar2,
                                       p_newIdentExp     date,
                                       p_Update_User     number,
                                       p_ReturnCode      out varchar2);

  --修改客户地址
  procedure prc_edit_person_address_info(p_IdCredit       cs_credit.id%type,
                                         p_IdPerson       cs_person.id%type,
                                         p_Id             number,
                                         p_OldProvince    varchar2,
                                         p_OldCity        varchar2,
                                         p_OldRegion      varchar2,
                                         p_OldTown        varchar2,
                                         p_OldStrret      varchar2,
                                         p_OldBuilding    varchar2,
                                         p_OldRoom        varchar2,
                                         p_OldAdress      varchar2,-----------------旧地址
                                         p_NewProvince    varchar2,
                                         p_NewCity        varchar2,
                                         p_NewRegion      varchar2,
                                         p_NewTown        varchar2,
                                         p_NewStrret      varchar2,
                                         p_NewBuilding    varchar2,
                                         p_NewRoom        varchar2,
                                         p_NewAdress      varchar2,-----------------新地址
                                         p_AddressType    varchar2,
                                         p_Update_User    number,
                                         p_ReturnCode     out varchar2);

  --修改客户家庭联系人类型或者方式
  procedure prc_edit_person_family_contact(p_IdCredit        cs_credit.id%type,
                                           p_IdPerson        cs_person.id%type,
                                           p_Id              number,
                                           p_OldName         varchar2,
                                           p_OldPersonType   varchar2,
                                           p_NewName         varchar2,
                                           p_NewPersonType   varchar2,
                                           p_Update_User     number,
                                           p_ReturnCode      out varchar2);

end PKG_EDIT_PERSON_INFO;


/

