create function FUN_GET_RELEASE_REBATES(credit_amount cs_credit.credit_amount%type,
                                                   payment_num product.payment_num%type) 
                                                   return varchar2 is
 v_return            varchar2(50);
 v_credit_amount     cs_credit.credit_amount%type;
 
 ---返点金额计算
begin
   
     if payment_num=6 then
     v_credit_amount:=credit_amount*1/100;
     v_return:= v_credit_amount||',1';
     elsif payment_num=9 then
     v_credit_amount:=credit_amount*1/100;
     v_return:= v_credit_amount||',1';
     elsif payment_num=10 then
     v_credit_amount:=credit_amount*1/100;
     v_return:= v_credit_amount||',1';
     elsif payment_num=12 then
     v_credit_amount:=credit_amount*4/100;
     v_return:= v_credit_amount||',4';
     elsif payment_num=15 then
     v_credit_amount:=credit_amount*4/100;
     v_return:= v_credit_amount||',4';
     elsif payment_num=18 then
     v_credit_amount:=credit_amount*5/100;
     v_return:= v_credit_amount||',5';
     elsif payment_num=24 then
     v_credit_amount:=credit_amount*5/100;
     v_return:= v_credit_amount||',5';
     else
       v_return:='NULL';
     end if;
   

  return(v_return);
end FUN_GET_RELEASE_REBATES;


/

