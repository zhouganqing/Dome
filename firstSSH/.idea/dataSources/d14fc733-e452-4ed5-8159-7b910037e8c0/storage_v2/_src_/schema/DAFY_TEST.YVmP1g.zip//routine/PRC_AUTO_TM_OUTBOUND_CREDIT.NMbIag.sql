create procedure prc_auto_tm_outbound_credit(p_ReturnCode  out varchar2) is
  -- Author  : wangxiaofeng
  -- Created : 2015/05/21 19:10:11
  -- Purpose : 电销合同报表每小时执行一次（交叉现金贷现行的合同）
  error_info  varchar2(1000);
  
  v_Count   number(10);
  v_Count1  number(10);
begin
  --查找交叉现金贷客户现行合同
  for cs in(select a.id,a.app_date,a.credit_amount,a.id_person,b.payment_num,b.prod_type from cs_credit a,product b
            where a.id_product=b.id and not exists(select '#' from tm_outbound_contract_report c where c.id_credit=a.id)
            and a.status='a' and b.prod_type in(6,7) and a.update_time>=sysdate-1/24
  )loop
    for act in(select a.active_id,a.call_stage,b.start_date,b.end_date from tm_outbound_call_list a,cross_active_list b
               where a.active_id=b.active_id and b.start_date<=trunc(sysdate) and b.end_date>=trunc(sysdate) and b.status=1 and a.id_person=cs.id_person
    )loop
      select count(1) into v_Count from tm_outbound_call_result t
      where t.update_time>=act.start_date and t.update_time<=cs.app_date
      and t.active_id=act.active_id and t.id_person=cs.id_person;
      --不存在呼叫结果，则只保存合同信息
      if v_Count<=0 then
        insert into tm_outbound_contract_report
          (id_credit,app_date,credit_amount,payment_num,prod_type,id_person,active_id,call_result,update_user)
        values
          (cs.id,cs.app_date,cs.credit_amount,cs.payment_num,cs.prod_type,cs.id_person,act.active_id,99,100000);
      else
        for res in(select update_user,update_time,call_result,call_type from
            (select a.call_result,a.update_user,a.update_time,a.call_type,row_number() over(partition by a.id_person order by a.update_time desc) nums
             from tm_outbound_call_result a
             where a.update_time>=act.start_date and a.update_time<=cs.app_date
             and a.active_id=act.active_id and a.id_person=cs.id_person
            ) where nums=1
        )loop
          if res.call_result in(2,3) then
            insert into tm_outbound_contract_report
              (id_credit,app_date,credit_amount,payment_num,prod_type,id_person,active_id,call_user,call_type,call_stage,call_result,call_update_time,update_user)
            values
              (cs.id,cs.app_date,cs.credit_amount,cs.payment_num,cs.prod_type,cs.id_person,act.active_id,
              res.update_user,res.call_type,act.call_stage,res.call_result,res.update_time,100000);
          elsif res.call_result in(6,7,8,9,10,11) then
            insert into tm_outbound_contract_report
              (id_credit,app_date,credit_amount,payment_num,prod_type,id_person,active_id,call_result,update_user)
            values
              (cs.id,cs.app_date,cs.credit_amount,cs.payment_num,cs.prod_type,cs.id_person,act.active_id,88,100000);
          else
            select nvl(min(nums),0) into v_Count from
            (select a.call_result,a.update_user,a.update_time,a.call_type,row_number() over(partition by a.id_person order by a.update_time desc) nums
             from tm_outbound_call_result a
             where a.update_time>=act.start_date and a.update_time<=cs.app_date
             and a.active_id=act.active_id and a.id_person=cs.id_person
            ) where call_result in(2,3);
            if v_Count<=0 then
              insert into tm_outbound_contract_report
                (id_credit,app_date,credit_amount,payment_num,prod_type,id_person,active_id,call_result,update_user)
              values
                (cs.id,cs.app_date,cs.credit_amount,cs.payment_num,cs.prod_type,cs.id_person,act.active_id,88,100000);
            else
              select nvl(min(nums),0) into v_Count1 from
              (select a.call_result,a.update_user,a.update_time,a.call_type,row_number() over(partition by a.id_person order by a.update_time desc) nums
               from tm_outbound_call_result a
               where a.update_time>=act.start_date and a.update_time<=cs.app_date
               and a.active_id=act.active_id and a.id_person=cs.id_person
              ) where call_result in(6,7,8,9,10,11);
              if v_Count1<=0 or v_Count1>v_Count then
                insert into tm_outbound_contract_report
                  (id_credit,app_date,credit_amount,payment_num,prod_type,id_person,active_id,
                  call_user,call_type,call_stage,call_result,call_update_time,update_user)
                select cs.id,cs.app_date,cs.credit_amount,cs.payment_num,cs.prod_type,cs.id_person,act.active_id,
                  update_user,call_type,act.call_stage,call_result,update_time,100000 from
                  (select a.call_result,a.update_user,a.update_time,a.call_type,row_number() over(partition by a.id_person order by a.update_time desc) nums
                   from tm_outbound_call_result a
                   where a.update_time>=act.start_date and a.update_time<=cs.app_date
                   and a.active_id=act.active_id and a.id_person=cs.id_person and a.call_result in(2,3)
                  ) where nums=1;
              else
                insert into tm_outbound_contract_report
                  (id_credit,app_date,credit_amount,payment_num,prod_type,id_person,active_id,call_result,update_user)
                values
                  (cs.id,cs.app_date,cs.credit_amount,cs.payment_num,cs.prod_type,cs.id_person,act.active_id,88,100000); 
              end if; 
            end if; 
          end if;    
        end loop;
      end if;
    end loop;
  end loop;

  commit;
  p_ReturnCode:='A';
  return;
Exception
  When others Then
    error_info := sqlerrm;
    Rollback;

    p_ReturnCode := 'Z-'||error_info;
end prc_auto_tm_outbound_credit;


/

