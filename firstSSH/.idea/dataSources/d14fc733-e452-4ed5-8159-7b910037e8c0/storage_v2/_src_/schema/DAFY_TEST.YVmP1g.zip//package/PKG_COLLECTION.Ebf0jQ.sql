create package PKG_COLLECTION is

  -- Author  : 王晓锋
  -- Created : 2015/1/5 9:15:11
  -- Purpose : 催收模块

  --根据催收员备注中的联系结果（客户死亡/被捕，投诉，否认贷款）添加疑难案件
  procedure prc_add_coll_diffcult(p_ContractNo     varchar2,
                                  p_Update_User    number,
                                  p_Reason         varchar2,
                                  p_ReturnCode     out varchar2);

  --疑难案件处理
  procedure prc_coll_diffcult_manage(p_ContractNo     varchar2,
                                     p_Flag           number,
                                     p_Update_User    number,
                                     p_Reason         varchar2,
                                     p_ReturnCode     out varchar2);

  --申请停催案件处理
  procedure prc_coll_stop_apply_manage(p_ContractNo     varchar2,
                                       p_Flag           number,
                                       p_Update_User    number,
                                       p_Reason         varchar2,
                                       p_ReturnCode     out varchar2);

  --停催案件处理
  procedure prc_coll_stop_manage(p_ContractNo     varchar2,
                                 p_Flag           number,
                                 p_Update_User    number,
                                 p_Reason         varchar2,
                                 p_ReturnCode     out varchar2);

  --催收每天自动跑取消分期过程
  procedure prc_auto_cancel_instalment(p_ReturnCode out varchar2);
  
  --恢复取消分期合同
  procedure prc_recover_cancel_instalment(p_id_person   cs_person.id%type,
                                          p_ReturnCode  out varchar2);
                                          
  --催收手动取消分期
  procedure prc_hand_cancel_instalment(p_contract_no   varchar2,
                                       p_update_user   number,
                                       p_ReturnCode    out varchar2);
                                       
  --修改在PTP期间的错误备注转态
  procedure prc_edit_coll_call_status(p_contract_no   varchar2,
                                      p_coll_call_id  number,
                                      p_ptp_type      varchar2,
                                      p_update_user   number,
                                      p_ReturnCode    out varchar2); 
                                                                                                              

end PKG_COLLECTION;


/

