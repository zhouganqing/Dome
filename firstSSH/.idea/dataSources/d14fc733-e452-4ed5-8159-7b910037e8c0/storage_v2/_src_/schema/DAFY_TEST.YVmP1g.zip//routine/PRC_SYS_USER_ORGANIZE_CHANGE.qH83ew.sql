create procedure PRC_SYS_USER_ORGANIZE_CHANGE(p_TryFlag         integer,
                                                         p_ReturnCode      out varchar2) is
   -- Author  : Luchangjiang
   -- Create Date : 2015-1-28
   -- Purpose : 批量修改上下级;
   error_info            varchar2(1000);
   errmsg                varchar2(1000); 

   v_UserId              sys_user_organize.user_id%type;
   v_OrgId               sys_organize.id%type;
   v_IdSellerPlace       integer;

   v_SeCity              sellerplace.city%type;
   v_UserCity            sellerplace.city%type;

   spltPosCode           ty_str_split;
   v_PlanDate            date;

   v_Count               integer;
   idx                   integer;
   v_ErrId               integer:=-1;
begin
   if p_TryFlag=0 then
       v_PlanDate:= trunc(sysdate);
   else
       v_PlanDate:= trunc(sysdate)+30;
   end if;
   for changeList in (select a.id,a.user_id,a.old_superior_id,a.new_superior_id,a.pos_code_list,b.org_id,a.update_user
           from sys_user_organize_change a,sys_user_organize b where a.user_id=b.user_id and a.active_flag=0 and a.plan_date<=v_PlanDate)
   loop
       --检查原上级是否正确
       v_ErrId:=changeList.Id;
       select count(1) into v_Count from sys_organize a,sys_user_organize b where rownum=1 and a.pid=b.org_id and b.user_id=changeList.New_Superior_Id;
       if v_Count=0 then
          p_ReturnCode:='Z-The new superior ['||changeList.New_Superior_Id||'] has not subordinate where id='||changeList.id;
          rollback;
          return;
       end if;
       select a.id into v_OrgId from sys_organize a,sys_user_organize b where rownum=1 and a.pid=b.org_id and b.user_id=changeList.New_Superior_Id;

       delete sys_user_organize where user_id=changeList.user_id;
       insert into sys_user_organize(user_id,org_id,update_user,update_time)values(changeList.user_id,v_OrgId,changeList.Update_User,sysdate);

       delete user_pos where user_name=changeList.User_Id;

       if changeList.pos_code_list is not null then
          spltPosCode:=fun_split(changeList.pos_code_list,',');
          for idx in 1..spltPosCode.Count loop
              if spltPosCode(idx) is not null then
                  select count(1) into v_Count from sellerplace where pos_code=spltPosCode(idx);
                  if v_Count=1 then
                     select id,city into v_IdSellerplace,v_SeCity from sellerplace where pos_code=spltPosCode(idx);
                     select city into v_UserCity from sys_user_list where id=changeList.User_Id;
                     if v_SeCity<>v_UserCity then
                         p_ReturnCode:='Z-Sellerplace city is ['||v_SeCity||'] while user city is ['||v_UserCity|| '] where id='||changeList.id;
                         rollback;
                         return;
                     else
                         insert into user_pos(user_name,id_sellerplace,update_user,update_time)
                              values(changeList.User_Id,v_IdSellerplace,changeList.Update_User,sysdate);
                     end if;
                  else
                     p_ReturnCode:='Z-Can not find pos code '||spltPosCode(idx)|| ' where id='||changeList.id;
                     rollback;
                     return;
                  end if;
              end if;
          end loop;
       end if;
       update sys_user_organize_change set active_flag=1,active_time=sysdate where id=changeList.id;
   end loop;
   if p_TryFlag=1 then
      rollback;
   else
      commit;
   end if;
   p_ReturnCode:='A';
   return;
Exception
   When others Then
     error_info := sqlerrm;
     rollback;
     if v_ErrId=-1 then
        p_ReturnCode:='Z-'||error_info;
     else
        p_ReturnCode:='Z-id in ['||v_ErrId||'] '||error_info;
     end if;
end;


/

