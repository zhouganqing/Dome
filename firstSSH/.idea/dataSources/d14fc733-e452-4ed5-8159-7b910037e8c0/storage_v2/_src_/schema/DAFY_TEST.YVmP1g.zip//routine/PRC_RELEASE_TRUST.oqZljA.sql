create procedure PRC_RELEASE_TRUST(p_IdCredit cs_credit.id%type,
                                                      p_Paystatus  varchar2,
                                                      p_ReturnCode out varchar2) is
    error_info           varchar2(1000);
    v_count              integer:=0;
    
    ---信托放款标注 庾文峰
begin

    for branch in (
          select commit_time,loan_date,contract_no,retailer_code,seller_name,pos_code,dealer_name,city,bank_name,account_name,account_no,
          person_name,credit_amount,init_pay,price,prod_code,payment_num,eir from v_credit_release where status in('a','p','k','t') and credit_type='SS' and credit_model='XT'
          and id_credit=p_IdCredit
                  )
  loop
    select count(1) into v_count from release_credit where contractno=branch.contract_no; 
    if v_count=0 then
   
     insert into release_credit(id,committime,loandate,contractno,retailercode,sellername,
     poscode,dealername,city,bankname,accountname,accountno,personname,creditamount,initpay,price,prodcode,num_instalment,eir,status,service_fee)
     values(seq_release_credit.nextval,branch.commit_time,branch.loan_date,to_char(branch.contract_no),branch.retailer_code,branch.seller_name,
     branch.pos_code,branch.dealer_name,branch.city, branch.bank_name,branch.account_name,branch.account_no,branch.person_name,branch.credit_amount,branch.init_pay,
     branch.price,branch.prod_code,branch.payment_num,branch.eir,'a',0);
     
     else
     
       update release_credit set update_time=sysdate where contractno= branch.contract_no;
     
     end if;
     
  end loop;
  
   commit;
   p_ReturnCode:='A';
   return;
Exception
   When others Then
     error_info := sqlerrm;
     p_ReturnCode:='Z-'||error_info;
     rollback;
end;


/

