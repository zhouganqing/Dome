create function fun_get_role_desc(p_role_id sys_role_list.role_id%type)
                                          return varchar2 is
  v_role_desc   sys_role_list.role_desc%type;
begin
   select t.role_desc into v_role_desc from sys_role_list t where t.role_id=p_role_id;
   return(v_role_desc);
end fun_get_role_desc;


/

