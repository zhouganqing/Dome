create procedure prc_save_person_info(p_Id             number,
                                                 p_IdPerson       varchar2,
                                                 p_PersonType     varchar2,
                                                 p_ContactType    varchar2,
                                                 p_Name           varchar2,
                                                 p_ContactValue   varchar2,
                                                 p_Status         varchar2,
                                                 p_UpdateUser     varchar2,
                                                 p_Flag           number,
                                                 p_Remark         varchar2,
                                                 p_ReturnCode     out varchar2) is
  error_info      varchar2(1000);
  v_Role          sys_user_list.role_id%type;
--create user:WangXiaoFeng
--use: 将合同中所有联系号码添加到电话仓库中,此过程在web端提单中调用
begin
  if p_Flag = 1 then
      update cs_contact_portion set status='3' where id_person=p_IdPerson and id=p_Id;
  end if;

  select role_id into v_Role from sys_user_list a where a.id=p_UpdateUser;

  insert into cs_contact_portion(id,name,contact_value,contact_type,person_type,id_person,status,module,update_user,update_time,remark)
  values(seq_contact_portion.nextval,p_Name,p_ContactValue,p_ContactType,p_PersonType,p_IdPerson,p_Status,v_Role,p_UpdateUser,sysdate,p_Remark);

  commit;
  p_ReturnCode:='A';
  return;
Exception
  When others Then
    error_info := sqlerrm;
    Rollback;

    p_ReturnCode := 'Z-'||error_info;
end prc_save_person_info;


/

