create procedure SAVE_USER_TASK_GRANT(p_UserId       sys_user_list.id%type,
                                            p_SubsysName        varchar2,
                                            p_TaskList          varchar2,
                                            p_UpdateUser        varchar2,
                                            p_ReturnCode        out varchar2) is
  error_info      varchar2(1000);
  spltTaskList    ty_str_split;
  v_Count         integer;
  idx             integer:=0;
begin
  delete sys_task_grant where role_id=to_char(p_UserId) and task_code in (select task_code from sys_task_list where subsys_name=p_SubsysName);
  if p_TaskList is not null then
     spltTaskList:=fun_split(p_TaskList,',');
     for idx in 1..spltTaskList.Count loop
        select count(1) into v_Count from sys_task_grant a,sys_user_list b
         where a.role_id=b.role_id and a.task_code=spltTaskList(idx)
           and b.id=p_UserId;
        if v_Count=0 then
          insert into sys_task_grant(role_id,task_code,update_user,update_time)
               values(to_char(p_UserId),spltTaskList(idx),p_UpdateUser,sysdate);
        end if;
     end loop;
  end if;
  commit;
  p_ReturnCode:='A';
  return;
Exception
  When others Then
    error_info := sqlerrm;
    Rollback;

    p_ReturnCode := 'Z-'||error_info;
end SAVE_USER_TASK_GRANT;


/

