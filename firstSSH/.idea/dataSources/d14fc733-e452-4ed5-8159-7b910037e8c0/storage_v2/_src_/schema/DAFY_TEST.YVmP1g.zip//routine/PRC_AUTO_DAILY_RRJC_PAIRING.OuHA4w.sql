create procedure PRC_AUTO_DAILY_RRJC_PAIRING(p_ReturnCode   out varchar2) is

 error_info            varchar2(1000);
 v_DueDate             varchar2(20);
 v_ReleaseDate         varchar2(20);
 v_DueDate1            varchar2(20);
 v_ReleaseDate1        varchar2(20);
 v_Idx                 integer;
 
 v_day                 number;
 v_lastDay             number;
 v_nocharge            varchar2(50);

   function GetDate(n varchar2) return varchar2 is
       ret varchar2(20);
    begin
      v_lastDay:=to_number(to_char(last_day(add_months(to_date(n,'yyyy-MM-dd'),1)),'dd'));
      v_day:=to_number(to_char(to_date(n,'yyyy-MM-dd'),'dd'));
      if v_lastDay>=v_day then
        ret:= to_char(v_day,'00');
      else
        ret:= to_char(v_lastDay,'00');
      end if;
      return replace(ret,' ','');
    end;

begin
  
 for branch in(select contract_no,release_contract from instalment_p2p_rrjc_match where contract_no is not null order by contract_no asc)
   loop
   
     ---根据合同号匹配
       v_DueDate:=to_char(add_months(to_date(branch.release_contract,'yyyy-MM-dd'),1),'yyyy-MM-')||GetDate(branch.release_contract);
       v_ReleaseDate:=branch.release_contract;
       v_nocharge:=branch.release_contract;
       
       for aa in(select nvl(max(num_instalment),0) num_instalment from instalment_p2p_rrjc where contract_no=branch.contract_no and release_date is null)  
       loop
         
         for v_Idx in 1..aa.num_instalment loop 
           
            if v_Idx=1 then          
              v_DueDate:=v_DueDate;
              v_ReleaseDate:=v_ReleaseDate; 
            else           
              v_DueDate:=to_char(add_months(to_date(v_DueDate,'yyyy-MM-dd'),1),'yyyy-MM-')||GetDate(v_DueDate);
              v_ReleaseDate:=to_char(add_months(to_date(v_ReleaseDate,'yyyy-MM-dd'),1),'yyyy-MM-')||GetDate(v_ReleaseDate); 
            end if;
            
            update instalment_p2p_rrjc t set t.release_date=v_nocharge,t.date_due=v_DueDate where t.contract_no=branch.contract_no and t.num_instalment=v_Idx;
            update instalment_p2p_rrjc_match set status_contract=1 where contract_no=branch.contract_no;
            
         end loop;
         commit;
       end loop;
     ---根据合同号匹配

   end loop;
   
   
    for branch in(select distinct loan_date,release_loan from instalment_p2p_rrjc_match order by loan_date asc)
   loop
   
     ---根据现行日期匹配
       v_DueDate1:=to_char(add_months(to_date(branch.release_loan,'yyyy-MM-dd'),1),'yyyy-MM-')||GetDate(branch.release_loan);
       v_ReleaseDate1:=branch.release_loan;
       
       for item in(select distinct contract_no from instalment_p2p_rrjc a where a.loan_date=branch.loan_date and 
                   not exists(select 1 from instalment_p2p_rrjc_match t where t.contract_no=a.contract_no and t.contract_no is not null) 
                   and a.release_date is null
                   )
       loop
         
         v_DueDate:=v_DueDate1;
         v_ReleaseDate:=v_ReleaseDate1;
         v_nocharge:=v_ReleaseDate1;
       
       
       for aa in(select max(num_instalment) num_instalment from instalment_p2p_rrjc where contract_no=item.contract_no)  
       loop
         
         
         for v_Idx in 1..aa.num_instalment loop 
            if v_Idx=1 then          
              v_DueDate:=v_DueDate;
              v_ReleaseDate:=v_ReleaseDate; 
            else           
              v_DueDate:=to_char(add_months(to_date(v_DueDate,'yyyy-MM-dd'),1),'yyyy-MM-')||GetDate(v_DueDate);
              v_ReleaseDate:=to_char(add_months(to_date(v_ReleaseDate,'yyyy-MM-dd'),1),'yyyy-MM-')||GetDate(v_ReleaseDate); 
            end if;
            
            update instalment_p2p_rrjc t set t.release_date=v_nocharge,t.date_due=v_DueDate where t.contract_no=item.contract_no and t.num_instalment=v_Idx;
         end loop;
         
         end loop;
         
         commit;
         
       end loop;

       update instalment_p2p_rrjc_match set status_loan=1 where loan_date=branch.loan_date;
       commit;
       
     ---根据现行日期匹配

   end loop;
   
   
  
Exception
   When others Then
     error_info := sqlerrm;
     p_ReturnCode:='Z-'||error_info;
     rollback;
end;


/

