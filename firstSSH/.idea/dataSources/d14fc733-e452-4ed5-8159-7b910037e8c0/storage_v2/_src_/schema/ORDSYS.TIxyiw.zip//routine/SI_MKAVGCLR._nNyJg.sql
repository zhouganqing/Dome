create FUNCTION
  SI_mkAvgClr wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
a9 c2
jUQrjM/D3edllrCUKzycCbzRLPIwg0zXf8sVfHQCOItuFe8AhLB3f69RMhTG0QuAOXA4j+Sg
PlbYmpbtv8A1hmZpQkIZhvhA0LF//4iAREgYAVaDRKZsx3mOFyV1Jo0qosSCSWfqbC2V1Xns
hVpJb+LU53FqZ1gBsp2oax61tP6+Hh2hgwb1MWMkz6bIa2Li
/

