create TYPE          "exifMetadata222_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","TiffIfd" "TiffIfd223_T","ExifIfd" "ExifIfd224_T","GpsIfd" "GpsIfd225_T","InteroperabilityIfd" "InteroperabilityIfd226_T")FINAL INSTANTIABLE
/

