create FUNCTION
  SI_getClrHstgrFtrW wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
111 ff
wSDFruayMdulJijO+HjFlNf80cYwg1xKLcvWfHSi2k6UHNklLHCs26inJWkxSgRYxafcibXq
LkCeG9m/u8/LbNpjPtZQwry//jEGvw/ESyBOAHBkAn/3Fmls3PIFpnyDp6+uAVrnlmCA4MRH
KW1gm4+egslMGMoT/Mz3T4li3Mta7PuAe7gOprF7N3EJJzXvK6b5eQcZXL23jz3akDC0mNFS
jqStFnILd+wVijs79kreheMj6EUFKJmJWu8=
/

