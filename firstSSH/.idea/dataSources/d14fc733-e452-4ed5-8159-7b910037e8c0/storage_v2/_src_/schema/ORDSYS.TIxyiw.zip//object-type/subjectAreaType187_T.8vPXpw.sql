create TYPE          "subjectAreaType187_T" UNDER "subjectLocationType188_T"("Diameter" NUMBER(38),"Width" NUMBER(38),"Height" NUMBER(38))NOT FINAL INSTANTIABLE
/

