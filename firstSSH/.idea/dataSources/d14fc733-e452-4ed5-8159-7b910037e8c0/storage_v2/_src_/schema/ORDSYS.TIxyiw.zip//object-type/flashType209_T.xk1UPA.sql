create TYPE          "flashType209_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","tag" NUMBER(38),"Fired" "XDB"."XDB$ENUM_T","Return" "XDB"."XDB$ENUM_T","Mode" "XDB"."XDB$ENUM_T","Function" "XDB"."XDB$ENUM_T","RedEyeReduction" "XDB"."XDB$ENUM_T")NOT FINAL INSTANTIABLE
/

