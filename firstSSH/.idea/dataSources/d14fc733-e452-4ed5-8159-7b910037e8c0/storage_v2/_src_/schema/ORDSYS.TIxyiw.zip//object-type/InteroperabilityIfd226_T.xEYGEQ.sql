create TYPE          "InteroperabilityIfd226_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","tag" NUMBER(38),"InteroperabilityIndex" "interoperabilityType164_T")FINAL INSTANTIABLE
/

