create TYPE          "primaryChromaticitiesTy192_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","tag" NUMBER(38),"Color_1" "chromaticity190_T","Color_2" "chromaticity190_T","Color_3" "chromaticity190_T")NOT FINAL INSTANTIABLE
/

