create TYPE          "whitePointType191_T" UNDER "chromaticity190_T"("tag" NUMBER(38))NOT FINAL INSTANTIABLE
/

