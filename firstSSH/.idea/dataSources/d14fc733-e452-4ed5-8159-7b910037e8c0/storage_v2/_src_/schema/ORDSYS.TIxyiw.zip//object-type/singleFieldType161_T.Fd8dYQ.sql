create TYPE          "singleFieldType161_T" UNDER "singleField_t160_T"("tag" NUMBER(38))NOT FINAL INSTANTIABLE
/

