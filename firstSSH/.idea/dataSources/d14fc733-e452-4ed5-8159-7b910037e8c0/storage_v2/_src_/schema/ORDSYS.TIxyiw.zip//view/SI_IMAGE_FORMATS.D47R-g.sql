create view SI_IMAGE_FORMATS as
SELECT SI_FORMAT
  FROM ORDSYS.SI_image_formats_tab
  where read_flg = 'Y'
/

