create TYPE          "PN_ATTR_T445_T" UNDER "PN446_T"("tag" RAW(4),"definer" VARCHAR2(64 CHAR),"name" VARCHAR2(128 CHAR),"number" NUMBER(20),"offset" NUMBER(20),"length" NUMBER(20),"truncated" RAW(1),"rawValue" RAW(2000),"byteOrderLE" RAW(1))NOT FINAL INSTANTIABLE
/

