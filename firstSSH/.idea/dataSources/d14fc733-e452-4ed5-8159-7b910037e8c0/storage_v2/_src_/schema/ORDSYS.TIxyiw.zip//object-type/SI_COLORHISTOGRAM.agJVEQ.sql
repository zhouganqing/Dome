create TYPE SI_ColorHistogram
                                                                          
  AUTHID CURRENT_USER
  AS OBJECT
    (


   --IMPORTANT NOTE!!!!
   -- DO NOT change the order of the attributes
   -- DO NOT change the attribute names
   -- The third constructor function OVERRIDES and HIDES the SYSTEM DEFAULT
   -- constructor. This is done so that we can perform the necessary error
   -- checking to raise the appropriate error messages in the constructor
   --
   -- To do this the attribute names
   -- and order of the attributes must be exactly like it is defined here

     --attributes
     SI_ColorsList colorsList,
     --
     SI_frequenciesList colorFrequenciesList,
     --


     --Methods
     CONSTRUCTOR FUNCTION SI_ColorHistogram
     (sourceImage IN SI_StillImage)
     return SELF AS RESULT DETERMINISTIC ,
     --
      CONSTRUCTOR FUNCTION SI_ColorHistogram
       (firstColor IN SI_Color,
        frequency  IN DOUBLE PRECISION)
     return SELF AS RESULT DETERMINISTIC,


     --NOTE: This constructor OVERRIDES AND HIDES the system DEFAULT
     --constructor. The argument names MUST exactly match the attribute names
      CONSTRUCTOR FUNCTION SI_ColorHistogram
       (SI_ColorsList       IN  colorsList,
        SI_frequenciesList  IN  colorFrequenciesList)
      return SELF AS RESULT DETERMINISTIC,

      MEMBER PROCEDURE SI_Append
      (SELF      IN OUT NOCOPY SI_ColorHistogram,
       color     IN SI_Color,
       frequency IN DOUBLE PRECISION),
      --
      MEMBER FUNCTION SI_Score
      (SELF  IN SI_ColorHistogram ,
       image IN SI_StillImage)
      RETURN DOUBLE PRECISION DETERMINISTIC
) INSTANTIABLE
  NOT FINAL;
/

