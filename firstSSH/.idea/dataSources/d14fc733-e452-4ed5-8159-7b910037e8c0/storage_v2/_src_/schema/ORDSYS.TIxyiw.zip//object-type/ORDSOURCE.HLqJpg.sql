create TYPE ORDSource
                                                                      
authid current_user
AS OBJECT
(
-------------
-- Attributes
-------------

  -- storage for data within oracle. Every operation
  -- for the data stored in this field will be under
  -- the control of transaction within which the
  -- methods are called. This means that all the changes can
  -- either be commited or rolled back as desired by the
  -- user
  localData   BLOB,

  --
  -- srcType, srcLocation and srcName are limited to 4K
  -- due to system limitation on the size of varchar2 field
  --
  srcType     VARCHAR2(4000),
  srcLocation VARCHAR2(4000),
  srcName     VARCHAR2(4000),

  -- updateTime maintains the time when the users updated either
  -- source or the object containing the source last. This attribute
  -- is not updated when import is called, but importFrom updates
  -- this method since the source information is changed.
  --
  -- For recoding updates when the top level objevt changes, users
  -- must call set method at appropriate time.
  updateTime  DATE,

  -- 1 or NULL means data is in LOB
  -- 0 means that the data is in external sources
  local       NUMBER,
  --
----------
-- Methods
----------
  --
  -- METHODS RELATED TO 'local' FIELD
  MEMBER PROCEDURE setLocal(SELF IN OUT NOCOPY ORDSource),
  MEMBER PROCEDURE clearLocal(SELF IN OUT NOCOPY ORDSource),
  MEMBER FUNCTION  isLocal RETURN BOOLEAN,
  PRAGMA RESTRICT_REFERENCES(isLocal, WNDS, WNPS, RNDS, RNPS),
  --
  -- DATE RELATED METHODS
  MEMBER FUNCTION  getUpdateTime RETURN DATE,
  PRAGMA RESTRICT_REFERENCES(getUpdateTime, WNDS, WNPS, RNDS, RNPS),
  --
  MEMBER PROCEDURE setUpdateTime(SELF IN OUT NOCOPY ORDSource,
                                 current_time DATE),
  --
  -- SOURCE INFORMATION
  MEMBER PROCEDURE setSourceInformation(SELF IN OUT NOCOPY ORDSource,
                                        source_type   IN VARCHAR2,
                                        source_location IN VARCHAR2,
                                        source_name     IN VARCHAR2),
  MEMBER FUNCTION  getSourceInformation
                   RETURN VARCHAR2,
  PRAGMA RESTRICT_REFERENCES(getSourceInformation, WNDS, WNPS, RNDS, RNPS),
  --
  MEMBER FUNCTION  getSourceType RETURN VARCHAR2,
  PRAGMA RESTRICT_REFERENCES(getSourceType, WNDS, WNPS, RNDS, RNPS),
  --
  MEMBER FUNCTION  getSourceLocation RETURN VARCHAR2,
  PRAGMA RESTRICT_REFERENCES(getSourceLocation, WNDS, WNPS, RNDS, RNPS),
  --
  MEMBER FUNCTION  getSourceName RETURN VARCHAR2,
  PRAGMA RESTRICT_REFERENCES(getSourceName, WNDS, WNPS, RNDS, RNPS),
  --
  MEMBER FUNCTION  getBFile RETURN BFILE,
  PRAGMA RESTRICT_REFERENCES(getBFile, WNDS, WNPS, RNDS, RNPS),
  --
  -- SOURCE IMPORT/EXPORT OPERATIONS
  MEMBER PROCEDURE import(
                          SELF     IN OUT NOCOPY ORDSource,
                          ctx      IN OUT RAW,
                          mimetype OUT VARCHAR2,
                          format   OUT VARCHAR2),
  MEMBER PROCEDURE import(
                          SELF     IN OUT NOCOPY ORDSource,
                          ctx      IN OUT RAW,
                          dlob     IN OUT NOCOPY BLOB,
                          mimetype OUT VARCHAR2,
                          format   OUT VARCHAR2),
  MEMBER PROCEDURE importFrom( SELF            IN OUT NOCOPY ORDSource,
                               ctx             IN OUT RAW,
                               mimetype        OUT VARCHAR2,
                               format          OUT VARCHAR2,
                               source_type     IN VARCHAR2,
                               source_location IN VARCHAR2,
			       source_name     IN VARCHAR2),
  MEMBER PROCEDURE importFrom( SELF            IN OUT NOCOPY ORDSource,
                               ctx             IN OUT RAW,
                               dlob            IN OUT NOCOPY BLOB,
                               mimetype        OUT VARCHAR2,
                               format          OUT VARCHAR2,
                               source_type     IN VARCHAR2,
                               source_location IN VARCHAR2,
			       source_name     IN VARCHAR2),
  MEMBER PROCEDURE export(SELF            IN OUT NOCOPY ORDSource,
                          ctx             IN OUT RAW,
                          source_type     IN VARCHAR2,
                          source_location IN VARCHAR2,
                          source_name     IN VARCHAR2),
  --
  -- SOURCE CONTENT RELATED OPERATIONS
  MEMBER FUNCTION  getContentLength(ctx IN OUT RAW) RETURN INTEGER,
  --
  MEMBER FUNCTION  getSourceAddress(ctx IN OUT RAW,
                                    userData IN VARCHAR2) RETURN VARCHAR2,
  --
  MEMBER FUNCTION  getLocalContent RETURN BLOB,
  PRAGMA RESTRICT_REFERENCES(getLocalContent, WNDS, WNPS, RNDS, RNPS),
  --
  MEMBER PROCEDURE getContentInTempLob(
                                       SELF IN OUT NOCOPY ORDSource,
                                       ctx      IN OUT RAW,
                                       tempLob  IN OUT NOCOPY BLOB,
                                       mimetype OUT VARCHAR2,
                                       format   OUT  VARCHAR2,
                                       duration IN PLS_INTEGER := 10,
                                       cache    IN BOOLEAN := TRUE),
  MEMBER PROCEDURE deleteLocalContent,
  --
  -- SOURCE ACCESS METHODS
  MEMBER FUNCTION open(
                       SELF IN OUT NOCOPY ORDSource,
                       userArg IN RAW,
                       ctx OUT RAW) RETURN INTEGER,
  MEMBER FUNCTION close(
                       SELF IN OUT NOCOPY ORDSource,
                       ctx IN OUT RAW) RETURN INTEGER,
  MEMBER FUNCTION trim(SELF    IN OUT NOCOPY ORDSource,
                       ctx     IN OUT RAW,
                       newlen  IN INTEGER) RETURN INTEGER,
  --
  -- CONTENT READ/WRITE OPERATIONS
  MEMBER PROCEDURE read(SELF     IN OUT NOCOPY ORDSource,
                        ctx      IN OUT RAW,
                        startPos IN     INTEGER,
                        numBytes IN OUT INTEGER,
                        buffer   OUT    RAW),
  MEMBER PROCEDURE write(SELF IN OUT NOCOPY ORDSource,
                         ctx      IN OUT RAW,
                         startPos IN INTEGER,
                         numBytes IN OUT INTEGER,
                         buffer   IN RAW),
  --
  -- SEND OFF ANY COMMAND TO THE EXTERNAL SOURCE PLUGIN
  MEMBER FUNCTION processCommand(
                      SELF    IN OUT NOCOPY ORDSource,
                      ctx     IN OUT RAW,
                      command IN VARCHAR2,
                      arglist IN VARCHAR2,
                      result  OUT RAW) RETURN RAW
  --
);
/

