create function FUN_GETREG_VALUE(p_RegNumber    registers.reg_number%type,
                                           p_RegValCode   registers.reg_val_code%type)
                                          return varchar2 is
  v_RegValName   registers.reg_val_name%type;
  v_Count        integer;
begin
   select count(1) into v_Count from registers where reg_number=p_RegNumber and reg_val_code=p_RegValCode;
   if v_Count=1 then
      select reg_val_name into v_RegValName from registers where reg_number=p_RegNumber and reg_val_code=p_RegValCode;
   else
      v_RegValName:='';
   end if;
   return(v_RegValName);
end;
/

