create procedure prc_collect_element_pa_exnl(p_IdCredit cs_credit.id%type,p_externalCode varchar2,p_ReturnCode out varchar2) is
       -- Author  : MaJianFeng
       -- Create Date : 2018-06-06
       -- Purpose : put credit data into decision_element_data_pa_PA table;
       error_info                  varchar2(1000);     
       v_CommitTime                cs_credit.commit_time%type;
       v_InterCode                 cs_credit.inter_code%type;   
       v_CreditType                cs_credit.credit_type%type;   
       v_Seq                       decision_element_data_pa.sort_code%type;
       v_Count                     integer;
    begin
       delete decision_element_data_pa where id_credit=p_IdCredit and external_code=p_externalCode;
       
       select a.commit_time,a.credit_type
         into v_CommitTime,v_CreditType
         from cs_credit a where a.id=p_IdCredit;   

       v_Seq:=0;   
       
     --反欺诈-白骑士
     if p_externalCode = 'BaiqishiAntifraud' then  
          
          /*一个白骑士的元素FinalDecision  yangzhenxian  2019-03-18*/
          for d in (
              with temp as(
              select id_cerdit id_credit,final_decision from BAIQISHI_DECISION_RESULT p
               where p.id_cerdit=p_IdCredit order by p.create_time desc
               )
              select final_decision from temp where rownum=1
            )loop
              if d.final_decision is not null
              then
                
                insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                 values( p_IdCredit,'External','BaiQiShi','PaFinalDecision',d.final_decision,v_Seq+1,p_externalCode );
                 
                v_Seq:=v_Seq + 1;
                
              end if;
              
            end loop;
            
            /*在External---BaiQiShi 下新增元素StrategyName     yangzhenxian   2019-07-24*/
              for d in (
                select min(
                case when bqs2.STRATEGY_NAME='历史安装应用统计策略' then 1
                     when bqs2.STRATEGY_NAME='历史多头名单策略' then 2
                     when bqs2.STRATEGY_NAME='失信风险策略' then 3
                     when bqs2.STRATEGY_NAME='多头风险策略' and bqs4.NAME='总数' and bqs4.RULE_DETAIL_VALUE>20 then 4
                     when bqs2.STRATEGY_NAME='多头风险策略' and bqs4.NAME not in ('第三方支付','银行') then 5
                     when bqs2.STRATEGY_NAME='多头风险策略' then 6
                     when bqs2.STRATEGY_NAME='百度风险名单策略' then 7
                     when bqs2.STRATEGY_NAME='复杂关系网络策略' then 8
                     when bqs2.STRATEGY_NAME='历史复杂网络策略' then 9
                     when bqs2.STRATEGY_NAME='异常行为策略' then 10 else 99 end) as StrategyName
                FROM BAIQISHI_DECISION_RESULT bqs
                /*JOIN dafy_sales.cs_credit cc ON bqs.id_cerdit=cc.id*/
                LEFT JOIN BAIQISHI_DECISION_STRATEGY bqs2 ON bqs.id=bqs2.result_id
                LEFT JOIN BAIQISHI_DECISION_RULE bqs3 ON bqs2.id=bqs3.strategy_id
                LEFT JOIN BAIQISHI_DECISION_RULE_DETAIL bqs4 ON bqs3.id=bqs4.rule_id
                where bqs.ID_CERDIT=p_IdCredit
              )loop
              
                  insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                   values( p_IdCredit,'External','BaiQiShi','PaStrategyName',d.StrategyName,v_Seq+1,p_externalCode  );
                   
                  v_Seq:=v_Seq + 1;
                  
              end loop;	
        
       end if; 
       
     --贷前预审,复杂网络-实时风险群体分析-同盾
     if  p_externalCode = 'TongDunRiskService' then 
        for d in (
            select decode(count(1),0,0,1) FraudMetrixActive --是否查得同盾数据FraudMetrixActive (1, 查得; 0, 未查得)
            ,max(nvl(t.final_score,-1)) as final_score    --总分数
            from wfi_fraud_metrix_result t where t.event_name='Credit' and t.associated_id=p_IdCredit
          )loop
           insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
           values( p_IdCredit,'HardCheck','*','PaFraudMetrixActive',d.FraudMetrixActive,v_Seq+1,p_externalCode);             
           v_Seq:=v_Seq + 1; 
               
           insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
           values( p_IdCredit,'External','TongDun','PaFinalScore',d.final_score,v_Seq+1,p_externalCode);             
           v_Seq:=v_Seq + 1;                 
          end loop;      
         
       
         -- 过去半小时内同盾未查得合同数FraudMetrixFailedCount 2017/03/03 update
         insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
         select p_IdCredit,'HardCheck','*','PaFraudMetrixFailedCount',count(1),v_Seq,p_externalCode
         from cs_credit a where not exists(select 1 from wfi_fraud_metrix_result b
                                             where b.event_name='Credit'  and b.associated_id=a.id)
                           and a.status not in('r','t') and nvl(a.inter_code,0) not in(3,4)
                           and a.credit_type=decode(v_CreditType,'SC','SC','SS','SS','SP','SP','XF')
                           and a.create_time>=v_CommitTime-35/24/60 and a.create_time<=v_CommitTime-5/24/60;
                           
         v_Seq:=v_Seq + 1;
         
         --BlackListCateFraudMetrix:同盾黑名单分类
         insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
         select  p_IdCredit,'HardCheck','*','PaBlackListCateFraudMetrix',substr(max(case when rule_no in (
            840098,2900153,2901749,2992525,840072,891780,891784,2900089,840080,840116,2992509,2992523,2992511,2901741,840076,
            891788,2901719,2992521,891804,840106,2901711,2992507,840096,891814,2901715,11532,14130,840100,78586,891806,891824,891808,
            5638201,5640421,5640431,5640411) then '9失信名单'
            when rule_no in (840086,2901725,891794,891816,2901743,840108,840118,2901751,891826) then '8灰名单'
            when rule_no in (2900149,891792,2901723,840084,584894) then '7已结案名单'
            when rule_no in (2900083,2901761,2901759,891782,840074,2901713,840082,891790,891802,840094,891812,891832,891834,891836,
              2901731,891828,840120,891830,840122,11534,840104,840126,44126,15726,840124,840128) then '6低风险失信名单'
            else '0其他' end),2,10) BlackListCateFraudMetrix,v_Seq,p_externalCode
            from WFI_FRAUD_METRIX_RESULT a join WFI_FRAUD_METRIX_RULE t on a.id=t.fraud_metrix_result_id
            where a.event_name='Credit' and a.associated_id=p_IdCredit
            group by a.associated_id;
            
            v_Seq:=v_Seq + 1;
            
         --3个月内借款平台数MultiLoanTypeCountFraudMetrix3M: rule_name='新_3个月内申请人身份证或手机在多个平台申请借款'，从extra_data中取值
         select nvl(max(b.extra_data),0) into v_Count
         from WFI_FRAUD_METRIX_RESULT a
         join WFI_FRAUD_METRIX_RULE b on a.id=b.fraud_metrix_result_id
         where b.rule_no in(1044388,1053416)
               and a.event_name='Credit' and a.associated_id=p_IdCredit;

         insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                values(p_IdCredit,'HardCheck','*','PaMultiLoanTypeCountFraudMetrix3M',v_Count,v_Seq,p_externalCode);
                
         v_Seq:=v_Seq + 1;       
       
        --2018/05/29 majianfeng MultiLoanP2PCountFraudMetrix1M：近一个月命中同盾P2P网贷的次数元素代码
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
           SELECT p_IdCredit,'HardCheck','*','PaMultiLoanP2PCountFraudMetrix1M',nvl(
           (select MultiLoanP2PCountFraudMetrix1M from (SELECT a.ASSOCIATED_ID as id_credit,
               MAX(CASE WHEN INSTR(SUBSTR(RULE_DETAIL,instr(rule_detail, 'P2P网贷') + 6),',') > 0
               THEN SUBSTR(SUBSTR(RULE_DETAIL,instr(rule_detail, 'P2P网贷') + 6),1,instr(SUBSTR(RULE_DETAIL,instr(rule_detail, 'P2P网贷') + 6),',') - 1)
               ELSE SUBSTR(RULE_DETAIL, instr(rule_detail, 'P2P网贷') + 6, 3)END) AS MultiLoanP2PCountFraudMetrix1M
          from WFI_FRAUD_METRIX_RESULT a
          left join WFI_FRAUD_METRIX_RULE t
            on a.id = t.fraud_metrix_result_id
           where  a.ASSOCIATED_ID=p_IdCredit  and  A.EVENT_NAME = 'Credit'  AND T.RULE_NAME = '新_1个月内申请人身份证或手机在多个平台申请借款' and rule_detail like '%P2P网贷%'
           GROUP BY a.ASSOCIATED_ID) ), 0),v_Seq,p_externalCode
          from dual;
          
            --1天内借款平台数MultiLoanTypeCountFraudMetrix1D: majianfeng 2018/05/16
           select nvl(max(b.extra_data),0) into v_Count
           from WFI_FRAUD_METRIX_RESULT a
           join WFI_FRAUD_METRIX_RULE b on a.id=b.fraud_metrix_result_id
           where b.rule_no in(1049650,1053410)
                 and a.event_name='Credit' and a.associated_id=p_IdCredit;
           insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                  values(p_IdCredit,'HardCheck','*','PaMultiLoanTypeCountFraudMetrix1D',v_Count,v_Seq+1,p_externalCode);
                  
           v_Seq:=v_Seq + 1;
           
           --1个月内借款平台数MultiLoanTypeCountFraudMetrix1M: rule_name='新_1个月内申请人身份证或手机在多个平台申请借款'，从extra_data中取值
           select nvl(max(b.extra_data),0) into v_Count
           from WFI_FRAUD_METRIX_RESULT a
           join WFI_FRAUD_METRIX_RULE b on a.id=b.fraud_metrix_result_id
           where b.rule_no in(1044438,1053414)
                 and a.event_name='Credit' and a.associated_id=p_IdCredit;

           insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                  values(p_IdCredit,'HardCheck','*','PaMultiLoanTypeCountFraudMetrix1M',v_Count,v_Seq+1,p_externalCode);
                  
           v_Seq:=v_Seq + 1;
           
           v_Count:=0;
           
          --新_7天内申请人身份证或手机在多个平台申请借款   majianfeng 2018/07/23
           select nvl(max(b.extra_data),0) into v_Count
            from WFI_FRAUD_METRIX_RESULT a
             join WFI_FRAUD_METRIX_RULE b on a.id=b.fraud_metrix_result_id
              where b.rule_no in(1049606,1053412) and a.event_name='Credit' and a.associated_id=p_IdCredit;
              
           insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                  values(p_IdCredit,'HardCheck','*','PaMultiLoanTypeCountFraudMetrix7D',v_Count,v_Seq+1,p_externalCode);
                  
           v_Seq:=v_Seq + 1;
           
           v_Count:=0;
       
         /*  MultiLoanTypeCountSmallLoanCompanies1M(新_1个月内申请人身份证或手机在小额贷款公司申请借款)   yangzhenxian  2018-10-30   */
          for d in (
              WITH td_mul_detail_data AS
              (
              SELECT a.associated_id as id_credit,
                     CASE WHEN  instr(rule_detail, '小额贷款公司')>0 THEN
                          CASE WHEN INSTR(SUBSTR(RULE_DETAIL,instr(rule_detail, '小额贷款公司')+7),',')>0 THEN SUBSTR(SUBSTR(RULE_DETAIL,instr(rule_detail, '小额贷款公司')+7),1,INSTR(SUBSTR(RULE_DETAIL,instr(rule_detail, '小额贷款公司')+7), ',')-1)
                                                                                                         ELSE SUBSTR(RULE_DETAIL,instr(rule_detail, '小额贷款公司')+7,3) END
                          ELSE NULL END
                     AS Small_loan_companies_1M,
                     row_number() over(partition by a.associated_id,t.rule_name order by t.extra_data DESC,t.update_time DESC) as rank
              from WFI_FRAUD_METRIX_RESULT a
              join WFI_FRAUD_METRIX_RULE t on a.id=t.fraud_metrix_result_id
              where a.event_name='Credit' AND t.rule_no IN (22719304,1053414,2902207,16602803,1044438) and a.ASSOCIATED_ID=p_IdCredit
              )
              select * FROM td_mul_detail_data WHERE RANK=1
            )loop
            
            if d.Small_loan_companies_1M is not null then
              insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
               values( p_IdCredit,'HardCheck','*','PaMultiLoanTypeCountSmallLoanCompanies1M',d.Small_loan_companies_1M,v_Seq+1,p_externalCode );
               
              v_Seq:=v_Seq + 1;
              
            end if;
            
          end loop;
          
       -- 1个月内借款平台类型MultiLoanTypeFraudMetrix1M: rule_name='新_1个月内申请人身份证或手机在多个平台申请借款', 根据rule_detail计算取值；
       --计算时排除本平台（本平台类型为'一般消费分期平台')，当命中多个平台类型时，只取一个，
       --按以下顺序优先(小额贷款:MC,一般消费:CFC_NL,大型消费:CFC,P2P网贷:P2P,其他:Z)
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
       select p_IdCredit,'HardCheck','*','PaMultiLoanTypeFraudMetrix1M',
       case when replace(b.rule_detail,'一般消费分期平台:1','') like '%小额贷款%' then 'MC'
       when replace(b.rule_detail,'一般消费分期平台:1','') like '%一般消费分期平台%' then 'CFC_NL'
       when replace(b.rule_detail,'一般消费分期平台:1','') like '%消费金融%' then 'CFC'
       when replace(b.rule_detail,'一般消费分期平台:1','') like '%P2P%' then 'P2P'
       else 'Z' end,v_Seq+1,p_externalCode
       from WFI_FRAUD_METRIX_RESULT a
       join WFI_FRAUD_METRIX_RULE b on a.id=b.fraud_metrix_result_id
       where b.rule_no in(1044438,1053414)
             and a.event_name='Credit' and a.associated_id=p_IdCredit;
             
       --3个月内借款平台类型MultiLoanTypeFraudMetrix3M: rule_name='新_3个月内申请人身份证或手机在多个平台申请借款', 根据rule_detail计算取值；
       --计算时排除本平台（本平台类型为'一般消费分期平台')，当命中多个平台类型时，只取一个，
       --按以下顺序优先(小额贷款:MC,一般消费:CFC_NL,大型消费:CFC,P2P网贷:P2P,其他:Z)
       --b.rule_name in ('新_3个月内申请人身份证或手机在多个平台申请借款')
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
       select p_IdCredit,'HardCheck','*','PaMultiLoanTypeFraudMetrix3M',
       case when replace(b.rule_detail,'一般消费分期平台:1','') like '%小额贷款%' then 'MC'
       when replace(b.rule_detail,'一般消费分期平台:1','') like '%一般消费分期平台%' then 'CFC_NL'
       when replace(b.rule_detail,'一般消费分期平台:1','') like '%消费金融%' then 'CFC'
       when replace(b.rule_detail,'一般消费分期平台:1','') like '%P2P%' then 'P2P'
       when replace(b.rule_detail,'一般消费分期平台:1','') like '%财产保险%' then 'CX'
       when replace(b.rule_detail,'一般消费分期平台:1','') like '%理财机构%' then 'LO'
       when replace(b.rule_detail,'一般消费分期平台:1','') like '%互联网金融%' then 'TF'
       else 'Z' end,v_Seq+1,p_externalCode
       from WFI_FRAUD_METRIX_RESULT a
       join WFI_FRAUD_METRIX_RULE b on a.id=b.fraud_metrix_result_id
       where b.rule_no in(1044388,1053416)
             and a.event_name='Credit' and a.associated_id=p_IdCredit;
             
       --  ThirdService：第三方服务商  majianfeng 2018/07/23
       select  max(case when instr(rule_detail,'第三方服务商')>0 then 1 else 0 end ) into  v_Count   ----未命中，未查得则为0
        from WFI_FRAUD_METRIX_RESULT a
        left join WFI_FRAUD_METRIX_RULE t on a.id=t.fraud_metrix_result_id
        where a.event_name='Credit'  and a.associated_id=p_IdCredit;
        insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
              values(p_IdCredit,'HardCheck','*','PaThirdService',v_Count,v_Seq+1,p_externalCode);
              
       v_Seq:=v_Seq + 1;
       
       v_Count:=0;         
         
      /*External.TongDun.CorrelatedRisksScore：关联风险分
      External.TongDun.AttentListProportion：关注名单占比    yangzhenxian   2018-10-29*/
      for d in (
          select max(case when d.rule_name like'%复杂网络%' and detail_name='关联风险分' then to_number(detail_val) end )  correlated_risks_score
          ,max(case when d.rule_name like'%复杂网络%' and d.detail_name='关注名单占比' then to_number(substr(detail_val,1,instr(detail_val,'%',-1)-1)) end ) Attention_list_per
          from WFI_FRAUD_METRIX_RESULT a
          left join WFI_FRAUD_METRIX_RULE t on a.id=t.fraud_metrix_result_id
          left join wfi_fraud_metrix_rule_detail d  on t.id=d.rule_id
          where a.event_name='Credit' and a.ASSOCIATED_ID=p_IdCredit
        )loop
         if d.correlated_risks_score is not null then
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
           values( p_IdCredit,'External','TongDun','PaCorrelatedRisksScore',d.correlated_risks_score,v_Seq+1,p_externalCode );
          v_Seq:=v_Seq + 1;
          end if;

         if d.Attention_list_per is not null then
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
           values( p_IdCredit,'External','TongDun','PaAttentListProportion',d.Attention_list_per,v_Seq+1,p_externalCode );
           
          v_Seq:=v_Seq + 1;
          
          end if;
          
        end loop;
        
      /*External.TongDun.ComplexNetwork：复杂网络    yangzhenxian   2018-10-29*/
      for d in (
          select substr(max(case when rule_no=25561664 then '3_reject'--借款人身份证命中复杂网络_建议拒绝
                  when rule_no=25559994 then '2_uw'--借款人身份证命中复杂网络_建议人工审核
                  when rule_no=25559984  then '1_approve'--借款人身份证命中复杂网络_建议人工审核
                   end ),3,10)   Complex_Network
                 ,max(case when instr(t.rule_detail,'P2P网贷')>0 then 1 else 0 end) as is_P2P
          from WFI_FRAUD_METRIX_RESULT a
          left join WFI_FRAUD_METRIX_RULE t on a.id=t.fraud_metrix_result_id
          where a.event_name='Credit' and a.ASSOCIATED_ID=p_IdCredit
        )loop

         if d.Complex_Network is not null then
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
           values( p_IdCredit,'External','TongDun','PaComplexNetwork',d.Complex_Network,v_Seq+1,p_externalCode );
           
          v_Seq:=v_Seq + 1;
          
          end if;
                 
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
           values( p_IdCredit,'External','TongDun','PaP2pNetloan',d.is_P2P,v_Seq+1,p_externalCode );
                 
          v_Seq:=v_Seq + 1;
          
        end loop;
        
        /*External.TongDun.GelConPlatform7D：新_7天内申请人身份证或手机在多个平台申请借款    yangzhenxian   2019-01-23*/
         insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
         select p_IdCredit,'External','TongDun','PaGelConPlatform7D',
         nvl(MAX(CASE WHEN instr(RULE_DETAIL, '一般消费分期平台')>0
           THEN CASE WHEN INSTR(SUBSTR(RULE_DETAIL,instr(rule_detail, '一般消费分期平台')+9),',')>0
           THEN SUBSTR(SUBSTR(RULE_DETAIL,instr(rule_detail, '一般消费分期平台')+9),1,INSTR(SUBSTR(RULE_DETAIL,instr(rule_detail, '一般消费分期平台')+9), ',')-1)
           ELSE SUBSTR(RULE_DETAIL,instr(rule_detail, '一般消费分期平台')+9,3) END
           ELSE NULL END),-1)  --近7天申请人身份证或手机在多个平台申请借款次数（主要分为：一般消费平台，大型消费金融公司，小额贷款公司，P2P网贷）
           ,v_Seq+1,p_externalCode
         from WFI_FRAUD_METRIX_RESULT a
         join WFI_FRAUD_METRIX_RULE b on a.id=b.fraud_metrix_result_id
         where b.rule_no in(1049606,1053412)          --新_7天内申请人身份证或手机在多个平台申请借款
               and a.event_name='Credit' and a.associated_id=p_IdCredit;
             
          v_Seq:=v_Seq + 1;
          
           --2019/03/07 yangzhenxian MultiLoanP2PCountFraudMetrix3M：近三个月命中同盾P2P网贷的次数元素代码
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
           SELECT p_IdCredit,'External','TongDun','PaMultiLoanP2PCountFraudMetrix3M',nvl(
           (select MultiLoanP2PCountFraudMetrix3M from (SELECT a.ASSOCIATED_ID as id_credit
            ,MAX(CASE WHEN INSTR(SUBSTR(RULE_DETAIL,instr(rule_detail, 'P2P网贷') + 6),',') > 0
               THEN SUBSTR(SUBSTR(RULE_DETAIL,instr(rule_detail, 'P2P网贷') + 6),1,instr(SUBSTR(RULE_DETAIL,instr(rule_detail, 'P2P网贷') + 6),',') - 1)
               ELSE SUBSTR(RULE_DETAIL, instr(rule_detail, 'P2P网贷') + 6, 3)END) AS MultiLoanP2PCountFraudMetrix3M
            from WFI_FRAUD_METRIX_RESULT a
            left join WFI_FRAUD_METRIX_RULE t
            on a.id = t.fraud_metrix_result_id
            where  a.ASSOCIATED_ID=p_IdCredit and A.EVENT_NAME = 'Credit'  AND T.RULE_NO IN(1044388,1053416) and rule_detail like '%P2P网贷%'
            group by  a.ASSOCIATED_ID
            ) ), 0),v_Seq,p_externalCode
          from dual;

         v_Seq:=v_Seq + 1;   
        
         /*在External---Device 下新增设备指纹信息     hongbinbin   2019-09-04*/
        for d in (
            --ip share IP地址共享
            select count( b.ident) as IPCNT--IP地址历史共享次数
              ,sum(case when trunc(a.CREATE_TIME)=trunc(b.CREATE_TIME)  then 1 else 0 end) as IPCNT1day--IP地址1天共享次数
              ,sum(case when b.CREATE_TIME>=a.CREATE_TIME-7 then 1 else 0 end) as IPCNT7day--IP地址7天共享次数
              ,sum(case when b.CREATE_TIME>=a.CREATE_TIME-15 then 1 else 0 end) as IPCNT15day--IP地址15天共享次数
              ,sum(case when b.CREATE_TIME>=a.CREATE_TIME-30 then 1 else 0 end) as IPCNT30day--IP地址30天共享次数
              from TONGDUN_APPLY_INFOANALYSIS a
              left join TONGDUN_APPLY_INFOANALYSIS b on a.CREATE_TIME>b.CREATE_TIME and a.ident<>b.ident and a.IP_ADDRESS=b.IP_ADDRESS
              where a.id_credit=p_IdCredit
              group by a.ID_CREDIT
        )loop
        
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             values( p_IdCredit,'External','Device','PaIPCNT',d.IPCNT,v_Seq+1,p_externalCode);

            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             values( p_IdCredit,'External','Device','PaIPCNT1day',d.IPCNT1day,v_Seq+2,p_externalCode);

            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             values( p_IdCredit,'External','Device','PaIPCNT7day',d.IPCNT7day,v_Seq+3,p_externalCode);

            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             values( p_IdCredit,'External','Device','PaIPCNT15day',d.IPCNT15day,v_Seq+4,p_externalCode);

            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             values( p_IdCredit,'External','Device','PaIPCNT30day',d.IPCNT30day,v_Seq+5,p_externalCode);

            v_Seq:=v_Seq + 5;
            
        end loop;
        
        /*在External---Device 下新增设备指纹信息     hongbinbin   2019-09-04*/
        for d in (
            --net position 网络归属地
            select case when instr(g.position,'中国')>0 then '中国'
              when g.position='局域网' then '局域网'
              when g.position='保留地址' then '保留地址'
              when g.position='共享地址' then '共享地址'
              else '国外' end as NetPosition --网络归属地
              from TONGDUN_APPLY_INFOANALYSIS a
              join TONGDUN_APPLY_IN_GEOIP_INFO  g on a.id=g.MAIN_ID
              where a.id_credit=p_IdCredit
        )loop
        
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             values( p_IdCredit,'External','Device','PaNetPosition',d.NetPosition,v_Seq+1,p_externalCode);
             
            v_Seq:=v_Seq + 1;
            
        end loop;
       
       end if;
       
     --信贷保镖-同盾
     if p_externalCode = 'TongDun' then      
              /*同盾信贷保镖保存在External—TongDun里  yangzhenxian  2019-07-03*/
            for d in (
                with temp as(
                select min(case when risk_name='设备状态异常_高风险' then 1
                when risk_name='借款设备代理识别' then 2
                when risk_name='借款设备作弊工具识别' then 3
                when risk_name='借款设备越狱识别' then 4
                when risk_name='短时间移动距离位置异常' then 5
                when risk_name='3个月内申请人手机号作为联系人手机号出现的次数过多' then 6
                when risk_name in ('3个月内申请人身份证关联配偶手机数过多','3个月内申请人身份证关联父亲手机数过多') then 7
                when risk_name='1天内身份证使用过多设备进行申请' then 8
                when risk_name='敏感时间段申请1点至5点' then 9
                else 100 end) as RiskName
                from TONGDUN_APPLY_ANTIFRAUD an
                left join TONGDUN_APPLY_AF_RISK_ITEMS af on to_char(an.ID)=af.main_id and an.id_credit=p_IdCredit order by an.create_time desc
                 )
                select RiskName from temp where rownum=1
              )loop
              
                  insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                   values( p_IdCredit,'External','TongDun','PaRiskName',d.RiskName,v_Seq+1,p_externalCode );
                   
                  v_Seq:=v_Seq + 1;
                  
              end loop;
              
        end if;
       
     --手机在网时长
     if p_externalCode = 'MobileTelPeriod' then      
           
          /*在网时长元素需求MobileOnlineTime  yangzhenxian  2018-12-19*/
          for d in (
              with temp as(
              select p.id_credit,
                     case when p.period in ('(0,3]','[0,3)') then '(0,3)'
                          when p.period in ('(3,6]','[3,6)') then '(3,6)'
                          when p.period in ('(6,12]','[6,12)') then '(6,12)'
                          when p.period in ('(12,24]','[12,24)') then '(12,24)'
                          when p.period in ('(24,+)','[24,+)') then '(24,+)'
                          when p.period in ('T-1月前已离网','已离网或新入网用户') then '已离网'
                     else p.period end as period   --------为空时不生成该元素
              from mobile_online_period p
               where p.id_credit=p_IdCredit order by p.create_time desc
               )
              select period from temp where rownum=1
            )loop
            
              if d.period is not null
              then
                
                insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                 values( p_IdCredit,'HardCheck','*','PaMobileOnlineTime',d.period,v_Seq+1 ,p_externalCode);
                 
                v_Seq:=v_Seq + 1;
                
              end if;
              
            end loop;
            
     end if;
         
     --聚信立（蜜罐）
     if p_externalCode = 'Miguan' then  
         
         --蜜罐元素数据 2016/06/23 wangxiaofeng
       for mi in(select user_gray_score,contacts_one_blacklist_cnt,contacts_two_blacklist_cnt,
                  blacklist_category,user_register_cnt,iwop_susp_phone
                  from(
                  select nvl(a.user_gray_score,999) user_gray_score,nvl(a.contacts_one_blacklist_cnt,0) contacts_one_blacklist_cnt,
                  nvl(a.contacts_two_blacklist_cnt,0) contacts_two_blacklist_cnt,nvl(a.blacklist_category,'其他') blacklist_category,
                  nvl(a.user_register_cnt,0) user_register_cnt,decode(a.iwop_susp_phone,null,'否','是') iwop_susp_phone
                  from external_miguan_basic_info a
                  where a.create_time>=trunc(sysdate-1) 
                  and nvl(remark,'0') IN ('0','MIGUAN_SEARCH_SUCCESS[获取蜜罐查询成功]')
                  and a.id_credit=p_IdCredit order by user_id desc
                  ) where rownum=1)
       loop
         
         --用户黑中介评分
         insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
         values( p_IdCredit,'External','JuxinliMiguan','PaGrayScore',mi.user_gray_score,v_Seq + 1,p_externalCode);
         
         --一阶联系人黑名单人数
         insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
         values( p_IdCredit,'External','JuxinliMiguan','PaPhoneBlackCNTOne',mi.contacts_one_blacklist_cnt,v_Seq + 2,p_externalCode);
         
         --二阶联系人黑名单人数
         insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
         values( p_IdCredit,'External','JuxinliMiguan','PaPhoneBlackCNTTwo',mi.contacts_two_blacklist_cnt,v_Seq + 3,p_externalCode);
         
         --黑名单类型
         insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
         values( p_IdCredit,'External','JuxinliMiguan','PaBlackType',mi.blacklist_category,v_Seq + 4,p_externalCode);
         
         --注册机构个数
         insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
         values( p_IdCredit,'External','JuxinliMiguan','PaRegisterCNT',mi.user_register_cnt,v_Seq + 5,p_externalCode);
         
         --身份证是否组合过其他电话号码 返回结果为是否
         insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
         values( p_IdCredit,'External','JuxinliMiguan','PaSameIdentDiffPhone',nvl(mi.iwop_susp_phone,-1),v_Seq + 6,p_externalCode);
         
         v_Seq:=v_Seq + 7;
         
       end loop;
       
      -- /*蜜罐一介联系人总数*/ 2017/10/27 machaochun   增加元素External. JuxinliMiguan. ContactOneCNT
      insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
      select p_IdCredit,'External','JuxinliMiguan','PaContactOneCNT', nvl(t.contacts_class1_cnt,-1) ,v_Seq+1,p_externalCode
      from (select contacts_class1_cnt from EXTERNAL_MIGUAN_BASIC_INFO  
      where id_credit=p_IdCredit  and nvl(remark,'0') IN ('0','MIGUAN_SEARCH_SUCCESS[获取蜜罐查询成功]')
      order by create_time ) t where rownum=1;
      
      v_Seq:=v_Seq + 1;
      
      /*蜜罐是否查询成功*/
      insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
       select p_IdCredit,'External','JuxinliMiguan','PaIsMG',case when nvl(v_InterCode,'1') in('3','4') then 1 when IsMG >0 then 1 else 0 end,v_Seq+1,p_externalCode
       from (select count(1) IsMG from external_miguan_basic_info t where t.id_credit=p_IdCredit
       and (remark is null or remark='MIGUAN_SEARCH_SUCCESS[获取蜜罐查询成功]')) ;
       
      v_Seq:=v_Seq + 1;
      
      --钱包面签 HardCheck.SumApprovedSameFactory，客户所在工厂历史面签通过的合同数 2016/11/03 wangxiaofeng --
       ---------------聚信立授权是否成功  JxlGrant -------------------------by yangzhenxian 2017-08-30
       for ca in(select collected from
         (select collected from ca_collect where id_credit=p_IdCredit order by update_time desc) a where rownum=1)
       loop
         
         insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
          values( p_IdCredit,'External','JuxinliMiguan','PaJxlGrant',ca.collected,v_Seq + 1,p_externalCode);
          
          v_Seq:=v_Seq + 1;
          
        end loop;
     
        /*身份证在哪种机构类型出现     yangzhenxian   2019-07-03*/
        for d in (
          select min(case when IAIO_SUSP_ORG_TYPE ='线上信用现金贷' then '1线上信用现金贷'
          when IAIO_SUSP_ORG_TYPE ='线下信用现金贷' then '2线下信用现金贷'
          when IAIO_SUSP_ORG_TYPE ='线上信用卡代还' then '3线上信用卡代还'
          when IAIO_SUSP_ORG_TYPE ='线上租房分期' then '4线上租房分期' else IAIO_SUSP_ORG_TYPE end)as IaioSuspOrgType
          from external_miguan_basic_info m
          where m.id_credit=p_IdCredit
        )loop
        
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             values( p_IdCredit,'External','JuxinliMiguan','PaIaioSuspOrgType',d.IaioSuspOrgType,v_Seq+1,p_externalCode );
             
            v_Seq:=v_Seq + 1;
            
        end loop;
     
       end if;

     if p_externalCode = 'Intellicredit_Blacklist' then 
              
            --External.zhongzhicheng.ConfirmBlackList 中智城 客户命中中智诚黑名单 2018-05-09 majianfeng
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
              select p_IdCredit,'External','ZhongZhiCheng','PaConfirmBlackList',nvl(substr(max(case when qr.confirm_type='DLQ90plus' then '4overdue90+'
	             when qr.confirm_type='DLQX' then '3overduels'
                  when qr.confirm_type='fraud' then '2fraud'
                  else '0other'end ),2,10),'0other') as ConfirmBlackList,v_Seq+1,p_externalCode
              from external_intelli_bl_query bq
            left join external_intelli_bl_q_records qr on bq.id=qr.bl_q_id
            where bq.id_credit=p_IdCredit;
            
        end if; 

     if p_externalCode = 'Intellicredit_Antifraud' then 
          
           --External.ZhongZhiCheng.P2PMultiLoan   DiffMultiLoan  中智诚多次借贷情况 2019-01-23 yangzhenxian
            for c in(select max(case when INSTR(k.DESCRIPTION,'网贷机构')>0 then 1 else 0 end) as P2PMultiLoan --申请人在网贷机构出现过
                    ,max(case when INSTR(k.DESCRIPTION,'不同机构')>0 then 1 else 0 end) as DiffMultiLoan --申请人在不同机构出现过
                    FROM EXTERNAL_INTELLI_ANTIFRAUD h
                    left join EXTERNAL_INTELLI_AF_RULES k on k.ANTIFRAUD_ID=h.id
                    where h.id_credit=p_IdCredit
              )loop
              
                insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                  values(p_IdCredit,'External','ZhongZhiCheng','PaP2PMultiLoan',c.P2PMultiLoan,v_Seq+1,p_externalCode);
                  
                v_Seq:=v_Seq + 1;
                
                insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                  values(p_IdCredit,'External','ZhongZhiCheng','PaDiffMultiLoan',c.DiffMultiLoan,v_Seq+1,p_externalCode);
                  
                v_Seq:=v_Seq + 1;
                
              end loop;            
        end if; 
   
     if p_externalCode = 'FuShu' then  
            /*富数信用卡（主表）  yangzhenxian  2019-06-28*/
            for d in (
              select
              max(CARD_CREDIT_LINE/100)as CardLine--该银行下授信总额度
              ,max(CARD_CREDIT_LIMIT/100)as CardLimit --消费额度
              ,max(CARD_USABLE_CONSUME_LIMIT/100)as CardUsCsLimit--可用消费额度
              ,max(IS_OVERDUE)as Overdue--逾期用户
              from FS_BANK_CREDITS_BASIC a
              where id_credit=p_IdCredit
            )loop
            
                insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                 values( p_IdCredit,'External','FuShu','PaCardLine',d.CardLine,v_Seq+1,p_externalCode );
                 
                v_Seq:=v_Seq + 1;

                insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                 values( p_IdCredit,'External','FuShu','PaCardLimit',d.CardLimit,v_Seq+1,p_externalCode );
                 
                v_Seq:=v_Seq + 1;

                insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                 values( p_IdCredit,'External','FuShu','PaCardUsCsLimit',d.CardUsCsLimit,v_Seq+1,p_externalCode );
                 
                v_Seq:=v_Seq + 1;

                insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                 values( p_IdCredit,'External','FuShu','PaOverdue',d.Overdue,v_Seq+1,p_externalCode );
                 
                v_Seq:=v_Seq + 1;
                
            end loop;
        
             /*富数信用卡（主表）  yangzhenxian  2019-06-28*/
            for d in (
              with base as(
              select (case when id_credit is not null then 1 else 0 end) as IsCreditCard--是否信用卡客户
              from FS_BANK_CREDITS_BASIC cs where cs.id_credit=p_IdCredit
              )
              select * from base where rownum=1
            )loop
            
                insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                 values( p_IdCredit,'External','FuShu','PaIsCreditCard',d.IsCreditCard,v_Seq+1,p_externalCode );
                 
                v_Seq:=v_Seq + 1;
                
            end loop;
        
            /*富数网银-信用卡-近一年账单概况  yangzhenxian  2019-06-28*/
            for d in (
              select
              sum(TOTAL_OUTFLOW_TRADE_AMOUNT/100)as TotalOutTradeAmt--总消费金额
              ,sum(TOTAL_INFLOW_TRADE_AMOUNT/100)as TotalInTradeAmt--总还款金额
              from FS_BANK_CR_BILL_FLOW_STATS a
              where id_credit=p_IdCredit
            )loop
            
                insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                 values( p_IdCredit,'External','FuShu','PaTotalOutTradeAmt',d.TotalOutTradeAmt,v_Seq+1,p_externalCode );
                 
                v_Seq:=v_Seq + 1;

                insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                 values( p_IdCredit,'External','FuShu','PaTotalInTradeAmt',d.TotalInTradeAmt,v_Seq+1,p_externalCode );
                 
                v_Seq:=v_Seq + 1;
                
            end loop;
        
            /*富数网银-信用卡-流水概况  yangzhenxian  2019-06-28*/
            for d in (
              select
              max(case when AMOUNTS=12 then AMOUNT_AVERAGE_OUTFLOWS/100 else null end )as AmtAvgOutF12M--近12个月平均每笔消费额
              ,max(case when AMOUNTS=12 then AMOUNT_AVERAGEINFLOWS/100  else null end) as AmtAvgInF12M--近12个月平均每笔还款额
              from FS_BANK_CR_FLOW_STAT a
              where id_credit=p_IdCredit
            )loop
            
                insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                 values( p_IdCredit,'External','FuShu','PaAmtAvgOutF12M',d.AmtAvgOutF12M,v_Seq+1,p_externalCode );
                 
                v_Seq:=v_Seq + 1;

                insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                 values( p_IdCredit,'External','FuShu','PaAmtAvgInF12M',d.AmtAvgInF12M,v_Seq+1,p_externalCode );
                 
                v_Seq:=v_Seq + 1;
                
            end loop;
        
            /*富数网银-信用卡-已出账单流水概况  yangzhenxian  2019-06-28*/
            for d in (
              select
              sum(REPAY_FLOWS_AMOUNT/100) as TotalRepayFlowAmt--总实际还款金额
              ,max(MAX_TRADE_AMOUNT/100)as MaxTradeAmt--最大消费金额
              from FS_BANK_CR_READY_BILL_FLOWS a
              where id_credit=p_IdCredit
            )loop
            
                insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                 values( p_IdCredit,'External','FuShu','PaTotalRepayFlowAmt',d.TotalRepayFlowAmt,v_Seq+1,p_externalCode );
                 
                v_Seq:=v_Seq + 1;

                insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                 values( p_IdCredit,'External','FuShu','PaMaxTradeAmt',d.MaxTradeAmt,v_Seq+1,p_externalCode );
                 
                v_Seq:=v_Seq + 1;
                
            end loop;
            
             /*富数运营商：基础数据表    yangzhenxian   2019-07-03*/
            for d in (
              select
              max(FRIEND_CNT_3M)as FriendCnt3M--近3月朋友联系数量
              ,max(best_friend_cnt_3m)as BestFriendCnt3M---近3月好朋友联系数量（联系10次以上）
              ,max(friend_cnt_6m)as FriendCnt6M--近6月朋友联系数量
              ,max(best_friend_cnt_6m)as BestFriendCnt6M---近6月好朋友联系数量（联系10次以上）
              ,max(interphone_cnt_3m)as InterPhoneCnt3M--近3月互通电话号码数目
              ,max(interphone_cnt_6m)as InterPhoneCnt6M--近6月互通电话号码数目
              from fs_telecom_basic
              where id_credit=p_IdCredit
            )loop
            
                insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                 values( p_IdCredit,'External','FuShu','PaFriendCnt3M',d.FriendCnt3M,v_Seq+1,p_externalCode );
                 
                v_Seq:=v_Seq + 1;

                insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                 values( p_IdCredit,'External','FuShu','PaBestFriendCnt3M',d.BestFriendCnt3M,v_Seq+1,p_externalCode );
                 
                v_Seq:=v_Seq + 1;

                insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                 values( p_IdCredit,'External','FuShu','PaFriendCnt6M',d.FriendCnt6M,v_Seq+1,p_externalCode );
                 
                v_Seq:=v_Seq + 1;

                insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                 values( p_IdCredit,'External','FuShu','PaBestFriendCnt6M',d.BestFriendCnt6M,v_Seq+1,p_externalCode );
                 
                v_Seq:=v_Seq + 1;

                insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                 values( p_IdCredit,'External','FuShu','PaInterPhoneCnt3M',d.InterPhoneCnt3M,v_Seq+1,p_externalCode );
                 
                v_Seq:=v_Seq + 1;

                insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                 values( p_IdCredit,'External','FuShu','PaInterPhoneCnt6M',d.InterPhoneCnt6M,v_Seq+1,p_externalCode );
                 
                v_Seq:=v_Seq + 1;
                
            end loop;
        
            /*富数运营商：通话详详单分析    yangzhenxian   2019-07-03*/
            for d in (
              select count(distinct fc.phone)as ContactCount---联系人手机号在通话详单个数
              from  cs_contact cs
              left join FS_TELECOM_FREQUENT_CALLS fc  on cs.id_credit=fc.id_credit and cs.CONTACT_VALUE=fc.phone
              where cs.person_type != '1' and cs.id_credit=p_IdCredit
            )loop
            
                insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                 values( p_IdCredit,'External','FuShu','PaContactCount',d.ContactCount,v_Seq+1,p_externalCode );
                 
                v_Seq:=v_Seq + 1;
                
            end loop;
        
            /*富数运营商：通话详详单分析    yangzhenxian   2019-07-03*/
            for d in (
              select count(distinct m.opposite)as Top3mCount---联系人手机号在联系人top3个数
              from cs_contact cs
              left join FS_TELECOM_TOP3_3M m on cs.id_credit=m.id_credit and cs.CONTACT_VALUE=m.opposite
              where cs.person_type != '1' and cs.id_credit=p_IdCredit
            )loop
            
                insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                 values( p_IdCredit,'External','FuShu','PaTop3mCount',d.Top3mCount,v_Seq+1,p_externalCode );
                 
                v_Seq:=v_Seq + 1;
                
            end loop;
            
            /*富数运营商：通话活跃     yangzhenxian   2019-07-03*/
            for d in (
              select max(case when PERIOD='1个月' then non_call_rate END)as NonCallRate1M--近一个月无通话天数占比
              ,max(case when PERIOD='1个月' then TOTAL_COUNT end)as TotalCount1M--近一个月通话次数
              ,max(case when PERIOD='1个月' then calling_num end)as CallingNum1M--近一个月主叫通话次数
              ,max(case when PERIOD='1个月' then call_number end)as CallNum1M--近一个月通话号码数
              ,max(case when PERIOD='3个月' then call_number end)as CallNum3M--近一个月通话号码数
              ,max(case when PERIOD='3个月' then interphone_rate end)as InterphoneRate--近一个月互通号码数占比
              ,max(case when PERIOD='1个月' then call_time end)as CallTimet1M--近一个月通话时长
              ,max(case when PERIOD='1个月' then CALLING_TIME end)as CallingTimet1M--近一个月主叫通话时长
              ,max(case when PERIOD='1个月' then call_active_day end)as CallActiveDay1M--近一个月通话活跃天数
              ,max(case when PERIOD='1个月' then morning_count end)as MorningCount1M--近一个月凌晨(0:00-6:00)通话次数
              from FS_TELECOM_PHONALYZR a
              where id_credit=p_IdCredit
            )loop
            
                insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                 values( p_IdCredit,'External','FuShu','PaNonCallRate1M',d.NonCallRate1M,v_Seq+1,p_externalCode );
                 
                v_Seq:=v_Seq + 1;

                insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                 values( p_IdCredit,'External','FuShu','PaTotalCount1M',d.TotalCount1M,v_Seq+1,p_externalCode );
                 
                v_Seq:=v_Seq + 1;

                insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                 values( p_IdCredit,'External','FuShu','PaCallingNum1M',d.CallingNum1M,v_Seq+1,p_externalCode );
                 
                v_Seq:=v_Seq + 1;

                insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                 values( p_IdCredit,'External','FuShu','PaCallNum1M',d.CallNum1M,v_Seq+1,p_externalCode );
                 
                v_Seq:=v_Seq + 1;

                insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                 values( p_IdCredit,'External','FuShu','PaCallNum3M',d.CallNum3M,v_Seq+1,p_externalCode );
                 
                v_Seq:=v_Seq + 1;

                insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                 values( p_IdCredit,'External','FuShu','PaInterphoneRate',d.InterphoneRate,v_Seq+1,p_externalCode );
                 
                v_Seq:=v_Seq + 1;

                insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                 values( p_IdCredit,'External','FuShu','PaCallTimet1M',d.CallTimet1M,v_Seq+1,p_externalCode );
                 
                v_Seq:=v_Seq + 1;

                insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                 values( p_IdCredit,'External','FuShu','PaCallingTimet1M',d.CallingTimet1M,v_Seq+1,p_externalCode );
                 
                v_Seq:=v_Seq + 1;

                insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                 values( p_IdCredit,'External','FuShu','PaCallActiveDay1M',d.CallActiveDay1M,v_Seq+1,p_externalCode );
                 
                v_Seq:=v_Seq + 1;

                insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                 values( p_IdCredit,'External','FuShu','PaMorningCount1M',d.MorningCount1M,v_Seq+1,p_externalCode );
                 
                v_Seq:=v_Seq + 1;
                
            end loop;
      
            /*富数运营商：用户位置分布     yangzhenxian  2019-07-03*/
            for d in (
                select min(rank) as CityRank--申请城市通话排名
                from (select id_credit,city,row_number()over(partition by id_credit order by days*1 desc)as rank from FS_TELECOM_POSITION) a
                join cs_address ca on a.id_credit=ca.ID_CREDIT  and ca.ADDRESS_TYPE=2 and replace(ca.CITY,'市','')=replace(a.CITY,'市','')
                where ca.id_credit=p_IdCredit
              )loop
              
                  insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                   values( p_IdCredit,'External','FuShu','PaCityRank',d.CityRank,v_Seq+1,p_externalCode );
                   
                  v_Seq:=v_Seq + 1;
                  
              end loop;
      
              /*富数运营商：账单数据     yangzhenxian  2019-07-03*/
              for d in (
                  select min(a.pay_amount/100) as MinPayAmount --过去三个月最小账单金额
                  from FS_TELECOM_BILL_ANALYSIS a
                  where  to_date(month||'01','yyyy-mm-dd')>=add_months(trunc(sysdate,'mm'),-3) and id_credit=p_IdCredit
                )loop
                
                    insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                     values( p_IdCredit,'External','FuShu','PaMinPayAmount',d.MinPayAmount,v_Seq+1,p_externalCode );
                     
                    v_Seq:=v_Seq + 1;
                    
                end loop;
        
                /*富数运营商：通话详详单分析     yangzhenxian    2019-07-03*/
                for d in (
                  select max(nvl(call_count_l3m,0)) as FriendCallCountL3m--2个联系人中任意1人近3月最大联系次数
                  ,max(nvl(call_count_l6m,0)) as FriendCallCountL6m--2个联系人中任意1人近6月最大联系次数
                  ,min(case when person_type in ('F','M','P')and  a.ID_CREDIT is null then 0 else call_count_l6m *1 end) as ParentCallCountL6m--父母近6个月最小联系次数
                  from cs_contact cc
                  left join FS_TELECOM_FREQUENT_CALLS  a on a.ID_CREDIT=cc.id_credit and cc.CONTACT_VALUE=a.phone
                  where  cc.CONTACT_TYPE=2 and person_type<>'1' and cc.id_credit=p_IdCredit
                )loop
                
                    insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                     values( p_IdCredit,'External','FuShu','PaFriendCallCountL3m',d.FriendCallCountL3m,v_Seq+1,p_externalCode );
                     
                    v_Seq:=v_Seq + 1;
                    
                    insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                     values( p_IdCredit,'External','FuShu','PaFriendCallCountL6m',d.FriendCallCountL6m,v_Seq+1,p_externalCode );
                     
                    v_Seq:=v_Seq + 1;
                    
                    insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                     values( p_IdCredit,'External','FuShu','PaParentCallCountL6m',d.ParentCallCountL6m,v_Seq+1,p_externalCode );
                     
                    v_Seq:=v_Seq + 1;
                    
                end loop;
                
        end if;
      
     if p_externalCode = 'HuiMao' then           
   
            --在元素类比External下面添加元素子类=HuiMao，元素名称FlagOverDue(是否命中逾期平台数据)
            for d in (
                with temp as(
                select sum(case when c2.QUERY_REPORT_ID is not null then 1 when c1.order_no is not null then 0 else null end) as FlagOverDue,
                min(case when instr(c2.map_key,'DAY30')>0 then '1'
                    when instr(c2.map_key,'DAY60')>0 then '2'
                    when instr(c2.map_key,'DAY90')>0 then '3'
                    when instr(c2.map_key,'DAY180')>0 then '4'
                    when instr(c2.map_key,'DAY365')>0 then '5'
                    when instr(c2.map_key,'HISTORY')>0 then '6'
                    else null end) OverDueLineCate
                from GREYCAT_APPLY_REPORT c
                left join GREYCAT_QUERY_REPORT c1 on c.order_no=c1.order_no
                left join GREYCAT_OVERDUE_DETAIL c2 on c1.id=c2.QUERY_REPORT_ID
                where c.id_credit=p_IdCredit)
                select * from temp where FlagOverDue is not null
              )loop
              
                insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                 values( p_IdCredit,'External','HuiMao','PaFlagOverDue',case when d.FlagOverDue>1 then 1 else d.FlagOverDue end,v_Seq+1,p_externalCode );
                 
                v_Seq:=v_Seq + 1;
        
                ---OverDueLineCate：客户逾期情况  yangzhenxian  2018-03-28
                if d.OverDueLineCate is not null
                  then
                    
                  insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                   values( p_IdCredit,'External','HuiMao','PaOverDueLineCate',d.OverDueLineCate,v_Seq+1,p_externalCode );
                   
                  v_Seq:=v_Seq + 1;
                  
                  end if;
                  
                end loop;
        
            --在元素类比External下面添加元素子类=HuiMao，元素名称FlagApply(是否命中申请平台数据)
            for d in (
                  with temp as(
                  select sum(case when c2.QUERY_REPORT_ID is not null then 1 when c1.order_no is not null then 0 else null end) as FlagApply
                  from GREYCAT_APPLY_REPORT c
                  left join GREYCAT_QUERY_REPORT c1 on c.order_no=c1.order_no
                  left join GREYCAT_APPLY_LOAN_DETAIL c2 on c1.id=c2.QUERY_REPORT_ID
                  where c.id_credit=p_IdCredit)
                  select * from temp where FlagApply is not null
                )loop
                
                  insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                   values( p_IdCredit,'External','HuiMao','PaFlagApply',case when d.FlagApply>1 then 1 else d.FlagApply end,v_Seq+1,p_externalCode );
                   
                  v_Seq:=v_Seq + 1;
                
                end loop;
        
            --在元素类比External下面添加元素子类=HuiMao，元素名称FlagPay(是否命中还款平台数据)
            for d in (
                with temp as(
                select sum(case when c2.QUERY_REPORT_ID is not null then 1 when c1.order_no is not null then 0 else null end) as FlagPay
                from GREYCAT_APPLY_REPORT c
                left join GREYCAT_QUERY_REPORT c1 on c.order_no=c1.order_no
                left join GREYCAT_APPLY_LOAN_DETAIL c2 on c1.id=c2.QUERY_REPORT_ID and c2.apply_sum_money='0.00'
                where c.id_credit=p_IdCredit)
                select * from temp where FlagPay is not null
              )loop
                  
                insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                 values( p_IdCredit,'External','HuiMao','PaFlagPay',case when d.FlagPay>1 then 1 else d.FlagPay end,v_Seq+1,p_externalCode );
                     
                v_Seq:=v_Seq + 1;
                  
              end loop;
        
            --在元素类比External下面添加元素子类=HuiMao，元素名称Score(灰猫评分)
            for d in (
                with temp as(
                select c1.score
                from GREYCAT_APPLY_REPORT c
                join GREYCAT_QUERY_REPORT c1 on c.ORDER_NO=c1.ORDER_NO
                where c.id_credit=p_IdCredit order by c1.create_time desc)
                select * from temp where rownum=1
              )loop
                  
                insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                 values( p_IdCredit,'External','HuiMao','PaScore',d.Score,v_Seq+1,p_externalCode );
                     
                v_Seq:=v_Seq + 1;
                  
              end loop;
        end if;

     --挖财风控系统
     if p_externalCode = 'WacaiRisk' then 
           
          /*挖财审批结果及额度  yangzhenxian  2019-07-15*/
          for d in (
              with temp as(
              select VERDICT as FinalDecision--挖财审批结果
              ,CREDIT_AMOUNT/100 as Limit--挖财最高额度
              ,RISK_LEVEL as RiskLevel--挖财风险等级
              from  WACAI_RISK_MANAGEMENT a
              where id_credit=p_IdCredit order by a.create_time desc
               )
              select * from temp where rownum=1
            )loop
              
                insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                 values( p_IdCredit,'External','WaCai','PaFinalDecision',d.FinalDecision,v_Seq+1,p_externalCode );
                   
                v_Seq:=v_Seq + 1;

                insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                 values( p_IdCredit,'External','WaCai','PaLimit',d.Limit,v_Seq+1,p_externalCode );
                   
                v_Seq:=v_Seq + 1;

                insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                 values( p_IdCredit,'External','WaCai','PaRiskLevel',d.RiskLevel,v_Seq+1,p_externalCode );
                   
                v_Seq:=v_Seq + 1;
                  
              end loop;
         end if;

     --百融打包（打包1+2）
     if p_externalCode = 'BaiRongPack' or p_externalCode = 'BaiRongPack1' or p_externalCode = 'BaiRongPack2' then    
              
             for d in (
                select * from (select t.flag_stability_c,STAB_AUTH_NAME from external_br_stability_c t
               where t.id_credit=p_IdCredit order by t.create_time desc) where rownum=1
              )loop
              
              -------3.增加元素External. BaiRong. FlagStability/*特殊名单核查产品输出标识*/
              insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
               values( p_IdCredit,'External','BaiRong','PaFlagStability',d.flag_stability_c,v_Seq+1,p_externalCode );
               
              v_Seq:=v_Seq + 1;

              -------增加元素External. BaiRong. AuthName  百融稳定性库中姓名是否匹配  2018-04-18 yangzhenxian
              insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
               values( p_IdCredit,'External','BaiRong','PaAuthName',nvl(d.stab_auth_name,-1),v_Seq+1,p_externalCode );
               
              v_Seq:=v_Seq + 1;
              
            end loop;
    
             /*过去半个小时内百融多次借贷未查得合同数BRApplyLoanFailedCount           yangzhenxian   2018/04/27 add      2019/01/22  update*/
             insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             select p_IdCredit,'External','BaiRong','PaBRApplyLoanFailedCount',count(1),v_Seq+1,p_externalCode
             from cs_credit a where not exists(select 1 from external_br_applyloan b
                                                 where b.code<>9999 and b.id_credit=a.id)
                               and a.status not in('r','t') and nvl(a.inter_code,0) not in(3,4)
                               and a.credit_type=decode(v_CreditType,'SC','SC','SS','SS','XF','XF','SP')
                               and a.commit_time>=v_CommitTime-35/24/60 and a.commit_time<=v_CommitTime-5/24/60;
                               
             v_Seq:=v_Seq + 1;
       
            --BRCreditcardDef3M: 最近3个月信用卡是否逾期
            select count(1) into v_Count
            from external_br_accountchangemonth t
            where t.acm_m1_credit_def is not null and t.acm_m2_credit_def is not null
             and t.acm_m3_credit_def is not null and t.id_credit=p_IdCredit;
            if v_Count>=1 then
              
              --BRCreditcardDef3M: 最近3个月信用卡是否逾期
              insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
              select p_IdCredit,'External','BaiRong','PaBRCreditcardDef3M',
              nvl(t.acm_m1_credit_def,0)+nvl(t.acm_m2_credit_def,0)+nvl(t.acm_m3_credit_def,0),v_Seq+1,p_externalCode
              from external_br_accountchangemonth t where t.id_credit=p_IdCredit;
              
              v_Seq:=v_Seq + 1;
              
            end if;
      
            --BRMultiLoanCountNotBank12M: 最近12个月身份证或手机在非银行借款次数，排除本机构，取ident_notbank,mobilephone_notbank的较大值
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
            select p_IdCredit,'External','BaiRong','PaBRMultiLoanCountNotBank12M',
            case when (nvl(t1.al_m12_id_notbank_allnum,0)-nvl(t1.al_m12_id_notbank_selfnum,0))-
            (nvl(t1.al_m12_cell_notbank_allnum,0)-nvl(t1.al_m12_cell_notbank_selfnum,0))>0 then
            (nvl(t1.al_m12_id_notbank_allnum,0)-nvl(t1.al_m12_id_notbank_selfnum,0)) else
            (nvl(t1.al_m12_cell_notbank_allnum,0)-nvl(t1.al_m12_cell_notbank_selfnum,0)) end,
            v_Seq+1,p_externalCode
            from external_br_applyloan t1 where t1.id_credit=p_IdCredit;
            
            v_Seq:=v_Seq + 1;
      
            --BRMultiLoanCountBank12M: 最近12个月身份证或手机在银行借款次数，取ident_bank,mobilephone_bank较大值
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
            select p_IdCredit,'External','BaiRong','PaBRMultiLoanCountBank12M',
            case when nvl(t1.al_m12_id_bank_allnum,0)-nvl(t1.al_m12_cell_bank_allnum,0)>0 then
            nvl(t1.al_m12_id_bank_allnum,0) else
            nvl(t1.al_m12_cell_bank_allnum,0) end,
            v_Seq+1,p_externalCode
            from external_br_applyloan t1 where t1.id_credit=p_IdCredit;
            
            v_Seq:=v_Seq + 1;
            
            --百融评分 External. BaiRong. BRScore 2016/11/03 wangxiaofeng --
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
              select p_IdCredit,'External','BaiRong','PaBRScore',t.scoreconsoffv2,v_Seq+1,p_externalCode
              from external_br_rules t
              where t.scoreconsoffv2 is not null and t.id_credit=p_IdCredit;
              
              v_Seq:=v_Seq + 1;
      
            --BRScorecardActive: 是否命中百融评分卡(1,命中; 0,未命中)，满足以下条件之一即命中
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
            select p_IdCredit,'External','BaiRong','PaBRScorecardActive',decode(count(1),0,0,1),v_Seq+1,p_externalCode
            from external_br_accountchangemonth t2
            join external_br_applyloan t1 on t1.id_credit=t2.id_credit
            where ((nvl(t1.al_m12_id_notbank_allnum,0)-nvl(t1.al_m12_id_notbank_selfnum,0)>0
                 or nvl(t1.al_m12_cell_notbank_allnum,0)-nvl(t1.al_m12_cell_notbank_selfnum,0)>0
                 or nvl(t1.al_m12_id_bank_allnum,0)>0 or nvl(t1.al_m12_cell_bank_allnum,0)>0
                 or nvl(t2.flag_accountchangemonth,0)=1))
                 and t2.id_credit=p_IdCredit;
                 
            v_Seq:=v_Seq + 1;

            --------------------按身份证号查询，近12个月在非银机构-消费类分期申请机构数 yangzhenxian   2017-12-06    
           insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             select p_IdCredit,'External','BaiRong','PaIdentNBank12M',IdentNBank12M,v_Seq+1,p_externalCode
             from (select t.ALS_M12_ID_NBANK_CF_ORGNUM IdentNBank12M from external_br_applyloan t
             where t.id_credit=p_IdCredit order by t.create_time desc) where rownum=1 ;
               
            v_Seq:=v_Seq + 1;

            --------------------按身份证号查询，近12个月在非银机构-消费类分期申请机构数 yangzhenxian   2017-12-06
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             select p_IdCredit,'External','BaiRong','PaIdentNBank1M',IdentNBank1M,v_Seq+1,p_externalCode
             from (select t.ALS_M1_ID_NBANK_CF_ORGNUM IdentNBank1M from external_br_applyloan t
             where t.id_credit=p_IdCredit order by t.create_time desc) where rownum=1 ;
               
            v_Seq:=v_Seq + 1;    

            --------------------按身份证号查询，近6个月在非银机构-其他申请次数 yangzhenxian   2017-12-06
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             select p_IdCredit,'External','BaiRong','PaIdentNBank6M',IdentNBank6M,v_Seq+1,p_externalCode
             from (select t.ALS_M6_ID_NBANK_OTH_ALLNUM IdentNBank6M from external_br_applyloan t
             where t.id_credit=p_IdCredit order by t.create_time desc) where rownum=1 ;
               
            v_Seq:=v_Seq + 1;

           -------begin 2017/11/02 machaochun-----
          for d in (
              select * from (select ID_CREDIT,nvl(t.als_lst_id_nbank_inteday,0) IdentNBankIteDay
              ,nvl(t.ALS_M12_CELL_NBANK_AVG_MONNUM,0) MobileApplyCountNotBank12M ,nvl(t.AL_M12_ID_NOTBANK_ORGNUM,0) IdentNBankORG12M,nvl(t.ALS_M6_CELL_NBANK_OTH_ORGNUM,0) BRCellNBankORG6M
              from external_br_applyloan t
             where t.id_credit=p_IdCredit order by t.create_time desc) where rownum=1
            )loop
            -------1.增加元素External. BaiRong. IdentNBankIteDay/*按身份证号查询，距最近在非银行机构申请的间隔天数*/
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             values( p_IdCredit,'External','BaiRong','PaIdentNBankIteDay',d.IdentNBankIteDay,v_Seq+1,p_externalCode );
               
            v_Seq:=v_Seq + 1;
              
            -------2.  External.BaiRong. MobileApplyCountNotBank12M：按手机号查询，近12个月在非银机构平均每月申请次数 (可参考External.BaiRong.IdentNBankIteDay)
            -------2019-03-07 yangzhenxian
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             values( p_IdCredit,'External','BaiRong','PaMobileApplyCountNotBank12M',d.MobileApplyCountNotBank12M,v_Seq+1,p_externalCode );
               
            v_Seq:=v_Seq + 1;
              
            -------外部数据库--百融--- IdentNBankORG12M  近12个月在非银机构平台数
            -------2019-04-02 yangzhenxian
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             values( p_IdCredit,'External','BaiRong','PaIdentNBankORG12M',nvl(d.IdentNBankORG12M,-1),v_Seq+1,p_externalCode );
               
            v_Seq:=v_Seq + 1;
              
            -------2019-08-22 yangzhenxian
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             values( p_IdCredit,'External','BaiRong','PaBRCellNBankORG6M',d.BRCellNBankORG6M,v_Seq+1,p_externalCode );
               
            v_Seq:=v_Seq + 1;
              
          end loop;
    
          --------------------近6个月身份证在百融非银合作机构申请机构数 yangzhenxian   2017-12-21
          for d in (
              with temp as(
              select t.AL_M6_ID_NOTBANK_ORGNUM as IdentNBankORG6M from external_br_applyloan t
              where t.id_credit=p_IdCredit order by t.create_time desc)
              select  IdentNBankORG6M from temp where rownum=1
            )loop
            
              insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
               values( p_IdCredit,'External','BaiRong','PaIdentNBankORG6M',d.IdentNBankORG6M,v_Seq+1,p_externalCode );
               
              v_Seq:=v_Seq + 1;
            
            end loop;
        
           --------------------身份证关联的手机号个数 yangzhenxian   2017-12-06
            for d in(
              with temp as(select t.IR_ID_X_CELL_CNT IdentRelateCell,t.IR_ID_IS_REABNORMAL as IsIdentAbnormal
              ,t.IR_M3_CELL_X_BIZ_ADDR_CNT as MobRelateAddr3M ,t.IR_CELL_X_ID_CNT as MobRelateIdCnt,t.IR_M6_CELL_X_BIZ_ADDR_CNT MobRelateAddr6M
              from external_br_inforelation t where t.id_credit=p_IdCredit order by t.create_time desc)
                select * from temp where rownum=1
              )
            loop
              
              insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
               values(p_IdCredit,'External','BaiRong','PaIdentRelateCell',d.IdentRelateCell,v_Seq+1,p_externalCode);
               
              v_Seq:=v_Seq + 1;

              ------------------身份证号是否关联异常 yangzhenxian    2018-01-15
              insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
               values(p_IdCredit,'External','BaiRong','PaIsIdentAbnormal',d.IsIdentAbnormal,v_Seq+1,p_externalCode);
               
              v_Seq:=v_Seq + 1;

              ------------------MobRelateAddr3M:近三个月手机号关联公司地址个数 yangzhenxian    2018-03-23
              insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
               values(p_IdCredit,'External','BaiRong','PaMobRelateAddr3M',d.MobRelateAddr3M,v_Seq+1,p_externalCode);
               
              v_Seq:=v_Seq + 1;
              
              ------------------MobRelateAddr6M:近六个月手机号关联公司地址个数 马剑锋    2018-05-31
               insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
               values(p_IdCredit,'External','BaiRong','PaMobRelateAddr6M',d.MobRelateAddr6M,v_Seq+1,p_externalCode);
               
              v_Seq:=v_Seq + 1;

              ------------------MobRelateIdCnt：手机号关联身份证个数 yangzhenxian    2018-03-23
              if d.MobRelateIdCnt is not null
              then
                
                insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                 values(p_IdCredit,'External','BaiRong','PaMobRelateIdCnt',d.MobRelateIdCnt,v_Seq+1,p_externalCode);
                 
                v_Seq:=v_Seq + 1;
                
              end if;
              
            end loop;
      
            ------------------------外部数据是否查询正常  yangzhenxian  2018-02-06
            /*表external_br_applyloan是否正常*/
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             select p_IdCredit,'External','BaiRong','PaIsApplyLoan',case when nvl(v_InterCode,'1') in('3','4') then 1 when IsApplyLoan >0 then 1 else 0 end,v_Seq+1,p_externalCode
             from (select count(1) IsApplyLoan from external_br_applyloan t where t.id_credit=p_IdCredit) ;
             
            v_Seq:=v_Seq + 1;
            
            /*表external_br_speciallist_c是否正常*/
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             select p_IdCredit,'External','BaiRong','PaIsSpecialList',case when nvl(v_InterCode,'1') in('3','4') then 1 when IsSpecialList>0 then 1 else 0 end,v_Seq+1,p_externalCode
             from (select count(1) IsSpecialList from external_br_speciallist_c t where t.id_credit=p_IdCredit) ;
             
            v_Seq:=v_Seq + 1;
      
            /*表external_br_stability_c是否正常*/
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             select p_IdCredit,'External','BaiRong','PaIsStability',case when nvl(v_InterCode,'1') in('3','4') then 1 when IsStability >0 then 1 else 0 end,v_Seq+1,p_externalCode
             from (select count(1) IsStability from external_br_stability_c t where t.id_credit=p_IdCredit) ;
             
            v_Seq:=v_Seq + 1;
            
            /*表external_br_inforelation是否正常*/
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             select p_IdCredit,'External','BaiRong','PaIsInforelation',case when nvl(v_InterCode,'1') in('3','4') then 1 when IsInforelation >0 then 1 else 0 end,v_Seq+1,p_externalCode
             from (select count(1) IsInforelation from external_br_inforelation t where t.id_credit=p_IdCredit) ;
             
            v_Seq:=v_Seq + 1;
      
            /*表external_br_consumption_c是否正常*/
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             select p_IdCredit,'External','BaiRong','PaIsConsumption',case when nvl(v_InterCode,'1') in('3','4') then 1 when IsConsumption >0 then 1 else 0 end,v_Seq+1,p_externalCode
             from (select count(1) IsConsumption from external_br_consumption_c t where t.id_credit=p_IdCredit) ;
             
            v_Seq:=v_Seq + 1;
            
            /*百融表是否查询成功*/
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             select p_IdCredit,'External','BaiRong','PaIsBr',case when nvl(v_InterCode,'1') in('3','4') then 1 when is_applyloan>0 and is_speciallist>0 and is_stability>0 and is_inforelation>0
             and is_pay_behavior>0 and is_consumption_c>0 then 1 else 0 end,v_Seq+1,p_externalCode
             from (
                  select
                  (select count(1)  from external_br_applyloan where id_credit=p_IdCredit ) is_applyloan,
                  (select count(1)  from external_br_speciallist_c where id_credit=p_IdCredit ) is_speciallist,
                  (select count(1)  from external_br_stability_c where id_credit=p_IdCredit ) is_stability,
                  (select count(1)  from external_br_inforelation where id_credit=p_IdCredit ) is_inforelation,
                  (select count(1)  from external_br_pay_behavior where id_credit=p_IdCredit ) is_pay_behavior,
                  (select count(1)  from external_br_consumption_c where id_credit=p_IdCredit ) is_consumption_c
                  from dual
             ) ;
             
            v_Seq:=v_Seq + 1;
      
            --------------------商品消费模块最近12个月最大单类目消费次数 yangzhenxian   2017-12-21
            for d in (
                with temp as(
                select t.CONS_MAX_M12_NUM as MaxPayCate12M from external_br_consumption_c t
                where t.id_credit=p_IdCredit order by t.create_time desc)
                select  MaxPayCate12M from temp where rownum=1
              )loop
                
                insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                 values( p_IdCredit,'External','BaiRong','PaMaxPayCate12M',d.MaxPayCate12M,v_Seq+1,p_externalCode );
                 
                v_Seq:=v_Seq + 1;
                
              end loop;
        
            --------------------近3个月最大单类目消费金额的类目 yangzhenxian   2017-12-06
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             select p_IdCredit,'External','BaiRong','PaMaxPayCate3M',MaxPayCate3M,v_Seq+1,p_externalCode
             from (select t.CONS_MAX_M3_PAYCATE MaxPayCate3M from external_br_consumption_c t
             where t.id_credit=p_IdCredit order by t.create_time desc) where rownum=1 ;
             
            v_Seq:=v_Seq + 1;

      
            -------4.增加元素External. BaiRong. MobChangeIteDay/*身份证关联的手机号最近一次变动距今天数*/
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
               select ID_CREDIT,'External','BaiRong','PaMobChangeIteDay',nvl(ir_id_x_cell_lastchg_days,0),v_Seq+1,p_externalCode
               from (select ID_CREDIT,t.ir_id_x_cell_lastchg_days from external_br_inforelation t
               where t.id_credit=p_IdCredit order by t.create_time desc) where rownum=1 ;
               
            v_Seq:=v_Seq + 1;
      
            /*近12月手机号关联邮箱个数MobRelateMail12M  yangzhenxian  2019-03-18*/
            for d in (
                with temp as(
                select IR_M12_CELL_X_MAIL_CNT as MobRelateMail12M from external_br_inforelation p
                 where p.id_credit=p_IdCredit order by p.create_time desc
                 )
                select MobRelateMail12M from temp where rownum=1
              )loop
              
                if d.MobRelateMail12M is not null
                then
                  
                  insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                   values( p_IdCredit,'External','BaiRong','PaMobRelateMail12M',d.MobRelateMail12M,v_Seq+1,p_externalCode );
                   
                  v_Seq:=v_Seq + 1;
                  
                end if;
                
              end loop;
    
              --------2019/08/22  yangzhenxian----
              for d in (
                  select * from (select ID_CREDIT,t.pc_user_level BRPcUserLevel from external_br_personalcre t
                 where t.id_credit=p_IdCredit order by t.create_time desc) where rownum=1
                )loop
                
                  insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                   values( p_IdCredit,'External','BaiRong','PaBRPcUserLevel',d.BRPcUserLevel,v_Seq+1,p_externalCode );
                   
                  v_Seq:=v_Seq + 1;
                
              end loop;
               /*在External---BaiRong FlagSpecialCate     hongbinbin    2019-09-04*/
                  for d in (
                       select max(case when decode(a.sl_cell_bank_refuse,null,0,1)+decode(a.sl_cell_nbank_cf_refuse,null,0,1)+decode(a.sl_cell_bank_fraud,null,0,1)+decode(a.sl_id_nbank_p2p_bad,null,0,1)>0 then '1HighRisk'
                                    when decode(a.sl_id_nbank_p2p_bad,null,0,1)+decode(a.sl_cell_nbank_p2p_bad,null,0,1)+decode(a.sl_id_nbank_cf_bad,null,0,1)+decode(a.sl_cell_p2p_bad,null,0,1)>0 then '2MediumRisk'
                                    when a.FLAG_SPECIALLIST_C ='1' then '3FlagRisk' else '9Normal' end )as FlagSpecialCate  ---旧版特殊名单核查分类
                      from cs_credit cc
                      left join external_br_speciallist_c  a on a.ID_CREDIT=cc.ID
                      where cc.id=p_IdCredit
                  )loop
                  
                      insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                       values( p_IdCredit,'External','BaiRong','PaFlagSpecialCate',d.FlagSpecialCate,v_Seq+1,p_externalCode);
                       
                      v_Seq:=v_Seq + 1;
                      
                  end loop;
        
                /*在External---BaiRong  FlagSpeciallistNew、FlagSpecialCateNew     hongbinbin   2019-09-04*/
                for d in (
                    select a.FLAG_SPECIALLIST_C as FlagSpeciallistNew,---新版特殊名单核查产品输出标识
                            max(case when decode(a.SL_CELL_BANK_FRAUD_TIME,null,0,1)+decode(a.SL_LM_CELL_BANK_BAD_ALLNUM,null,0,1)+decode(a.SL_CELL_BANK_FRAUD,null,0,1)+decode(a.SL_CELL_BANK_FRAUD_ALLNUM,null,0,1)+decode(a.SL_LM_CELL_BANK_BAD,null,0,1) >0 then  '1BankRisk'
                              when decode(a.SL_ID_NBANK_FINLEA_BAD,null,0,1)+decode(a.SL_ID_NBANK_FINLEA_BAD_TIME,null,0,1)+decode(a.SL_ID_NBANK_FINLEA_BAD_ALLNUM,null,0,1)+decode(a.SL_CELL_NBANK_FINLEA_BAD,null,0,1)+decode(a.SL_CELL_NBANK_FINLEA_BAD_TIME,null,0,1)+decode(a.SL_CELL_NBANK_FI_BAD_ALLNUM,null,0,1) >0 then  '2FinleaRisk'
                              when decode(a.SL_ID_NBANK_NSLOAN_BAD,null,0,1)+decode(a.SL_ID_NBANK_NSLOAN_BAD_ALLNUM,null,0,1)+decode(a.SL_CELL_NBANK_SLOAN_BAD,null,0,1)+decode(a.SL_CELL_NBANK_SLOAN_BAD_ALLNUM,null,0,1)+decode(a.SL_ID_NBANK_NSLOAN_BAD_TIME,null,0,1) >0 then  '3XiaodaiRisk'
                              when decode(a.SL_CELL_NBANK_OTHER_BAD_ALLNUM,null,0,1)+decode(a.SL_CELL_NBANK_OTHER_BAD,null,0,1) >0 then  '4OtherRisk'
                              when decode(a.SL_ID_NBANK_AU_OVERDUE_TIME,null,0,1)+decode(a.SL_ID_NBANK_AUTOFIN_OVERDUE,null,0,1)+decode(a.SL_ID_NBANK_AU_OVERDUE_ALLNUM,null,0,1) >0 then  '5AutofinRisk'
                              when decode(a.SL_CELL_NBANK_BAD_ALLNUM,null,0,1)+decode(a.SL_ID_BAD_INFO_TIME,null,0,1)+decode(a.SL_LM_CELL_NBANK_OTHER_BAD,null,0,1) >0 then  '6GeneralRisk'
                              when a.FLAG_SPECIALLIST_C ='1' then '7FlagRisk' else '9Normal' end )as FlagSpecialCateNew  --新版特殊名单核查分类
                        from cs_credit cc
                        left join external_br_speciallist_v2  a on a.ID_CREDIT=cc.ID
                        where cc.id=p_IdCredit
                        group by  cc.id, a.FLAG_SPECIALLIST_C
                )loop
                  
                    insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                     values( p_IdCredit,'External','BaiRong','PaFlagSpeciallistNew',d.FlagSpeciallistNew,v_Seq+1,p_externalCode);

                    insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                     values( p_IdCredit,'External','BaiRong','PaFlagSpecialCateNew',d.FlagSpecialCateNew,v_Seq+2,p_externalCode);

                    v_Seq:=v_Seq + 2;
                      
                end loop;
                
           --hongbinbin 20191011
            for d in(
                select 
                  to_number(nvl(ALS_M6_ID_NBANK_OTH_ORGNUM,-1)) as IdentNBankOthORG6M 
                  from cs_credit b
                  left join External_Br_Stability_c  sta on sta.ID_CREDIT = b.id --稳定性评估
                  left join External_Br_Applyloan ap on ap.ID_CREDIT = b.id    --多次申请核查    --多头
                  where b.COMMIT_TIME>date'2019-09-01' and b.id=p_IdCredit
                )loop
                
                 --按身份证号查询，近6个月在非银机构-其他申请机构数 
                 insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                  values(p_IdCredit,'External','BaiRong','PaIdentNBankOthORG6M',d.IdentNBankOthORG6M,v_Seq+1);            
                 
                 v_Seq:=v_Seq + 1; 
                
            end loop;   

         end if;
   
      --百融特殊名单
      if p_externalCode = 'BaiRongSpecialist' then 
          
             -------2.增加元素External. BaiRong. FlagSpeciallist/*稳定性评估产品输出标识*/
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             select ID_CREDIT,'External','BaiRong','PaFlagSpeciallist',flag_speciallist_c,v_Seq+1,p_externalCode
             from (select ID_CREDIT,t.flag_speciallist_c from external_br_speciallist_c t
             where t.id_credit=p_IdCredit order by t.create_time desc) where rownum=1 ;
             
            v_Seq:=v_Seq + 1;
            
        end if;
      
      --百融支付行为
      if p_externalCode = 'BaiRongPaybehavior' then 
        
         /*表external_br_pay_behavior是否正常*/
        insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
         select p_IdCredit,'External','BaiRong','PaIsBehavior',case when nvl(v_InterCode,'1') in('3','4') then 1 when IsBehavior >0 then 1 else 0 end,v_Seq+1,p_externalCode
         from (select count(1) IsBehavior from external_br_pay_behavior t where t.id_credit=p_IdCredit) ;
         
         v_Seq:=v_Seq + 1;
        
        for d in (
              select * from (select ID_CREDIT,t.MON_12_VAR1 RecentYearDeal, RFM_12_VAR1 BRDealAmount12M,
                          FLAG_PAYBEHAVIOR as PayBehavior,SUMMARY_SCORE as SummaryScore,MCC_3_VAR1 AS MCCCnt3M,
                          RFM_6_VAR3 AS LargestConsAmt6M,FLAG_6_VAR4 AS FlagOnline6M 
              from external_br_pay_behavior t
             where t.id_credit=p_IdCredit order by t.create_time desc) where rownum=1
            )loop
            --------2017/11/29  machaochun----
            --------1.增加元素External. BaiRong. RecentYearDeal /*近十二个月发生交易月份数*/
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             values( p_IdCredit,'External','BaiRong','PaRecentYearDeal',d.RecentYearDeal,v_Seq+1,p_externalCode );
             
            v_Seq:=v_Seq + 1;

            -------增加元素External. BaiRong. BRDealAmount12M  2019-08-22 yangzhenxian
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             values( p_IdCredit,'External','BaiRong','PaBRDealAmount12M',d.BRDealAmount12M,v_Seq+1,p_externalCode );
             
            v_Seq:=v_Seq + 1;            
            
            --hongbinbin 20190924
             --支付消费行为偏好产品计费标识
             insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                    values( p_IdCredit,'External','BaiRong','PaPayBehavior',d.PayBehavior,v_Seq+1,p_externalCode); 
                    
             --消费综合评分
             insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                    values( p_IdCredit,'External','BaiRong','PaSummaryScore',d.SummaryScore,v_Seq+2,p_externalCode); 
                    
             --近3个月发生交易的MCC种类数
             insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                    values( p_IdCredit,'External','BaiRong','PaMCCCnt3M',d.MCCCnt3M,v_Seq+3,p_externalCode); 
                    
             --交易代码是消费类且近6个月最大的消费金额
             insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                    values( p_IdCredit,'External','BaiRong','PaLargestConsAmt6M',d.LargestConsAmt6M,v_Seq+4,p_externalCode); 
                    
             --近6个月线上消费标志
             insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                    values( p_IdCredit,'External','BaiRong','PaFlagOnline6M',d.FlagOnline6M,v_Seq+5,p_externalCode); 
                
             v_Seq:=v_Seq + 5;
             
          end loop;
        
      end if;
      
      if p_externalCode = 'QiakeRisk' then   
          
           /*全量客户经过洽客系统，把洽客作为第三方征信保存在External—QiaKe里  yangzhenxian  2019-07-04*/
          for d in (
              with temp as(
              select case when CREDIT_RESULT is null or CREDIT_RESULT='U' then 'Fail' else CREDIT_RESULT end as CreditResult --洽客订单的状态，如果洽客处理失败则返回Fail值。
              ,FINAL_DECISION as FinalDecision --洽客最终决策结果
              ,POS_LOAN_LIMIT as Limit--洽客授信额度
              ,CUSTOMER_RISK_LEVEL as RiskLevel --洽客客户风险等级
              ,SYNTHETIC_SCORE as Score         --洽客分数
              from QIAKE_RISK_MANAGEMENT 
              where id_credit=p_IdCredit
               )
              select * from temp where rownum=1
            )loop
            
                insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                 values( p_IdCredit,'External','QiaKe','PaCreditResult',d.CreditResult,v_Seq+1,p_externalCode );                 
                v_Seq:=v_Seq + 1;
                
                insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                 values( p_IdCredit,'External','QiaKe','PaFinalDecision',d.FinalDecision,v_Seq+1,p_externalCode );                 
                v_Seq:=v_Seq + 1;
                
                insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                 values( p_IdCredit,'External','QiaKe','PaLimit',d.Limit,v_Seq+1,p_externalCode );                 
                v_Seq:=v_Seq + 1;
                
                insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                 values( p_IdCredit,'External','QiaKe','PaRiskLevel',d.RiskLevel,v_Seq+1,p_externalCode );                 
                v_Seq:=v_Seq + 1;
                  
                insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                 values( p_IdCredit,'External','QiaKe','PaScore',d.Score,v_Seq+1,p_externalCode );                   
                v_Seq:=v_Seq + 1;
                
            end loop;
        
        end if;           
    
       --人脸比对接口
       if p_externalCode = 'IdentVerify' then        
        
           --爰金人脸识别分数      IdentVerifyYuanjin
           insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
           select p_IdCredit,'External','*','PaIdentVerifyYuanjin',max(case when v.ID_CREDIT is null then 999  when v.score is null and v.remark like'图片质量不合格%' then 888  else nvl(v.SCORE,-1) end),v_Seq+1,p_externalCode
           from cs_credit c left join liveness_ident_verify v on c.id=v.ID_CREDIT  and v.SUPPLIER_CODE='YUANJIN' where c.id=p_IdCredit;           
           v_Seq:=v_Seq + 1;

          
           --商汤人脸识别分数      IdentVerifyShangtang
           insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
           select p_IdCredit,'External','*','PaIdentVerifyShangtang',max(case when v.ID_CREDIT is null then 999 when v.score is null and v.remark like'图片质量不合格%' then 888  else nvl(v.SCORE,-1) end),v_Seq+1,p_externalCode
           from cs_credit c left join liveness_ident_verify v on c.id=v.ID_CREDIT  and v.SUPPLIER_CODE='SHANGTANG' where c.id=p_IdCredit;           
           v_Seq:=v_Seq + 1;
          
           --face人脸识别分数      IdentVerifyFace
           insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
           select p_IdCredit,'External','*','PaIdentVerifyFace',max(case when v.ID_CREDIT is null then 999 when v.score is null and v.remark like'图片质量不合格%' then 888 else nvl(v.SCORE,-1) end),v_Seq+1,p_externalCode
           from cs_credit c left join liveness_ident_verify v on c.id=v.ID_CREDIT  and v.SUPPLIER_CODE='FACEID' where c.id=p_IdCredit;           
           v_Seq:=v_Seq + 1;
           
           --腾讯云人脸识别分数      IdentVerifyTX
           insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
           select p_IdCredit,'External','*','PaIdentVerifyTX',max(case when v.ID_CREDIT is null then 999  else nvl(v.SCORE,-1) end),v_Seq+1,p_externalCode
           from cs_credit c left join liveness_ident_verify v on c.id=v.ID_CREDIT  and v.SUPPLIER_CODE='TX.IMGVERIFY' where c.id=p_IdCredit;                     
           v_Seq:=v_Seq + 1;
          
           --人脸识别分数汇总     IdentVerifyScore
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
            select p_IdCredit,'External','*','PaIdentVerifyScore',max(case when v.ID_CREDIT is null then 999 when v.score is null and v.remark like'图片质量不合格%' then 888   else nvl(v.SCORE,-1) end),v_Seq+1,p_externalCode
            from cs_credit c left join liveness_ident_verify v on c.id=v.ID_CREDIT   where c.id=p_IdCredit;
            
            v_Seq:=v_Seq + 1;

          end if;
          
       --聚信立（蜜罐）
       if p_externalCode = 'Miguan' then  
             
         for d in (
           select max(CONTACTS_ROUTER_CNT)as ContactByTwoCNT--引起二阶黑名单人数
           ,max(PAIO_SUSP_ORG_TYPE) as NameOGRType --电话号码在那种机构类型中出现该姓名最近一次出现机构类型名称
           ,max(GRAY_CNS_CNT_TO_APPLIED) as GrayCnsCntAppl--主动联系人中曾为申请人的人数
           ,max(BLACKLIST_NAME_WITH_IDCARD) as BlackListNameCard--姓名+身份证是否在黑名单中1:是；0：否
            from external_miguan_basic_info v where v.id_credit=p_IdCredit
         )loop
             
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             values( p_IdCredit,'External','JuxinliMiguan','PaContactByTwoCNT',d.ContactByTwoCNT,v_Seq+1,p_externalCode );
                 
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             values( p_IdCredit,'External','JuxinliMiguan','PaNameOGRType',d.NameOGRType,v_Seq+1,p_externalCode );
                 
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             values( p_IdCredit,'External','JuxinliMiguan','PaGrayCnsCntAppl',d.GrayCnsCntAppl,v_Seq+1,p_externalCode );
                        
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             values( p_IdCredit,'External','JuxinliMiguan','PaBlackListNameCard',d.BlackListNameCard,v_Seq+1,p_externalCode );
                          
             v_Seq:=v_Seq + 4;
                
         end loop;
         
         for d in (
             select * from (
              select to_number(SEARCH_BY_M_24_PCT_CNT_ORG_ALL ) as SearchOrgInAllCntRate24M
              ,USER_PHONE_CITY as UserPhoneCity
              ,row_number()over(partition by cc.id order by m.create_time desc) as rnk
              from cs_credit cc 
              left join external_miguan_basic_info m ON m.id_credit=cc.id
              where cc.id=p_IdCredit
              )where rnk=1
           )loop
           
              --蜜罐24个月内查询机构数在总体查询分布中的百分位
              insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values( p_IdCredit,'External','JuxinliMiguan','PaSearchOrgInAllCntRate24M',d.SearchOrgInAllCntRate24M,v_Seq+1 );
               
              --手机号归属地城市
              insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values( p_IdCredit,'External','JuxinliMiguan','PaUserPhoneCity',d.UserPhoneCity,v_Seq+1 );
               
              v_Seq:=v_Seq + 2;
              
           end loop;  
           
       end if;

       --贷前预审,复杂网络-实时风险群体分析-同盾
       if p_externalCode = 'TongDunRiskService' then 
           /*External.TongDun.MultiLoanMCCountFraudMetrix3M：同盾最近三个月小额贷款次数 */
          for d in (
              select max(case when t.rule_name='新_3个月内申请人身份证或手机在多个平台申请借款' and instr(t.rule_detail,'小额贷款公司')>0
                              then to_number(regexp_substr(substr(t.RULE_DETAIL,instr(t.rule_detail,'小额贷款公司') + 7,3),'[0-9]+')) else 0 end)
                     as MultiLoanMCCountFraudMetrix3M---同盾最近三个月小额贷款次数
              from WFI_FRAUD_METRIX_RESULT a
              left join WFI_FRAUD_METRIX_RULE t on a.id=t.fraud_metrix_result_id
              where a.event_name='Credit' and a.update_time>=date'2018-01-01' and a.ASSOCIATED_ID=p_IdCredit
            )loop
                
              insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
               values( p_IdCredit,'External','TongDun','PaMultiLoanMCCountFraudMetrix3M',d.MultiLoanMCCountFraudMetrix3M,v_Seq+1,p_externalCode );
                   
              v_Seq:=v_Seq + 1;
                  
            end loop;
            
          for d in (
            select max(case when r.DETAIL_NAME='二度关联节点个数' then to_number(r.DETAIL_VAL) else 0 end) as RiskTwoCount --同盾复杂网络二度关联节点个数
                   ,max(case when r.DETAIL_NAME='风险群体的节点分布' and instr(r.DETAIL_VAL,'设备ID')>0 then 1 else 0 end) as RiskGroupSheBei--同盾复杂网络设备节点分布
            from WFI_FRAUD_METRIX_RESULT a
            left join WFI_FRAUD_METRIX_RULE t on a.id=t.fraud_metrix_result_id
            left join wfi_fraud_metrix_rule_detail r on t.id=r.RULE_ID and r.rule_name like '%复杂网络%'
            where a.event_name='Credit' and a.update_time>=date'2018-01-01' and a.ASSOCIATED_ID=p_IdCredit
          )loop
              
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             values( p_IdCredit,'External','TongDun','PaRiskTwoCount',d.RiskTwoCount,v_Seq+1,p_externalCode );
                 
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             values( p_IdCredit,'External','TongDun','PaRiskGroupSheBei',d.RiskGroupSheBei,v_Seq+1,p_externalCode );
                 
            v_Seq:=v_Seq + 2;
                
          end loop;
          
          for d in(
              select max(case when r.DETAIL_NAME='一度关联节点个数' then to_number(r.DETAIL_VAL) else 0 end) as RiskOneCount
              ,max(case when instr(t.rule_detail,'小额贷款公司')>0 then 1 else 0 end) as IsMc 
              from cs_credit b
              join WFI_FRAUD_METRIX_RESULT a on b.id =a.ASSOCIATED_ID
              left join WFI_FRAUD_METRIX_RULE t on a.id=t.fraud_metrix_result_id  
              left join wfi_fraud_metrix_rule_detail r on t.id=r.RULE_ID and instr(r.RULE_NAME,'复杂网络')>0
              where a.event_name='Credit' and a.update_time>=date'2018-12-01' and b.id=p_IdCredit
              group by b.id
          )
          loop
            
             --同盾复杂网络一度关联节点个数
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values(p_IdCredit,'External','TongDun','PaRiskOneCount',d.RiskOneCount,v_Seq+1);                                      
            v_Seq:=v_Seq + 1;         
            
            --是否命中小额贷款公司     
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
               values(p_IdCredit,'External','TongDun','PaIsMc',d.IsMc,v_Seq+1,p_externalCode);                              
            v_Seq:=v_Seq + 1;         
            
          end loop;
            
        end if;
        
       --探针A黑名单-新颜
       if p_externalCode = 'XinYanBlackList' then   
                    
             --新颜探针A黑名单建议      BlackListSuggest
             insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             select p_IdCredit,'External','XinYan','PaBlackListSuggest',max(result_code),v_Seq+1,p_externalCode
             from XINYAN_PROBEA_BLACKLIST v where v.id_credit=p_IdCredit;
             
             v_Seq:=v_Seq + 1;
              
          end if;

       --探针B白名单-新颜
       if p_externalCode = 'XinYanWhiteList' then      
             
           --新颜探针B白名单建议      WhiteListSuggest
           insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
           select p_IdCredit,'External','XinYan','PaWhiteListSuggest',max(result_code),v_Seq+1,p_externalCode
           from XINYAN_PROBEB_WHITELIST v where v.id_credit=p_IdCredit;
           
         -- v_Seq:=v_Seq + 1;
         
         end if;
       
       if p_externalCode = 'Antifraud' or p_externalCode='ALL'  then           
        /*在External. Ronghui下添加元素RonghuiAntifraudScore:  yangzhenxian  2019-12-31*/      
        for d in (
            with temp as(
              select to_number(score) as RonghuijinkeScore from ronghui_antifraud r where r.id_credit = p_IdCredit order by r.create_time desc
             )
            select RonghuijinkeScore from temp where rownum=1
          )loop              
              insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
               values( p_IdCredit,'External','Ronghui','PaRonghuiAntifraudScore',d.RonghuijinkeScore,v_Seq+1,p_externalCode );                           
               v_Seq:=v_Seq + 1;
                    
            end loop;            
        end if;

       --以上元素，如果值为空则删除（与终审保持一致）  yangzhenxian    2019-06-18
       delete decision_element_data_pa where id_credit=p_IdCredit and element_value is null;

       commit;

       p_ReturnCode:='A';
       return;
    exception
       When others Then
         error_info := sqlerrm;
         p_ReturnCode:='Z-'||error_info||DBMS_UTILITY.format_error_backtrace;
         rollback;
    end;
/

