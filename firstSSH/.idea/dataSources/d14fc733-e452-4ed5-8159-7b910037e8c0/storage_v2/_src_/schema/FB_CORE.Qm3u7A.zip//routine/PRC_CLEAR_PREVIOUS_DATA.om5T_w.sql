create procedure PRC_CLEAR_PREVIOUS_DATA
       -- Author  : 马超春
       -- Create Date : 2017-11-21
       -- Purpose : fb_core2定时清除历史数据;
is
newdate date :=sysdate-2;
begin
       delete decision_element_data_history t where t.create_time < to_date(to_char(newdate,'yyyy-mm-dd'),'yyyy-mm-dd');
       delete decision_scorecard_data t where t.update_time < newdate;
       delete decision_log_detail t where t.log_guid in (
              select log_guid from decision_log m where m.start_time< newdate);
       delete decision_log m where m.start_time< newdate;
       
       delete decision_test_batch_detail t where t.batch_id in (
              select batch_id from decision_test_batch m where m.start_time< newdate );
       delete decision_test_batch m where m.start_time< newdate;
       commit;
exception
  when others then
  rollback;
end;
/

