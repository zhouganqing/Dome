create procedure prc_collect_element_pa(p_IdCredit cs_credit.id%type,p_ReturnCode out varchar2) is
       -- Author  : MaJianFeng
       -- Create Date : 2018-06-06
       -- Purpose : put credit data into decision_element_data_pa_PA table;
       error_info                  varchar2(1000);
        v_IdPerson                  cs_person.id%type;
       v_PersonName                cs_person.name%type;
       v_Ident                     cs_person.ident%type;
       v_IdentExp                  cs_person.ident_exp%type;
       v_National                  cs_person.national%type;
       v_CommitTime                cs_credit.commit_time%type;
       v_InterCode                 cs_credit.inter_code%type;
       v_IdSa                      cs_credit.id_sa%type;
       v_SaName                    sys_user_list.user_name%type;
       v_SaMobile                  sys_user_list.phone%type;
       v_SaIdent                   sys_user_list.ident%type;
       v_CreditType                cs_credit.credit_type%type;
       v_PreInterCode              cs_credit.pa_inter_code%type;
       v_CreditModel               cs_credit.credit_model%type;
       v_PayAmount                 cs_credit.pay_amount%type;
       v_AppDate                   cs_credit.app_date%type;
       v_PosCode                   sellerplace.pos_code%type;
       v_IdSellerPlace             sellerplace.id%type;
       v_Province                  sellerplace.province%type;
       v_City                      sellerplace.city%type;
       v_UseCity                   sellerplace.city%type;
       v_Seq                       decision_element_data_pa.sort_code%type;
       v_IdCredit                  number;
       v_Count                     integer;
       v_GoodsVolume               number:=0;
       v_MaxGoodsPrice             number:=-1;
       v_MaxGoodsType              goods_type.name%type;
       v_MinGoodsPrice             number:=-1;
       v_MinGoodsType              goods_type.name%type;
       v_IsRecall                  number:=0;
       v_CreditAmount              cs_credit.credit_amount%type;
       v_SCI_Amount                status_change_information.credit_amount%type;
       v_SCI_Category              status_change_information.goodsnewcategory%type;
       v_NewCategory               varchar2(50);

       v_ElementType               decision_element_data_pa.element_type%type;
       v_ContractNo                cs_credit.contract_no%type;
       v_Price                     cs_credit.price%type;
       v_Annuity                   cs_credit.annuity%type;
       v_CreditSource              cs_credit.credit_source%type;

       v_Birthday                  varchar2(20);
       v_Age                       integer;
       v_Sex                       cs_person.sex%type;
       v_PersonMobile              varchar2(100);
       v_OfficeTel                 varchar2(100);

       v_IdProduct                 product.id%type;
       v_ProdType                  product.prod_type%type;
       v_SearchType                product.search_type%type;
       v_PaymentNum                product.payment_num%type;
       v_TempVue                   varchar2(50);

       v_Position                  number:=-1;

       v_varTemp                   varchar2(100);

       v_FamilyPhoneUseCount           number:=0;
       v_OtherPhoneUseCount            number:=0;
       v_FamilyPhoneUseSameCityCount   number:=0;
       v_FamilyPhoneUseSamePosCount    number:=0;
       v_OtherPhoneUseSameCityCount    number:=0;
       v_OtherPhoneUseSamePosCount     number:=0;
       strSql                      varchar2(4000);
    begin
       delete decision_element_data_pa where id_credit=p_IdCredit;
       -------------------------Start--------------------------------
      -- prc_save_cs_contact(100000,p_IdCredit,p_ReturnCode);
       v_Seq:=0;
       v_ElementType:='Special';
       insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
            values(p_IdCredit,v_ElementType,'Random5',round(dbms_random.value(),6),v_Seq+1);
       v_Seq:=v_Seq + 1;

       v_ElementType:='Credit';
       select a.contract_no,a.credit_model,a.commit_time,nvl(a.id_sa,''),a.credit_amount,a.price,a.annuity,a.id_person,a.credit_type,a.pa_inter_code,a.pay_amount,a.app_date,a.credit_source
         into v_ContractNo,v_CreditModel,v_CommitTime,v_IdSa,v_CreditAmount,v_Price,v_Annuity,v_IdPerson,v_CreditType,v_PreInterCode,v_PayAmount,v_AppDate,v_CreditSource
         from cs_credit a where a.id=p_IdCredit;
       --2017/03/21 update wangxiaofeng v_AppDate date 改为datetime
       strSql:='insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
                select '||p_IdCredit||','''||v_ElementType||''','||'''PaContractNo'''||','''||v_ContractNo||''','||(v_Seq+1)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''PaPrice'''||','''||v_Price||''','||(v_Seq+2)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''PaCreditAmount'''||','''||v_CreditAmount||''','||(v_Seq+3)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''PaAnnuity'''||','''||v_Annuity||''','||(v_Seq+4)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''PaCommitTime'''||','''||to_char(v_CommitTime,'yyyy-MM-dd HH24:mi:ss')||''','||(v_Seq+5)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''PaInterCode'''||','''||v_PreInterCode||''','||(v_Seq+6)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''PaIdSa'''||','''||v_IdSa||''','||(v_Seq+7)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''PaCreditType'''||','''||v_CreditType||''','||(v_Seq+8)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''PaCreditModel'''||','''||v_CreditModel||''','||(v_Seq+9)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''PaPayAmount'''||','''||v_PayAmount||''','||(v_Seq+10)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''PaAppDate'''||','''||to_char(v_AppDate,'yyyy-MM-dd HH24:mi:ss')||''','||(v_Seq+11)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''PaCreditSource'''||','''||v_CreditSource||''','||(v_Seq+12)||' from dual';
       Execute immediate strSql;
       v_Seq:=v_Seq +12;
       
       --修改中移产品cs.credit_type='XF'的销售信息生成逻辑	 yangzhenxian	 2019-05-10
       if v_CreditType='XF'
       then         
           for c in(select 
            SALES_NAME as SaName,--销售员姓名
            SALES_PHONE as SaMobile,--销售员手机
            SALES_IDCARD as SaIdent---销售员身份证
            from cs_merchant_store where contract_no=v_ContractNo
             )loop
              insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
                   values(p_IdCredit,v_ElementType,'PaSaName',c.SaName,v_Seq+1);
              insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
                   values(p_IdCredit,v_ElementType,'PaSaMobile',c.SaMobile,v_Seq+1);
              insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
                   values(p_IdCredit,v_ElementType,'PaSaIdent',c.SaIdent,v_Seq+1);
              
              v_SaName:=c.SaName;
              v_SaMobile:=c.SaMobile;
              v_SaIdent:=c.SaIdent;
              v_Seq:=v_Seq + 3;
           end loop;
       end if;
       
       
       --享购机元素      yangzhenxian	2019-06-12
           for c in(select 
            Supplier as Supplier,--套餐运营商（实际运营商）
            Channel_type as ChannelType,--渠道
            fw_channel as FwChannel--资方批发渠道
            from cs_credit_ext where id_credit=p_IdCredit
             )loop
              insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
                   values(p_IdCredit,'Credit','PaSupplier',c.Supplier,v_Seq+1);
              insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
                   values(p_IdCredit,'Credit','PaChannelType',c.ChannelType,v_Seq+1);
              insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
                   values(p_IdCredit,'Credit','PaFwChannel',c.FwChannel,v_Seq+1);
              
              v_Seq:=v_Seq + 3;
           end loop;
    --添加元素Credit.TotalAnnuity，包括以下期款及费用 annuity+power_fee+insurance_fee+screen_fee+post_fee-COUPON_AMOUNT
    insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
    select p_IdCredit,'Credit','*','PaTotalAnnuity',nvl(sum(TotalAnnuity),0),v_Seq
    from(select nvl(annuity,0)+nvl(power_fee,0)+nvl(insurance_fee,0)+nvl(broken_screen_service,0)+nvl(stag_insurance_service,0)
          -nvl(coupon_amount,0)+nvl(treasure_box_fee,0)+nvl(COMPREHENSIVE_INSURANCE,0) as TotalAnnuity
    from cs_credit_fee where id_credit=p_IdCredit);


       for fee in(select t.insurance_fee from cs_credit_fee t where t.id_credit=p_IdCredit)
         loop
           --保险费用
           insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
           values(p_IdCredit,'Credit','*','PaInsuranceFee',fee.insurance_fee,v_Seq+1);
           v_Seq:=v_Seq + 1;
       end loop;
       
       
     --区分召回客户的决策流程
     select b.name  ,b.ident,b.id,a.credit_amount into v_PersonName,v_Ident,v_IdPerson,v_CreditAmount from cs_credit a join cs_person b on a.id_person=b.id and a.id=p_IdCredit;
     select count(1) into v_Count from status_change_information where personname=v_PersonName and personident=v_Ident
                                                                       and credit_type=v_CreditType and begin_time<=v_CommitTime and end_time>=v_CommitTime;
       if v_Count=0 then
          v_IsRecall:=0;
       else
          select credit_amount,goodsnewcategory into v_SCI_Amount,v_SCI_Category from status_change_information
           where rownum=1 and personname=v_PersonName and personident=v_Ident;
          if v_CreditAmount<=v_SCI_Amount and v_NewCategory=v_SCI_Category then
             v_IsRecall:=1;
          else
             v_IsRecall:=2;
          end if;
       end if;
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            values(p_IdCredit,'Credit','*','PaIsRecall',v_IsRecall,v_Seq);
       
       ---------------------------------------------------------
       v_ElementType:='Address';
       for address in (select decode(address_type,1,'ResidentAddress',2,'CurrentAddress','CompanyAddress') address_type,province,city,region,town,street,building,room
              from cs_address where id_credit=p_IdCredit order by address_type)
       loop
           insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,address.address_type,'PaProvince',address.province,v_Seq+1);
           insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,address.address_type,'PaCity',address.city,v_Seq+2);
           insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,address.address_type,'PaRegion',address.region,v_Seq+3);
           insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,address.address_type,'PaTown',address.town,v_Seq+4);
           insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,address.address_type,'PaStreet',address.street,v_Seq+5);
           insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,address.address_type,'PaBuilding',address.building,v_Seq+6);
           insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,address.address_type,'PaRoom',address.room,v_Seq+7);
               v_Seq:=v_Seq + 7;
       end loop;

       ---------------------------------------------------------
       v_ElementType:='Career';

       for employer in (select nvl(fun_getreg_value(399,a.company_type),'') as company_type,nvl(fun_getreg_value(397,a.industry),'') as industry,a.position,
              nvl(b.university,a.company_name1) university,nvl(a.department,'') as department,decode(a.start_date, null, '', to_char(a.start_date, 'yyyy-MM-dd')) startdate,decode(a.end_date, null, '', to_char(a.end_date, 'yyyy-MM-dd')) enddate
              from cs_employer a,university b where a.company_name=b.id(+) and a.id_credit=p_IdCredit)
       loop
           v_Position:=employer.position;
           /*insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,'CompanyType',employer.company_type,v_Seq+1);*/
           insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,'PaIndustry',employer.Industry,v_Seq+1);
               v_Seq:=v_Seq + 1;
           insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,'PaPosition',employer.position,v_Seq+1);
               v_Seq:=v_Seq + 1;
           /*insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,'University',pkg_decision.filterStr(employer.university),v_Seq+4);
           insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,'Department',employer.department,v_Seq+5);
           insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,'StartDate',employer.startdate,v_Seq+6);
           if employer.enddate is not null then
               insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
                   (p_IdCredit,v_ElementType,'EndDate',employer.enddate,v_Seq+7);
               v_Seq:=v_Seq + 7;
           else
               v_Seq:=v_Seq + 6;
           end if;*/
       end loop;

       ---------------------------------------------------------
       v_ElementType:='Person';
       select name,ident,sex,nvl(ident_exp,''),nvl(fun_getreg_value(790,a.national),'汉')
         into v_PersonName,v_Ident,v_Sex,v_IdentExp,v_National
         from cs_person a where id=v_IdPerson;

       if length(v_Ident)=15 then
           v_Birthday:=to_char(to_date('19'||substr(v_Ident,7,6),'yyyy-MM-dd'),'yyyy-MM-dd');
           select to_number(to_char(sysdate,'yyyy')) - to_number('19'||substr(v_Ident,7,2)) into v_Age from dual;
       else
           v_Birthday:=to_char(to_date(substr(v_Ident,7,8),'yyyy-MM-dd'),'yyyy-MM-dd');
           select to_number(to_char(sysdate,'yyyy')) - to_number(substr(v_Ident,7,4)) into v_Age from dual;
       end if;
       strSql:='insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
                select '||p_IdCredit||','''||v_ElementType||''','||'''PaBirthday'''||','''||v_Birthday||''','||(v_Seq+1)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''PaIdPerson'''||','''||v_IdPerson||''','||(v_Seq+2)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''PaAge'''||','''||v_Age||''','||(v_Seq+3)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''PaSex'''||','''||v_Sex||''','||(v_Seq+4)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''PaName'''||','''||v_PersonName||''','||(v_Seq+5)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''PaIdent'''||','''||v_Ident||''','||(v_Seq+6)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''PaIdentExp'''||','''||to_char(v_IdentExp,'yyyy-MM-dd')||''','||(v_Seq+7)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''PaNational'''||','''||v_National||''','||(v_Seq+9)||' from dual';
       v_Seq:=v_Seq +6;
       Execute immediate strSql;

      ------------------------------------------------------------
       select a.id_product into  v_IdProduct from cs_credit a where a.id=p_IdCredit;
       if v_IdProduct!=0 then
         v_ElementType:='Product';
         select prod_type,search_type,payment_num
           into v_ProdType,v_SearchType,v_PaymentNum
           from product where id=v_IdProduct;

         strSql:='insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
                  select '||p_IdCredit||','''||v_ElementType||''','||'''PaProdType'''||','''||v_ProdType||''','||(v_Seq+1)||' from dual
                  union select '||p_IdCredit||','''||v_ElementType||''','||'''PaSearchType'''||','''||v_SearchType||''','||(v_Seq+2)||' from dual
                  union select '||p_IdCredit||','''||v_ElementType||''','||'''PaPaymentNum'''||','''||v_PaymentNum||''','||(v_Seq+3)||' from dual';
         Execute immediate strSql;
         v_Seq:=v_Seq +3;
         end if;
         
     --------------------------------------------------------------    
     select a.id_sellerplace into  v_IdSellerPlace from cs_credit a where a.id=p_IdCredit;

       if v_IdSellerPlace>0 then
           v_ElementType:='SellerPlace';
           select province,city,pos_code
             into v_Province,v_City,v_PosCode
             from sellerplace where id=v_IdSellerPlace;
           v_UseCity:=v_City;

           strSql:='insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
                    select '||p_IdCredit||','''||v_ElementType||''','||'''PaProvince'''||','''||v_Province||''','||(v_Seq+1)||' from dual
                    union select '||p_IdCredit||','''||v_ElementType||''','||'''PaPosCode'''||','''||v_PosCode||''','||(v_Seq+2)||' from dual
                    union select '||p_IdCredit||','''||v_ElementType||''','||'''PaCity'''||','''||v_City||''','||(v_Seq+3)||' from dual';

           v_Seq:=v_Seq +3;
           Execute immediate strSql;
      end if;
       
       ----------------------在SellerPlace下的元素中添加中移消费贷相关逻辑   yangzhenxian	2019-03-08------------------------------
       for c in(select decode(a.business_code,null,b.store_no,a.business_code) as PosCode
                ,b.STORE_NAME as  Name 
                ,decode(store_province,null,g.AREA_NAME,store_province) as Province
                ,store_city as City
                ,store_address as Address
                from cs_credit_ext c
                left join cs_merchant_store b on b.contract_no=c.contract_no
                left join bs_area_info g on g.AREA_CODE=c.user_prov_no 
                left join (
                select p.business_code ,'中移' as pos_type ---===中移动表
                from mv_bs_store p 
                union 
                select q.business_code ,'中联' as pos_type ---===中联表
                from mv_xy_bs_store q) a on a.business_code =b.store_no where c.contract_no=v_ContractNo and rownum=1
         )loop
          insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
               values(p_IdCredit,'SellerPlace','PaPosCode',c.PosCode,v_Seq+1);
          insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
               values(p_IdCredit,'SellerPlace','PaName',c.Name,v_Seq+1);
          insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
               values(p_IdCredit,'SellerPlace','PaProvince',c.Province,v_Seq+1);
          insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
               values(p_IdCredit,'SellerPlace','PaCity',c.City,v_Seq+1);
          insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
               values(p_IdCredit,'SellerPlace','PaAddress',c.Address,v_Seq+1);
          if v_CreditType in ('XF','XFC')
          then
             v_PosCode:=c.PosCode;
          end if;
          v_Seq:=v_Seq + 5;
       end loop;
      
    --AfPosCate:反欺诈门店等级类别，取于表RISK_CONTROL.DF_AF_GSPN，当status=a中的字段AF_TYPE 2016/03/16 wangxiaofeng
     insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
     select p_IdCredit,'SellerPlace','PaAfPosCate',nvl(max(t.af_type),0),v_Seq from mv_df_af_gspn t
     where t.status='a' and t.pos_code=v_PosCode;
     v_Seq:=v_Seq +1;


    --AfSaCate:反欺诈销售等级类别，取于表RISK_CONTROL.DF_AF_GSPN_ABNORMAL，当status=a中的字段AF_TYPE 2016/03/16 wangxiaofeng    
       if v_CreditType='XF'
       then
         insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
         select p_IdCredit,'SellerPlace','PaAfSaCate',nvl(max(t.af_type),0),v_Seq from mv_df_af_gspn_abnormal t
         where t.status='a' and t.ident=v_SaIdent;
       else
         insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
         select p_IdCredit,'SellerPlace','PaAfSaCate',nvl(max(t.af_type),0),v_Seq from mv_df_af_gspn_abnormal t
         where t.status='a' and t.id_sa=v_IdSa;
       end if;
       v_Seq:=v_Seq + 1;

     --majianfeng 2018/08/28
      insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
      select p_IdCredit,'SellerPlace','PaRiskCate',risk_cate,v_Seq+1 from mv_df_pos_risk_cate_gl
      where pos_code=v_PosCode;

      insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
       select p_IdCredit,'SellerPlace','PaRiskCate_Challenge',risk_cate_Challenge,v_Seq+2 from mv_df_pos_risk_cate_gl
       where pos_code=v_PosCode;

      ----------------------------------------------------------
      --2017/03/29 wangxiaofeng 元素Goods.NewCategory，区分手机类型中的苹果与非苹果，其他类型不变
       for c in(with a as (select cc.id id_credit,cg.id_goods_category,cg.producer,
                 c.name goods_category,t.name goods_type,row_number() over(order by cg.goods_price desc) rn
                from cs_credit cc
                join cs_goods cg on cc.id=cg.id_credit
                join goods_category c on cg.id_goods_category=c.id
                join goods_type t on cg.id_goods_type=t.id
                where cc.id=p_IdCredit)
                select case when id_goods_category=7 and (goods_type like '%苹果%' or producer like '%苹果%'
                   or upper(producer) like '%IPHONE%' or upper(producer) like '%APPLE%') THEN '苹果'
                   else to_char(goods_category) end as new_category
                from a where rn=1
         )loop
           insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
           values(p_IdCredit,'Goods','PaNewCategory',c.new_category,v_Seq);
           v_Seq:=v_Seq + 1;
           v_NewCategory:=c.new_category;
         end loop;


       for goods in (select b.name goods_category,c.name goods_type,producer,brand,goods_price from cs_goods a,goods_category b,goods_type c
              where a.id_goods_category=b.id and a.id_goods_type=c.id and a.id_credit=p_IdCredit)
       loop
           if v_MaxGoodsPrice=-1 or v_MaxGoodsPrice<goods.goods_price then
              v_MaxGoodsPrice:=goods.goods_price;
              v_MaxGoodsType:=goods.goods_type;
           end if;

           if v_MinGoodsPrice=-1 or v_MinGoodsPrice>goods.goods_price then
              v_MinGoodsPrice:=goods.goods_price;
              v_MinGoodsType:=goods.goods_type;
           end if;

           insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,'Goods','PaCategory',goods.goods_category,v_Seq+1);
           insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,'Goods','PaGoodsType',goods.goods_type,v_Seq+2);
           insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,'Goods','PaProducer',goods.producer,v_Seq+3);
           v_Seq:=v_Seq + 3;
           v_GoodsVolume:=v_GoodsVolume+1;
       end loop;
       insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,'Goods','PaMaxPrice',v_MaxGoodsPrice,v_Seq+1);
       insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,'Goods','PaMaxGoodsType',v_MaxGoodsType,v_Seq+2);
       insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,'Goods','PaMinGoodsType',v_MinGoodsType,v_Seq+3);
       insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,'Goods','PaGoodsVolume',v_GoodsVolume,v_Seq+4);
        v_Seq:=v_Seq + 4;

       ---------------------------------------------------------------------------
       v_ElementType:='FamilyInfo';
       for familyinfo in (select decode(id_spouse, 1, '未婚', 2, '已婚', '其它') mariage,nvl(child,0) children_count,fun_getreg_value(2, house_type) house_type,expense_month
                   from cs_family_info where id_credit=p_IdCredit)
       loop
          insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
                 (p_IdCredit,v_ElementType,'PaMarriage',familyinfo.mariage,v_Seq+1);
          v_Seq:=v_Seq + 1;
       end loop;

      
       ---------------------------------------------------------------------------
       v_ElementType:='Other';

       for experience in (select nvl(a.total_wk_exp,0) total_wk_exp,nvl(a.wk_income,0) wk_income,nvl(a.other_income,0) other_income,nvl(a.family_income,0) family_income,
              nvl(fun_getreg_value(11,a.education),'') education,nvl(ssi,'') ssi,nvl(a.cur_wk_exp,0) cur_wk_exp,fun_getreg_value(776,a.bank_name) bank_name,a.bank_no,a.branch,
              fun_get_ybscity(a.id_ybs_city,a.id_credit) bank_region,nvl(a.is_dd,0) is_dd,nvl(a.is_ssi,0) is_ssi,to_char(a.fst_date_pay, 'yyyy-MM-dd') fst_date_pay
              from cs_experience a where id_credit=p_IdCredit)
       loop
          if v_Position=9 then
               v_varTemp:='LeftGraduateMonth';
          else
               v_varTemp:='CurrentEmpMonth';
          end if;
          /*insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
                 (p_IdCredit,v_ElementType,v_varTemp,experience.total_wk_exp,v_Seq+1);*/
          insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
                 (p_IdCredit,v_ElementType,'PaPersonIncome',experience.wk_income,v_Seq+2);
          insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
                 (p_IdCredit,v_ElementType,'PaOtherIncome',experience.other_income,v_Seq+3);
          insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
                 (p_IdCredit,v_ElementType,'PaFamilyIncome',experience.family_income,v_Seq+4);
          insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
                 (p_IdCredit,v_ElementType,'PaEducation',experience.education,v_Seq+5);
          insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
                 (p_IdCredit,v_ElementType,'PaBankName',experience.bank_name,v_Seq+6);
          insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
                 (p_IdCredit,v_ElementType,'PaBankNo',experience.bank_no,v_Seq+7);
          insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
                 (p_IdCredit,v_ElementType,'PaBankCity',experience.bank_region,v_Seq+8);

          v_Seq:=v_Seq + 8;
       end loop;
       
       --客户本人手机号码所属城市
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'Other','*','PaPhoneNoCity',nvl(max(a.city),'null'),v_Seq+1
       from mv_df_phone_attribution_gl a where a.mobilenumber=substr(v_PersonMobile,1,7);
       --(select substr(contact_value,1,7) from cs_contact t where t.id_credit=p_IdCredit and t.person_type = '1' and t.contact_type='2');
       v_Seq:=v_Seq + 1;
       
       
     --------------------------------------------------------------------------------
     --客户在申请此合同时，前30天内的合同总次数
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            select p_IdCredit,'HardCheck','*','PaApplicationLast30Day',count(1),v_Seq from cs_credit a where a.id_person=v_IdPerson
               and a.id<>p_IdCredit and trunc(a.create_time)>=trunc(sysdate)-30 and a.create_time<v_CommitTime;--2017-09-22增加时间范围
       v_Seq:=v_Seq + 1;


       --客户在申请此合同时，当天取消的合同总数
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            select p_IdCredit,'HardCheck','*','PaCancleApplicationSameDay',count(1),v_Seq from cs_credit a where a.id_person=v_IdPerson
               and trunc(a.commit_time)=trunc(sysdate) and a.status='t' and a.id<>p_IdCredit  and a.create_time<v_CommitTime;--2017-09-22增加时间范围
       v_Seq:=v_Seq + 1;
       
       --HardCheck.MaxCpd,HardCheck.Last3mCpd
       for prev_instalment in
          (select to_char(min(date_due_first),'yyyy-MM-dd') as date_due_first,--客户最早的应还款日期
               max(cpd) as cpd,--客户在申请合同时其他合同的现在的未还的逾期天数，精确到天
               max(max_dpd) as max_dpd,--客户在申请合同时历史上最大逾期天数，精确到天
               max(last_3m_dpd) as last_3m_dpd, --客户在申请合同时最近三个月（自然月）的最大逾期天数，精确到天
               max(max_cpd) as max_cpd,
               max(last_3m_cpd) as last_3m_cpd
              from (
                select a.id_person ,
                date_due_first,--客户最早的应还款日期
                cpd,--客户在申请合同时其他合同的现在的未还的逾期天数，精确到天
                remaining_amount, --客户在申请此合同时其他合同剩余的未还期金额（包含未到期的）
                remaining_instal, --客户在申请此合同时其他合同剩余的未还期数之和（包含未到期的）
                max_dpd,--客户在申请合同时历史上最大逾期天数，精确到天
                last_3m_dpd, --客户在申请合同时最近三个月（自然月）的最大逾期天数，精确到天
                max_cpd,
                last_3m_cpd,
                date_3m_dpd,
                m_paid_ndpd,--客户在申请此合同前成功还款且没有逾期的期数总合
                m_due--客户在申请此合同时前面已经到期的期数之和
                from mv_DF_PD_SUM_GL   a 
                join cs_credit c on a.contract_no=c.contract_no and c.credit_channel='GIVEU'

                union

                select b.id as id_person,
                null as date_due_first,--客户最早的应还款日期
                0 as cpd,--客户在申请合同时其他合同的现在的未还的逾期天数，精确到天
                0 as remaining_amount, --客户在申请此合同时其他合同剩余的未还期金额（包含未到期的）
                0 as remaining_instal, --客户在申请此合同时其他合同剩余的未还期数之和（包含未到期的）
                max_dpd,--客户在申请合同时历史上最大逾期天数，精确到天
                last_3m_dpd, --客户在申请合同时最近三个月（自然月）的最大逾期天数，精确到天
                0 as max_cpd,
                0 as last_3m_cpd,
                null as date_3m_dpd,
                0 as m_paid_ndpd,--客户在申请此合同前成功还款且没有逾期的期数总合
                0 as m_due--客户在申请此合同时前面已经到期的期数之和
                from qk_pd_total a
                join cs_person b on a.cust_no=b.IDENT
                --where a.cust_no=v_ident 
                )
              where id_person=v_IdPerson)
       loop
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
              values(p_IdCredit,'HardCheck','*','PaDateDueFirst',prev_instalment.date_due_first,v_Seq+1);
          v_Seq:=v_Seq + 1;
       
        --客户在申请合同时其他合同的现在的未还的逾期天数，精确到天
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values(p_IdCredit,'HardCheck','*','PaCpd',prev_instalment.cpd,v_Seq);
          v_Seq:=v_Seq + 1;

        --客户在申请合同时最近三个月（自然月）的最大逾期天数，精确到天
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values(p_IdCredit,'HardCheck','*','PaLast3mDpd',prev_instalment.last_3m_dpd,v_Seq);
          v_Seq:=v_Seq + 1;

        --客户在申请合同时历史上最大逾期天数，精确到天
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values(p_IdCredit,'HardCheck','*','PaMaxCpd',prev_instalment.max_cpd,v_Seq);
          v_Seq:=v_Seq + 1;
        --客户在申请合同时历史上最大逾期天数，精确到天
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values(p_IdCredit,'HardCheck','*','PaMaxDpd',prev_instalment.max_dpd,v_Seq);
          v_Seq:=v_Seq + 1;

        --客户在申请合同时最近三个月（自然月）的最大逾期天数，精确到天
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values(p_IdCredit,'HardCheck','*','PaLast3mCpd',prev_instalment.last_3m_cpd,v_Seq);
          v_Seq:=v_Seq + 1;
       end loop;
       commit;
      --客户在申请此合同时前面一张通过的合同的申请时间，除拒绝和取消的合同外（状态为d/t/x/u的除外）update_time2016/11/30

        select to_char(max(create_time),'yyyy-MM-dd HH24:mi:ss') into v_TempVue from cs_credit
             where id_person=v_IdPerson and create_time<=v_CommitTime and credit_type in('SS','SC','XF','SP') and id!=p_IdCredit and status not in('d','t','x','u','r','q','pr','pa','py');
             if v_TempVue is not null then
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       values(p_IdCredit,'HardCheck','*','PaMaxPrevCommitTime',v_TempVue,v_Seq );
            /*select p_IdCredit,'HardCheck','*','MaxPrevCommitTime',to_char(max(create_time),'yyyy-MM-dd HH24:mi:ss'),v_Seq from cs_credit
             where id_person=v_IdPerson and create_time<=v_CommitTime and credit_type in('SS','SC') and id!=p_IdCredit and status not in('d','t','x','u','r','q');*/
             end if;
       v_Seq:=v_Seq + 1;

      
       --该客户上一单拒绝原因
       select nvl(max(id),0) into v_IdCredit from cs_credit t where id_person=v_IdPerson and t.id!=p_IdCredit and t.status='d';
       if v_IdCredit!=0 then
         insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         select p_IdCredit,'HardCheck','*','PaPreRejectReason',case when c.event is null then fun_get_reject_reason(a.id) else replace(replace(fun_getreg_value(779,nvl(c.event,-1)),'[',''),']','') end,v_Seq
         from cs_credit a,wfi_final_decision c where a.id=c.id_credit(+) and a.id=v_IdCredit;
       end if;
       v_Seq:=v_Seq + 1;

       --客户在申请此合同时前面一张拒绝的合同的申请时间（状态为d）
       select to_char(max(create_time),'yyyy-MM-dd HH24:mi:ss') into v_TempVue from cs_credit
             where id_person=v_IdPerson and create_time<=v_CommitTime and (credit_type in('SS','SC','MQ','XF','SP') or (credit_type='QB' and id_sa is not null)) and id!=p_IdCredit and status='d';
         if  v_TempVue is not null then
        insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
              values(p_IdCredit,'HardCheck','*','PaRejectPrevCommitTime',v_TempVue,v_Seq);
       v_Seq:=v_Seq + 1;
       end if;
      --客户在申请此合同时现行状态的合同数量(状态为a）
      select count(1) into v_Count from cs_credit where id_person=v_IdPerson and create_time<=v_CommitTime and id!=p_IdCredit and status ='a';
      insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
           values(p_IdCredit,'HardCheck','*','PaSumDue',v_Count,v_Seq);
      v_Seq:=v_Seq + 1;

      --IsMysteryIdent 客户申请时身份证是否属于暗访人员白名单(select ident from mv_WHITELIST_MYST_INVE where status='a')
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         select p_IdCredit,'HardCheck','*','PaIsMysteryIdent',decode(count(1),0,0,1),v_Seq
         from mv_WHITELIST_MYST_INVE t where status='a' and t.ident=v_Ident;
       v_Seq:=v_Seq + 1;

       --客户身份证黑名单
       select count(1) into v_Count from customer_blacklist where ident=v_Ident;
       if v_Count>0 then
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
              values(p_IdCredit,'HardCheck','*','PaBlackListIDent','1',v_Seq);
          v_Seq:=v_Seq + 1;
       end if;

      --客户本人手机号码黑名单
       select count(1) into v_Count from customer_blacklist
       where mobile in(select contact_value from cs_contact where id_person=v_IdPerson and person_type='1' and contact_type in('2','3','18','19'));
       if v_Count>0 then
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
              values(p_IdCredit,'HardCheck','*','PaBlackListMobile','1',v_Seq);
          v_Seq:=v_Seq + 1;
       end if;
       
       
              
       --公司名称黑名单
       select count(1) into v_Count from company_blacklist where employer_name in(select company_name1 from cs_employer where id_person=v_IdPerson);
       if v_Count>0 then
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
              values(p_IdCredit,'HardCheck','*','PaBlackListCompanyName','1',v_Seq+1);
          v_Seq:=v_Seq + 1;
       end if;
       --客户其它手机号码黑名单
       select count(1) into v_Count from customer_blacklist
       where mobile in(select contact_value from cs_contact where id_person=v_IdPerson and person_type<>'1' and contact_type in('2','3','18','19'));
       if v_Count>0 then
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
              values(p_IdCredit,'HardCheck','*','PaBlackListOtherMobile','1',v_Seq+1);
          v_Seq:=v_Seq + 1;
       end if;
       --客户家庭电话黑名单
       select count(1) into v_Count from customer_blacklist
       where home_num in(select contact_value from cs_contact where id_person=v_IdPerson and contact_type='18');
       if v_Count>0 then
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
              values(p_IdCredit,'HardCheck','*','PaBlackListHomePhone','1',v_Seq+1);
          v_Seq:=v_Seq + 1;
       end if;
       --客户QQ号码黑名单 2016/07/07 wangxiaofeng
       select count(1) into v_Count from cs_contact c
       where c.person_type='1' and c.contact_type='13' and c.id_credit=p_IdCredit
       and exists( select * from customer_blacklist b where b.qq=regexp_substr(c.contact_value,'[0-9]+'));
       if v_Count>0 then
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
              values(p_IdCredit,'HardCheck','*','PaBlackListQQ','1',v_Seq+1);
          v_Seq:=v_Seq + 1;
       end if;
       --公司工作电话黑名单
       select count(1) into v_Count from company_blacklist where office_num in(select contact_value from cs_contact where id_person=v_IdPerson and contact_type='3');
       if v_Count>0 then
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
              values(p_IdCredit,'HardCheck','*','PaBlackListOfficePhone','1',v_Seq+1);
          v_Seq:=v_Seq + 1;
       end if;  
 

      --客户此合同一共提供了多少个电话
       select count(1) into v_Count from cs_contact where contact_type in ('2','3','18','19') and id_credit=p_IdCredit;
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            values(p_IdCredit,'HardCheck','*','PaTotalPhoneCount',v_Count,v_Seq+1);
       v_Seq:=v_Seq + 1;

       --一共提供了多少个家庭联系人电话
       select count(1) into v_Count from cs_contact
       where person_type in(select reg_val_code from registers t where reg_number=265 and status='a' and reg_val_code!='1') and contact_type in('2','3','18','19') and id_credit=p_IdCredit;
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            values(p_IdCredit,'HardCheck','*','PaTotalFamilyPhoneCount',v_Count,v_Seq+1);
       v_Seq:=v_Seq + 1;

       --一共提供了多少个其他联系人电话
       select count(1) into v_Count from cs_contact
       where person_type in(select reg_val_code from registers t where reg_number=396 and status='a') and contact_type in('2','3','18','19') and id_credit=p_IdCredit;
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            values(p_IdCredit,'HardCheck','*','PaTotalOtherPhoneCount',v_Count,v_Seq+1);
       v_Seq:=v_Seq + 1;

       --一共提供了多少个家庭联系人电话和其他联系人中亲人的电话
       select count(1) into v_Count from cs_contact a
       where a.contact_type in(2,3,18,19)
        and a.person_type!='1'
        and (a.person_type in('BA','BB','BC','SA','SB','SC','5A','5B','5C')
            or a.person_type in(select reg_val_code from registers b where b.reg_number=265))
        and a.id_credit=p_IdCredit;
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            values(p_IdCredit,'HardCheck','*','PaTotalRelativePhoneCount',v_Count,v_Seq+1);
       v_Seq:=v_Seq + 1;      
 

         
         ----PackageInfo  套餐类型          yangzhenxian                          2019-04-28
         for d in(with temp as (
             select PACKAGE_INFO as PackageInfo from cs_goods where id_credit=p_IdCredit order by update_time desc
              )
              select * from temp where rownum=1
         )
         loop
           insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
           values( p_IdCredit,'Goods','*','PaPackageInfo',d.PackageInfo,v_Seq);
           v_Seq:=v_Seq + 1;
         end loop;
       ---------------------------------------------------------
       v_ElementType:='Contact';
       for contact in (select fun_getreg_value(395,t.contact_type) contact_type,t.contact_type cont_type,contact_value from cs_contact t where person_type='1' and id_credit=p_IdCredit)
       loop
           insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,'Pa'||contact.contact_type,contact.contact_value,v_Seq+1);
           v_Seq:=v_Seq + 1;

           if contact.cont_type='3' then
             v_OfficeTel:=contact.contact_value;
           end if;
           if contact.cont_type='2' then
             v_PersonMobile:=contact.contact_value;
           end if;
       end loop;
       
       --hongbinbin  20190924
       for qq in (
         select 
            case when contact_value like '%qq.com' then substr(regexp_substr(contact_value,'[0-9]+'),1,1) end as QQIntDigit---qq号首字母
            ,case when contact_value like '%qq.com' then length(regexp_substr(contact_value,'[0-9]+'))end as QQLength---qq号长度
            from (select a.person_type,a.contact_type,a.contact_value,
                row_number()over (partition by id_credit,person_type,contact_type,contact_value order by  update_time desc) as rank_id
                from cs_contact a where a.id_credit=p_IdCredit) ctpq
            where ctpq.rank_id=1 and ctpq.person_type='1' and ctpq.contact_type='11'
         )loop
         
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,'*','PaQQIntDigit',qq.QQIntDigit,v_Seq+1);
               
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,'*','PaQQLength',qq.QQLength,v_Seq+2);
       
           v_Seq:=v_Seq + 2;
         
         end loop;
             
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'HardCheck','*','PaOffPhoneUseSameCityCount',count(distinct a.id),v_Seq+1 from cs_credit a,cs_contact b,sellerplace c,cs_address ad
         where a.id=b.id_credit(+) and a.id_sellerplace=c.id(+) and b.contact_type='3' and a.id_person!=v_IdPerson
         and a.id=ad.id_credit(+) and ad.address_type=2
         and a.status not in('t','r') and a.commit_time>=sysdate-30  and a.commit_time<=v_CommitTime
         and b.contact_value=nvl(v_OfficeTel,'#') and nvl(c.city,ad.city)=v_UseCity;
       --and b.contact_value in(select t.contact_value from cs_contact t where t.contact_type='3' and t.id_credit=p_IdCredit) and c.city=v_UseCity;
       v_Seq:=v_Seq + 1;

       --其他联系人电话在最近180天被其他不同的客户用作其他所有电话（办公电话除外）总的次数
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            values(p_IdCredit,'HardCheck','*','PaOtherPhoneUseCount',v_OtherPhoneUseCount,v_Seq+1);
       v_Seq:=v_Seq + 1;

       --其他联系人电话在过去30天在同个城市被其他人重复使用的情况；状态不等于tr（办公电话除外）总的次数
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            values(p_IdCredit,'HardCheck','*','PaOtherPhoneUseSameCityCount',v_OtherPhoneUseSameCityCount,v_Seq+1);
       v_Seq:=v_Seq + 1;

       --1. SumAgrSameOffPhoneLast6M:客户在申请此合同时，客户办公号码在过去6个月被其他客户（作为申请人办公号码）
       --使用过的可衡量30天逾期的合同数( select sum(agr_fpd30) from risk_control.df_pd_sum_gl)
       --2. SumDefSameOffPhoneLast6M:客户在申请此合同时，客户办公号码在过去6个月被其他客户（作为申请人办公号码）
       --使用过的出现30天逾期的合同数( select sum(fpd30) from risk_control.df_pd_sum_gl)
       for cs in(select nvl(sum(decode(a.agr_fpd30,null,0,a.agr_fpd30)),0) agr_fpd30,
                 nvl(sum(decode(a.fpd30,null,0,a.fpd30)),0) fpd30
                 from mv_df_pd_sum_gl a
                 join cs_contact b on b.id_credit=a.id_credit
                 where b.contact_type='3'
                 and b.contact_value in(select contact_value from cs_contact c
                                      where c.contact_type='3' and c.person_type='1' and c.id_credit=p_IdCredit)
                 and b.update_time>=trunc(v_CommitTime-180) and b.update_time<=v_CommitTime)
       loop
         insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                values(p_IdCredit,'HardCheck','*','PaSumAgrSameOffPhoneLast6M',cs.agr_fpd30,v_Seq+1);
           v_Seq:=v_Seq + 1;
         insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                values(p_IdCredit,'HardCheck','*','PaSumDefSameOffPhoneLast6M',cs.fpd30,v_Seq+1);
           v_Seq:=v_Seq + 1;
       end loop;
       
       --客户在申请此合同时通过状态的合同数量（状态为a/k/p）
       for pre_credit in (select count(1) sumdue,sum(credit_amount) sumamount from cs_credit where id_person=v_IdPerson and id!=p_IdCredit and status in ('a','k','p'))
       loop
           insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                values(p_IdCredit,'HardCheck','*','PaSumPassContract',pre_credit.sumdue,v_Seq+1);
           v_Seq:=v_Seq + 1;
           --客户在申请此合同时通过状态的合同贷款额之和（状态为a/k/p）
           --select count(sum(prev_credit_amount)) into v_Count from v_previous_contract where prev_status in ('a','k','p') and id_credit=p_IdCredit group by id_credit;
           insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                values(p_IdCredit,'HardCheck','*','PaSumPassCreditAmount',pre_credit.sumamount,v_Seq+1);
           v_Seq:=v_Seq + 1;
       end loop;

       for pre_credit in (select to_char(max(commit_time),'yyyy-MM-dd HH24:mi:ss') commit_time,count(1) sumdue,sum(annuity) annuity from cs_credit where id_person=v_IdPerson and commit_time<=v_CommitTime and id!=p_IdCredit and status ='a')
       loop
           --客户在申请此合同时现行状态的合同的每期期款之和(状态为a）
           --select count(sum(prev_annuity)) into v_Count from v_previous_contract where prev_status='a' and id_credit=p_IdCredit group by id_credit;
           insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                values(p_IdCredit,'HardCheck','*','PaSumSurplusValueInstalment',pre_credit.annuity,v_Seq+1);
           v_Seq:=v_Seq + 1;
       end loop;

       for phone_depository in (select relationship,contact_value,status,contact_type,id_sellerplace,city from v_phone_depository where id_credit=p_IdCredit)
       loop
          if phone_depository.relationship='client' and phone_depository.contact_type='2' then
              --客户在申请此合同时，前6个月内客户手机号码被使用过次数
              insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                   select p_IdCredit,'HardCheck','*','PaSameMobileLast6Month',count(1),v_Seq+1 from v_phone_depository
                    where contact_value=phone_depository.contact_value and contact_type='2' and relationship='client'
                    and id_person!=v_IdPerson and status not in('r','t') and commit_time>=sysdate-180 and commit_time<=v_CommitTime;
              v_Seq:=v_Seq + 1;
              --客户在申请此合同时，客户手机号码被历史其他客户（作为申请人移动电话）使用过的次数（除状态为t,d,r的合同）
              insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                   select p_IdCredit,'HardCheck','*','PaSameMobileHisCount',count(1),v_Seq+1 from v_phone_depository
                    where contact_value=phone_depository.contact_value and contact_type='2' and relationship='client'
                    and id_person!=v_IdPerson and status not in('d','t','r') and commit_time<=v_CommitTime;
              v_Seq:=v_Seq + 1;
              --客户办公电话在过去30天在同个城市被其他人重复使用为办公电话的情况；状态不等于tr 使用过的次数（除状态为t,r的合同）----------------------
              insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                   select p_IdCredit,'HardCheck','*','PaMobPhoneUseSameCityCount',count(1),v_Seq+1 from v_phone_depository
                    where contact_value=phone_depository.contact_value and id_person!=v_IdPerson and commit_time>=sysdate-30
                     and commit_time<=v_CommitTime and status not in('t','r') and city=phone_depository.city;
              v_Seq:=v_Seq + 1;
              --客户办公电话在过去30天在同个城市被其他人重复使用为办公电话的情况；状态不等于tr 使用过的次数（除状态为t,r的合同）
              insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                   select p_IdCredit,'HardCheck','*','MobPhoneUseSamePosCount',count(1),v_Seq+1 from v_phone_depository
                    where contact_value=phone_depository.contact_value and id_person!=v_IdPerson and commit_time>=sysdate-30
                     and commit_time<=v_CommitTime and status not in('t','r') and id_sellerplace=phone_depository.id_sellerplace;
              v_Seq:=v_Seq + 1;
              --客户在申请此合同时，客户手机号码存在，在职SA移动电话列表
              select count(1) into v_Count from sys_user_list a where upper(a.role_id)='SA' and a.phone=phone_depository.contact_value;
              if v_Count>0 then
                 insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                   values(p_IdCredit,'HardCheck','*','PaSAMobilelist','1',v_Seq+1);
                 v_Seq:=v_Seq + 1;
              end if;
          elsif phone_depository.relationship='client' and phone_depository.contact_type='18' then
              --客户在申请此合同时，客户家庭固话被历史其他客户（作为家庭固话）使用过的次数（除状态为t,d,r的合同）--------------------------------------
              insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                   select p_IdCredit,'HardCheck','*','PaFamilyPhoneHisUseCount',count(1),v_Seq+1 from v_phone_depository
                    where contact_value=phone_depository.contact_value and contact_type='18' and relationship='client'
                     and commit_time<=v_CommitTime and id_person!=v_IdPerson and status not in('d','t','r');
              v_Seq:=v_Seq + 1;
          elsif phone_depository.relationship='family' then
              --家庭成员电话在最近180天被其他不同的客户用作其他所有电话（办公电话除外）的次数
              select count(distinct(id_credit||contact_value)) into v_Count from v_phone_depository
              where contact_value=phone_depository.contact_value and id_person!=v_IdPerson and commit_time>=sysdate-180 and commit_time<=v_CommitTime and status not in('t','r');
              v_FamilyPhoneUseCount:=v_FamilyPhoneUseCount+v_Count;
              --家庭成员电话在过去30天在同个城市被其他人重复使用的情况；状态不等于tr的次数
              select count(distinct(id_credit||contact_value)) into v_Count from v_phone_depository
              where contact_value=phone_depository.contact_value and id_person!=v_IdPerson and commit_time>=sysdate-30 and commit_time<=v_CommitTime and status not in('t','r') and city=phone_depository.city;
              v_FamilyPhoneUseSameCityCount:=v_FamilyPhoneUseSameCityCount+v_Count;
              --家庭成员电话在过去30天在同个门店被其他人重复使用的情况；状态不等于tr的次数
              select count(distinct(id_credit||contact_value)) into v_Count from v_phone_depository
              where contact_value=phone_depository.contact_value and id_person!=v_IdPerson and commit_time>=sysdate-30 and commit_time<=v_CommitTime and status not in('t','r') and id_sellerplace=phone_depository.id_sellerplace;
              v_FamilyPhoneUseSamePosCount:=v_FamilyPhoneUseSamePosCount+v_Count;
          elsif phone_depository.relationship='others' then
              --其他联系人电话在最近180天被其他不同的客户用作其他所有电话（办公电话除外）的次数
              select count(distinct(id_credit||contact_value)) into v_Count from v_phone_depository
              where contact_value=phone_depository.contact_value and id_person!=v_IdPerson and commit_time>=sysdate-180 and commit_time<=v_CommitTime and status not in('t','r');
              v_OtherPhoneUseCount:=v_OtherPhoneUseCount+v_Count;
              v_Seq:=v_Seq + 1;
              --其他联系人电话在过去30天在同个城市被其他人重复使用的情况；状态不等于tr的次数
              select count(distinct(id_credit||contact_value)) into v_Count from v_phone_depository
              where contact_value=phone_depository.contact_value and id_person!=v_IdPerson and commit_time>=sysdate-30 and commit_time<=v_CommitTime and status not in('t','r') and city=phone_depository.city;
              v_OtherPhoneUseSameCityCount:=v_OtherPhoneUseSameCityCount+v_Count;
              v_Seq:=v_Seq + 1;
              --其他联系人电话在过去30天在同个门店被其他人重复使用的情况；状态不等于tr的次数
              select count(distinct(id_credit||contact_value)) into v_Count from v_phone_depository
              where contact_value=phone_depository.contact_value and id_person!=v_IdPerson and commit_time>=sysdate-30 and commit_time<=v_CommitTime and status not in('t','r') and id_sellerplace=phone_depository.id_sellerplace;
              v_OtherPhoneUseSamePosCount:=v_OtherPhoneUseSamePosCount+v_Count;
              v_Seq:=v_Seq + 1;
          end if;
       end loop;
       
        --2017/05/24 wangxiaofeng
        --HardCheck FamilyPhoneUpdateCount:客户在申请此合同时该客户之前更改了家庭联系人电话的次数
        --HardCheck ThirdPhoneUpdateCount:客户在申请此合同时该客户之前更改了第三方联系人电话的次数
        for c in(select count(distinct case when person_type in ('其他亲戚','配偶','父母','兄弟姐妹','儿女') then t.contact_value else null end) familyphoneupdatecount
                ,count(distinct case when person_type='第三方' then t.contact_value else null end) thirdphoneupdatecount
                from cs_contact_portion t
                where t.status in(1,3) and t.contact_type='移动电话'
                and t.person_type in('其他亲戚','配偶','父母','兄弟姐妹','儿女','第三方') and t.id_person=v_IdPerson and t.update_time<v_CommitTime--2017-09-22增加时间范围
        )loop
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
           values(p_IdCredit,'HardCheck','*','PaFamilyPhoneUpdateCount',c.familyphoneupdatecount,v_Seq+1);
          v_Seq:=v_Seq + 1;
        end loop;

       --家庭成员电话在最近180天被其他不同的客户用作其他所有电话（办公电话除外）总的次数
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            values(p_IdCredit,'HardCheck','*','PaFamilyPhoneUseCount',v_FamilyPhoneUseCount,v_Seq+1);
       v_Seq:=v_Seq + 1;

       --家庭成员电话在过去30天在同个城市被其他人重复使用的情况；状态不等于tr（办公电话除外）总的次数
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            values(p_IdCredit,'HardCheck','*','PaFamilyPhoneUseSameCityCount',v_FamilyPhoneUseSameCityCount,v_Seq+1);
       v_Seq:=v_Seq + 1;
       
         --2016/12/02 wangxiaofeng 在hardcheck类别添加元素IsFpd10SamePhoneLast6M
         --客户在申请合同时，客户号码（不包含办公电话号码）在过去6个月被其他申请人使用时是否出现fpd10 逾期
         insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         select p_IdCredit,'HardCheck','*','PaIsFpd10SamePhoneLast6M',decode(nvl(sum(m.fpd10),0),0,0,1),v_Seq+1
         from v_phone_depository a
         join mv_df_pd_sum_gl m on m.contract_no=a.contract_no
         where a.credit_type='SS' and a.status in('a','p','k')
         and a.contact_type in('2','18','19') and a.commit_time>=trunc(sysdate-180)
         and a.contact_value in(select b.contact_value from cs_contact b where b.contact_type in('2','18','19') and b.id_credit=p_IdCredit);
         v_Seq:=v_Seq + 1;
         
       --客户在申请此合同时，非客户本人的手机号码在过去6个月被其他客户用作非本人的手机号码相同且姓名不同的次数（除状态为t，r的合同）
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'HardCheck','*','PaMobileUseDiffNameCountLast6M',count(1),v_Seq+1
       from cs_credit t
       join cs_contact a on a.id_credit=t.id and a.person_type!='1' and a.contact_type='2'
       join cs_other_person b on b.id_credit=a.id_credit and b.person_type=a.person_type
       join (select e.name,g.contact_value from cs_contact g
            join cs_other_person e on e.id_credit=g.id_credit and e.person_type=g.person_type
            where g.person_type!='1' and g.contact_type='2' and g.id_credit=p_IdCredit
            ) c on c.contact_value=a.contact_value and b.name!=c.name
       where t.id_person!=v_IdPerson and t.status not in('t','r')
       and t.id_sa not in ('800079','888888','300079') and t.credit_type='SS'
       and t.commit_time>v_CommitTime-180 and t.commit_time<v_CommitTime;

       --同一年龄下在过去1个月（<30天）的QQ平均长度 2016/07/07 wangxiaofeng
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'HardCheck','*','PaLast1MonthQQAvgLen',round(nvl(sum(qq_length),0)/decode(count(1),0,1,count(1)),4),v_Seq+1
       from mv_qq_length_30 t where t.birth_year=substr(v_Ident,7,4);

       --同一年龄下在过去3个月（<90天）的QQ平均长度
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'HardCheck','*','PaLast3MonthQQAvgLen',round(nvl(sum(qq_length),0)/decode(count(1),0,1,count(1)),4),v_Seq+1
       from mv_qq_length t where t.birth_year=substr(v_Ident,7,4);

        /*Last3mCpd_Cnt：最近3个月cpd>0的次数  yangzhenxian    2018-03-23*/
          select count(1) into v_Count from cs_credit c
          join df_pd_detail_gl pd on c.contract_no=pd.contract_no
          where c.id_person=v_IdPerson and c.CREDIT_TYPE in ('SS','SC','POS') and c.status in ('a','p','k')
          and c.app_date<v_AppDate and date_due>=add_months(v_AppDate,-3) and date_due < v_AppDate and  max_cpd>0 ;

          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
           values( p_IdCredit,'HardCheck','*','PaLast3mCpd_Cnt',v_Count,v_Seq+1 );
          v_Seq:=v_Seq + 1;
          

       --IsSAIdent客户申请时,身份证是否属于销售代表/销售经理/门店法人身份证
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'HardCheck','*','PaIsSAIdent',case when sum(amount)>0 then 1 else 0 end,v_Seq
       from (
         select count(1) amount from sys_user_list a where upper(a.role_id) in('SA','DSM','MENTOR') and a.ident=v_Ident
         union
         select count(1) amount from seller where legal_ident=v_Ident);
       v_Seq:=v_Seq + 1;



  --是否查得同盾数据FraudMetrixActive (1, 查得; 0, 未查得)
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'HardCheck','*','PaFraudMetrixActive',decode(count(1),0,0,1),v_Seq
       from wfi_fraud_metrix_result t where t.event_name='Credit' and t.associated_id=p_IdCredit;
       v_Seq:=v_Seq + 1;
       
       -- 过去半小时内同盾未查得合同数FraudMetrixFailedCount 2017/03/03 update
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'HardCheck','*','PaFraudMetrixFailedCount',count(1),v_Seq
       from cs_credit a where not exists(select 1 from wfi_fraud_metrix_result b
                                           where b.event_name='Credit'  and b.associated_id=a.id)
                         and a.status not in('r','t') and nvl(a.inter_code,0) not in(3,4)
                         and a.credit_type=decode(v_CreditType,'SC','SC','SS','SS','SP','SP','XF')
                         and a.create_time>=v_CommitTime-35/24/60 and a.create_time<=v_CommitTime-5/24/60;
       v_Seq:=v_Seq + 1;
       
       
       --BlackListCateFraudMetrix:同盾黑名单分类
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select  p_IdCredit,'HardCheck','*','PaBlackListCateFraudMetrix',substr(max(case when rule_no in (
          840098,2900153,2901749,2992525,840072,891780,891784,2900089,840080,840116,2992509,2992523,2992511,2901741,840076,
          891788,2901719,2992521,891804,840106,2901711,2992507,840096,891814,2901715,11532,14130,840100,78586,891806,891824,891808,
          5638201,5640421,5640431,5640411) then '9失信名单'
          when rule_no in (840086,2901725,891794,891816,2901743,840108,840118,2901751,891826) then '8灰名单'
          when rule_no in (2900149,891792,2901723,840084,584894) then '7已结案名单'
          when rule_no in (2900083,2901761,2901759,891782,840074,2901713,840082,891790,891802,840094,891812,891832,891834,891836,
            2901731,891828,840120,891830,840122,11534,840104,840126,44126,15726,840124,840128) then '6低风险失信名单'
          else '0其他' end),2,10) BlackListCateFraudMetrix,v_Seq
          from WFI_FRAUD_METRIX_RESULT a join WFI_FRAUD_METRIX_RULE t on a.id=t.fraud_metrix_result_id
          where a.event_name='Credit' and a.associated_id=p_IdCredit
          group by a.associated_id;
          v_Seq:=v_Seq + 1;
       

       --3个月内借款平台数MultiLoanTypeCountFraudMetrix3M: rule_name='新_3个月内申请人身份证或手机在多个平台申请借款'，从extra_data中取值
       select nvl(max(b.extra_data),0) into v_Count
       from WFI_FRAUD_METRIX_RESULT a
       join WFI_FRAUD_METRIX_RULE b on a.id=b.fraud_metrix_result_id
       where b.rule_no in(1044388,1053416)
             and a.event_name='Credit' and a.associated_id=p_IdCredit;

       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
              values(p_IdCredit,'HardCheck','*','PaMultiLoanTypeCountFraudMetrix3M',v_Count,v_Seq);
       v_Seq:=v_Seq + 1;
 
        --2018/05/29 majianfeng MultiLoanP2PCountFraudMetrix1M：近一个月命中同盾P2P网贷的次数元素代码
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
           SELECT p_IdCredit,'HardCheck','*','PaMultiLoanP2PCountFraudMetrix1M',nvl(
           (select MultiLoanP2PCountFraudMetrix1M from (SELECT a.ASSOCIATED_ID as id_credit,
               MAX(CASE WHEN INSTR(SUBSTR(RULE_DETAIL,instr(rule_detail, 'P2P网贷') + 6),',') > 0
               THEN SUBSTR(SUBSTR(RULE_DETAIL,instr(rule_detail, 'P2P网贷') + 6),1,instr(SUBSTR(RULE_DETAIL,instr(rule_detail, 'P2P网贷') + 6),',') - 1)
               ELSE SUBSTR(RULE_DETAIL, instr(rule_detail, 'P2P网贷') + 6, 3)END) AS MultiLoanP2PCountFraudMetrix1M
          from WFI_FRAUD_METRIX_RESULT a
          left join WFI_FRAUD_METRIX_RULE t
            on a.id = t.fraud_metrix_result_id
         where  a.ASSOCIATED_ID=p_IdCredit  and  A.EVENT_NAME = 'Credit'  AND T.RULE_NAME = '新_1个月内申请人身份证或手机在多个平台申请借款' and rule_detail like '%P2P网贷%'
         GROUP BY a.ASSOCIATED_ID) ), 0),v_Seq
          from dual;

       --1天内借款平台数MultiLoanTypeCountFraudMetrix1D: majianfeng 2018/05/16
       select nvl(max(b.extra_data),0) into v_Count
       from WFI_FRAUD_METRIX_RESULT a
       join WFI_FRAUD_METRIX_RULE b on a.id=b.fraud_metrix_result_id
       where b.rule_no in(1049650,1053410)
             and a.event_name='Credit' and a.associated_id=p_IdCredit;
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
              values(p_IdCredit,'HardCheck','*','PaMultiLoanTypeCountFraudMetrix1D',v_Count,v_Seq+1);
       v_Seq:=v_Seq + 1;


       --1个月内借款平台数MultiLoanTypeCountFraudMetrix1M: rule_name='新_1个月内申请人身份证或手机在多个平台申请借款'，从extra_data中取值
       select nvl(max(b.extra_data),0) into v_Count
       from WFI_FRAUD_METRIX_RESULT a
       join WFI_FRAUD_METRIX_RULE b on a.id=b.fraud_metrix_result_id
       where b.rule_no in(1044438,1053414)
             and a.event_name='Credit' and a.associated_id=p_IdCredit;
             
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
              values(p_IdCredit,'HardCheck','*','PaMultiLoanTypeCountFraudMetrix1M',v_Count,v_Seq+1);
       v_Seq:=v_Seq + 1;
       v_Count:=0;
       
       --新_7天内申请人身份证或手机在多个平台申请借款   majianfeng 2018/07/23
       select nvl(max(b.extra_data),0) into v_Count
        from WFI_FRAUD_METRIX_RESULT a
         join WFI_FRAUD_METRIX_RULE b on a.id=b.fraud_metrix_result_id
          where b.rule_no in(1049606,1053412) and a.event_name='Credit' and a.associated_id=p_IdCredit;
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
              values(p_IdCredit,'HardCheck','*','PaMultiLoanTypeCountFraudMetrix7D',v_Count,v_Seq+1);
       v_Seq:=v_Seq + 1;
       v_Count:=0;
          
          /*  MultiLoanTypeCountSmallLoanCompanies1M(新_1个月内申请人身份证或手机在小额贷款公司申请借款)   yangzhenxian  2018-10-30   */
          for d in (
              WITH td_mul_detail_data AS
              (
              SELECT a.associated_id as id_credit,
                     CASE WHEN  instr(rule_detail, '小额贷款公司')>0 THEN 
                          CASE WHEN INSTR(SUBSTR(RULE_DETAIL,instr(rule_detail, '小额贷款公司')+7),',')>0 THEN SUBSTR(SUBSTR(RULE_DETAIL,instr(rule_detail, '小额贷款公司')+7),1,INSTR(SUBSTR(RULE_DETAIL,instr(rule_detail, '小额贷款公司')+7), ',')-1)
                                                                                                         ELSE SUBSTR(RULE_DETAIL,instr(rule_detail, '小额贷款公司')+7,3) END 
                          ELSE NULL END
                     AS Small_loan_companies_1M,
                     row_number() over(partition by a.associated_id,t.rule_name order by t.extra_data DESC,t.update_time DESC) as rank 
              from WFI_FRAUD_METRIX_RESULT a
              join WFI_FRAUD_METRIX_RULE t on a.id=t.fraud_metrix_result_id 
              where a.event_name='Credit' AND t.rule_no IN (22719304,1053414,2902207,16602803,1044438) and a.ASSOCIATED_ID=p_IdCredit
              )
              select * FROM td_mul_detail_data WHERE RANK=1
            )loop
            if d.Small_loan_companies_1M is not null then
              insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values( p_IdCredit,'HardCheck','*','PaMultiLoanTypeCountSmallLoanCompanies1M',d.Small_loan_companies_1M,v_Seq+1 );
              v_Seq:=v_Seq + 1;
            end if;     
          end loop;

       -- 1个月内借款平台类型MultiLoanTypeFraudMetrix1M: rule_name='新_1个月内申请人身份证或手机在多个平台申请借款', 根据rule_detail计算取值；
       --计算时排除本平台（本平台类型为'一般消费分期平台')，当命中多个平台类型时，只取一个，
       --按以下顺序优先(小额贷款:MC,一般消费:CFC_NL,大型消费:CFC,P2P网贷:P2P,其他:Z)
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'HardCheck','*','PaMultiLoanTypeFraudMetrix1M',
       case when replace(b.rule_detail,'一般消费分期平台:1','') like '%小额贷款%' then 'MC'
       when replace(b.rule_detail,'一般消费分期平台:1','') like '%一般消费分期平台%' then 'CFC_NL'
       when replace(b.rule_detail,'一般消费分期平台:1','') like '%消费金融%' then 'CFC'
       when replace(b.rule_detail,'一般消费分期平台:1','') like '%P2P%' then 'P2P'
       else 'Z' end,v_Seq+1
       from WFI_FRAUD_METRIX_RESULT a
       join WFI_FRAUD_METRIX_RULE b on a.id=b.fraud_metrix_result_id
       where b.rule_no in(1044438,1053414)
             and a.event_name='Credit' and a.associated_id=p_IdCredit;

       --3个月内借款平台类型MultiLoanTypeFraudMetrix3M: rule_name='新_3个月内申请人身份证或手机在多个平台申请借款', 根据rule_detail计算取值；
       --计算时排除本平台（本平台类型为'一般消费分期平台')，当命中多个平台类型时，只取一个，
       --按以下顺序优先(小额贷款:MC,一般消费:CFC_NL,大型消费:CFC,P2P网贷:P2P,其他:Z)
       --b.rule_name in ('新_3个月内申请人身份证或手机在多个平台申请借款')
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'HardCheck','*','PaMultiLoanTypeFraudMetrix3M',
       case when replace(b.rule_detail,'一般消费分期平台:1','') like '%小额贷款%' then 'MC'
       when replace(b.rule_detail,'一般消费分期平台:1','') like '%一般消费分期平台%' then 'CFC_NL'
       when replace(b.rule_detail,'一般消费分期平台:1','') like '%消费金融%' then 'CFC'
       when replace(b.rule_detail,'一般消费分期平台:1','') like '%P2P%' then 'P2P'
       when replace(b.rule_detail,'一般消费分期平台:1','') like '%财产保险%' then 'CX'
       when replace(b.rule_detail,'一般消费分期平台:1','') like '%理财机构%' then 'LO'
       when replace(b.rule_detail,'一般消费分期平台:1','') like '%互联网金融%' then 'TF'
       else 'Z' end,v_Seq+1
       from WFI_FRAUD_METRIX_RESULT a
       join WFI_FRAUD_METRIX_RULE b on a.id=b.fraud_metrix_result_id
       where b.rule_no in(1044388,1053416)
             and a.event_name='Credit' and a.associated_id=p_IdCredit;
      
  
       --  ThirdService：第三方服务商  majianfeng 2018/07/23
       select  max(case when instr(rule_detail,'第三方服务商')>0 then 1 else 0 end ) into  v_Count   ----未命中，未查得则为0
        from WFI_FRAUD_METRIX_RESULT a
        left join WFI_FRAUD_METRIX_RULE t on a.id=t.fraud_metrix_result_id
        where a.event_name='Credit'  and a.associated_id=p_IdCredit;
        insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
              values(p_IdCredit,'HardCheck','*','PaThirdService',v_Count,v_Seq+1);
       v_Seq:=v_Seq + 1;
       v_Count:=0;
       
       
      /*在网时长元素需求MobileOnlineTime  yangzhenxian  2018-12-19*/
      for d in (
          with temp as(
          select p.id_credit,
                 case when p.period in ('(0,3]','[0,3)') then '(0,3)'
                      when p.period in ('(3,6]','[3,6)') then '(3,6)'
                      when p.period in ('(6,12]','[6,12)') then '(6,12)'
                      when p.period in ('(12,24]','[12,24)') then '(12,24)'
                      when p.period in ('(24,+)','[24,+)') then '(24,+)'                       
                      when p.period in ('T-1月前已离网','已离网或新入网用户') then '已离网'
                 else p.period end as period   --------为空时不生成该元素 
          from mobile_online_period p
           where p.id_credit=p_IdCredit order by p.create_time desc
           )
          select period from temp where rownum=1
        )loop
          if d.period is not null
          then 
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'HardCheck','*','PaMobileOnlineTime',d.period,v_Seq+1 );
            v_Seq:=v_Seq + 1;
          end if;
        end loop;
 
       
  ------------------------------------------------------------------------------
      /*一个白骑士的元素FinalDecision  yangzhenxian  2019-03-18*/
      for d in (
          with temp as(
          select id_cerdit id_credit,final_decision from BAIQISHI_DECISION_RESULT p
           where p.id_cerdit=p_IdCredit order by p.create_time desc
           )
          select final_decision from temp where rownum=1
        )loop
          if d.final_decision is not null
          then 
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'External','BaiQiShi','PaFinalDecision',d.final_decision,v_Seq+1 );
            v_Seq:=v_Seq + 1;
          end if;
        end loop;
   
    --------------------------------------------------------------------------
    for d in (
        select * from (select t.flag_stability_c,STAB_AUTH_NAME from external_br_stability_c t
       where t.id_credit=p_IdCredit order by t.create_time desc) where rownum=1
      )loop
      -------3.增加元素External. BaiRong. FlagStability/*特殊名单核查产品输出标识*/
      insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       values( p_IdCredit,'External','BaiRong','PaFlagStability',d.flag_stability_c,v_Seq+1 );
      v_Seq:=v_Seq + 1;

      -------增加元素External. BaiRong. AuthName  百融稳定性库中姓名是否匹配  2018-04-18 yangzhenxian
      insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       values( p_IdCredit,'External','BaiRong','PaAuthName',nvl(d.stab_auth_name,-1),v_Seq+1 );
      v_Seq:=v_Seq + 1;
    end loop;

       /*过去半个小时内百融多次借贷未查得合同数BRApplyLoanFailedCount           yangzhenxian   2018/04/27 add      2019/01/22  update*/
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'External','BaiRong','PaBRApplyLoanFailedCount',count(1),v_Seq+1
       from cs_credit a where not exists(select 1 from external_br_applyloan b
                                           where b.code<>9999 and b.id_credit=a.id)
                         and a.status not in('r','t') and nvl(a.inter_code,0) not in(3,4)
                         and a.credit_type=decode(v_CreditType,'SC','SC','SS','SS','XF','XF','SP')
                         and a.commit_time>=v_CommitTime-35/24/60 and a.commit_time<=v_CommitTime-5/24/60;
       v_Seq:=v_Seq + 1;
      --BRCreditcardDef3M: 最近3个月信用卡是否逾期
      select count(1) into v_Count
      from external_br_accountchangemonth t
      where t.acm_m1_credit_def is not null and t.acm_m2_credit_def is not null
       and t.acm_m3_credit_def is not null and t.id_credit=p_IdCredit;
      if v_Count>=1 then
        --BRCreditcardDef3M: 最近3个月信用卡是否逾期
        insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
        select p_IdCredit,'External','BaiRong','PaBRCreditcardDef3M',
        nvl(t.acm_m1_credit_def,0)+nvl(t.acm_m2_credit_def,0)+nvl(t.acm_m3_credit_def,0),v_Seq+1
        from external_br_accountchangemonth t where t.id_credit=p_IdCredit;
        v_Seq:=v_Seq + 1;
      end if;

      --BRMultiLoanCountNotBank12M: 最近12个月身份证或手机在非银行借款次数，排除本机构，取ident_notbank,mobilephone_notbank的较大值
      insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
      select p_IdCredit,'External','BaiRong','PaBRMultiLoanCountNotBank12M',
      case when (nvl(t1.al_m12_id_notbank_allnum,0)-nvl(t1.al_m12_id_notbank_selfnum,0))-
      (nvl(t1.al_m12_cell_notbank_allnum,0)-nvl(t1.al_m12_cell_notbank_selfnum,0))>0 then
      (nvl(t1.al_m12_id_notbank_allnum,0)-nvl(t1.al_m12_id_notbank_selfnum,0)) else
      (nvl(t1.al_m12_cell_notbank_allnum,0)-nvl(t1.al_m12_cell_notbank_selfnum,0)) end,
      v_Seq+1
      from external_br_applyloan t1 where t1.id_credit=p_IdCredit;
      v_Seq:=v_Seq + 1;
      --BRMultiLoanCountBank12M: 最近12个月身份证或手机在银行借款次数，取ident_bank,mobilephone_bank较大值
      insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
      select p_IdCredit,'External','BaiRong','PaBRMultiLoanCountBank12M',
      case when nvl(t1.al_m12_id_bank_allnum,0)-nvl(t1.al_m12_cell_bank_allnum,0)>0 then
      nvl(t1.al_m12_id_bank_allnum,0) else
      nvl(t1.al_m12_cell_bank_allnum,0) end,
      v_Seq+1
      from external_br_applyloan t1 where t1.id_credit=p_IdCredit;
      v_Seq:=v_Seq + 1;

    --百融评分 External. BaiRong. BRScore 2016/11/03 wangxiaofeng --
    insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
      select p_IdCredit,'External','BaiRong','PaBRScore',t.scoreconsoffv2,v_Seq+1
      from external_br_rules t
      where t.scoreconsoffv2 is not null and t.id_credit=p_IdCredit;
      v_Seq:=v_Seq + 1;
      
      --BRScorecardActive: 是否命中百融评分卡(1,命中; 0,未命中)，满足以下条件之一即命中
      insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
      select p_IdCredit,'External','BaiRong','PaBRScorecardActive',decode(count(1),0,0,1),v_Seq+1
      from external_br_accountchangemonth t2
      join external_br_applyloan t1 on t1.id_credit=t2.id_credit
      where ((nvl(t1.al_m12_id_notbank_allnum,0)-nvl(t1.al_m12_id_notbank_selfnum,0)>0
           or nvl(t1.al_m12_cell_notbank_allnum,0)-nvl(t1.al_m12_cell_notbank_selfnum,0)>0
           or nvl(t1.al_m12_id_bank_allnum,0)>0 or nvl(t1.al_m12_cell_bank_allnum,0)>0
           or nvl(t2.flag_accountchangemonth,0)=1))
           and t2.id_credit=p_IdCredit;
      v_Seq:=v_Seq + 1;
      
      
      -------2.增加元素External. BaiRong. FlagSpeciallist/*稳定性评估产品输出标识*/
    insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select ID_CREDIT,'External','BaiRong','PaFlagSpeciallist',flag_speciallist_c,v_Seq+1
       from (select ID_CREDIT,t.flag_speciallist_c from external_br_speciallist_c t
       where t.id_credit=p_IdCredit order by t.create_time desc) where rownum=1 ;
      v_Seq:=v_Seq + 1;
     

       for phone_depository in (select relationship,contact_value,status,contact_type,id_sellerplace,city from v_phone_depository where id_credit=p_IdCredit)
       loop
          if phone_depository.relationship='client' and phone_depository.contact_type='2' then
              --客户在申请此合同时，客户手机号码存在，在职SA移动电话列表
              select count(1) into v_Count from sys_user_list a where upper(a.role_id)='SA' and a.phone=phone_depository.contact_value;
              if v_Count>0 then
                 insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                   values(p_IdCredit,'HardCheck','*','PaSAMobilelist','1',v_Seq+1);
                 v_Seq:=v_Seq + 1;
              end if;
             end if;
       end loop;

      --------------------按身份证号查询，近12个月在非银机构-消费类分期申请机构数 yangzhenxian   2017-12-06
      insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'External','BaiRong','PaIdentNBank12M',IdentNBank12M,v_Seq+1
       from (select t.ALS_M12_ID_NBANK_CF_ORGNUM IdentNBank12M from external_br_applyloan t
       where t.id_credit=p_IdCredit order by t.create_time desc) where rownum=1 ;
      v_Seq:=v_Seq + 1;

      --------------------按身份证号查询，近12个月在非银机构-消费类分期申请机构数 yangzhenxian   2017-12-06
      insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'External','BaiRong','PaIdentNBank1M',IdentNBank1M,v_Seq+1
       from (select t.ALS_M1_ID_NBANK_CF_ORGNUM IdentNBank1M from external_br_applyloan t
       where t.id_credit=p_IdCredit order by t.create_time desc) where rownum=1 ;
      v_Seq:=v_Seq + 1;

      --------------------按身份证号查询，近6个月在非银机构-其他申请次数 yangzhenxian   2017-12-06
      insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'External','BaiRong','PaIdentNBank6M',IdentNBank6M,v_Seq+1
       from (select t.ALS_M6_ID_NBANK_OTH_ALLNUM IdentNBank6M from external_br_applyloan t
       where t.id_credit=p_IdCredit order by t.create_time desc) where rownum=1 ;
      v_Seq:=v_Seq + 1;

     -------begin 2017/11/02 machaochun-----
    for d in (
        select * from (select ID_CREDIT,nvl(t.als_lst_id_nbank_inteday,0) IdentNBankIteDay 
        ,nvl(t.ALS_M12_CELL_NBANK_AVG_MONNUM,0) MobileApplyCountNotBank12M ,nvl(t.AL_M12_ID_NOTBANK_ORGNUM,0) IdentNBankORG12M,nvl(t.ALS_M6_CELL_NBANK_OTH_ORGNUM,0) BRCellNBankORG6M
        from external_br_applyloan t
       where t.id_credit=p_IdCredit order by t.create_time desc) where rownum=1
      )loop
      -------1.增加元素External. BaiRong. IdentNBankIteDay/*按身份证号查询，距最近在非银行机构申请的间隔天数*/
      insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       values( p_IdCredit,'External','BaiRong','PaIdentNBankIteDay',d.IdentNBankIteDay,v_Seq+1 );
      v_Seq:=v_Seq + 1;

      -------2.  External.BaiRong. MobileApplyCountNotBank12M：按手机号查询，近12个月在非银机构平均每月申请次数 (可参考External.BaiRong.IdentNBankIteDay)
      -------2019-03-07 yangzhenxian
      insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       values( p_IdCredit,'External','BaiRong','PaMobileApplyCountNotBank12M',d.MobileApplyCountNotBank12M,v_Seq+1 );
      v_Seq:=v_Seq + 1;      

      -------外部数据库--百融--- IdentNBankORG12M  近12个月在非银机构平台数
      -------2019-04-02 yangzhenxian
      insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       values( p_IdCredit,'External','BaiRong','PaIdentNBankORG12M',nvl(d.IdentNBankORG12M,-1),v_Seq+1 );
      v_Seq:=v_Seq + 1;
      
      -------2019-08-22 yangzhenxian
      insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       values( p_IdCredit,'External','BaiRong','PaBRCellNBankORG6M',d.BRCellNBankORG6M,v_Seq+1 );
      v_Seq:=v_Seq + 1;
    end loop;

      --------------------近6个月身份证在百融非银合作机构申请机构数 yangzhenxian   2017-12-21
      for d in (
          with temp as(
          select t.AL_M6_ID_NOTBANK_ORGNUM as IdentNBankORG6M from external_br_applyloan t
          where t.id_credit=p_IdCredit order by t.create_time desc)
          select  IdentNBankORG6M from temp where rownum=1
        )loop
        insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         values( p_IdCredit,'External','BaiRong','PaIdentNBankORG6M',d.IdentNBankORG6M,v_Seq+1 );
        v_Seq:=v_Seq + 1;
        end loop;

     --------------------身份证关联的手机号个数 yangzhenxian   2017-12-06
      for d in(
        with temp as(select t.IR_ID_X_CELL_CNT IdentRelateCell,t.IR_ID_IS_REABNORMAL as IsIdentAbnormal
        ,t.IR_M3_CELL_X_BIZ_ADDR_CNT as MobRelateAddr3M ,t.IR_CELL_X_ID_CNT as MobRelateIdCnt,t.IR_M6_CELL_X_BIZ_ADDR_CNT MobRelateAddr6M
        from external_br_inforelation t where t.id_credit=p_IdCredit order by t.create_time desc)
          select * from temp where rownum=1
        )
      loop
        insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         values(p_IdCredit,'External','BaiRong','PaIdentRelateCell',d.IdentRelateCell,v_Seq+1);
        v_Seq:=v_Seq + 1;

        ------------------身份证号是否关联异常 yangzhenxian    2018-01-15
        insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         values(p_IdCredit,'External','BaiRong','PaIsIdentAbnormal',d.IsIdentAbnormal,v_Seq+1);
        v_Seq:=v_Seq + 1;

        ------------------MobRelateAddr3M:近三个月手机号关联公司地址个数 yangzhenxian    2018-03-23
        insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         values(p_IdCredit,'External','BaiRong','PaMobRelateAddr3M',d.MobRelateAddr3M,v_Seq+1);
        v_Seq:=v_Seq + 1;
        ------------------MobRelateAddr6M:近六个月手机号关联公司地址个数 马剑锋    2018-05-31
         insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         values(p_IdCredit,'External','BaiRong','PaMobRelateAddr6M',d.MobRelateAddr6M,v_Seq+1);
        v_Seq:=v_Seq + 1;

        ------------------MobRelateIdCnt：手机号关联身份证个数 yangzhenxian    2018-03-23
        if d.MobRelateIdCnt is not null
        then
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
           values(p_IdCredit,'External','BaiRong','PaMobRelateIdCnt',d.MobRelateIdCnt,v_Seq+1);
          v_Seq:=v_Seq + 1;
        end if;
      end loop;

      ------------------------外部数据是否查询正常  yangzhenxian  2018-02-06
      /*表external_br_applyloan是否正常*/
      insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'External','BaiRong','PaIsApplyLoan',case when nvl(v_InterCode,'1') in('3','4') then 1 when IsApplyLoan >0 then 1 else 0 end,v_Seq+1
       from (select count(1) IsApplyLoan from external_br_applyloan t where t.id_credit=p_IdCredit) ;
      v_Seq:=v_Seq + 1;

      /*表external_br_speciallist_c是否正常*/
      insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'External','BaiRong','PaIsSpecialList',case when nvl(v_InterCode,'1') in('3','4') then 1 when IsSpecialList>0 then 1 else 0 end,v_Seq+1
       from (select count(1) IsSpecialList from external_br_speciallist_c t where t.id_credit=p_IdCredit) ;
      v_Seq:=v_Seq + 1;

      /*表external_br_stability_c是否正常*/
      insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'External','BaiRong','PaIsStability',case when nvl(v_InterCode,'1') in('3','4') then 1 when IsStability >0 then 1 else 0 end,v_Seq+1
       from (select count(1) IsStability from external_br_stability_c t where t.id_credit=p_IdCredit) ;
      v_Seq:=v_Seq + 1;

      /*表external_br_inforelation是否正常*/
      insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'External','BaiRong','PaIsInforelation',case when nvl(v_InterCode,'1') in('3','4') then 1 when IsInforelation >0 then 1 else 0 end,v_Seq+1
       from (select count(1) IsInforelation from external_br_inforelation t where t.id_credit=p_IdCredit) ;
      v_Seq:=v_Seq + 1;

      /*表external_br_pay_behavior是否正常*/
      insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'External','BaiRong','PaIsBehavior',case when nvl(v_InterCode,'1') in('3','4') then 1 when IsBehavior >0 then 1 else 0 end,v_Seq+1
       from (select count(1) IsBehavior from external_br_pay_behavior t where t.id_credit=p_IdCredit) ;
      v_Seq:=v_Seq + 1;

      /*表external_br_consumption_c是否正常*/
      insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'External','BaiRong','PaIsConsumption',case when nvl(v_InterCode,'1') in('3','4') then 1 when IsConsumption >0 then 1 else 0 end,v_Seq+1
       from (select count(1) IsConsumption from external_br_consumption_c t where t.id_credit=p_IdCredit) ;
      v_Seq:=v_Seq + 1;

      /*百融表是否查询成功*/
      insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'External','BaiRong','PaIsBr',case when nvl(v_InterCode,'1') in('3','4') then 1 when is_applyloan>0 and is_speciallist>0 and is_stability>0 and is_inforelation>0
       and is_pay_behavior>0 and is_consumption_c>0 then 1 else 0 end,v_Seq+1
       from (
            select
            (select count(1)  from external_br_applyloan where id_credit=p_IdCredit ) is_applyloan,
            (select count(1)  from external_br_speciallist_c where id_credit=p_IdCredit ) is_speciallist,
            (select count(1)  from external_br_stability_c where id_credit=p_IdCredit ) is_stability,
            (select count(1)  from external_br_inforelation where id_credit=p_IdCredit ) is_inforelation,
            (select count(1)  from external_br_pay_behavior where id_credit=p_IdCredit ) is_pay_behavior,
            (select count(1)  from external_br_consumption_c where id_credit=p_IdCredit ) is_consumption_c
            from dual
       ) ;
      v_Seq:=v_Seq + 1;

      --------------------商品消费模块最近12个月最大单类目消费次数 yangzhenxian   2017-12-21
      for d in (
          with temp as(
          select t.CONS_MAX_M12_NUM as MaxPayCate12M from external_br_consumption_c t
          where t.id_credit=p_IdCredit order by t.create_time desc)
          select  MaxPayCate12M from temp where rownum=1
        )loop
        insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         values( p_IdCredit,'External','BaiRong','PaMaxPayCate12M',d.MaxPayCate12M,v_Seq+1 );
        v_Seq:=v_Seq + 1;
        end loop;

      --------------------近3个月最大单类目消费金额的类目 yangzhenxian   2017-12-06
      insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'External','BaiRong','PaMaxPayCate3M',MaxPayCate3M,v_Seq+1
       from (select t.CONS_MAX_M3_PAYCATE MaxPayCate3M from external_br_consumption_c t
       where t.id_credit=p_IdCredit order by t.create_time desc) where rownum=1 ;
      v_Seq:=v_Seq + 1;
      
      -------4.增加元素External. BaiRong. MobChangeIteDay/*身份证关联的手机号最近一次变动距今天数*/
    insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select ID_CREDIT,'External','BaiRong','PaMobChangeIteDay',nvl(ir_id_x_cell_lastchg_days,0),v_Seq+1
       from (select ID_CREDIT,t.ir_id_x_cell_lastchg_days from external_br_inforelation t
       where t.id_credit=p_IdCredit order by t.create_time desc) where rownum=1 ;
      v_Seq:=v_Seq + 1;
      
      /*近12月手机号关联邮箱个数MobRelateMail12M  yangzhenxian  2019-03-18*/
      for d in (
          with temp as(
          select IR_M12_CELL_X_MAIL_CNT as MobRelateMail12M from external_br_inforelation p
           where p.id_credit=p_IdCredit order by p.create_time desc
           )
          select MobRelateMail12M from temp where rownum=1
        )loop
          if d.MobRelateMail12M is not null
          then 
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'External','BaiRong','PaMobRelateMail12M',d.MobRelateMail12M,v_Seq+1 );
            v_Seq:=v_Seq + 1;
          end if;
        end loop;

    for d in (
        select * from (select ID_CREDIT,t.MON_12_VAR1 RecentYearDeal, RFM_12_VAR1 BRDealAmount12M,
                    FLAG_PAYBEHAVIOR as PayBehavior,SUMMARY_SCORE as SummaryScore,MCC_3_VAR1 AS MCCCnt3M,
                    RFM_6_VAR3 AS LargestConsAmt6M,FLAG_6_VAR4 AS FlagOnline6M 
        from external_br_pay_behavior t
       where t.id_credit=p_IdCredit order by t.create_time desc) where rownum=1
      )loop
      --------2017/11/29  machaochun----
      --------1.增加元素External. BaiRong. RecentYearDeal /*近十二个月发生交易月份数*/
      insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       values( p_IdCredit,'External','BaiRong','PaRecentYearDeal',d.RecentYearDeal,v_Seq+1 );
      v_Seq:=v_Seq + 1;

      -------增加元素External. BaiRong. BRDealAmount12M  2019-08-22 yangzhenxian
      insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       values( p_IdCredit,'External','BaiRong','PaBRDealAmount12M',d.BRDealAmount12M,v_Seq+1 );
      v_Seq:=v_Seq + 1;
      
      --hongbinbin 20190924
       --支付消费行为偏好产品计费标识
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
              values( p_IdCredit,'External','BaiRong','PaPayBehavior',d.PayBehavior,v_Seq+1); 
       --消费综合评分
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
              values( p_IdCredit,'External','BaiRong','PaSummaryScore',d.SummaryScore,v_Seq+2); 
       --近3个月发生交易的MCC种类数
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
              values( p_IdCredit,'External','BaiRong','PaMCCCnt3M',d.MCCCnt3M,v_Seq+3); 
       --交易代码是消费类且近6个月最大的消费金额
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
              values( p_IdCredit,'External','BaiRong','PaLargestConsAmt6M',d.LargestConsAmt6M,v_Seq+4); 
       --近6个月线上消费标志
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
              values( p_IdCredit,'External','BaiRong','PaFlagOnline6M',d.FlagOnline6M,v_Seq+5); 
          
       v_Seq:=v_Seq + 5;
       
    end loop;
    
      --------2019/08/22  yangzhenxian----
    for d in (
        select * from (select ID_CREDIT,t.pc_user_level BRPcUserLevel from external_br_personalcre t
       where t.id_credit=p_IdCredit order by t.create_time desc) where rownum=1
      )loop
      insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       values( p_IdCredit,'External','BaiRong','PaBRPcUserLevel',d.BRPcUserLevel,v_Seq+1 );
      v_Seq:=v_Seq + 1;
    end loop;

    --银行卡三要素验证结果 2017/03/17 wangxiaofeng
    for c in(select status from(select t.status,row_number() over(order by update_time desc) nums
              from bank_account_verify t
              where t.update_time>=trunc(sysdate) and t.verify_type=0
                     and t.ident=v_Ident and t.account_name=v_PersonName) b where nums=1
      )loop
        insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
          values(p_IdCredit,'External','BankVerify','PaThreeFactorStatus',c.status,v_Seq+1);
        v_Seq:=v_Seq + 1;
      end loop;

    --银行卡四要素验证结果 2017/03/17 wangxiaofeng
    for c in(select status from(select t.status,row_number() over(order by update_time desc) nums
              from bank_account_verify t
              where t.update_time>=trunc(sysdate) and t.verify_type=1
                     and t.ident=v_Ident and t.account_name=v_PersonName) b where nums=1
      )loop
        insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
          values(p_IdCredit,'External','BankVerify','PaFourFactorStatus',c.status,v_Seq+1);
        v_Seq:=v_Seq + 1;
      end loop;


      -----灰猫begin yangzhenxian     2017-12-21-----------
      --在元素类比External下面添加元素子类=HuiMao，元素名称FlagOverDue(是否命中逾期平台数据)
      for d in (
          with temp as(
          select sum(case when c2.QUERY_REPORT_ID is not null then 1 when c1.order_no is not null then 0 else null end) as FlagOverDue,
          min(case when instr(c2.map_key,'DAY30')>0 then '1'
              when instr(c2.map_key,'DAY60')>0 then '2'
              when instr(c2.map_key,'DAY90')>0 then '3'
              when instr(c2.map_key,'DAY180')>0 then '4'
              when instr(c2.map_key,'DAY365')>0 then '5'
              when instr(c2.map_key,'HISTORY')>0 then '6'
              else null end) OverDueLineCate
          from GREYCAT_APPLY_REPORT c
          left join GREYCAT_QUERY_REPORT c1 on c.order_no=c1.order_no
          left join GREYCAT_OVERDUE_DETAIL c2 on c1.id=c2.QUERY_REPORT_ID
          where c.id_credit=p_IdCredit)
          select * from temp where FlagOverDue is not null
        )loop
        insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         values( p_IdCredit,'External','HuiMao','PaFlagOverDue',case when d.FlagOverDue>1 then 1 else d.FlagOverDue end,v_Seq+1 );
        v_Seq:=v_Seq + 1;

        ---OverDueLineCate：客户逾期情况  yangzhenxian  2018-03-28
        if d.OverDueLineCate is not null
          then
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
           values( p_IdCredit,'External','HuiMao','PaOverDueLineCate',d.OverDueLineCate,v_Seq+1 );
          v_Seq:=v_Seq + 1;
          end if;
        end loop;

      --在元素类比External下面添加元素子类=HuiMao，元素名称FlagApply(是否命中申请平台数据)
      for d in (
          with temp as(
          select sum(case when c2.QUERY_REPORT_ID is not null then 1 when c1.order_no is not null then 0 else null end) as FlagApply
          from GREYCAT_APPLY_REPORT c
          left join GREYCAT_QUERY_REPORT c1 on c.order_no=c1.order_no
          left join GREYCAT_APPLY_LOAN_DETAIL c2 on c1.id=c2.QUERY_REPORT_ID
          where c.id_credit=p_IdCredit)
          select * from temp where FlagApply is not null
        )loop
        insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         values( p_IdCredit,'External','HuiMao','PaFlagApply',case when d.FlagApply>1 then 1 else d.FlagApply end,v_Seq+1 );
        v_Seq:=v_Seq + 1;
        end loop;

      --在元素类比External下面添加元素子类=HuiMao，元素名称FlagPay(是否命中还款平台数据)
      for d in (
          with temp as(
          select sum(case when c2.QUERY_REPORT_ID is not null then 1 when c1.order_no is not null then 0 else null end) as FlagPay
          from GREYCAT_APPLY_REPORT c
          left join GREYCAT_QUERY_REPORT c1 on c.order_no=c1.order_no
          left join GREYCAT_APPLY_LOAN_DETAIL c2 on c1.id=c2.QUERY_REPORT_ID and c2.apply_sum_money='0.00'
          where c.id_credit=p_IdCredit)
          select * from temp where FlagPay is not null
        )loop
        insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         values( p_IdCredit,'External','HuiMao','PaFlagPay',case when d.FlagPay>1 then 1 else d.FlagPay end,v_Seq+1 );
        v_Seq:=v_Seq + 1;
        end loop;


      --在元素类比External下面添加元素子类=HuiMao，元素名称Score(灰猫评分)
      for d in (
          with temp as(
          select c1.score
          from GREYCAT_APPLY_REPORT c
          join GREYCAT_QUERY_REPORT c1 on c.ORDER_NO=c1.ORDER_NO
          where c.id_credit=p_IdCredit order by c1.create_time desc)
          select * from temp where rownum=1
        )loop
        insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         values( p_IdCredit,'External','HuiMao','PaScore',d.Score,v_Seq+1 );
        v_Seq:=v_Seq + 1;
        end loop;

      -----灰猫end---------------

       --蜜罐元素数据 2016/06/23 wangxiaofeng
       for mi in(select user_gray_score,contacts_one_blacklist_cnt,contacts_two_blacklist_cnt,
                  blacklist_category,user_register_cnt,iwop_susp_phone
                  from(
                  select nvl(a.user_gray_score,999) user_gray_score,nvl(a.contacts_one_blacklist_cnt,0) contacts_one_blacklist_cnt,
                  nvl(a.contacts_two_blacklist_cnt,0) contacts_two_blacklist_cnt,nvl(a.blacklist_category,'其他') blacklist_category,
                  nvl(a.user_register_cnt,0) user_register_cnt,decode(a.iwop_susp_phone,null,'否','是') iwop_susp_phone
                  from external_miguan_basic_info a
                  where a.create_time>=trunc(sysdate-1) 
                  and nvl(remark,'0') IN ('0','MIGUAN_SEARCH_SUCCESS[获取蜜罐查询成功]')
                  and a.id_credit=p_IdCredit order by user_id desc
                  ) where rownum=1)
       loop
         --用户黑中介评分
         insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         values( p_IdCredit,'External','JuxinliMiguan','PaGrayScore',mi.user_gray_score,v_Seq + 1);
         --一阶联系人黑名单人数
         insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         values( p_IdCredit,'External','JuxinliMiguan','PaPhoneBlackCNTOne',mi.contacts_one_blacklist_cnt,v_Seq + 2);
         --二阶联系人黑名单人数
         insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         values( p_IdCredit,'External','JuxinliMiguan','PaPhoneBlackCNTTwo',mi.contacts_two_blacklist_cnt,v_Seq + 3);
         --黑名单类型
         insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         values( p_IdCredit,'External','JuxinliMiguan','PaBlackType',mi.blacklist_category,v_Seq + 4);
         --注册机构个数
         insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         values( p_IdCredit,'External','JuxinliMiguan','PaRegisterCNT',mi.user_register_cnt,v_Seq + 5);
         --身份证是否组合过其他电话号码 返回结果为是否
         insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         values( p_IdCredit,'External','JuxinliMiguan','PaSameIdentDiffPhone',nvl(mi.iwop_susp_phone,-1),v_Seq + 6);
         v_Seq:=v_Seq + 7;
       end loop;

       -- /*蜜罐一介联系人总数*/ 2017/10/27 machaochun   增加元素External. JuxinliMiguan. ContactOneCNT
      insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
      select p_IdCredit,'External','JuxinliMiguan','PaContactOneCNT', nvl(t.contacts_class1_cnt,-1) ,v_Seq+1
      from (select contacts_class1_cnt from EXTERNAL_MIGUAN_BASIC_INFO  
      where id_credit=p_IdCredit  and nvl(remark,'0') IN ('0','MIGUAN_SEARCH_SUCCESS[获取蜜罐查询成功]')
       order by create_time ) t where rownum=1;
      v_Seq:=v_Seq + 1;
      
      ---------------手机三项验证----NameResultQB-----IdentrResultQB---------------by yangzhenxian 2017-08-30
      for py in(select nameresult,Identresult from
                  (select phone.nameresult,phone.Identresult
                         from cs_pyphone_data phone,Wallet_Apply_Info wa
                         where phone.id_credit=wa.id and wa.id_credit=p_IdCredit and phone.event_name=1
                         and (phone.person_type='1' or phone.person_type is null)  order by phone.update_time desc) a
                  where rownum=1)
      loop
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
        values( p_IdCredit,'External','PengYuan','PaNameResultQB',py.nameresult,v_Seq + 1 );
        v_Seq:=v_Seq + 1;

       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
        values( p_IdCredit,'External','PengYuan','PaIdentResultQB',py.Identresult,v_Seq + 1 );
        v_Seq:=v_Seq + 1;
      end loop;


      /*蜜罐是否查询成功*/
      insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'External','JuxinliMiguan','PaIsMG',case when nvl(v_InterCode,'1') in('3','4') then 1 when IsMG >0 then 1 else 0 end,v_Seq+1
       from (select count(1) IsMG from external_miguan_basic_info t where t.id_credit=p_IdCredit
       and (remark is null or remark='MIGUAN_SEARCH_SUCCESS[获取蜜罐查询成功]')) ;
      v_Seq:=v_Seq + 1;

    --钱包面签 HardCheck.SumApprovedSameFactory，客户所在工厂历史面签通过的合同数 2016/11/03 wangxiaofeng --
     ---------------聚信立授权是否成功  JxlGrant -------------------------by yangzhenxian 2017-08-30
     for ca in(select collected from
       (select collected from ca_collect where id_credit=p_IdCredit order by update_time desc) a where rownum=1)
     loop
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
        values( p_IdCredit,'External','JuxinliMiguan','PaJxlGrant',ca.collected,v_Seq + 1);
        v_Seq:=v_Seq + 1;
     end loop;
      
      /*External.TongDun.CorrelatedRisksScore：关联风险分
      External.TongDun.AttentListProportion：关注名单占比    yangzhenxian   2018-10-29*/
      for d in (
          select max(case when d.rule_name like'%复杂网络%' and detail_name='关联风险分' then to_number(detail_val) end )  correlated_risks_score
          ,max(case when d.rule_name like'%复杂网络%' and d.detail_name='关注名单占比' then to_number(substr(detail_val,1,instr(detail_val,'%',-1)-1)) end ) Attention_list_per
          from WFI_FRAUD_METRIX_RESULT a
          left join WFI_FRAUD_METRIX_RULE t on a.id=t.fraud_metrix_result_id
          left join wfi_fraud_metrix_rule_detail d  on t.id=d.rule_id 
          where a.event_name='Credit' and a.ASSOCIATED_ID=p_IdCredit
        )loop
         if d.correlated_risks_score is not null then
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
           values( p_IdCredit,'External','TongDun','PaCorrelatedRisksScore',d.correlated_risks_score,v_Seq+1 );
          v_Seq:=v_Seq + 1;
          end if;
          
         if d.Attention_list_per is not null then
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
           values( p_IdCredit,'External','TongDun','PaAttentListProportion',d.Attention_list_per,v_Seq+1 );
          v_Seq:=v_Seq + 1;
          end if;
        end loop;
      
      /*External.TongDun.ComplexNetwork：复杂网络    yangzhenxian   2018-10-29*/
      for d in (
          select substr(max(case when rule_no=25561664 then '3_reject'--借款人身份证命中复杂网络_建议拒绝
                  when rule_no=25559994 then '2_uw'--借款人身份证命中复杂网络_建议人工审核
                  when rule_no=25559984  then '1_approve'--借款人身份证命中复杂网络_建议人工审核
                   end ),3,10)   Complex_Network  
          from WFI_FRAUD_METRIX_RESULT a
          left join WFI_FRAUD_METRIX_RULE t on a.id=t.fraud_metrix_result_id
          where a.event_name='Credit' and a.ASSOCIATED_ID=p_IdCredit
        )loop
        
         if d.Complex_Network is not null then
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
           values( p_IdCredit,'External','TongDun','PaComplexNetwork',d.Complex_Network,v_Seq+1 );
          v_Seq:=v_Seq + 1;
          end if;
        end loop;
        
      /*External.TongDun.GelConPlatform7D：新_7天内申请人身份证或手机在多个平台申请借款    yangzhenxian   2019-01-23*/
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'External','TongDun','PaGelConPlatform7D',
       nvl(MAX(CASE WHEN instr(RULE_DETAIL, '一般消费分期平台')>0 
         THEN CASE WHEN INSTR(SUBSTR(RULE_DETAIL,instr(rule_detail, '一般消费分期平台')+9),',')>0 
         THEN SUBSTR(SUBSTR(RULE_DETAIL,instr(rule_detail, '一般消费分期平台')+9),1,INSTR(SUBSTR(RULE_DETAIL,instr(rule_detail, '一般消费分期平台')+9), ',')-1)
         ELSE SUBSTR(RULE_DETAIL,instr(rule_detail, '一般消费分期平台')+9,3) END 
         ELSE NULL END),-1)  --近7天申请人身份证或手机在多个平台申请借款次数（主要分为：一般消费平台，大型消费金融公司，小额贷款公司，P2P网贷）
         ,v_Seq+1
       from WFI_FRAUD_METRIX_RESULT a
       join WFI_FRAUD_METRIX_RULE b on a.id=b.fraud_metrix_result_id
       where b.rule_no in(1049606,1053412)          --新_7天内申请人身份证或手机在多个平台申请借款
             and a.event_name='Credit' and a.associated_id=p_IdCredit;
          v_Seq:=v_Seq + 1;

         --2019/03/07 yangzhenxian MultiLoanP2PCountFraudMetrix3M：近三个月命中同盾P2P网贷的次数元素代码
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
           SELECT p_IdCredit,'External','TongDun','PaMultiLoanP2PCountFraudMetrix3M',nvl(
           (select MultiLoanP2PCountFraudMetrix3M from (SELECT a.ASSOCIATED_ID as id_credit
            ,MAX(CASE WHEN INSTR(SUBSTR(RULE_DETAIL,instr(rule_detail, 'P2P网贷') + 6),',') > 0
               THEN SUBSTR(SUBSTR(RULE_DETAIL,instr(rule_detail, 'P2P网贷') + 6),1,instr(SUBSTR(RULE_DETAIL,instr(rule_detail, 'P2P网贷') + 6),',') - 1)
               ELSE SUBSTR(RULE_DETAIL, instr(rule_detail, 'P2P网贷') + 6, 3)END) AS MultiLoanP2PCountFraudMetrix3M
            from WFI_FRAUD_METRIX_RESULT a
            left join WFI_FRAUD_METRIX_RULE t
            on a.id = t.fraud_metrix_result_id
            where  a.ASSOCIATED_ID=p_IdCredit and A.EVENT_NAME = 'Credit'  AND T.RULE_NO IN(1044388,1053416) and rule_detail like '%P2P网贷%'
            group by  a.ASSOCIATED_ID
            ) ), 0),v_Seq
          from dual;

         v_Seq:=v_Seq + 1;

    --External.ZhongZhiCheng.P2PMultiLoan   DiffMultiLoan  中智诚多次借贷情况 2019-01-23 yangzhenxian
    for c in(select max(case when INSTR(k.DESCRIPTION,'网贷机构')>0 then 1 else 0 end) as P2PMultiLoan --申请人在网贷机构出现过
            ,max(case when INSTR(k.DESCRIPTION,'不同机构')>0 then 1 else 0 end) as DiffMultiLoan --申请人在不同机构出现过
            FROM EXTERNAL_INTELLI_ANTIFRAUD h 
            left join EXTERNAL_INTELLI_AF_RULES k on k.ANTIFRAUD_ID=h.id
            where h.id_credit=p_IdCredit
      )loop
        insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
          values(p_IdCredit,'External','ZhongZhiCheng','PaP2PMultiLoan',c.P2PMultiLoan,v_Seq+1);
        v_Seq:=v_Seq + 1;
        insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
          values(p_IdCredit,'External','ZhongZhiCheng','PaDiffMultiLoan',c.DiffMultiLoan,v_Seq+1);
        v_Seq:=v_Seq + 1;
      end loop;

        --External.zhongzhicheng.ConfirmBlackList 中智城 客户命中中智诚黑名单 2018-05-09 majianfeng
        insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
          select p_IdCredit,'External','ZhongZhiCheng','PaConfirmBlackList',nvl(substr(max(case when qr.confirm_type='overdue' then '4overdue'
              when qr.confirm_type='reject' then '3reject'
              when qr.confirm_type='fraud' then '2fraud'
              else '0other'end ),2,10),'0other') as ConfirmBlackList,v_Seq+1
          from external_intelli_bl_query bq
        left join external_intelli_bl_q_records qr on bq.id=qr.bl_q_id
        where bq.id_credit=p_IdCredit;
       
       
        
        /*富数信用卡（主表）  yangzhenxian  2019-06-28*/
        for d in (
          select 
          max(CARD_CREDIT_LINE/100)as CardLine--该银行下授信总额度
          ,max(CARD_CREDIT_LIMIT/100)as CardLimit --消费额度
          ,max(CARD_USABLE_CONSUME_LIMIT/100)as CardUsCsLimit--可用消费额度
          ,max(IS_OVERDUE)as Overdue--逾期用户
          from FS_BANK_CREDITS_BASIC a
          where id_credit=p_IdCredit
        )loop
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'External','FuShu','PaCardLine',d.CardLine,v_Seq+1 );
            v_Seq:=v_Seq + 1;   
            
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'External','FuShu','PaCardLimit',d.CardLimit,v_Seq+1 );
            v_Seq:=v_Seq + 1;   
            
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'External','FuShu','PaCardUsCsLimit',d.CardUsCsLimit,v_Seq+1 );
            v_Seq:=v_Seq + 1;   
            
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'External','FuShu','PaOverdue',d.Overdue,v_Seq+1 );
            v_Seq:=v_Seq + 1;   
        end loop;
        
        /*富数信用卡（主表）  yangzhenxian  2019-06-28*/
        for d in (
          with base as(
          select (case when id_credit is not null then 1 else 0 end) as IsCreditCard--是否信用卡客户
          from FS_BANK_CREDITS_BASIC cs where cs.id_credit=p_IdCredit
          )
          select * from base where rownum=1

        )loop
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'External','FuShu','PaIsCreditCard',d.IsCreditCard,v_Seq+1 );
            v_Seq:=v_Seq + 1;
        end loop;
        
        /*富数网银-信用卡-近一年账单概况  yangzhenxian  2019-06-28*/
        for d in (
          select 
          sum(TOTAL_OUTFLOW_TRADE_AMOUNT/100)as TotalOutTradeAmt--总消费金额
          ,sum(TOTAL_INFLOW_TRADE_AMOUNT/100)as TotalInTradeAmt--总还款金额
          from FS_BANK_CR_BILL_FLOW_STATS a
          where id_credit=p_IdCredit
        )loop
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'External','FuShu','PaTotalOutTradeAmt',d.TotalOutTradeAmt,v_Seq+1 );
            v_Seq:=v_Seq + 1;   
            
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'External','FuShu','PaTotalInTradeAmt',d.TotalInTradeAmt,v_Seq+1 );
            v_Seq:=v_Seq + 1;  
        end loop;
        
        /*富数网银-信用卡-流水概况  yangzhenxian  2019-06-28*/
        for d in (
          select 
          max(case when AMOUNTS=12 then AMOUNT_AVERAGE_OUTFLOWS/100 else null end )as AmtAvgOutF12M--近12个月平均每笔消费额
          ,max(case when AMOUNTS=12 then AMOUNT_AVERAGEINFLOWS/100  else null end) as AmtAvgInF12M--近12个月平均每笔还款额
          from FS_BANK_CR_FLOW_STAT a
          where id_credit=p_IdCredit
        )loop
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'External','FuShu','PaAmtAvgOutF12M',d.AmtAvgOutF12M,v_Seq+1 );
            v_Seq:=v_Seq + 1;   
            
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'External','FuShu','PaAmtAvgInF12M',d.AmtAvgInF12M,v_Seq+1 );
            v_Seq:=v_Seq + 1;  
        end loop;
        
        /*富数网银-信用卡-已出账单流水概况  yangzhenxian  2019-06-28*/
        for d in (
          select 
          sum(REPAY_FLOWS_AMOUNT/100) as TotalRepayFlowAmt--总实际还款金额
          ,max(MAX_TRADE_AMOUNT/100)as MaxTradeAmt--最大消费金额
          from FS_BANK_CR_READY_BILL_FLOWS a
          where id_credit=p_IdCredit
        )loop
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'External','FuShu','PaTotalRepayFlowAmt',d.TotalRepayFlowAmt,v_Seq+1 );
            v_Seq:=v_Seq + 1;   
            
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'External','FuShu','PaMaxTradeAmt',d.MaxTradeAmt,v_Seq+1 );
            v_Seq:=v_Seq + 1;  
        end loop;
        
        /*富数运营商：基础数据表    yangzhenxian	  2019-07-03*/
        for d in (
          select 
          max(FRIEND_CNT_3M)as FriendCnt3M--近3月朋友联系数量
          ,max(best_friend_cnt_3m)as BestFriendCnt3M---近3月好朋友联系数量（联系10次以上）
          ,max(friend_cnt_6m)as FriendCnt6M--近6月朋友联系数量
          ,max(best_friend_cnt_6m)as BestFriendCnt6M---近6月好朋友联系数量（联系10次以上）
          ,max(interphone_cnt_3m)as InterPhoneCnt3M--近3月互通电话号码数目
          ,max(interphone_cnt_6m)as InterPhoneCnt6M--近6月互通电话号码数目
          from fs_telecom_basic
          where id_credit=p_IdCredit
        )loop
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'External','FuShu','PaFriendCnt3M',d.FriendCnt3M,v_Seq+1 );
            v_Seq:=v_Seq + 1;   
            
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'External','FuShu','PaBestFriendCnt3M',d.BestFriendCnt3M,v_Seq+1 );
            v_Seq:=v_Seq + 1;   
            
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'External','FuShu','PaFriendCnt6M',d.FriendCnt6M,v_Seq+1 );
            v_Seq:=v_Seq + 1;   
            
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'External','FuShu','PaBestFriendCnt6M',d.BestFriendCnt6M,v_Seq+1 );
            v_Seq:=v_Seq + 1;   
            
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'External','FuShu','PaInterPhoneCnt3M',d.InterPhoneCnt3M,v_Seq+1 );
            v_Seq:=v_Seq + 1;   
            
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'External','FuShu','PaInterPhoneCnt6M',d.InterPhoneCnt6M,v_Seq+1 );
            v_Seq:=v_Seq + 1;   
        end loop;
        
        /*富数运营商：通话详详单分析    yangzhenxian	  2019-07-03*/
        for d in (
          select count(distinct fc.phone)as ContactCount---联系人手机号在通话详单个数
          from  cs_contact cs
          left join FS_TELECOM_FREQUENT_CALLS fc  on cs.id_credit=fc.id_credit and cs.CONTACT_VALUE=fc.phone 
          where cs.person_type != '1' and cs.id_credit=p_IdCredit
        )loop
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'External','FuShu','PaContactCount',d.ContactCount,v_Seq+1 );
            v_Seq:=v_Seq + 1;   
        end loop;
        
        /*富数运营商：通话详详单分析    yangzhenxian	  2019-07-03*/
        for d in (
          select count(distinct m.opposite)as Top3mCount---联系人手机号在联系人top3个数
          from cs_contact cs
          left join FS_TELECOM_TOP3_3M m on cs.id_credit=m.id_credit and cs.CONTACT_VALUE=m.opposite
          where cs.person_type != '1' and cs.id_credit=p_IdCredit
        )loop
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'External','FuShu','PaTop3mCount',d.Top3mCount,v_Seq+1 );
            v_Seq:=v_Seq + 1;   
        end loop;
        
        /*富数运营商：通话活跃     yangzhenxian	  2019-07-03*/
        for d in (
          select max(case when PERIOD='1个月' then non_call_rate END)as NonCallRate1M--近一个月无通话天数占比
          ,max(case when PERIOD='1个月' then TOTAL_COUNT end)as TotalCount1M--近一个月通话次数
          ,max(case when PERIOD='1个月' then calling_num end)as CallingNum1M--近一个月主叫通话次数

          ,max(case when PERIOD='1个月' then call_number end)as CallNum1M--近一个月通话号码数
          ,max(case when PERIOD='3个月' then call_number end)as CallNum3M--近一个月通话号码数
          ,max(case when PERIOD='3个月' then interphone_rate end)as InterphoneRate--近一个月互通号码数占比
          
          ,max(case when PERIOD='1个月' then call_time end)as CallTimet1M--近一个月通话时长
          ,max(case when PERIOD='1个月' then CALLING_TIME end)as CallingTimet1M--近一个月主叫通话时长
          ,max(case when PERIOD='1个月' then call_active_day end)as CallActiveDay1M--近一个月通话活跃天数
          ,max(case when PERIOD='1个月' then morning_count end)as MorningCount1M--近一个月凌晨(0:00-6:00)通话次数
          from FS_TELECOM_PHONALYZR a
          where id_credit=p_IdCredit
        )loop
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'External','FuShu','PaNonCallRate1M',d.NonCallRate1M,v_Seq+1 );
            v_Seq:=v_Seq + 1;   
            
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'External','FuShu','PaTotalCount1M',d.TotalCount1M,v_Seq+1 );
            v_Seq:=v_Seq + 1;   
            
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'External','FuShu','PaCallingNum1M',d.CallingNum1M,v_Seq+1 );
            v_Seq:=v_Seq + 1;   
            
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'External','FuShu','PaCallNum1M',d.CallNum1M,v_Seq+1 );
            v_Seq:=v_Seq + 1;   
            
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'External','FuShu','PaCallNum3M',d.CallNum3M,v_Seq+1 );
            v_Seq:=v_Seq + 1;   
            
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'External','FuShu','PaInterphoneRate',d.InterphoneRate,v_Seq+1 );
            v_Seq:=v_Seq + 1;   
            
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'External','FuShu','PaCallTimet1M',d.CallTimet1M,v_Seq+1 );
            v_Seq:=v_Seq + 1;   
            
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'External','FuShu','PaCallingTimet1M',d.CallingTimet1M,v_Seq+1 );
            v_Seq:=v_Seq + 1;   
            
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'External','FuShu','PaCallActiveDay1M',d.CallActiveDay1M,v_Seq+1 );
            v_Seq:=v_Seq + 1;   
            
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'External','FuShu','PaMorningCount1M',d.MorningCount1M,v_Seq+1 );
            v_Seq:=v_Seq + 1;   
        end loop;
      
      /*富数运营商：用户位置分布     yangzhenxian  2019-07-03*/
      for d in (
          select min(rank) as CityRank--申请城市通话排名
          from (select id_credit,city,row_number()over(partition by id_credit order by days*1 desc)as rank from FS_TELECOM_POSITION) a
          join cs_address ca on a.id_credit=ca.ID_CREDIT  and ca.ADDRESS_TYPE=2 and replace(ca.CITY,'市','')=replace(a.CITY,'市','')
          where ca.id_credit=p_IdCredit
        )loop
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'External','FuShu','PaCityRank',d.CityRank,v_Seq+1 );
            v_Seq:=v_Seq + 1;
        end loop;
      
      /*富数运营商：账单数据     yangzhenxian  2019-07-03*/
      for d in (
          select min(a.pay_amount/100) as MinPayAmount --过去三个月最小账单金额
          from FS_TELECOM_BILL_ANALYSIS a
          where  to_date(month||'01','yyyy-mm-dd')>=add_months(trunc(sysdate,'mm'),-3) and id_credit=p_IdCredit
        )loop
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'External','FuShu','PaMinPayAmount',d.MinPayAmount,v_Seq+1 );
            v_Seq:=v_Seq + 1;
        end loop;
        
        /*富数运营商：通话详详单分析     yangzhenxian	  2019-07-03*/
        for d in (
          select max(nvl(call_count_l3m,0)) as FriendCallCountL3m--2个联系人中任意1人近3月最大联系次数
          ,max(nvl(call_count_l6m,0)) as FriendCallCountL6m--2个联系人中任意1人近6月最大联系次数
          ,min(case when person_type in ('F','M','P')and  a.ID_CREDIT is null then 0 else call_count_l6m *1 end) as ParentCallCountL6m--父母近6个月最小联系次数
          from cs_contact cc
          left join FS_TELECOM_FREQUENT_CALLS  a on a.ID_CREDIT=cc.id_credit and cc.CONTACT_VALUE=a.phone
          where  cc.CONTACT_TYPE=2 and person_type<>'1' and cc.id_credit=p_IdCredit
        )loop
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'External','FuShu','PaFriendCallCountL3m',d.FriendCallCountL3m,v_Seq+1 );
            v_Seq:=v_Seq + 1;   
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'External','FuShu','PaFriendCallCountL6m',d.FriendCallCountL6m,v_Seq+1 );
            v_Seq:=v_Seq + 1;   
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'External','FuShu','PaParentCallCountL6m',d.ParentCallCountL6m,v_Seq+1 );
            v_Seq:=v_Seq + 1;   
        end loop;
      
      /*同盾信贷保镖保存在External—TongDun里  yangzhenxian  2019-07-03*/
      for d in (
          with temp as(
          select min(case when risk_name='设备状态异常_高风险' then 1 
          when risk_name='借款设备代理识别' then 2 
          when risk_name='借款设备作弊工具识别' then 3 
          when risk_name='借款设备越狱识别' then 4
          when risk_name='短时间移动距离位置异常' then 5 
          when risk_name='3个月内申请人手机号作为联系人手机号出现的次数过多' then 6 
          when risk_name in ('3个月内申请人身份证关联配偶手机数过多','3个月内申请人身份证关联父亲手机数过多') then 7
          when risk_name='1天内身份证使用过多设备进行申请' then 8
          when risk_name='敏感时间段申请1点至5点' then 9
          else 100 end) as RiskName
          from TONGDUN_APPLY_ANTIFRAUD an
          left join TONGDUN_APPLY_AF_RISK_ITEMS af on to_char(an.ID)=af.main_id and an.id_credit=p_IdCredit order by an.create_time desc
           )
          select RiskName from temp where rownum=1
        )loop
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'External','TongDun','PaRiskName',d.RiskName,v_Seq+1 );
            v_Seq:=v_Seq + 1;
        end loop;
        
         for d in(
          select max(case when r.DETAIL_NAME='一度关联节点个数' then to_number(r.DETAIL_VAL) else 0 end) as RiskOneCount
            from cs_credit b
            join WFI_FRAUD_METRIX_RESULT a on b.id =a.ASSOCIATED_ID
            left join WFI_FRAUD_METRIX_RULE t on a.id=t.fraud_metrix_result_id  
            left join wfi_fraud_metrix_rule_detail r on t.id=r.RULE_ID and instr(r.RULE_NAME,'复杂网络')>0
            where a.event_name='Credit' and a.update_time>=date'2018-12-01' and b.id=p_IdCredit
            group by b.id
          )
          loop
             --同盾复杂网络一度关联节点个数
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values(p_IdCredit,'External','TongDun','PaRiskOneCount',d.RiskOneCount,v_Seq+1);
                                      
            v_Seq:=v_Seq + 1;
            
          end loop;
        
        /*身份证在哪种机构类型出现     yangzhenxian	  2019-07-03*/
        for d in (
          select min(case when IAIO_SUSP_ORG_TYPE ='线上信用现金贷' then '1线上信用现金贷'
          when IAIO_SUSP_ORG_TYPE ='线下信用现金贷' then '2线下信用现金贷'
          when IAIO_SUSP_ORG_TYPE ='线上信用卡代还' then '3线上信用卡代还'
          when IAIO_SUSP_ORG_TYPE ='线上租房分期' then '4线上租房分期' else IAIO_SUSP_ORG_TYPE end)as IaioSuspOrgType
          from external_miguan_basic_info m
          where m.id_credit=p_IdCredit
        )loop
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'External','JuxinliMiguan','PaIaioSuspOrgType',d.IaioSuspOrgType,v_Seq+1 );
            v_Seq:=v_Seq + 1;   
        end loop;
      
      /*全量客户经过洽客系统，把洽客作为第三方征信保存在External—QiaKe里  yangzhenxian  2019-07-04*/
      for d in (
          with temp as(
          select case when CREDIT_RESULT is null or CREDIT_RESULT='U' then 'Fail' else CREDIT_RESULT end as CreditResult --洽客订单的状态，如果洽客处理失败则返回Fail值。
          ,FINAL_DECISION as FinalDecision --洽客最终决策结果
          ,POS_LOAN_LIMIT as Limit--洽客授信额度
          ,CUSTOMER_RISK_LEVEL as RiskLevel --洽客客户风险等级
          from QIAKE_RISK_MANAGEMENT 
          where id_credit=p_IdCredit
           )
          select * from temp where rownum=1
        )loop
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'External','QiaKe','PaCreditResult',d.CreditResult,v_Seq+1 );
            v_Seq:=v_Seq + 1;
            
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'External','QiaKe','PaFinalDecision',d.FinalDecision,v_Seq+1 );
            v_Seq:=v_Seq + 1;
            
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'External','QiaKe','PaLimit',d.Limit,v_Seq+1 );
            v_Seq:=v_Seq + 1;
            
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'External','QiaKe','PaRiskLevel',d.RiskLevel,v_Seq+1 );
            v_Seq:=v_Seq + 1;
        end loop;
        
         --hongbinbin 20191010
         insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         select p_IdCredit,'Other','*','PaCreditSource', credit_source as CreditSource, --即速用用户来源渠道
            v_Seq+1
         from jsy_credit_source where id_credit=p_IdCredit;
         
         v_Seq:=v_Seq + 1;    
       
      /*预审随机数，取值再0-1之间   yangzhenxian	  2019-07-04*/
       insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
            values(p_IdCredit,'Special','PaRandom',round(dbms_random.value(),6),v_Seq+1);
       v_Seq:=v_Seq + 1;
        
        /*风控渠道类型     yangzhenxian	  2019-07-15*/
        for d in (
          select 
          sum(case when CHANNEL_TYPE='QIAKE' and VERDICT is not null then 1 when CHANNEL_TYPE='WACAI' and VERDICT is not null then 2 else 0 end) as RiskChannelType
          from RISK_MANAGEMENT
          where id_credit=p_IdCredit
        )loop
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'Credit','*','PaRiskChannelType',d.RiskChannelType,v_Seq+1 );
            v_Seq:=v_Seq + 1;   
        end loop;
      
      /*挖财审批结果及额度  yangzhenxian  2019-07-15*/
      for d in (
          with temp as(
          select VERDICT as FinalDecision--挖财审批结果
          ,CREDIT_AMOUNT/100 as Limit--挖财最高额度
          ,RISK_LEVEL as RiskLevel--挖财风险等级
          from  WACAI_RISK_MANAGEMENT a 
          where id_credit=p_IdCredit order by a.create_time desc
           )
          select * from temp where rownum=1
        )loop
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'External','WaCai','PaFinalDecision',d.FinalDecision,v_Seq+1 );
            v_Seq:=v_Seq + 1;
            
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'External','WaCai','PaLimit',d.Limit,v_Seq+1 );
            v_Seq:=v_Seq + 1;
            
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'External','WaCai','PaRiskLevel',d.RiskLevel,v_Seq+1 );
            v_Seq:=v_Seq + 1;
        end loop;
        
        /*在External---BaiQiShi 下新增元素StrategyName     yangzhenxian	  2019-07-24*/
        for d in (
          select min(
          case when bqs2.STRATEGY_NAME='历史安装应用统计策略' then 1
               when bqs2.STRATEGY_NAME='历史多头名单策略' then 2
               when bqs2.STRATEGY_NAME='失信风险策略' then 3
               when bqs2.STRATEGY_NAME='多头风险策略' and bqs4.NAME='总数' and bqs4.RULE_DETAIL_VALUE>20 then 4
               when bqs2.STRATEGY_NAME='多头风险策略' and bqs4.NAME not in ('第三方支付','银行') then 5
               when bqs2.STRATEGY_NAME='多头风险策略' then 6
               when bqs2.STRATEGY_NAME='百度风险名单策略' then 7                 
               when bqs2.STRATEGY_NAME='复杂关系网络策略' then 8            
               when bqs2.STRATEGY_NAME='历史复杂网络策略' then 9
               when bqs2.STRATEGY_NAME='异常行为策略' then 10 else 99 end) as StrategyName
          FROM BAIQISHI_DECISION_RESULT bqs
          /*JOIN dafy_sales.cs_credit cc ON bqs.id_cerdit=cc.id*/
          LEFT JOIN BAIQISHI_DECISION_STRATEGY bqs2 ON bqs.id=bqs2.result_id
          LEFT JOIN BAIQISHI_DECISION_RULE bqs3 ON bqs2.id=bqs3.strategy_id
          LEFT JOIN BAIQISHI_DECISION_RULE_DETAIL bqs4 ON bqs3.id=bqs4.rule_id
          where bqs.ID_CERDIT=p_IdCredit
        )loop
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'External','BaiQiShi','PaStrategyName',d.StrategyName,v_Seq+1 );
            v_Seq:=v_Seq + 1;   
        end loop;
        
        /*在External---BaiRong FlagSpecialCate     hongbinbin	  2019-09-04*/
        for d in (
             select max(case when decode(a.sl_cell_bank_refuse,null,0,1)+decode(a.sl_cell_nbank_cf_refuse,null,0,1)+decode(a.sl_cell_bank_fraud,null,0,1)+decode(a.sl_id_nbank_p2p_bad,null,0,1)>0 then '1HighRisk'
                          when decode(a.sl_id_nbank_p2p_bad,null,0,1)+decode(a.sl_cell_nbank_p2p_bad,null,0,1)+decode(a.sl_id_nbank_cf_bad,null,0,1)+decode(a.sl_cell_p2p_bad,null,0,1)>0 then '2MediumRisk'
                          when a.FLAG_SPECIALLIST_C ='1' then '3FlagRisk' else '9Normal' end )as FlagSpecialCate  ---旧版特殊名单核查分类
            from cs_credit cc
            left join external_br_speciallist_c  a on a.ID_CREDIT=cc.ID
            where cc.id=p_IdCredit
        )loop
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'External','BaiRong','PaFlagSpecialCate',d.FlagSpecialCate,v_Seq+1);
            v_Seq:=v_Seq + 1;   
        end loop;
        
        /*在External---BaiRong  FlagSpeciallistNew、FlagSpecialCateNew     hongbinbin	  2019-09-04*/
        for d in (
            select a.FLAG_SPECIALLIST_C as FlagSpeciallistNew,---新版特殊名单核查产品输出标识
                    max(case when decode(a.SL_CELL_BANK_FRAUD_TIME,null,0,1)+decode(a.SL_LM_CELL_BANK_BAD_ALLNUM,null,0,1)+decode(a.SL_CELL_BANK_FRAUD,null,0,1)+decode(a.SL_CELL_BANK_FRAUD_ALLNUM,null,0,1)+decode(a.SL_LM_CELL_BANK_BAD,null,0,1) >0 then  '1BankRisk'
                      when decode(a.SL_ID_NBANK_FINLEA_BAD,null,0,1)+decode(a.SL_ID_NBANK_FINLEA_BAD_TIME,null,0,1)+decode(a.SL_ID_NBANK_FINLEA_BAD_ALLNUM,null,0,1)+decode(a.SL_CELL_NBANK_FINLEA_BAD,null,0,1)+decode(a.SL_CELL_NBANK_FINLEA_BAD_TIME,null,0,1)+decode(a.SL_CELL_NBANK_FI_BAD_ALLNUM,null,0,1) >0 then  '2FinleaRisk'
                      when decode(a.SL_ID_NBANK_NSLOAN_BAD,null,0,1)+decode(a.SL_ID_NBANK_NSLOAN_BAD_ALLNUM,null,0,1)+decode(a.SL_CELL_NBANK_SLOAN_BAD,null,0,1)+decode(a.SL_CELL_NBANK_SLOAN_BAD_ALLNUM,null,0,1)+decode(a.SL_ID_NBANK_NSLOAN_BAD_TIME,null,0,1) >0 then  '3XiaodaiRisk'
                      when decode(a.SL_CELL_NBANK_OTHER_BAD_ALLNUM,null,0,1)+decode(a.SL_CELL_NBANK_OTHER_BAD,null,0,1) >0 then  '4OtherRisk'
                      when decode(a.SL_ID_NBANK_AU_OVERDUE_TIME,null,0,1)+decode(a.SL_ID_NBANK_AUTOFIN_OVERDUE,null,0,1)+decode(a.SL_ID_NBANK_AU_OVERDUE_ALLNUM,null,0,1) >0 then  '5AutofinRisk'
                      when decode(a.SL_CELL_NBANK_BAD_ALLNUM,null,0,1)+decode(a.SL_ID_BAD_INFO_TIME,null,0,1)+decode(a.SL_LM_CELL_NBANK_OTHER_BAD,null,0,1) >0 then  '6GeneralRisk'
                      when a.FLAG_SPECIALLIST_C ='1' then '7FlagRisk' else '9Normal' end )as FlagSpecialCateNew  --新版特殊名单核查分类
                from cs_credit cc
                left join external_br_speciallist_v2  a on a.ID_CREDIT=cc.ID
                where cc.id=p_IdCredit
                group by  cc.id, a.FLAG_SPECIALLIST_C 
        )loop
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'External','BaiRong','PaFlagSpeciallistNew',d.FlagSpeciallistNew,v_Seq+1); 
        
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'External','BaiRong','PaFlagSpecialCateNew',d.FlagSpecialCateNew,v_Seq+2);
             
            v_Seq:=v_Seq + 2;   
        end loop;     
        
       --hongbinbin 20191011
        for d in(
            select 
              to_number(nvl(ALS_M6_ID_NBANK_OTH_ORGNUM,-1)) as IdentNBankOthORG6M 
              from cs_credit b
              left join External_Br_Stability_c  sta on sta.ID_CREDIT = b.id --稳定性评估
              left join External_Br_Applyloan ap on ap.ID_CREDIT = b.id    --多次申请核查    --多头
              where b.COMMIT_TIME>date'2019-09-01' and b.id=p_IdCredit
            )loop
             --按身份证号查询，近6个月在非银机构-其他申请机构数 
             insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
              values(p_IdCredit,'External','BaiRong','PaIdentNBankOthORG6M',d.IdentNBankOthORG6M,v_Seq+1);            
             
             v_Seq:=v_Seq + 1; 
            
            end loop;   
        
        /*在External---Device 下新增设备指纹信息     hongbinbin	  2019-09-04*/
        for d in (
            --ip share IP地址共享
            select count( b.ident) as IPCNT--IP地址历史共享次数
              ,sum(case when trunc(a.CREATE_TIME)=trunc(b.CREATE_TIME)  then 1 else 0 end) as IPCNT1day--IP地址1天共享次数
              ,sum(case when b.CREATE_TIME>=a.CREATE_TIME-7 then 1 else 0 end) as IPCNT7day--IP地址7天共享次数
              ,sum(case when b.CREATE_TIME>=a.CREATE_TIME-15 then 1 else 0 end) as IPCNT15day--IP地址15天共享次数
              ,sum(case when b.CREATE_TIME>=a.CREATE_TIME-30 then 1 else 0 end) as IPCNT30day--IP地址30天共享次数
              from TONGDUN_APPLY_INFOANALYSIS a
              left join TONGDUN_APPLY_INFOANALYSIS b on a.CREATE_TIME>b.CREATE_TIME and a.ident<>b.ident and a.IP_ADDRESS=b.IP_ADDRESS
              where a.ID_CREDIT=p_IdCredit
              group by a.ID_CREDIT
        )loop
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'External','Device','PaIPCNT',d.IPCNT,v_Seq+1); 
        
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'External','Device','PaIPCNT1day',d.IPCNT1day,v_Seq+2);
             
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'External','Device','PaIPCNT7day',d.IPCNT7day,v_Seq+3);
             
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'External','Device','PaIPCNT15day',d.IPCNT15day,v_Seq+4);
             
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'External','Device','PaIPCNT30day',d.IPCNT30day,v_Seq+5);
             
            v_Seq:=v_Seq + 5;   
        end loop;
        
        /*在External---Device 下新增设备指纹信息     hongbinbin	  2019-09-04*/
        for d in (
            --net position 网络归属地
            select case when instr(g.position,'中国')>0 then '中国'
              when g.position='局域网' then '局域网'
              when g.position='保留地址' then '保留地址'
              when g.position='共享地址' then '共享地址'
              else '国外' end as NetPosition --网络归属地
              from TONGDUN_APPLY_INFOANALYSIS a
              join TONGDUN_APPLY_IN_GEOIP_INFO  g on a.id=g.MAIN_ID
              where a.ID_CREDIT=p_IdCredit
        )loop
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'External','Device','PaNetPosition',d.NetPosition,v_Seq+1);
            v_Seq:=v_Seq + 1;   
        end loop;
    
        --hongbinbin 20190927
           for d in(           
                select cc.commit_time, cg.id_goods_category, cg.brand, cg.producer,case when to_char(sp.city) is not null then to_char(sp.city) else 
                    case when to_char(cm.STORE_PROVINCE) in('天津市','重庆市','北京市','上海市') then to_char(cm.STORE_PROVINCE) else to_char(cm.STORE_CITY) end end as city
                from cs_credit cc
                  join (select a.*,row_number() over(partition by a.id_credit order by a.GOODS_PRICE desc) as num_id from cs_goods a)cg 
                        on cc.id=cg.ID_CREDIT and cg.num_id=1
                  left join sellerplace sp on cc.id_sellerplace=sp.id
                  left join cs_merchant_store cm on cm.CONTRACT_NO=cc.CONTRACT_NO
                  where cc.id=p_IdCredit
                                  
           ) loop
               for f in (
                 with y as (
                    select id_credit,min(end_time) as end_time
                    from cs_audit_log2 l
                    join cs_credit cc on l.id_credit=cc.id                   
                    where to_status='y' and cc.app_date >= trunc(sysdate) -30 
                    group by id_credit)

                    ,goodsprice_data as (
                    select cc.CONTRACT_NO,cc.id,cc.commit_time,cc.APP_DATE,cc.status,cg.goods_price, cg.num_id
                    ,case when to_char(sp.city) is not null then to_char(sp.city) else 
                        case when to_char(cm.STORE_PROVINCE) in('天津市','重庆市','北京市','上海市') then to_char(cm.STORE_PROVINCE) else to_char(cm.STORE_CITY) end end as city
                    ,cg.id_goods_category,cg.id_goods_type,cg.producer,cg.brand,c.name as good_category,t.name as goods_type
                    from cs_credit cc
                    join (select a.*,row_number() over(partition by a.id_credit order by a.GOODS_PRICE desc) as num_id from cs_goods a)cg 
                          on cc.id=cg.ID_CREDIT and cg.num_id=1
                    join goods_category c on cg.id_goods_category=c.id
                    join goods_type t on cg.id_goods_type=t.id
                    left join sellerplace sp on cc.id_sellerplace=sp.id
                    left join cs_merchant_store cm on cm.CONTRACT_NO=cc.CONTRACT_NO
                    where cc.credit_model<>'YD' and cc.app_date >= trunc(sysdate) -30 
                          and cg.id_goods_category=d.id_goods_category and upper(cg.brand)=upper(d.brand) and upper(cg.producer)=upper(d.producer)
                          and trunc(cc.commit_time)>trunc(d.commit_time)-30 
                          and trunc(cc.commit_time)<trunc(d.commit_time)                        
                          and cc.status in ('a','p','k','y')
                    )
                    
                    ,goods_price_base as (
                      select a.*,end_time from goodsprice_data a
                      left join y on a.id=y.id_credit and y.end_time<trunc(d.commit_time)
                      where a.num_id=1 and a.city=d.city
                    )
                    
                    select nvl(sum(a.goods_price),0)/decode(count(a.id),0,1,count(a.id)) as L1mAvgPrice from goods_price_base a
                 )loop
                   --过去30天已通过合同在相同城市同品牌同类的产品平均价格
                   insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                   values(p_IdCredit,'HardCheck','*','PaL1mAvgPrice',f.L1mAvgPrice,v_Seq+1);
                   
                   v_Seq:=v_Seq + 1;
                
               end loop;              
              
           end loop;
           
         for d in(
            select a.id, a.commit_time,substr(b.ident,7,4) as birth_year,
              case when nvl(a.ID_SA,'1234') not in ('800079','300079','300076') and a.STATUS not in ('r','j') and a.CREDIT_TYPE<>'SC'
              then 
               case when max(case when c.address_type=2 then c.province else null end) in('天津市','重庆市','北京市','上海市') or max(case when c.address_type=3 then c.province else null end) in('天津市','重庆市','北京市','上海市')
                 then max(case when c.address_type=2 then c.province else null end) 
                 else
                replace(nvl(max(case when c.address_type=2 then c.city else null end),max(case when c.address_type=3 then c.city else null end)),'市')
              end else null end as city
              from cs_credit a
              join cs_person b on b.id=a.id_person
              left join cs_address c on c.id_credit=a.id
              where a.id=p_IdCredit
              group by a.id,a.commit_time,b.ident,a.ID_SA,a.STATUS,a.CREDIT_TYPE     
           )loop
           
              for f in(
                with y as (
                select id_credit,min(end_time) as end_time from cs_audit_log2 l
                join cs_credit cc on l.id_credit=cc.id and cc.CREDIT_TYPE<>'SC'
                where to_status='y' and cc.commit_time >= trunc(d.commit_time -30) and cc.commit_time < d.commit_time
                group by id_credit)
                
                ,contract_base as
                  (select crr.id,crr.commit_time,crr.status
                  from cs_credit crr
                  where nvl(crr.ID_SA,'1234') not in ('800079','300079','300076') and crr.STATUS not in ('r','j')
                        and CRR.CREDIT_TYPE<>'SC' and crr.commit_time >= trunc(d.commit_time -30) and crr.commit_time < d.commit_time
                  )
                  
                ,address_detail as(
                    select cb.id,
                    max(case when ca.address_type=2 then province else null end) as cur_province,
                    max(case when ca.address_type=2 then city else null end) as cur_city,
                    max(case when ca.address_type=3 then province else null end) as com_province,
                    max(case when ca.address_type=3 then city else null end) as com_city
                    from cs_address ca
                    join contract_base cb on ca.id_credit=cb.id
                    group by cb.id)
                    
                 ,wkincome_data as (
                    select * from
                    (
                      select cc.CONTRACT_NO,cc.id,cc.commit_time,cc.APP_DATE,cc.status,g.WK_INCOME,substr(ident,7,4) as birth_year
                      ,case when nvl(cur_province,com_province) in('天津市','重庆市','北京市','上海市') then nvl(cur_province,com_province)
                       else replace(nvl(cur_city,cur_city),'市') end as city
                      from cs_credit cc
                      join cs_person a on cc.ID_PERSON=a.ID
                      left join cs_employer ce on ce.ID_CREDIT=cc.ID and ce.STATUS='a' and ce.POSITION<>'9'
                      left join cs_experience g on cc.id=g.ID_CREDIT
                      left join address_detail s on cc.ID=s.ID
                      where credit_type<>'SC' and cc.CREDIT_MODEL<>'YD' and g.wk_income between 1000 and 10000 
                            and substr(ident,7,4) = d.birth_year
                            and cc.commit_time>trunc(d.commit_time)-30 and cc.commit_time<trunc(d.commit_time) 
                            and cc.status in ('a','p','k','y')
                      )tt where tt.city=d.city
                    ) 
                    
                  ,wkincome_base as (
                    select a.*,end_time from wkincome_data a
                    left join y on a.id=y.id_credit and y.end_time<trunc(d.commit_time)
                    )
                    
                    select
                     -- nvl(sum(a.WK_INCOME),0) sum_wkincome
                     -- ,sum(case when a.id is not null then 1 else 0 end) cases
                      nvl(sum(a.WK_INCOME),0)/decode(count(a.id),0,1,count(a.id)) as L1mAvgIncome
                      from wkincome_base a
                )loop
                 --L1mAvgIncome 过去30天已通过合同在相同城市同年龄客户的平均收入水平
                 insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                 values(p_IdCredit,'HardCheck','*','PaL1mAvgIncome',f.L1mAvgIncome,v_Seq+1);
                 v_Seq:=v_Seq + 1;             
             end loop;
             
           end loop;
           
         --hongbinbin 20191010 
        for d in (
          with sp_contact as (
            select b.id ,b.id_person, b.app_date, cs.PERSON_TYPE, cs.CONTACT_TYPE, cs.CONTACT_VALUE,  cs.UPDATE_TIME
            from  cs_credit b 
            left join cs_contact cs on b.id=cs.id_credit
            where b.credit_type='SP' and b.id=p_IdCredit and cs.PERSON_TYPE='1' and cs.CONTACT_TYPE='2'
            )    
                    
            select distinct aa.id,sum(case when bb.ID_CREDIT is not null then 1 else 0 end) as MobileDifTimes
              from sp_contact aa
              left join (
                   select distinct cc.ID_PERSON,cc.UPDATE_TIME,cc.ID_CREDIT,
                          cc.PERSON_TYPE,cc.CONTACT_TYPE,cc.CONTACT_VALUE
                    from cs_contact cc
                    where length(cc.CONTACT_VALUE)>=11
                    and cc.CONTACT_TYPE not in (2,11,17,13)                    
              ) bb on bb.ID_PERSON=aa.ID_PERSON and aa.CONTACT_VALUE=bb.CONTACT_VALUE
              and aa.id <> bb.ID_CREDIT and bb.UPDATE_TIME < aa.app_date              
              group by aa.id,bb.id_credit
          )loop           
              
               --客户在申请此合同时，客户手机号码被本人历史作为非移动电话使用过次数
               insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                 values( p_IdCredit,'HardCheck','*','PaMobileDifTimes',d.MobileDifTimes,v_Seq+1);
                 
                v_Seq:=v_Seq + 1;
          
          end loop;    
          
        for d in (
          with sp_contact as (
            select b.id ,b.id_person, b.app_date, cs.PERSON_TYPE, cs.CONTACT_TYPE, cs.CONTACT_VALUE,  cs.UPDATE_TIME
            from  cs_credit b 
            left join cs_contact cs on b.id=cs.id_credit
            where b.credit_type='SP' and b.id=p_IdCredit and cs.PERSON_TYPE='1' and cs.CONTACT_TYPE='3'
            )    
                    
           select distinct aa.id,sum(case when bb.ID_CREDIT is not null then 1 else 0 end) as ComPhoneUseCount
              from sp_contact aa
              left join (
                   select distinct cc.ID_PERSON,cc.UPDATE_TIME,cc.ID_CREDIT,
                          cc.PERSON_TYPE,cc.CONTACT_TYPE,cc.CONTACT_VALUE
                    from cs_contact cc
                    where length(cc.CONTACT_VALUE)>=11
                    and cc.CONTACT_TYPE = '3'                    
              ) bb on bb.ID_PERSON<>aa.ID_PERSON and aa.CONTACT_VALUE=bb.CONTACT_VALUE
              and aa.id <> bb.ID_CREDIT and bb.UPDATE_TIME < aa.app_date  
              group by aa.id,bb.id_credit    
              order by aa.id         

          )loop                     
               --客户办公电话在过去被其他人重复使用为办公电话次数
               insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                 values( p_IdCredit,'HardCheck','*','PaComPhoneUseCount',d.ComPhoneUseCount,v_Seq+1);
                 
                v_Seq:=v_Seq + 1;
          
          end loop;          
      
      --以上元素，如果值为空则删除（与终审保持一致）	yangzhenxian    2019-06-18
       delete decision_element_data_pa where id_credit=p_IdCredit and element_value is null;
        
        
        --即速用新增元素        yangzhenxian                                          2019-05-15
        if v_CreditType ='SP'
        then
           --是否即有消费贷客户      PaIsSsPerson
           insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
           select p_IdCredit,'HardCheck','*','PaIsSsPerson',max(case when ID_PERSON is null then 0 else 1 end),v_Seq+1
           from cs_credit where id_person=v_IdPerson and credit_type='SS' and status in ('a','p','k','d');
          v_Seq:=v_Seq + 1;
        
        end if;
          
           --爰金人脸识别分数      IdentVerifyYuanjin
           insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
           select p_IdCredit,'External','*','PaIdentVerifyYuanjin',max(case when v.ID_CREDIT is null then 999  when v.score is null and v.remark like'图片质量不合格%' then 888  else nvl(v.SCORE,-1) end),v_Seq+1
           from cs_credit c left join liveness_ident_verify v on c.id=v.ID_CREDIT  and v.SUPPLIER_CODE='YUANJIN' where c.id=p_IdCredit;
          v_Seq:=v_Seq + 1;
          
           --商汤人脸识别分数      IdentVerifyShangtang
           insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
           select p_IdCredit,'External','*','PaIdentVerifyShangtang',max(case when v.ID_CREDIT is null then 999 when v.score is null and v.remark like'图片质量不合格%' then 888  else nvl(v.SCORE,-1) end),v_Seq+1
           from cs_credit c left join liveness_ident_verify v on c.id=v.ID_CREDIT  and v.SUPPLIER_CODE='SHANGTANG' where c.id=p_IdCredit;
          v_Seq:=v_Seq + 1;
          
           --face人脸识别分数      IdentVerifyFace
           insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
           select p_IdCredit,'External','*','PaIdentVerifyFace',max(case when v.ID_CREDIT is null then 999 when v.score is null and v.remark like'图片质量不合格%' then 888 else nvl(v.SCORE,-1) end),v_Seq+1
           from cs_credit c left join liveness_ident_verify v on c.id=v.ID_CREDIT  and v.SUPPLIER_CODE='FACEID' where c.id=p_IdCredit;
          v_Seq:=v_Seq + 1;
          
           --人脸识别分数汇总     IdentVerifyScore
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            select p_IdCredit,'External','*','PaIdentVerifyScore',max(case when v.ID_CREDIT is null then 999 when v.score is null and v.remark like'图片质量不合格%' then 888   else nvl(v.SCORE,-1) end),v_Seq+1
            from cs_credit c left join liveness_ident_verify v on c.id=v.ID_CREDIT   where c.id=p_IdCredit;
            v_Seq:=v_Seq + 1;
          
           for d in (
             select max(CONTACTS_ROUTER_CNT)as ContactByTwoCNT--引起二阶黑名单人数
             ,max(PAIO_SUSP_ORG_TYPE) as NameOGRType --电话号码在那种机构类型中出现该姓名最近一次出现机构类型名称
             ,max(GRAY_CNS_CNT_TO_APPLIED) as GrayCnsCntAppl--主动联系人中曾为申请人的人数
              from external_miguan_basic_info v where v.id_credit=p_IdCredit
           )loop
              insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values( p_IdCredit,'External','JuxinliMiguan','PaContactByTwoCNT',d.ContactByTwoCNT,v_Seq+1 );
              insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values( p_IdCredit,'External','JuxinliMiguan','PaNameOGRType',d.NameOGRType,v_Seq+1 );
              insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values( p_IdCredit,'External','JuxinliMiguan','PaGrayCnsCntAppl',d.GrayCnsCntAppl,v_Seq+1 );
              v_Seq:=v_Seq + 3;
           end loop;
           
            for d in (
             select * from (
              select to_number(SEARCH_BY_M_24_PCT_CNT_ORG_ALL ) as SearchOrgInAllCntRate24M
              ,USER_PHONE_CITY as UserPhoneCity
              ,row_number()over(partition by cc.id order by m.create_time desc) as rnk
              from cs_credit cc 
              left join external_miguan_basic_info m ON m.id_credit=cc.id
              where cc.id=p_IdCredit
              )where rnk=1
           )loop
           
              --蜜罐24个月内查询机构数在总体查询分布中的百分位
              insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values( p_IdCredit,'External','JuxinliMiguan','PaSearchOrgInAllCntRate24M',d.SearchOrgInAllCntRate24M,v_Seq+1 );
               
              --手机号归属地城市
              insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values( p_IdCredit,'External','JuxinliMiguan','PaUserPhoneCity',d.UserPhoneCity,v_Seq+1 );
               
              v_Seq:=v_Seq + 2;
              
           end loop;    
           
          /*External.TongDun.MultiLoanMCCountFraudMetrix3M：同盾最近三个月小额贷款次数 */
          for d in (
              select max(case when t.rule_name='新_3个月内申请人身份证或手机在多个平台申请借款' and instr(t.rule_detail,'小额贷款公司')>0 
                              then to_number(regexp_substr(substr(t.RULE_DETAIL,instr(t.rule_detail,'小额贷款公司') + 7,3),'[0-9]+')) else 0 end) 
                     as MultiLoanMCCountFraudMetrix3M---同盾最近三个月小额贷款次数
              from WFI_FRAUD_METRIX_RESULT a
              left join WFI_FRAUD_METRIX_RULE t on a.id=t.fraud_metrix_result_id
              where a.event_name='Credit' and a.update_time>=date'2018-01-01' and a.ASSOCIATED_ID=p_IdCredit
            )loop
              insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values( p_IdCredit,'External','TongDun','PaMultiLoanMCCountFraudMetrix3M',d.MultiLoanMCCountFraudMetrix3M,v_Seq+1 );
              v_Seq:=v_Seq + 1;
            end loop;
           
          for d in (
              select max(case when r.DETAIL_NAME='二度关联节点个数' then to_number(r.DETAIL_VAL) else 0 end) as RiskTwoCount --同盾复杂网络二度关联节点个数
                     ,max(case when r.DETAIL_NAME='风险群体的节点分布' and instr(r.DETAIL_VAL,'设备ID')>0 then 1 else 0 end) as RiskGroupSheBei--同盾复杂网络设备节点分布
              from WFI_FRAUD_METRIX_RESULT a
              left join WFI_FRAUD_METRIX_RULE t on a.id=t.fraud_metrix_result_id
              left join wfi_fraud_metrix_rule_detail r on t.id=r.RULE_ID and r.rule_name like '%复杂网络%'
              where a.event_name='Credit' and a.update_time>=date'2018-01-01' and a.ASSOCIATED_ID=p_IdCredit
            )loop
              insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values( p_IdCredit,'External','TongDun','PaRiskTwoCount',d.RiskTwoCount,v_Seq+1 );
              insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values( p_IdCredit,'External','TongDun','PaRiskGroupSheBei',d.RiskGroupSheBei,v_Seq+1 );
              v_Seq:=v_Seq + 2;
            end loop;
          
           --新颜探针A黑名单建议      BlackListSuggest
           insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
           select p_IdCredit,'External','XinYan','PaBlackListSuggest',max(result_code),v_Seq+1
           from XINYAN_PROBEA_BLACKLIST v where v.id_credit=p_IdCredit;
          v_Seq:=v_Seq + 1;
          
           --新颜探针B白名单建议      WhiteListSuggest
           insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
           select p_IdCredit,'External','XinYan','PaWhiteListSuggest',max(result_code),v_Seq+1
           from XINYAN_PROBEB_WHITELIST v where v.id_credit=p_IdCredit;
          v_Seq:=v_Seq + 1;
        
       commit;

       p_ReturnCode:='A';
       return;
    exception
       When others Then
         error_info := sqlerrm;
         p_ReturnCode:='Z-'||error_info||DBMS_UTILITY.format_error_backtrace;
         rollback;
    end;
/

