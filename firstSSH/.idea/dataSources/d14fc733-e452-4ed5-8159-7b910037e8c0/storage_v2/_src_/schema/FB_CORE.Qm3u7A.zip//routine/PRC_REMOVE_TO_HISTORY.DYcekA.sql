create procedure PRC_REMOVE_TO_HISTORY
(
p_IdCredit cs_credit.id%type
)
is
begin

  delete decision_element_data_history where id_credit=p_IdCredit;
  insert into decision_element_data_history select * from decision_element_data where id_credit=p_IdCredit;
  delete decision_element_data where id_credit=p_IdCredit;
  --删除蜂鸟系统的审核元素数据
  delete decision_element_data_fn where id_credit=p_IdCredit and element_type='UwAudit';
  commit;

Exception
  When others Then
    rollback;
end PRC_REMOVE_TO_HISTORY;
/

