create procedure prc_collect_element_final_exnl(p_IdCredit cs_credit.id%type,p_externalCode varchar2,p_ReturnCode out varchar2) is
       error_info                  varchar2(1000);
       -- Author  : yangzhenxian
       -- Create Date : 2019-09-02
       -- Purpose : 提取终审外部数据元素;
       v_AppDate                   cs_credit.app_date%type;
       v_CommitTime                cs_credit.commit_time%type;
       v_InterCode                 cs_credit.inter_code%type;   
       v_CreditType                cs_credit.credit_type%type;    
       v_IdPerson                  cs_person.id%type;   
       v_Seq                       decision_element_data.sort_code%type;
       v_Count                     integer;
    begin
       delete decision_element_data where id_credit=p_IdCredit and external_code=p_externalCode;

       v_Seq:=0;
       
      select a.app_date,a.commit_time,a.inter_code,a.id_person,a.credit_type
         into v_AppDate,v_CommitTime,v_InterCode,v_IdPerson,v_CreditType
         from cs_credit a,sys_user_list b where a.id_sa=b.id(+) and a.id=p_IdCredit;
              
       if p_externalCode = 'BaiqishiAntifraud' or p_externalCode='ALL' then  
         
            /*在External---BaiQiShi 下新增元素StrategyName     yangzhenxian   2019-07-24*/        
            for d in (
              select min(
              case when bqs2.STRATEGY_NAME='历史安装应用统计策略' then 1
                   when bqs2.STRATEGY_NAME='历史多头名单策略' then 2
                   when bqs2.STRATEGY_NAME='失信风险策略' then 3
                   when bqs2.STRATEGY_NAME='多头风险策略' and bqs4.NAME='总数' and bqs4.RULE_DETAIL_VALUE>20 then 4
                   when bqs2.STRATEGY_NAME='多头风险策略' and bqs4.NAME not in ('第三方支付','银行') then 5
                   when bqs2.STRATEGY_NAME='多头风险策略' then 6
                   when bqs2.STRATEGY_NAME='百度风险名单策略' then 7                 
                   when bqs2.STRATEGY_NAME='复杂关系网络策略' then 8            
                   when bqs2.STRATEGY_NAME='历史复杂网络策略' then 9
                   when bqs2.STRATEGY_NAME='异常行为策略' then 10 else 99 end) as StrategyName
              FROM BAIQISHI_DECISION_RESULT bqs
              /*JOIN dafy_sales.cs_credit cc ON bqs.id_cerdit=cc.id*/          
              LEFT JOIN BAIQISHI_DECISION_STRATEGY bqs2 ON bqs.id=bqs2.result_id
              LEFT JOIN BAIQISHI_DECISION_RULE bqs3 ON bqs2.id=bqs3.strategy_id
              LEFT JOIN BAIQISHI_DECISION_RULE_DETAIL bqs4 ON bqs3.id=bqs4.rule_id
              where bqs.ID_CERDIT=p_IdCredit
            )loop
                insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                 values( p_IdCredit,'External','BaiQiShi','StrategyName',d.StrategyName,v_Seq+1,p_externalCode );            
                 v_Seq:=v_Seq + 1;   
            end loop;           
            
            /*一个白骑士的元素FinalDecision  yangzhenxian  2019-03-18*/      
            for d in (
                with temp as(
                select id_cerdit id_credit,final_decision from BAIQISHI_DECISION_RESULT p
                 where p.id_cerdit=p_IdCredit order by p.create_time desc
                 )
                select final_decision from temp where rownum=1
              )loop
                if d.final_decision is not null
                then 
                  insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                   values( p_IdCredit,'External','BaiQiShi','FinalDecision',d.final_decision,v_Seq+1,p_externalCode );            
                   v_Seq:=v_Seq + 1;
                end if;        
              end loop; 
                 
       end if;  
       
       --百融支付行为
       if p_externalCode = 'BaiRongPaybehavior' or p_externalCode='ALL' then
         
            /*表external_br_pay_behavior是否正常*/
            insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             select p_IdCredit,'External','BaiRong','IsBehavior',case when nvl(v_InterCode,'1') in('3','4') then 1 when IsBehavior >0 then 1 else 0 end,v_Seq+1,p_externalCode
             from (select count(1) IsBehavior from external_br_pay_behavior t where t.id_credit=p_IdCredit) ;
             
            v_Seq:=v_Seq + 1;
            
            for d in (
                select * from (select ID_CREDIT,t.MON_12_VAR1 RecentYearDeal, RFM_12_VAR1 BRDealAmount12M,
                      FLAG_PAYBEHAVIOR as PayBehavior,SUMMARY_SCORE as SummaryScore,MCC_3_VAR1 AS MCCCnt3M,
                      RFM_6_VAR3 AS LargestConsAmt6M,FLAG_6_VAR4 AS FlagOnline6M
                 from external_br_pay_behavior t
               where t.id_credit=p_IdCredit order by t.create_time desc) where rownum=1
              )loop
              
              --------1.增加元素External. BaiRong. RecentYearDeal /*近十二个月发生交易月份数*/
              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
               values( p_IdCredit,'External','BaiRong','RecentYearDeal',d.RecentYearDeal,v_Seq+1,p_externalCode );
               
              v_Seq:=v_Seq + 1;

              -------增加元素External. BaiRong. BRDealAmount12M  2019-08-22 yangzhenxian
              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
               values( p_IdCredit,'External','BaiRong','BRDealAmount12M',d.BRDealAmount12M,v_Seq+1,p_externalCode );
               
              v_Seq:=v_Seq + 1;
              
              --hongbinbin 20190924
               --支付消费行为偏好产品计费标识
               insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                      values( p_IdCredit,'External','BaiRong','PayBehavior',d.PayBehavior,v_Seq+1,p_externalCode); 
                      
               --消费综合评分
               insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                      values( p_IdCredit,'External','BaiRong','SummaryScore',d.SummaryScore,v_Seq+2,p_externalCode); 
                      
               --近3个月发生交易的MCC种类数
               insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                      values( p_IdCredit,'External','BaiRong','MCCCnt3M',d.MCCCnt3M,v_Seq+3,p_externalCode); 
                      
               --交易代码是消费类且近6个月最大的消费金额
               insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                      values( p_IdCredit,'External','BaiRong','LargestConsAmt6M',d.LargestConsAmt6M,v_Seq+4,p_externalCode); 
                      
               --近6个月线上消费标志
               insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                      values( p_IdCredit,'External','BaiRong','FlagOnline6M',d.FlagOnline6M,v_Seq+5,p_externalCode); 
                  
               v_Seq:=v_Seq + 5;     
               
            end loop;
            
       end if;
       
       --百融特殊名单
       if p_externalCode = 'BaiRongSpecialist' or p_externalCode='ALL' then
          -------2.增加元素External. BaiRong. FlagSpeciallist/*稳定性评估产品输出标识*/            
          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             select ID_CREDIT,'External','BaiRong','FlagSpeciallist',flag_speciallist_c,v_Seq+1,p_externalCode
             from (select ID_CREDIT,t.flag_speciallist_c from external_br_speciallist_c t
             where t.id_credit=p_IdCredit order by t.create_time desc) where rownum=1 ;

           v_Seq:=v_Seq + 1;
           
          /*表external_br_speciallist_c是否正常*/
          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
           select p_IdCredit,'External','BaiRong','IsSpecialList',case when nvl(v_InterCode,'1') in('3','4') then 1 when IsSpecialList>0 then 1 else 0 end,v_Seq+1,p_externalCode
           from (select count(1) IsSpecialList from external_br_speciallist_c t where t.id_credit=p_IdCredit) ;
             
          v_Seq:=v_Seq + 1;       
            
       end if;
       
       --百融打包（打包1+2）
       if p_externalCode = 'BaiRongPack' or p_externalCode = 'BaiRongPack1' or p_externalCode = 'BaiRongPack2' or p_externalCode='ALL'  then       
         
          for d in (
              select * from (select t.flag_stability_c,STAB_AUTH_NAME from external_br_stability_c t
             where t.id_credit=p_IdCredit order by t.create_time desc) where rownum=1
            )loop
            
            -------增加元素External. BaiRong. AuthName  百融稳定性库中姓名是否匹配  2018-04-18 yangzhenxian
            insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             values( p_IdCredit,'External','BaiRong','AuthName',d.stab_auth_name,v_Seq+1,p_externalCode );
             
            v_Seq:=v_Seq + 1;
            
            -------3.增加元素External. BaiRong. FlagStability/*特殊名单核查产品输出标识*/
            insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             values( p_IdCredit,'External','BaiRong','FlagStability',d.flag_stability_c,v_Seq+1,p_externalCode );
             
            v_Seq:=v_Seq + 1;   
                     
          end loop;
            
             /*过去半个小时内百融多次借贷未查得合同数BRApplyLoanFailedCount           yangzhenxian   2018/04/27 add      2019/01/22  update*/
             insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             select p_IdCredit,'External','BaiRong','BRApplyLoanFailedCount',count(1),v_Seq+1,p_externalCode
             from cs_credit a where not exists(select 1 from external_br_applyloan b
                                                 where b.code<>9999 and b.id_credit=a.id)
                               and a.status not in('r','t') and nvl(a.inter_code,0) not in(3,4)
                               and a.credit_type=decode(v_CreditType,'SC','SC','SS','SS','XF','XF','SP')
                               and a.commit_time>=v_CommitTime-35/24/60 and a.commit_time<=v_CommitTime-5/24/60;
                               
             v_Seq:=v_Seq + 1;             
               
              --BRCreditcardDef3M: 最近3个月信用卡是否逾期
              select count(1) into v_Count
              from external_br_accountchangemonth t
              where t.acm_m1_credit_def is not null and t.acm_m2_credit_def is not null
               and t.acm_m3_credit_def is not null and t.id_credit=p_IdCredit;
              if v_Count>=1 then
                --BRCreditcardDef3M: 最近3个月信用卡是否逾期
                insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                select p_IdCredit,'External','BaiRong','BRCreditcardDef3M',
                nvl(t.acm_m1_credit_def,0)+nvl(t.acm_m2_credit_def,0)+nvl(t.acm_m3_credit_def,0),v_Seq+1,p_externalCode
                from external_br_accountchangemonth t where t.id_credit=p_IdCredit;
                v_Seq:=v_Seq + 1;
              end if;
              
              --BRMultiLoanCountBank12M: 最近12个月身份证或手机在银行借款次数，取ident_bank,mobilephone_bank较大值
              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
              select p_IdCredit,'External','BaiRong','BRMultiLoanCountBank12M',
              case when nvl(t1.al_m12_id_bank_allnum,0)-nvl(t1.al_m12_cell_bank_allnum,0)>0 then
              nvl(t1.al_m12_id_bank_allnum,0) else
              nvl(t1.al_m12_cell_bank_allnum,0) end,
              v_Seq+1,p_externalCode
              from external_br_applyloan t1 where t1.id_credit=p_IdCredit;
              v_Seq:=v_Seq + 1;
              v_Count:=0;
              
              --BRMultiLoanCountNotBank12M: 最近12个月身份证或手机在非银行借款次数，排除本机构，取ident_notbank,mobilephone_notbank的较大值
              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
              select p_IdCredit,'External','BaiRong','BRMultiLoanCountNotBank12M',
              case when (nvl(t1.al_m12_id_notbank_allnum,0)-nvl(t1.al_m12_id_notbank_selfnum,0))-
              (nvl(t1.al_m12_cell_notbank_allnum,0)-nvl(t1.al_m12_cell_notbank_selfnum,0))>0 then
              (nvl(t1.al_m12_id_notbank_allnum,0)-nvl(t1.al_m12_id_notbank_selfnum,0)) else
              (nvl(t1.al_m12_cell_notbank_allnum,0)-nvl(t1.al_m12_cell_notbank_selfnum,0)) end,
              v_Seq+1,p_externalCode
              from external_br_applyloan t1 where t1.id_credit=p_IdCredit;
              v_Seq:=v_Seq + 1;
              
               --百融评分 External. BaiRong. BRScore 2016/11/03 wangxiaofeng --              
              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                select p_IdCredit,'External','BaiRong','BRScore',t.scoreconsoffv2,v_Seq+1,p_externalCode
                from external_br_rules t
                where t.scoreconsoffv2 is not null and t.id_credit=p_IdCredit;
                v_Seq:=v_Seq + 1;
              
              --BRScorecardActive: 是否命中百融评分卡(1,命中; 0,未命中)，满足以下条件之一即命中
              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
              select p_IdCredit,'External','BaiRong','BRScorecardActive',decode(count(1),0,0,1),v_Seq+1,p_externalCode
              from external_br_accountchangemonth t2
              join external_br_applyloan t1 on t1.id_credit=t2.id_credit
              where ((nvl(t1.al_m12_id_notbank_allnum,0)-nvl(t1.al_m12_id_notbank_selfnum,0)>0
                   or nvl(t1.al_m12_cell_notbank_allnum,0)-nvl(t1.al_m12_cell_notbank_selfnum,0)>0
                   or nvl(t1.al_m12_id_bank_allnum,0)>0 or nvl(t1.al_m12_cell_bank_allnum,0)>0
                   or nvl(t2.flag_accountchangemonth,0)=1))
                   and t2.id_credit=p_IdCredit;
              v_Seq:=v_Seq + 1;
            
            --------------------按身份证号查询，近12个月在非银机构-消费类分期申请机构数 yangzhenxian   2017-12-06
            insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             select p_IdCredit,'External','BaiRong','IdentNBank12M',IdentNBank12M,v_Seq+1,p_externalCode
             from (select t.ALS_M12_ID_NBANK_CF_ORGNUM IdentNBank12M from external_br_applyloan t
             where t.id_credit=p_IdCredit order by t.create_time desc) where rownum=1 ;
             
             v_Seq:=v_Seq + 1;
              
              --------------------按身份证号查询，近12个月在非银机构-消费类分期申请机构数 yangzhenxian   2017-12-06
              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
               select p_IdCredit,'External','BaiRong','IdentNBank1M',IdentNBank1M,v_Seq+1,p_externalCode
               from (select t.ALS_M1_ID_NBANK_CF_ORGNUM IdentNBank1M from external_br_applyloan t
               where t.id_credit=p_IdCredit order by t.create_time desc) where rownum=1 ;
               
              v_Seq:=v_Seq + 1;
              
              --------------------按身份证号查询，近6个月在非银机构-其他申请次数 yangzhenxian   2017-12-06
              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
               select p_IdCredit,'External','BaiRong','IdentNBank6M',IdentNBank6M,v_Seq+1,p_externalCode
               from (select t.ALS_M6_ID_NBANK_OTH_ALLNUM IdentNBank6M from external_br_applyloan t
               where t.id_credit=p_IdCredit order by t.create_time desc) where rownum=1;
               
              v_Seq:=v_Seq + 1;
              
            for d in (
                select * from (select ID_CREDIT,nvl(t.als_lst_id_nbank_inteday,0) IdentNBankIteDay 
                ,nvl(t.ALS_M12_CELL_NBANK_AVG_MONNUM,0) MobileApplyCountNotBank12M ,nvl(t.AL_M12_ID_NOTBANK_ORGNUM,0) IdentNBankORG12M,nvl(t.ALS_M6_CELL_NBANK_OTH_ORGNUM,0) BRCellNBankORG6M
                from external_br_applyloan t
               where t.id_credit=p_IdCredit order by t.create_time desc) where rownum=1
              )loop
              -------1.增加元素External. BaiRong. IdentNBankIteDay/*按身份证号查询，距最近在非银行机构申请的间隔天数*/
              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
               values( p_IdCredit,'External','BaiRong','IdentNBankIteDay',d.IdentNBankIteDay,v_Seq+1,p_externalCode );
               
              v_Seq:=v_Seq + 1;

              -------2.  External.BaiRong. MobileApplyCountNotBank12M：按手机号查询，近12个月在非银机构平均每月申请次数 (可参考External.BaiRong.IdentNBankIteDay)
              -------2019-03-07 yangzhenxian
              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
               values( p_IdCredit,'External','BaiRong','MobileApplyCountNotBank12M',d.MobileApplyCountNotBank12M,v_Seq+1,p_externalCode );
               
              v_Seq:=v_Seq + 1;      

              -------外部数据库--百融--- IdentNBankORG12M  近12个月在非银机构平台数
              -------2019-04-02 yangzhenxian
              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
               values( p_IdCredit,'External','BaiRong','IdentNBankORG12M',d.IdentNBankORG12M,v_Seq+1,p_externalCode );
               
              v_Seq:=v_Seq + 1;
              
              -------2019-08-22 yangzhenxian
              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
               values( p_IdCredit,'External','BaiRong','BRCellNBankORG6M',d.BRCellNBankORG6M,v_Seq+1,p_externalCode );
               
              v_Seq:=v_Seq + 1;
              
            end loop;
             
            for d in (
                with temp as(
                select t.AL_M6_ID_NOTBANK_ORGNUM as IdentNBankORG6M from external_br_applyloan t
                where t.id_credit=p_IdCredit order by t.create_time desc)
                select  IdentNBankORG6M from temp where rownum=1
              )loop
              
              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
               values( p_IdCredit,'External','BaiRong','IdentNBankORG6M',d.IdentNBankORG6M,v_Seq+1,p_externalCode );
               
              v_Seq:=v_Seq + 1;
              
              end loop;
           
          for d in(
            with temp as(select t.IR_ID_X_CELL_CNT IdentRelateCell,t.IR_ID_IS_REABNORMAL as IsIdentAbnormal
            ,t.IR_M3_CELL_X_BIZ_ADDR_CNT as MobRelateAddr3M ,t.IR_CELL_X_ID_CNT as MobRelateIdCnt,t.IR_M6_CELL_X_BIZ_ADDR_CNT MobRelateAddr6M
            from external_br_inforelation t where t.id_credit=p_IdCredit order by t.create_time desc)
              select * from temp where rownum=1
            )
          loop
            
            insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             values(p_IdCredit,'External','BaiRong','IdentRelateCell',d.IdentRelateCell,v_Seq+1,p_externalCode);
             
            v_Seq:=v_Seq + 1;

            ------------------身份证号是否关联异常 yangzhenxian    2018-01-15
            insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             values(p_IdCredit,'External','BaiRong','IsIdentAbnormal',d.IsIdentAbnormal,v_Seq+1,p_externalCode);
             
            v_Seq:=v_Seq + 1;

            ------------------MobRelateAddr3M:近三个月手机号关联公司地址个数 yangzhenxian    2018-03-23
            insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             values(p_IdCredit,'External','BaiRong','MobRelateAddr3M',d.MobRelateAddr3M,v_Seq+1,p_externalCode);
             
            v_Seq:=v_Seq + 1;
            
            ------------------MobRelateAddr6M:近六个月手机号关联公司地址个数 马剑锋    2018-05-31
             insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             values(p_IdCredit,'External','BaiRong','MobRelateAddr6M',d.MobRelateAddr6M,v_Seq+1,p_externalCode);
             
            v_Seq:=v_Seq + 1;

            ------------------MobRelateIdCnt：手机号关联身份证个数 yangzhenxian    2018-03-23
            if d.MobRelateIdCnt is not null
            then
              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
               values(p_IdCredit,'External','BaiRong','MobRelateIdCnt',d.MobRelateIdCnt,v_Seq+1,p_externalCode);
               
              v_Seq:=v_Seq + 1;
              
            end if;
            
          end loop;
           
          -------4.增加元素External. BaiRong. MobChangeIteDay/*身份证关联的手机号最近一次变动距今天数*/
          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             select ID_CREDIT,'External','BaiRong','MobChangeIteDay',nvl(ir_id_x_cell_lastchg_days,0),v_Seq+1,p_externalCode
             from (select ID_CREDIT,t.ir_id_x_cell_lastchg_days from external_br_inforelation t
             where t.id_credit=p_IdCredit order by t.create_time desc) where rownum=1;
             
            v_Seq:=v_Seq + 1;
          
          for d in (
              select * from (select ID_CREDIT,t.pc_user_level BRPcUserLevel from external_br_personalcre t
             where t.id_credit=p_IdCredit order by t.create_time desc) where rownum=1
            )loop
            insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             values( p_IdCredit,'External','BaiRong','BRPcUserLevel',d.BRPcUserLevel,v_Seq+1,p_externalCode );
             
            v_Seq:=v_Seq + 1;
            
          end loop;
                     
          --------------------近3个月最大单类目消费金额的类目 yangzhenxian   2017-12-06
          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
           select p_IdCredit,'External','BaiRong','MaxPayCate3M',MaxPayCate3M,v_Seq+1,p_externalCode
           from (select t.CONS_MAX_M3_PAYCATE MaxPayCate3M from external_br_consumption_c t
           where t.id_credit=p_IdCredit order by t.create_time desc) where rownum=1 ;
           
           v_Seq:=v_Seq + 1;          
           
          for d in (
              with temp as(
              select t.CONS_MAX_M12_NUM as MaxPayCate12M from external_br_consumption_c t
              where t.id_credit=p_IdCredit order by t.create_time desc)
              select  MaxPayCate12M from temp where rownum=1
            )loop
            insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             values( p_IdCredit,'External','BaiRong','MaxPayCate12M',d.MaxPayCate12M,v_Seq+1,p_externalCode );
               
            v_Seq:=v_Seq + 1;
              
            end loop;
              
            ------------------------外部数据是否查询正常  yangzhenxian  2018-02-06
            /*表external_br_applyloan是否正常*/
            insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             select p_IdCredit,'External','BaiRong','IsApplyLoan',case when nvl(v_InterCode,'1') in('3','4') then 1 when IsApplyLoan >0 then 1 else 0 end,v_Seq+1,p_externalCode
             from (select count(1) IsApplyLoan from external_br_applyloan t where t.id_credit=p_IdCredit) ;
             
            v_Seq:=v_Seq + 1;
            
            /*表external_br_stability_c是否正常*/
            insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             select p_IdCredit,'External','BaiRong','IsStability',case when nvl(v_InterCode,'1') in('3','4') then 1 when IsStability >0 then 1 else 0 end,v_Seq+1,p_externalCode
             from (select count(1) IsStability from external_br_stability_c t where t.id_credit=p_IdCredit) ;
             
            v_Seq:=v_Seq + 1;
            
            /*表external_br_inforelation是否正常*/
            insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             select p_IdCredit,'External','BaiRong','IsInforelation',case when nvl(v_InterCode,'1') in('3','4') then 1 when IsInforelation >0 then 1 else 0 end,v_Seq+1,p_externalCode
             from (select count(1) IsInforelation from external_br_inforelation t where t.id_credit=p_IdCredit) ;
             
            v_Seq:=v_Seq + 1;
            
            /*表external_br_consumption_c是否正常*/
            insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             select p_IdCredit,'External','BaiRong','IsConsumption',case when nvl(v_InterCode,'1') in('3','4') then 1 when IsConsumption >0 then 1 else 0 end,v_Seq+1,p_externalCode
             from (select count(1) IsConsumption from external_br_consumption_c t where t.id_credit=p_IdCredit) ;
             
            v_Seq:=v_Seq + 1;
            
            /*百融表是否查询成功*/
            insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             select p_IdCredit,'External','BaiRong','IsBr',case when nvl(v_InterCode,'1') in('3','4') then 1 when is_applyloan>0 and is_speciallist>0 and is_stability>0 and is_inforelation>0
             and is_pay_behavior>0 and is_consumption_c>0 then 1 else 0 end,v_Seq+1,p_externalCode
             from (
                  select
                  (select count(1)  from external_br_applyloan where id_credit=p_IdCredit ) is_applyloan,
                  (select count(1)  from external_br_speciallist_c where id_credit=p_IdCredit ) is_speciallist,
                  (select count(1)  from external_br_stability_c where id_credit=p_IdCredit ) is_stability,
                  (select count(1)  from external_br_inforelation where id_credit=p_IdCredit ) is_inforelation,
                  (select count(1)  from external_br_pay_behavior where id_credit=p_IdCredit ) is_pay_behavior,
                  (select count(1)  from external_br_consumption_c where id_credit=p_IdCredit ) is_consumption_c
                  from dual
             ) ;
             
            v_Seq:=v_Seq + 1;	
            
            /*近12月手机号关联邮箱个数MobRelateMail12M  yangzhenxian  2019-03-18*/      
            for d in (
              with temp as(
              select IR_M12_CELL_X_MAIL_CNT as MobRelateMail12M from external_br_inforelation p
               where p.id_credit=p_IdCredit order by p.create_time desc
               )
              select MobRelateMail12M from temp where rownum=1
            )loop
            
              if d.MobRelateMail12M is not null
              then 
                
                insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                 values( p_IdCredit,'External','BaiRong','MobRelateMail12M',d.MobRelateMail12M,v_Seq+1,p_externalCode );
                             
                 v_Seq:=v_Seq + 1;
                 
              end if;  
                    
            end loop;             
           
           /*在External---BaiRong FlagSpecialCate     hongbinbin   2019-09-04*/        
           for d in (
               select max(case when decode(a.sl_cell_bank_refuse,null,0,1)+decode(a.sl_cell_nbank_cf_refuse,null,0,1)+decode(a.sl_cell_bank_fraud,null,0,1)+decode(a.sl_id_nbank_p2p_bad,null,0,1)>0 then '1HighRisk'
                            when decode(a.sl_id_nbank_p2p_bad,null,0,1)+decode(a.sl_cell_nbank_p2p_bad,null,0,1)+decode(a.sl_id_nbank_cf_bad,null,0,1)+decode(a.sl_cell_p2p_bad,null,0,1)>0 then '2MediumRisk'
                            when a.FLAG_SPECIALLIST_C ='1' then '3FlagRisk' else '9Normal' end )as FlagSpecialCate  ---旧版特殊名单核查分类
              from cs_credit cc
              left join external_br_speciallist_c  a on a.ID_CREDIT=cc.ID
              where cc.id=p_IdCredit
          )loop
          
              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
               values( p_IdCredit,'External','BaiRong','FlagSpecialCate',d.FlagSpecialCate,v_Seq+1,p_externalCode); 
                         
                v_Seq:=v_Seq + 1;   
                
          end loop; 
          
          /*在External---BaiRong  FlagSpeciallistNew、FlagSpecialCateNew     hongbinbin   2019-09-04*/        
          for d in (
              select a.FLAG_SPECIALLIST_C as FlagSpeciallistNew,---新版特殊名单核查产品输出标识
                      max(case when decode(a.SL_CELL_BANK_FRAUD_TIME,null,0,1)+decode(a.SL_LM_CELL_BANK_BAD_ALLNUM,null,0,1)+decode(a.SL_CELL_BANK_FRAUD,null,0,1)+decode(a.SL_CELL_BANK_FRAUD_ALLNUM,null,0,1)+decode(a.SL_LM_CELL_BANK_BAD,null,0,1) >0 then  '1BankRisk'
                        when decode(a.SL_ID_NBANK_FINLEA_BAD,null,0,1)+decode(a.SL_ID_NBANK_FINLEA_BAD_TIME,null,0,1)+decode(a.SL_ID_NBANK_FINLEA_BAD_ALLNUM,null,0,1)+decode(a.SL_CELL_NBANK_FINLEA_BAD,null,0,1)+decode(a.SL_CELL_NBANK_FINLEA_BAD_TIME,null,0,1)+decode(a.SL_CELL_NBANK_FI_BAD_ALLNUM,null,0,1) >0 then  '2FinleaRisk'
                        when decode(a.SL_ID_NBANK_NSLOAN_BAD,null,0,1)+decode(a.SL_ID_NBANK_NSLOAN_BAD_ALLNUM,null,0,1)+decode(a.SL_CELL_NBANK_SLOAN_BAD,null,0,1)+decode(a.SL_CELL_NBANK_SLOAN_BAD_ALLNUM,null,0,1)+decode(a.SL_ID_NBANK_NSLOAN_BAD_TIME,null,0,1) >0 then  '3XiaodaiRisk'
                        when decode(a.SL_CELL_NBANK_OTHER_BAD_ALLNUM,null,0,1)+decode(a.SL_CELL_NBANK_OTHER_BAD,null,0,1) >0 then  '4OtherRisk'
                        when decode(a.SL_ID_NBANK_AU_OVERDUE_TIME,null,0,1)+decode(a.SL_ID_NBANK_AUTOFIN_OVERDUE,null,0,1)+decode(a.SL_ID_NBANK_AU_OVERDUE_ALLNUM,null,0,1) >0 then  '5AutofinRisk'
                        when decode(a.SL_CELL_NBANK_BAD_ALLNUM,null,0,1)+decode(a.SL_ID_BAD_INFO_TIME,null,0,1)+decode(a.SL_LM_CELL_NBANK_OTHER_BAD,null,0,1) >0 then  '6GeneralRisk'
                        when a.FLAG_SPECIALLIST_C ='1' then '7FlagRisk' else '9Normal' end )as FlagSpecialCateNew  --新版特殊名单核查分类
                  from cs_credit cc
                  left join external_br_speciallist_v2  a on a.ID_CREDIT=cc.ID
                  where cc.id=p_IdCredit
                  group by  cc.id, a.FLAG_SPECIALLIST_C 
          )loop
          
              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
               values( p_IdCredit,'External','BaiRong','FlagSpeciallistNew',d.FlagSpeciallistNew,v_Seq+1,p_externalCode); 
          
              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
               values( p_IdCredit,'External','BaiRong','FlagSpecialCateNew',d.FlagSpecialCateNew,v_Seq+2,p_externalCode);  
                          
              v_Seq:=v_Seq + 2;   
              
          end loop;  
          
          for d in(
            select to_number(nvl(STAB_NAME_NUM,-1)) as StabNameNum
              ,to_number(nvl(ALS_M12_ID_NBANK_CA_ORGNUM,-1)) as IdentNBankCaORG12M 
              ,to_number(nvl(ALS_M12_ID_BANK_MIN_INTEDAY,-1)) as IdentBankMinDay12M 
              ,to_number(nvl(ALS_M12_ID_NBANK_OTH_ALLNUM,-1)) as IdentNBankOth12M 
              ,to_number(nvl(ALS_M12_ID_NBANK_MAX_MONNUM,-1)) as IdentNBankMax12M 
              ,to_number(nvl(ALS_M6_ID_NBANK_OTH_ORGNUM,-1)) as IdentNBankOthORG6M 
              ,to_number(nvl(ALS_M6_CELL_NBANK_AVG_MONNUM,-1)) as MobileApplyCountNotBank6M
              ,to_number(nvl(ALS_M3_CELL_NBANK_MAX_INTEDAY,-1)) as MobileNBankMaxDay3M
              from cs_credit b
              left join External_Br_Stability_c  sta on sta.ID_CREDIT = b.id --稳定性评估
              left join External_Br_Applyloan ap on ap.ID_CREDIT = b.id    --多次申请核查    --多头
              where b.COMMIT_TIME>date'2019-09-01' and b.id=p_IdCredit
            )loop
            
             --关联姓名个数
             insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
               values(p_IdCredit,'External','BaiRong','StabNameNum',d.StabNameNum,v_Seq+1,p_externalCode);
               
             --按身份证号查询，近12个月在非银机构-现金类分期申请机构数
             insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
              values(p_IdCredit,'External','BaiRong','IdentNBankCaORG12M',d.IdentNBankCaORG12M,v_Seq+2,p_externalCode);
              
             -- 按身份证号查询，近12个月在银行机构申请最小间隔天数
             insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
              values(p_IdCredit,'External','BaiRong','IdentBankMinDay12M',d.IdentBankMinDay12M,v_Seq+3,p_externalCode);
              
             --按身份证号查询，近12个月在非银机构-其他申请次数
             insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
              values(p_IdCredit,'External','BaiRong','IdentNBankOth12M',d.IdentNBankOth12M,v_Seq+4,p_externalCode);
              
             --按身份证号查询，近12个月在非银机构最大月申请次数 
             insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
              values(p_IdCredit,'External','BaiRong','IdentNBankMax12M',d.IdentNBankMax12M,v_Seq+5,p_externalCode);
              
             --按身份证号查询，近6个月在非银机构-其他申请机构数 
             insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
              values(p_IdCredit,'External','BaiRong','IdentNBankOthORG6M',d.IdentNBankOthORG6M,v_Seq+6,p_externalCode);
              
             --按手机号查询，近6个月在非银机构平均每月申请次数(有申请月份平均)
             insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
              values(p_IdCredit,'External','BaiRong','MobileApplyCountNotBank6M',d.MobileApplyCountNotBank6M,v_Seq+7,p_externalCode);
              
             --按手机号查询，近3个月在非银机构申请最大间隔天数
             insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
               values(p_IdCredit,'External','BaiRong','MobileNBankMaxDay3M',d.MobileNBankMaxDay3M,v_Seq+8,p_externalCode);
             
             v_Seq:=v_Seq + 8; 
            
            end loop;           
                    
       end if;  
       
       if p_externalCode = 'HuiMao' or p_externalCode='ALL'  then 
           
          -----灰猫begin yangzhenxian     2017-12-21-----------
          --在元素类比External下面添加元素子类=HuiMao，元素名称FlagOverDue(是否命中逾期平台数据)
          for d in (
              with temp as(
              select sum(case when c2.QUERY_REPORT_ID is not null then 1 when c1.order_no is not null then 0 else null end) as FlagOverDue,
              min(case when instr(c2.map_key,'DAY30')>0 then '1'
                  when instr(c2.map_key,'DAY60')>0 then '2'
                  when instr(c2.map_key,'DAY90')>0 then '3'
                  when instr(c2.map_key,'DAY180')>0 then '4'
                  when instr(c2.map_key,'DAY365')>0 then '5'
                  when instr(c2.map_key,'HISTORY')>0 then '6'
                  else null end) OverDueLineCate
              from GREYCAT_APPLY_REPORT c
              left join GREYCAT_QUERY_REPORT c1 on c.order_no=c1.order_no
              left join GREYCAT_OVERDUE_DETAIL c2 on c1.id=c2.QUERY_REPORT_ID
              where c.id_credit=p_IdCredit)
              select * from temp where FlagOverDue is not null
            )loop
            
            insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             values( p_IdCredit,'External','HuiMao','FlagOverDue',case when d.FlagOverDue>1 then 1 else d.FlagOverDue end,v_Seq+1,p_externalCode );
             
            v_Seq:=v_Seq + 1;

            ---OverDueLineCate：客户逾期情况  yangzhenxian  2018-03-28
            if d.OverDueLineCate is not null then
              
              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
               values( p_IdCredit,'External','HuiMao','OverDueLineCate',d.OverDueLineCate,v_Seq+1,p_externalCode );
               
              v_Seq:=v_Seq + 1;
              
              end if;
              
            end loop;
            
          --在元素类比External下面添加元素子类=HuiMao，元素名称FlagApply(是否命中申请平台数据)
          for d in (
              with temp as(
              select sum(case when c2.QUERY_REPORT_ID is not null then 1 when c1.order_no is not null then 0 else null end) as FlagApply
              from GREYCAT_APPLY_REPORT c
              left join GREYCAT_QUERY_REPORT c1 on c.order_no=c1.order_no
              left join GREYCAT_APPLY_LOAN_DETAIL c2 on c1.id=c2.QUERY_REPORT_ID
              where c.id_credit=p_IdCredit)
              select * from temp where FlagApply is not null
            )loop
            
              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
               values( p_IdCredit,'External','HuiMao','FlagApply',case when d.FlagApply>1 then 1 else d.FlagApply end,v_Seq+1,p_externalCode );
               
              v_Seq:=v_Seq + 1;
            
            end loop;

            
          --在元素类比External下面添加元素子类=HuiMao，元素名称FlagPay(是否命中还款平台数据)
          for d in (
              with temp as(
              select sum(case when c2.QUERY_REPORT_ID is not null then 1 when c1.order_no is not null then 0 else null end) as FlagPay
              from GREYCAT_APPLY_REPORT c
              left join GREYCAT_QUERY_REPORT c1 on c.order_no=c1.order_no
              left join GREYCAT_APPLY_LOAN_DETAIL c2 on c1.id=c2.QUERY_REPORT_ID and c2.apply_sum_money='0.00'
              where c.id_credit=p_IdCredit)
              select * from temp where FlagPay is not null
            )loop
            
              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
               values( p_IdCredit,'External','HuiMao','FlagPay',case when d.FlagPay>1 then 1 else d.FlagPay end,v_Seq+1,p_externalCode );
               
              v_Seq:=v_Seq + 1;
            
            end loop;
            
          --在元素类比External下面添加元素子类=HuiMao，元素名称Score(灰猫评分)
          for d in (
              with temp as(
              select c1.score
              from GREYCAT_APPLY_REPORT c
              join GREYCAT_QUERY_REPORT c1 on c.ORDER_NO=c1.ORDER_NO
              where c.id_credit=p_IdCredit order by c1.create_time desc)
              select * from temp where rownum=1
            )loop
            
            insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             values( p_IdCredit,'External','HuiMao','Score',d.Score,v_Seq+1,p_externalCode );
             
            v_Seq:=v_Seq + 1;
            
            end loop;       
       end if;
       
       if p_externalCode = 'Miguan' or p_externalCode='ALL'  then  
               
            if v_CreditType in('SC','POS') then
              
             /*MaxPrevSS_GrayScore：客户申请此合同时前面一张消费贷的蜜罐黑名单评分  yangzhenxian    2018-03-23*/
             for d in (
                    with temp as(
                      select c.id,mi.USER_GRAY_SCORE as USER_GRAY_SCORE from cs_credit c--消费贷
                      left join (select id_credit,user_name
                      ,nvl(A.USER_GRAY_SCORE,0) as USER_GRAY_SCORE
                      ,row_number()over (partition by id_credit order by create_time desc) as rnk
                      from external_miguan_basic_info a 
                      where nvl(remark,'0') IN ('0','MIGUAN_SEARCH_SUCCESS[获取蜜罐查询成功]') ) mi
                      on c.id=mi.id_credit
                      where c.id_person=v_IdPerson and c.credit_type='SS' and c.status in ('a','p','k')
                      and c.app_date<v_AppDate and c.commit_time<v_CommitTime and mi.rnk=1 order by c.commit_time desc )
                      select USER_GRAY_SCORE from temp where rownum=1
                )loop
                
                insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                 values( p_IdCredit,'External','JuxinliMiguan','MaxPrevSS_GrayScore',d.USER_GRAY_SCORE,v_Seq+1,p_externalCode );
                 
                v_Seq:=v_Seq + 1;
                
              end loop;
                    
          end if;
            
           --蜜罐元素数据 2016/06/23 wangxiaofeng
           for mi in(select user_gray_score,contacts_one_blacklist_cnt,contacts_two_blacklist_cnt,
                  blacklist_category,user_register_cnt,iwop_susp_phone
                  from(
                  select nvl(a.user_gray_score,999) user_gray_score,nvl(a.contacts_one_blacklist_cnt,0) contacts_one_blacklist_cnt,
                  nvl(a.contacts_two_blacklist_cnt,0) contacts_two_blacklist_cnt,nvl(a.blacklist_category,'其他') blacklist_category,
                  nvl(a.user_register_cnt,0) user_register_cnt,decode(a.iwop_susp_phone,null,'否','是') iwop_susp_phone
                  from external_miguan_basic_info a
                  where a.create_time>=trunc(sysdate-1) 
                  and nvl(remark,'0') IN ('0','MIGUAN_SEARCH_SUCCESS[获取蜜罐查询成功]')
                  and a.id_credit=p_IdCredit order by user_id desc
                  ) where rownum=1)
           loop
             
             --用户黑中介评分
             insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             values( p_IdCredit,'External','JuxinliMiguan','GrayScore',mi.user_gray_score,v_Seq + 1,p_externalCode);
             
             --一阶联系人黑名单人数
             insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             values( p_IdCredit,'External','JuxinliMiguan','PhoneBlackCNTOne',mi.contacts_one_blacklist_cnt,v_Seq + 2,p_externalCode);
             
             --二阶联系人黑名单人数
             insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             values( p_IdCredit,'External','JuxinliMiguan','PhoneBlackCNTTwo',mi.contacts_two_blacklist_cnt,v_Seq + 3,p_externalCode);
             
             --黑名单类型
             insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             values( p_IdCredit,'External','JuxinliMiguan','BlackType',mi.blacklist_category,v_Seq + 4,p_externalCode);
             
             --注册机构个数
             insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             values( p_IdCredit,'External','JuxinliMiguan','RegisterCNT',mi.user_register_cnt,v_Seq + 5,p_externalCode);
             
             --身份证是否组合过其他电话号码 返回结果为是否
             insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             values( p_IdCredit,'External','JuxinliMiguan','SameIdentDiffPhone',mi.iwop_susp_phone,v_Seq + 6,p_externalCode);
             
             v_Seq:=v_Seq + 7;
             
           end loop;

           
           -- /*蜜罐一介联系人总数*/ 2017/10/27 machaochun   增加元素External. JuxinliMiguan. ContactOneCNT
          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
          select p_IdCredit,'External','JuxinliMiguan','ContactOneCNT', t.contacts_class1_cnt ,v_Seq+1,p_externalCode
          from (select contacts_class1_cnt from EXTERNAL_MIGUAN_BASIC_INFO  
          where id_credit=p_IdCredit  and nvl(remark,'0') IN ('0','MIGUAN_SEARCH_SUCCESS[获取蜜罐查询成功]')
          order by create_time ) t where rownum=1;
          
          v_Seq:=v_Seq + 1;  
           
          /*蜜罐是否查询成功*/
          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
           select p_IdCredit,'External','JuxinliMiguan','IsMG',case when nvl(v_InterCode,'1') in('3','4') then 1 when IsMG >0 then 1 else 0 end,v_Seq+1,p_externalCode
           from (select count(1) IsMG from external_miguan_basic_info t where t.id_credit=p_IdCredit
           and (remark is null or remark='MIGUAN_SEARCH_SUCCESS[获取蜜罐查询成功]')) ;
           
          v_Seq:=v_Seq + 1;          
          
          --钱包面签 HardCheck.SumApprovedSameFactory，客户所在工厂历史面签通过的合同数 2016/11/03 wangxiaofeng --
          if v_CreditType='MQ' then
            
           ---------------聚信立授权是否成功  JxlGrant -------------------------by yangzhenxian 2017-08-30
           for ca in(select collected from
             (select collected from ca_collect where id_credit=p_IdCredit order by update_time desc) a where rownum=1)
           loop
             
             insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
              values( p_IdCredit,'External','JuxinliMiguan','JxlGrant',ca.collected,v_Seq + 1,p_externalCode);
              
              v_Seq:=v_Seq + 1;
              
           end loop;  
              
          end if;
           
        /*身份证在哪种机构类型出现     yangzhenxian   2019-07-03*/        
        for d in (
          select min(case when IAIO_SUSP_ORG_TYPE ='线上信用现金贷' then '1线上信用现金贷'
          when IAIO_SUSP_ORG_TYPE ='线下信用现金贷' then '2线下信用现金贷'
          when IAIO_SUSP_ORG_TYPE ='线上信用卡代还' then '3线上信用卡代还'
          when IAIO_SUSP_ORG_TYPE ='线上租房分期' then '4线上租房分期' else IAIO_SUSP_ORG_TYPE end)as IaioSuspOrgType
          from external_miguan_basic_info m
          where m.id_credit=p_IdCredit
        )loop
        
            insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             values( p_IdCredit,'External','JuxinliMiguan','IaioSuspOrgType',d.IaioSuspOrgType,v_Seq+1,p_externalCode );  
                       
             v_Seq:=v_Seq + 1;   
             
        end loop;
        
        ---与申请人被动的通话次数
        insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
        select  p_IdCredit, 'External','JuxinliMiguan','GrayCalledTimes',
           max(to_number(nvl(m.GRAY_CR_CALL_CNT_BE_APPLIED,0))) as GrayCalledTimes, v_Seq+1,p_externalCode
          from cs_credit b
          left join external_miguan_basic_info m on m.ID_CREDIT = b.id 
          where b.COMMIT_TIME>date'2019-09-01'and b.id=p_IdCredit
          group by b.id ;
          
        v_Seq:=v_Seq + 1;      
        
        for d in (
             select * from (
              select to_number(SEARCH_BY_M_24_PCT_CNT_ORG_ALL ) as SearchOrgInAllCntRate24M
              ,USER_PHONE_CITY as UserPhoneCity
              ,row_number()over(partition by cc.id order by m.create_time desc) as rnk
              from cs_credit cc 
              left join external_miguan_basic_info m ON m.id_credit=cc.id
              where cc.id=p_IdCredit
              )where rnk=1
           )loop
           
              --蜜罐24个月内查询机构数在总体查询分布中的百分位
              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values( p_IdCredit,'External','JuxinliMiguan','SearchOrgInAllCntRate24M',d.SearchOrgInAllCntRate24M,v_Seq+1 );
              
              --手机号归属地城市
              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values( p_IdCredit,'External','JuxinliMiguan','UserPhoneCity',d.UserPhoneCity,v_Seq+1 );
               
              v_Seq:=v_Seq + 2;
              
           end loop;     
           
       end if;

       if p_externalCode = 'TongDun' or p_externalCode='ALL'  then 
         
            /*同盾信贷保镖保存在External—TongDun里  yangzhenxian  2019-07-03*/      
              for d in (
                  with temp as(
                  select min(case when risk_name='设备状态异常_高风险' then 1 
                  when risk_name='借款设备代理识别' then 2 
                  when risk_name='借款设备作弊工具识别' then 3 
                  when risk_name='借款设备越狱识别' then 4
                  when risk_name='短时间移动距离位置异常' then 5 
                  when risk_name='3个月内申请人手机号作为联系人手机号出现的次数过多' then 6 
                  when risk_name in ('3个月内申请人身份证关联配偶手机数过多','3个月内申请人身份证关联父亲手机数过多') then 7
                  when risk_name='1天内身份证使用过多设备进行申请' then 8
                  when risk_name='敏感时间段申请1点至5点' then 9
                  else 100 end) as RiskName
                  from TONGDUN_APPLY_ANTIFRAUD an
                  left join TONGDUN_APPLY_AF_RISK_ITEMS af on to_char(an.ID)=af.main_id and an.id_credit=p_IdCredit order by an.create_time desc
                   )
                  select RiskName from temp where rownum=1
                )loop
                
                    insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                     values( p_IdCredit,'External','TongDun','RiskName',d.RiskName,v_Seq+1,p_externalCode ); 
                               
                     v_Seq:=v_Seq + 1;
                     
                end loop; 	
                         
       end if;
       
       --贷前预审,复杂网络-实时风险群体分析-同盾
       if p_externalCode = 'TongDunRiskService' or p_externalCode='ALL'  then 
           
             --External.TongDun. MultiLoanCFCCountFraudMetrix1M：近1个月申请人身份证或手机在大型消费金融公司的借款次数   yangzhenxian                 2019-04-01
              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
               SELECT p_IdCredit,'External','TongDun','MultiLoanCFCCountFraudMetrix1M',nvl(
               (select MultiLoanCFCCountFraudMetrix1M from (select a.ASSOCIATED_ID as id_credit
                  ,MAX(CASE WHEN rule_name IN ('新_1个月内申请人身份证或手机在多个平台申请借款') AND instr(rule_detail, '大型消费金融公司')>0 
                  THEN CASE WHEN INSTR(SUBSTR(RULE_DETAIL,instr(rule_detail, '大型消费金融公司')+9),',')>0 THEN 
                  SUBSTR(SUBSTR(RULE_DETAIL,instr(rule_detail, '大型消费金融公司')+9),1,INSTR(SUBSTR(RULE_DETAIL,instr(rule_detail, '大型消费金融公司')+9), ',')-1)
                  ELSE SUBSTR(RULE_DETAIL,instr(rule_detail, '大型消费金融公司')+9,3) END  ELSE NULL END) AS MultiLoanCFCCountFraudMetrix1M  
                  from WFI_FRAUD_METRIX_RESULT a
                  left join WFI_FRAUD_METRIX_RULE t on a.id = t.fraud_metrix_result_id
                  where  a.associated_id=p_IdCredit and A.EVENT_NAME = 'Credit' and t.rule_no in(1053414,1044438) /*'新_1个月内申请人身份证或手机在多个平台申请借款' */
                  and t.rule_detail like '%大型消费金融公司%'
                  group by  a.ASSOCIATED_ID) ), 0),v_Seq,p_externalCode
              from dual;
              
             v_Seq:=v_Seq + 1;
             
             --2019/03/07 yangzhenxian MultiLoanP2PCountFraudMetrix3M：近三个月命中同盾P2P网贷的次数元素代码
              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
               SELECT p_IdCredit,'External','TongDun','MultiLoanP2PCountFraudMetrix3M',nvl(
               (select MultiLoanP2PCountFraudMetrix3M from (SELECT a.ASSOCIATED_ID as id_credit
                ,MAX(CASE WHEN INSTR(SUBSTR(RULE_DETAIL,instr(rule_detail, 'P2P网贷') + 6),',') > 0
                   THEN SUBSTR(SUBSTR(RULE_DETAIL,instr(rule_detail, 'P2P网贷') + 6),1,instr(SUBSTR(RULE_DETAIL,instr(rule_detail, 'P2P网贷') + 6),',') - 1)
                   ELSE SUBSTR(RULE_DETAIL, instr(rule_detail, 'P2P网贷') + 6, 3)END) AS MultiLoanP2PCountFraudMetrix3M
                from WFI_FRAUD_METRIX_RESULT a
                left join WFI_FRAUD_METRIX_RULE t
                on a.id = t.fraud_metrix_result_id
                where  a.ASSOCIATED_ID=p_IdCredit and A.EVENT_NAME = 'Credit'  AND T.RULE_NO IN(1044388,1053416) and rule_detail like '%P2P网贷%'
                group by  a.ASSOCIATED_ID
                ) ), 0),v_Seq,p_externalCode
              from dual;

             v_Seq:=v_Seq + 1;
             
            /*External.TongDun.ComplexNetwork：复杂网络    yangzhenxian   2018-10-29*/
            for d in (
                select substr(max(case when rule_no=25561664 then '3_reject'--借款人身份证命中复杂网络_建议拒绝
                        when rule_no=25559994 then '2_uw'--借款人身份证命中复杂网络_建议人工审核
                        when rule_no=25559984  then '1_approve'--借款人身份证命中复杂网络_建议人工审核
                         end ),3,10)   Complex_Network  
                         ,max(case when instr(t.rule_detail,'P2P网贷')>0 then 1 else 0 end) as is_P2P
                from WFI_FRAUD_METRIX_RESULT a
                left join WFI_FRAUD_METRIX_RULE t on a.id=t.fraud_metrix_result_id
                where a.event_name='Credit' and a.ASSOCIATED_ID=p_IdCredit
              )loop
              
               if d.Complex_Network is not null then
                 
                insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                 values( p_IdCredit,'External','TongDun','ComplexNetwork',d.Complex_Network,v_Seq+1,p_externalCode );
                 
                v_Seq:=v_Seq + 1;
                
                end if;
                 
                insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                 values( p_IdCredit,'External','TongDun','P2pNetloan',d.is_P2P,v_Seq+1,p_externalCode );
                 
                v_Seq:=v_Seq + 1;
                
              end loop;
            
            /*External.TongDun.CorrelatedRisksScore：关联风险分
            External.TongDun.AttentListProportion：关注名单占比    yangzhenxian   2018-10-29*/
            for d in (
                select max(case when d.rule_name like'%复杂网络%' and detail_name='关联风险分' then to_number(detail_val) end )  correlated_risks_score
                ,max(case when d.rule_name like'%复杂网络%' and d.detail_name='关注名单占比' then to_number(substr(detail_val,1,instr(detail_val,'%',-1)-1)) end ) Attention_list_per
                from WFI_FRAUD_METRIX_RESULT a
                left join WFI_FRAUD_METRIX_RULE t on a.id=t.fraud_metrix_result_id
                left join wfi_fraud_metrix_rule_detail d  on t.id=d.rule_id 
                where a.event_name='Credit' and a.ASSOCIATED_ID=p_IdCredit
              )loop
              
               if d.correlated_risks_score is not null then
                 
                insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                 values( p_IdCredit,'External','TongDun','CorrelatedRisksScore',d.correlated_risks_score,v_Seq+1,p_externalCode );
                 
                v_Seq:=v_Seq + 1;
                
                end if;
                
               if d.Attention_list_per is not null then
                 
                insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                 values( p_IdCredit,'External','TongDun','AttentListProportion',d.Attention_list_per,v_Seq+1,p_externalCode );
                 
                v_Seq:=v_Seq + 1;
                
                end if;
                
              end loop;
              
              
            /*External.TongDun.GelConPlatform7D：新_7天内申请人身份证或手机在多个平台申请借款    yangzhenxian   2019-01-23*/
             insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             select p_IdCredit,'External','TongDun','GelConPlatform7D',
             MAX(CASE WHEN instr(RULE_DETAIL, '一般消费分期平台')>0 
               THEN CASE WHEN INSTR(SUBSTR(RULE_DETAIL,instr(rule_detail, '一般消费分期平台')+9),',')>0 
               THEN SUBSTR(SUBSTR(RULE_DETAIL,instr(rule_detail, '一般消费分期平台')+9),1,INSTR(SUBSTR(RULE_DETAIL,instr(rule_detail, '一般消费分期平台')+9), ',')-1)
               ELSE SUBSTR(RULE_DETAIL,instr(rule_detail, '一般消费分期平台')+9,3) END 
               ELSE NULL END)  --近7天申请人身份证或手机在多个平台申请借款次数（主要分为：一般消费平台，大型消费金融公司，小额贷款公司，P2P网贷）
               ,v_Seq+1,p_externalCode
             from WFI_FRAUD_METRIX_RESULT a
             join WFI_FRAUD_METRIX_RULE b on a.id=b.fraud_metrix_result_id
             where b.rule_no in(1049606,1053412)          --新_7天内申请人身份证或手机在多个平台申请借款
                   and a.event_name='Credit' and a.associated_id=p_IdCredit;
                   
             v_Seq:=v_Seq + 1;
             
             --BlackListCateFraudMetrix:同盾黑名单分类 2015/07/07 wangxiaofeng 2017/06/22由rule_name改为rule_no
             insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             select  p_IdCredit,'HardCheck','*','BlackListCateFraudMetrix',substr(max(case when rule_no in (
                840098,2900153,2901749,2992525,840072,891780,891784,2900089,840080,840116,2992509,2992523,2992511,2901741,840076,
                891788,2901719,2992521,891804,840106,2901711,2992507,840096,891814,2901715,11532,14130,840100,78586,891806,891824,891808,
                5638201,5640421,5640431,5640411) then '9失信名单'
                when rule_no in (840086,2901725,891794,891816,2901743,840108,840118,2901751,891826) then '8灰名单'
                when rule_no in (2900149,891792,2901723,840084,584894) then '7已结案名单'
                when rule_no in (2900083,2901761,2901759,891782,840074,2901713,840082,891790,891802,840094,891812,891832,891834,891836,
                  2901731,891828,840120,891830,840122,11534,840104,840126,44126,15726,840124,840128) then '6低风险失信名单'
                else '0其他' end),2,10) BlackListCateFraudMetrix,v_Seq+1,p_externalCode
                from WFI_FRAUD_METRIX_RESULT a join WFI_FRAUD_METRIX_RULE t on a.id=t.fraud_metrix_result_id
                where a.event_name='Credit' and a.associated_id=p_IdCredit
                group by a.associated_id;   
             
             --2016/09/05 wangxiaofeng    
            for d in (
                select decode(count(1),0,0,1) FraudMetrixActive --是否查得同盾数据FraudMetrixActive (1, 查得; 0, 未查得)
                ,max(nvl(t.final_score,-1)) as final_score    --总分数
                from wfi_fraud_metrix_result t where t.event_name='Credit' and t.associated_id=p_IdCredit
              )loop
               insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
               values( p_IdCredit,'HardCheck','*','FraudMetrixActive',d.FraudMetrixActive,v_Seq+1,p_externalCode);             
               v_Seq:=v_Seq + 1; 
               
               insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
               values( p_IdCredit,'External','TongDun','FinalScore',d.final_score,v_Seq+1,p_externalCode);             
               v_Seq:=v_Seq + 1;                 
              end loop;      
             
             -- 过去半小时内同盾未查得合同数FraudMetrixFailedCount 2017/03/03 update  2019/01/22   update
             insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             select p_IdCredit,'HardCheck','*','FraudMetrixFailedCount',count(1),v_Seq+1,p_externalCode
             from cs_credit a where not exists(select 1 from wfi_fraud_metrix_result b
                                                 where b.event_name='Credit'  and b.associated_id=a.id)
                               and a.status not in('r','t') and nvl(a.inter_code,0) not in(3,4)
                               and a.credit_type=decode(v_CreditType,'SC','SC','SS','SS','SP','SP','XF')
                               and a.commit_time>=v_CommitTime-35/24/60 and a.commit_time<=v_CommitTime-5/24/60;
                               
             v_Seq:=v_Seq + 1;
                          
             --2018/05/29 majianfeng MultiLoanP2PCountFraudMetrix1M：近一个月命中同盾P2P网贷的次数元素代码
              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
               SELECT p_IdCredit,'HardCheck','*','MultiLoanP2PCountFraudMetrix1M',nvl(
               (select MultiLoanP2PCountFraudMetrix1M from (SELECT a.ASSOCIATED_ID as id_credit,
                   MAX(CASE WHEN INSTR(SUBSTR(RULE_DETAIL,instr(rule_detail, 'P2P网贷') + 6),',') > 0
                   THEN SUBSTR(SUBSTR(RULE_DETAIL,instr(rule_detail, 'P2P网贷') + 6),1,instr(SUBSTR(RULE_DETAIL,instr(rule_detail, 'P2P网贷') + 6),',') - 1)
                   ELSE SUBSTR(RULE_DETAIL, instr(rule_detail, 'P2P网贷') + 6, 3)END) AS MultiLoanP2PCountFraudMetrix1M
              from WFI_FRAUD_METRIX_RESULT a
              left join WFI_FRAUD_METRIX_RULE t
                on a.id = t.fraud_metrix_result_id
             where  a.ASSOCIATED_ID=p_IdCredit  and  A.EVENT_NAME = 'Credit'  AND T.RULE_NAME = '新_1个月内申请人身份证或手机在多个平台申请借款' and rule_detail like '%P2P网贷%'
             GROUP BY a.ASSOCIATED_ID) ), 0),v_Seq,p_externalCode
              from dual;

             v_Seq:=v_Seq + 1;  
             
             --1天内借款平台数MultiLoanTypeCountFraudMetrix1D: majianfeng 2018/05/16
             select nvl(max(b.extra_data),0) into v_Count
             from WFI_FRAUD_METRIX_RESULT a
             join WFI_FRAUD_METRIX_RULE b on a.id=b.fraud_metrix_result_id
             where b.rule_no in(1049650,1053410)
                   and a.event_name='Credit' and a.associated_id=p_IdCredit;
             insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                    values(p_IdCredit,'HardCheck','*','MultiLoanTypeCountFraudMetrix1D',v_Count,v_Seq+1,p_externalCode);
                    
             v_Seq:=v_Seq + 1;
             
             v_Count:=0;             
             
             --1个月内借款平台数MultiLoanTypeCountFraudMetrix1M: rule_name='新_1个月内申请人身份证或手机在多个平台申请借款'，从extra_data中取值
             select nvl(max(b.extra_data),0) into v_Count
             from WFI_FRAUD_METRIX_RESULT a
             join WFI_FRAUD_METRIX_RULE b on a.id=b.fraud_metrix_result_id
             where b.rule_no in(1044438,1053414)
                   and a.event_name='Credit' and a.associated_id=p_IdCredit;

             insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                    values(p_IdCredit,'HardCheck','*','MultiLoanTypeCountFraudMetrix1M',v_Count,v_Seq+1,p_externalCode);
                    
             v_Seq:=v_Seq + 1;
             
             v_Count:=0;             
             
             --3个月内借款平台数MultiLoanTypeCountFraudMetrix3M: rule_name='新_3个月内申请人身份证或手机在多个平台申请借款'，从extra_data中取值
             select nvl(max(b.extra_data),0) into v_Count
             from WFI_FRAUD_METRIX_RESULT a
             join WFI_FRAUD_METRIX_RULE b on a.id=b.fraud_metrix_result_id
             where b.rule_no in(1044388,1053416)
                   and a.event_name='Credit' and a.associated_id=p_IdCredit;

             insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                    values(p_IdCredit,'HardCheck','*','MultiLoanTypeCountFraudMetrix3M',v_Count,v_Seq+1,p_externalCode);
                    
             v_Seq:=v_Seq + 1;
             
             v_Count:=0;             
             
             --新_7天内申请人身份证或手机在多个平台申请借款   majianfeng 2018/07/23
             select nvl(max(b.extra_data),0) into v_Count
              from WFI_FRAUD_METRIX_RESULT a
               join WFI_FRAUD_METRIX_RULE b on a.id=b.fraud_metrix_result_id
                where b.rule_no in(1049606,1053412) and a.event_name='Credit' and a.associated_id=p_IdCredit;
             insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                    values(p_IdCredit,'HardCheck','*','MultiLoanTypeCountFraudMetrix7D',v_Count,v_Seq+1,p_externalCode);
                    
             v_Seq:=v_Seq + 1;
             
             v_Count:=0;             
            
            /*  MultiLoanTypeCountSmallLoanCompanies1M(新_1个月内申请人身份证或手机在小额贷款公司申请借款)                  yangzhenxian  2018-10-30   */          
            for d in (
                WITH td_mul_detail_data AS
                (
                SELECT a.associated_id as id_credit,
                       CASE WHEN  instr(rule_detail, '小额贷款公司')>0 THEN 
                            CASE WHEN INSTR(SUBSTR(RULE_DETAIL,instr(rule_detail, '小额贷款公司')+7),',')>0 THEN SUBSTR(SUBSTR(RULE_DETAIL,instr(rule_detail, '小额贷款公司')+7),1,INSTR(SUBSTR(RULE_DETAIL,instr(rule_detail, '小额贷款公司')+7), ',')-1)
                                                                                                           ELSE SUBSTR(RULE_DETAIL,instr(rule_detail, '小额贷款公司')+7,3) END 
                            ELSE NULL END
                       AS Small_loan_companies_1M,
                       row_number() over(partition by a.associated_id,t.rule_name order by t.extra_data DESC,t.update_time DESC) as rank 
                from WFI_FRAUD_METRIX_RESULT a
                join WFI_FRAUD_METRIX_RULE t on a.id=t.fraud_metrix_result_id 
                where a.event_name='Credit' AND t.rule_no IN (22719304,1053414,2902207,16602803,1044438) and a.ASSOCIATED_ID=p_IdCredit
                )
                select * FROM td_mul_detail_data WHERE RANK=1
              )loop
              
              if d.Small_loan_companies_1M is not null then
                insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                 values( p_IdCredit,'HardCheck','*','MultiLoanTypeCountSmallLoanCompanies1M',d.Small_loan_companies_1M,v_Seq+1,p_externalCode );  
                             
                 v_Seq:=v_Seq + 1;
                 
              end if;  
                 
            end loop;   
           
           -- 1个月内借款平台类型MultiLoanTypeFraudMetrix1M: rule_name='新_1个月内申请人身份证或手机在多个平台申请借款', 根据rule_detail计算取值；
           --计算时排除本平台（本平台类型为'一般消费分期平台')，当命中多个平台类型时，只取一个，
           --按以下顺序优先(小额贷款:MC,一般消费:CFC_NL,大型消费:CFC,P2P网贷:P2P,其他:Z)
           insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
           select p_IdCredit,'HardCheck','*','MultiLoanTypeFraudMetrix1M',
           case when replace(b.rule_detail,'一般消费分期平台:1','') like '%小额贷款%' then 'MC'
           when replace(b.rule_detail,'一般消费分期平台:1','') like '%一般消费分期平台%' then 'CFC_NL'
           when replace(b.rule_detail,'一般消费分期平台:1','') like '%消费金融%' then 'CFC'
           when replace(b.rule_detail,'一般消费分期平台:1','') like '%P2P%' then 'P2P'
           else 'Z' end,v_Seq+1,p_externalCode
           from WFI_FRAUD_METRIX_RESULT a
           join WFI_FRAUD_METRIX_RULE b on a.id=b.fraud_metrix_result_id
           where b.rule_no in(1044438,1053414)
                 and a.event_name='Credit' and a.associated_id=p_IdCredit;   
                 
           
           --3个月内借款平台类型MultiLoanTypeFraudMetrix3M: rule_name='新_3个月内申请人身份证或手机在多个平台申请借款', 根据rule_detail计算取值；
           --计算时排除本平台（本平台类型为'一般消费分期平台')，当命中多个平台类型时，只取一个，
           --按以下顺序优先(小额贷款:MC,一般消费:CFC_NL,大型消费:CFC,P2P网贷:P2P,其他:Z)
           --b.rule_name in ('新_3个月内申请人身份证或手机在多个平台申请借款')
           insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
           select p_IdCredit,'HardCheck','*','MultiLoanTypeFraudMetrix3M',
           case when replace(b.rule_detail,'一般消费分期平台:1','') like '%小额贷款%' then 'MC'
           when replace(b.rule_detail,'一般消费分期平台:1','') like '%一般消费分期平台%' then 'CFC_NL'
           when replace(b.rule_detail,'一般消费分期平台:1','') like '%消费金融%' then 'CFC'
           when replace(b.rule_detail,'一般消费分期平台:1','') like '%P2P%' then 'P2P'
           when replace(b.rule_detail,'一般消费分期平台:1','') like '%财产保险%' then 'CX'
           when replace(b.rule_detail,'一般消费分期平台:1','') like '%理财机构%' then 'LO'
           when replace(b.rule_detail,'一般消费分期平台:1','') like '%互联网金融%' then 'TF'
           else 'Z' end,v_Seq+1,p_externalCode
           from WFI_FRAUD_METRIX_RESULT a
           join WFI_FRAUD_METRIX_RULE b on a.id=b.fraud_metrix_result_id
           where b.rule_no in(1044388,1053416)
                 and a.event_name='Credit' and a.associated_id=p_IdCredit;      
                 
           
           --  ThirdService：第三方服务商  majianfeng 2018/07/23
           select  max(case when instr(rule_detail,'第三方服务商')>0 then 1 else 0 end ) into  v_Count   ----未命中，未查得则为0
            from WFI_FRAUD_METRIX_RESULT a
            left join WFI_FRAUD_METRIX_RULE t on a.id=t.fraud_metrix_result_id
            where a.event_name='Credit'  and a.associated_id=p_IdCredit;
            
            insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                  values(p_IdCredit,'HardCheck','*','ThirdService',v_Count,v_Seq+1,p_externalCode);
                  
           v_Seq:=v_Seq + 1;
                 
        /*在External---Device 下新增设备指纹信息     hongbinbin   2019-09-04*/        
        for d in (
            --ip share IP地址共享
            select count( b.ident) as IPCNT--IP地址历史共享次数
              ,sum(case when trunc(a.CREATE_TIME)=trunc(b.CREATE_TIME)  then 1 else 0 end) as IPCNT1day--IP地址1天共享次数
              ,sum(case when b.CREATE_TIME>=a.CREATE_TIME-7 then 1 else 0 end) as IPCNT7day--IP地址7天共享次数
              ,sum(case when b.CREATE_TIME>=a.CREATE_TIME-15 then 1 else 0 end) as IPCNT15day--IP地址15天共享次数
              ,sum(case when b.CREATE_TIME>=a.CREATE_TIME-30 then 1 else 0 end) as IPCNT30day--IP地址30天共享次数
              from TONGDUN_APPLY_INFOANALYSIS a
              left join TONGDUN_APPLY_INFOANALYSIS b on a.CREATE_TIME>b.CREATE_TIME and a.ident<>b.ident and a.IP_ADDRESS=b.IP_ADDRESS
              where a.id_credit=p_IdCredit
              group by a.ID_CREDIT
        )loop
        
            insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             values( p_IdCredit,'External','Device','IPCNT',d.IPCNT,v_Seq+1,p_externalCode); 
        
            insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             values( p_IdCredit,'External','Device','IPCNT1day',d.IPCNT1day,v_Seq+2,p_externalCode);        
                  
            insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             values( p_IdCredit,'External','Device','IPCNT7day',d.IPCNT7day,v_Seq+3,p_externalCode);  
                        
            insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             values( p_IdCredit,'External','Device','IPCNT15day',d.IPCNT15day,v_Seq+4,p_externalCode); 
                         
            insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             values( p_IdCredit,'External','Device','IPCNT30day',d.IPCNT30day,v_Seq+5,p_externalCode);  
                        
            v_Seq:=v_Seq + 5; 
              
        end loop; 
               
        /*在External---Device 下新增设备指纹信息     hongbinbin   2019-09-04*/        
        for d in (
            --net position 网络归属地
            select case when instr(g.position,'中国')>0 then '中国'
              when g.position='局域网' then '局域网'
              when g.position='保留地址' then '保留地址'
              when g.position='共享地址' then '共享地址'
              else '国外' end as NetPosition --网络归属地
              from TONGDUN_APPLY_INFOANALYSIS a
              join TONGDUN_APPLY_IN_GEOIP_INFO  g on a.id=g.MAIN_ID
              where a.id_credit=p_IdCredit
        )loop
        
            insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             values( p_IdCredit,'External','Device','NetPosition',d.NetPosition,v_Seq+1,p_externalCode);       
                  
             v_Seq:=v_Seq + 1;   
             
        end loop; 
        
         for d in(
          select max(case when r.DETAIL_NAME='一度关联节点个数' then to_number(r.DETAIL_VAL) else 0 end) as RiskOneCount
            ,max(case when r.DETAIL_NAME='关注名单个数' then to_number(r.DETAIL_VAL) else 0 end) as FocusCount 
            ,max(case when instr(t.rule_detail,'小额贷款公司')>0 then 1 else 0 end) as IsMc 
            from cs_credit b
            join WFI_FRAUD_METRIX_RESULT a on b.id =a.ASSOCIATED_ID
            left join WFI_FRAUD_METRIX_RULE t on a.id=t.fraud_metrix_result_id  
            left join wfi_fraud_metrix_rule_detail r on t.id=r.RULE_ID and instr(r.RULE_NAME,'复杂网络')>0
            where a.event_name='Credit' and a.update_time>=date'2018-12-01' and b.id=p_IdCredit
            group by b.id
          )
          loop
            
             --同盾复杂网络一度关联节点个数
            insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
               values(p_IdCredit,'External','TongDun','RiskOneCount',d.RiskOneCount,v_Seq+1,p_externalCode);
                          
            --同盾复杂网络关注名单个数  
            insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
               values(p_IdCredit,'External','TongDun','FocusCount',d.FocusCount,v_Seq+2,p_externalCode);              
            
            --是否命中小额贷款公司     
            insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
               values(p_IdCredit,'External','TongDun','IsMc',d.IsMc,v_Seq+3,p_externalCode);
            
            v_Seq:=v_Seq + 3;
            
          end loop; 
          
          for d in(
            select c.id,c.id_person,c.contract_no,c.COMMIT_TIME,max(pc.id) as id_credit_ss,max(pc.contract_no) as contract_no_ss
                   ,max(sc.id) as id_credit_sc,max(sc.contract_no) as contract_no_sc
                   ,max(rece.id) as id_credit_rece,max(rece.contract_no) as contract_no_rece
                   ,max(MAX_AMOUNT) as max_amount
            from cs_credit c
            left join cs_credit pc on c.ID_PERSON=pc.ID_PERSON and pc.credit_type='SS' and pc.status in ('a','p','k') and pc.COMMIT_TIME<c.COMMIT_TIME
            left join cs_credit sc on c.ID_PERSON=sc.ID_PERSON and sc.credit_type='SC' and sc.status in ('a','p','k') and sc.COMMIT_TIME<c.COMMIT_TIME
            left join cs_credit rece on c.ID_PERSON=rece.ID_PERSON and rece.credit_type in ('SC','SS') and rece.status in ('a','p','k') and rece.COMMIT_TIME<c.COMMIT_TIME
            left join cross_active_detail cad on cad.id_person = sc.id_person 
            left join cross_active_list cal on cal.ACTIVE_ID = cad.ACTIVE_ID and trunc(sc.app_date) between cal.start_date and cal.end_date  
            where c.credit_type='CY' and c.id = p_IdCredit
            group by c.id,c.id_person,c.contract_no,c.COMMIT_TIME
            )loop   
                                
                for f in(
                    ----同盾贷后
                    select sum(case when rule_name='申请人身份证在多个平台申请借款' AND trunc(d.COMMIT_TIME)-30<=trunc(rl.update_time) then new_platform_total end) 
                        as PrevMultiLoanSum1M  
                    ,max(case when rule_name='申请人身份证在多个平台申请借款' then new_platform_total end) 
                        as PrevMultiLoanMaxCount
                    from  external_tongdun_monitor_info k 
                    LEFT JOIN external_tongdun_risk_list rl on k.sequence_Id =rl.REPORT_ID
                    where d.id_credit_rece=k.id_credit
                  )loop
                    
                    --客户在申请此合同前面一张消费贷或交叉现金贷最近一个月内身份证多次借贷总平台数
                    insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                           values(p_IdCredit,'External','TongDun','PrevMultiLoanSum1M',f.PrevMultiLoanSum1M,v_Seq+1,p_externalCode);
                             
                    --客户在申请此合同前面一张消费贷或交叉现金贷身份证多次借贷最大平台数      
                    insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                           values(p_IdCredit,'External','TongDun','PrevMultiLoanMaxCount',f.PrevMultiLoanMaxCount,v_Seq+2,p_externalCode);
                             
                    v_Seq:=v_Seq + 2; 
                      
                  end loop;      
                                
            end loop;    
           
       end if;
       
       if p_externalCode = 'Intellicredit_Blacklist' or p_externalCode='ALL'  then
          
          --External.zhongzhicheng.ConfirmBlackList 中智城 客户命中中智诚黑名单 2018-05-09 majianfeng
          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
            select p_IdCredit,'External','ZhongZhiCheng','ConfirmBlackList',nvl(substr(max(case when qr.confirm_type='DLQ90plus' then '4overdue90+'
             when qr.confirm_type='DLQX' then '3overduels'
                when qr.confirm_type='fraud' then '2fraud'
                else '0other'end ),2,10),'0other') as ConfirmBlackList,v_Seq+1,p_externalCode
            from external_intelli_bl_query bq
          left join external_intelli_bl_q_records qr on bq.id=qr.bl_q_id
          where bq.id_credit=p_IdCredit;
          
          v_Seq:=v_Seq + 1;            
            
       end if; 
       
       if p_externalCode = 'Intellicredit_Antifraud' or p_externalCode='ALL'  then         
          
          --External.ZhongZhiCheng.P2PMultiLoan   DiffMultiLoan  中智诚多次借贷情况 2019-01-23 yangzhenxian
          for c in(select max(case when INSTR(k.DESCRIPTION,'网贷机构')>0 then 1 else 0 end) as P2PMultiLoan --申请人在网贷机构出现过
                  ,max(case when INSTR(k.DESCRIPTION,'不同机构')>0 then 1 else 0 end) as DiffMultiLoan --申请人在不同机构出现过
                  FROM EXTERNAL_INTELLI_ANTIFRAUD h 
                  left join EXTERNAL_INTELLI_AF_RULES k on k.ANTIFRAUD_ID=h.id
                  where h.id_credit=p_IdCredit
            )loop
            
              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                values(p_IdCredit,'External','ZhongZhiCheng','P2PMultiLoan',c.P2PMultiLoan,v_Seq+1,p_externalCode);
                
              v_Seq:=v_Seq + 1;
              
              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                values(p_IdCredit,'External','ZhongZhiCheng','DiffMultiLoan',c.DiffMultiLoan,v_Seq+1,p_externalCode);
                
              v_Seq:=v_Seq + 1;
              
            end loop;  
            
       end if; 
       
       if p_externalCode = 'MobileTelPeriod' or p_externalCode='ALL'  then   
        
        /*在网时长元素需求MobileOnlineTime  yangzhenxian  2018-12-19*/      
        for d in (
            with temp as(
            select p.id_credit,
                   case when p.period in ('(0,3]','[0,3)') then '(0,3)'
                        when p.period in ('(3,6]','[3,6)') then '(3,6)'
                        when p.period in ('(6,12]','[6,12)') then '(6,12)'
                        when p.period in ('(12,24]','[12,24)') then '(12,24)'
                        when p.period in ('(24,+)','[24,+)') then '(24,+)'                       
                        when p.period in ('T-1月前已离网','已离网或新入网用户') then '已离网'
                   else p.period end as period   --------为空时不生成该元素 
            from mobile_online_period p
             where p.id_credit=p_IdCredit order by p.create_time desc
             )
            select period from temp where rownum=1
          )loop
          
            if d.period is not null then 
              
              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
               values( p_IdCredit,'HardCheck','*','MobileOnlineTime',d.period,v_Seq+1,p_externalCode );
                           
               v_Seq:=v_Seq + 1;
               
            end if;
                    
            end loop;
            
        end if;     
       
       if p_externalCode = 'QiakeRisk' or p_externalCode='ALL'  then   
            
            /*全量客户经过洽客系统，把洽客作为第三方征信保存在External—QiaKe里  yangzhenxian  2019-07-04*/
            for d in (
                with temp as(
                select case when CREDIT_RESULT is null or CREDIT_RESULT='U' then 'Fail' else CREDIT_RESULT end as CreditResult --洽客订单的状态，如果洽客处理失败则返回Fail值。
                ,FINAL_DECISION as FinalDecision --洽客最终决策结果
                ,POS_LOAN_LIMIT as Limit--洽客授信额度
                ,CUSTOMER_RISK_LEVEL as RiskLevel --洽客客户风险等级
                ,SYNTHETIC_SCORE as Score         --洽客分数
                from QIAKE_RISK_MANAGEMENT 
                where id_credit=p_IdCredit
                 )
                select * from temp where rownum=1
              )loop
              
                  insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                   values( p_IdCredit,'External','QiaKe','CreditResult',d.CreditResult,v_Seq+1,p_externalCode );                   
                  v_Seq:=v_Seq + 1;
                  
                  insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                   values( p_IdCredit,'External','QiaKe','FinalDecision',d.FinalDecision,v_Seq+1,p_externalCode );                   
                  v_Seq:=v_Seq + 1;
                  
                  insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                   values( p_IdCredit,'External','QiaKe','Limit',d.Limit,v_Seq+1,p_externalCode );                   
                  v_Seq:=v_Seq + 1;
                  
                  insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                   values( p_IdCredit,'External','QiaKe','RiskLevel',d.RiskLevel,v_Seq+1,p_externalCode );                   
                  v_Seq:=v_Seq + 1;
                  
                  insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                   values( p_IdCredit,'External','QiaKe','Score',d.Score,v_Seq+1,p_externalCode );                   
                  v_Seq:=v_Seq + 1;
                  
              end loop; 
        
        /*风控渠道类型     yangzhenxian   2019-07-15*/
        for d in (
          select 
          sum(case when CHANNEL_TYPE='QIAKE' and VERDICT is not null then 1 when CHANNEL_TYPE='WACAI' and VERDICT is not null then 2 else 0 end) as RiskChannelType
          from RISK_MANAGEMENT
          where id_credit=p_IdCredit
        )loop
        
            insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             values( p_IdCredit,'Credit','*','RiskChannelType',d.RiskChannelType,v_Seq+1,p_externalCode );
             
            v_Seq:=v_Seq + 1;   
            
        end loop;
                  
       end if;
       
       if p_externalCode = 'QiaKeRiskCashApply' or p_externalCode='ALL'  then   
              
             for d in (
                  select ID_CREDIT, CREDIT_RESULT as CashCreditResult, FINAL_LIMIT_CASH as CashLimit, CUSTOMER_RISK_LEVEL as CashRiskLevel
                   from QIAKE_RISK_CASH_APPLY where id_credit=p_IdCredit
              )loop
              
                  --洽客取现结果
                  insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                   values( p_IdCredit,'External','QiaKe','CashCreditResult',d.CashCreditResult,v_Seq+1);
                   
                  v_Seq:=v_Seq + 1;
                  
                  --最新取现额度
                  insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                   values( p_IdCredit,'External','QiaKe','CashLimit',d.CashLimit,v_Seq+1);
                   
                  v_Seq:=v_Seq + 1;
                  
                  --客户取现风险等级
                  insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                   values( p_IdCredit,'External','QiaKe','CashRiskLevel',d.CashRiskLevel,v_Seq+1);
                   
                  v_Seq:=v_Seq + 1;
                  
              end loop;
                  
       end if;
       
       --挖财风控系统
       if p_externalCode = 'WacaiRisk' or p_externalCode='ALL'  then
           /*挖财审批结果及额度  yangzhenxian  2019-07-15*/
          for d in (
              with temp as(
              select VERDICT as FinalDecision--挖财审批结果
              ,CREDIT_AMOUNT/100 as Limit--挖财最高额度
              ,RISK_LEVEL as RiskLevel--挖财风险等级
              from  WACAI_RISK_MANAGEMENT a 
              where id_credit=p_IdCredit order by a.create_time desc
               )
              select * from temp where rownum=1
            )loop
            
                insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                 values( p_IdCredit,'External','WaCai','FinalDecision',d.FinalDecision,v_Seq+1,p_externalCode );
                 
                v_Seq:=v_Seq + 1;
                
                insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                 values( p_IdCredit,'External','WaCai','Limit',d.Limit,v_Seq+1,p_externalCode );
                 
                v_Seq:=v_Seq + 1;
                
                insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
                 values( p_IdCredit,'External','WaCai','RiskLevel',d.RiskLevel,v_Seq+1,p_externalCode );
                 
                v_Seq:=v_Seq + 1;
                
            end loop;
        
        end if;
          
           
      if p_externalCode = 'IdentVerify' or p_externalCode='ALL'  then        
       
           --face人脸识别分数      IdentVerifyFace
           insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
           select p_IdCredit,'External','*','IdentVerifyFace',max(case when v.ID_CREDIT is null then 999 when v.score is null and v.remark like'图片质量不合格%' then 888 else nvl(v.SCORE,-1) end),v_Seq+1,p_externalCode
           from cs_credit c left join liveness_ident_verify v on c.id=v.ID_CREDIT  and v.SUPPLIER_CODE='FACEID' where c.id=p_IdCredit;                     
           v_Seq:=v_Seq + 1;           
            
           --商汤人脸识别分数      IdentVerifyShangtang
           insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
           select p_IdCredit,'External','*','IdentVerifyShangtang',max(case when v.ID_CREDIT is null then 999 when v.score is null and v.remark like'图片质量不合格%' then 888  else nvl(v.SCORE,-1) end),v_Seq+1,p_externalCode
           from cs_credit c left join liveness_ident_verify v on c.id=v.ID_CREDIT  and v.SUPPLIER_CODE='SHANGTANG' where c.id=p_IdCredit;                    
           v_Seq:=v_Seq + 1;           
           
           --爰金人脸识别分数      IdentVerifyYuanjin
           insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
           select p_IdCredit,'External','*','IdentVerifyYuanjin',max(case when v.ID_CREDIT is null then 999 when v.score is null and v.remark like'图片质量不合格%' then 888  else nvl(v.SCORE,-1) end),v_Seq+1,p_externalCode
           from cs_credit c left join liveness_ident_verify v on c.id=v.ID_CREDIT  and v.SUPPLIER_CODE='YUANJIN' where c.id=p_IdCredit;                     
           v_Seq:=v_Seq + 1;
           
           --腾讯云人脸识别分数      IdentVerifyTX
           insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
           select p_IdCredit,'External','*','IdentVerifyTX',max(case when v.ID_CREDIT is null then 999  else nvl(v.SCORE,-1) end),v_Seq+1,p_externalCode
           from cs_credit c left join liveness_ident_verify v on c.id=v.ID_CREDIT  and v.SUPPLIER_CODE='TX.IMGVERIFY' where c.id=p_IdCredit;                     
           v_Seq:=v_Seq + 1;
           
            --人脸识别分数汇总     IdentVerifyScore
            insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
            select p_IdCredit,'External','*','IdentVerifyScore',max(case when v.ID_CREDIT is null then 999 when v.score is null and v.remark like'图片质量不合格%' then 888   else nvl(v.SCORE,-1) end),v_Seq+1,p_externalCode
            from cs_credit c left join liveness_ident_verify v on c.id=v.ID_CREDIT   where c.id=p_IdCredit;                        
            v_Seq:=v_Seq + 1;
            
       end if;
       
      if p_externalCode = 'TongDunRiskService' or p_externalCode='ALL'  then 
         
        /*External.TongDun.MultiLoanMCCountFraudMetrix3M：同盾最近三个月小额贷款次数 */          
        for d in (
            select max(case when t.rule_name='新_3个月内申请人身份证或手机在多个平台申请借款' and instr(t.rule_detail,'小额贷款公司')>0 
                            then to_number(regexp_substr(substr(t.RULE_DETAIL,instr(t.rule_detail,'小额贷款公司') + 7,3),'[0-9]+')) else 0 end) 
                   as MultiLoanMCCountFraudMetrix3M---同盾最近三个月小额贷款次数
            from WFI_FRAUD_METRIX_RESULT a
            left join WFI_FRAUD_METRIX_RULE t on a.id=t.fraud_metrix_result_id
            where a.event_name='Credit' and a.update_time>=date'2018-01-01' and a.ASSOCIATED_ID=p_IdCredit
          )loop
          
            insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             values( p_IdCredit,'External','TongDun','MultiLoanMCCountFraudMetrix3M',d.MultiLoanMCCountFraudMetrix3M,v_Seq+1,p_externalCode ); 
                         
              v_Seq:=v_Seq + 1;
              
          end loop; 
         
          for d in (
              select max(case when r.DETAIL_NAME='二度关联节点个数' then to_number(r.DETAIL_VAL) else 0 end) as RiskTwoCount --同盾复杂网络二度关联节点个数
                     ,max(case when r.DETAIL_NAME='风险群体的节点分布' and instr(r.DETAIL_VAL,'设备ID')>0 then 1 else 0 end) as RiskGroupSheBei--同盾复杂网络设备节点分布
              from WFI_FRAUD_METRIX_RESULT a
              left join WFI_FRAUD_METRIX_RULE t on a.id=t.fraud_metrix_result_id
              left join wfi_fraud_metrix_rule_detail r on t.id=r.RULE_ID and r.rule_name like '%复杂网络%'
              where a.event_name='Credit' and a.update_time>=date'2018-01-01' and a.ASSOCIATED_ID=p_IdCredit
            )loop
            
              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
               values( p_IdCredit,'External','TongDun','RiskTwoCount',d.RiskTwoCount,v_Seq+1,p_externalCode );   
                          
               insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
               values( p_IdCredit,'External','TongDun','RiskGroupSheBei',d.RiskGroupSheBei,v_Seq+1,p_externalCode );      
                       
               v_Seq:=v_Seq + 2;
               
            end loop;       
             
      end if;

      if p_externalCode = 'Miguan' or p_externalCode='ALL'  then   
         
         for d in (
           select max(CONTACTS_ROUTER_CNT)as ContactByTwoCNT--引起二阶黑名单人数
           ,max(PAIO_SUSP_ORG_TYPE) as NameOGRType --电话号码在那种机构类型中出现该姓名最近一次出现机构类型名称
           ,max(GRAY_CNS_CNT_TO_APPLIED) as GrayCnsCntAppl--主动联系人中曾为申请人的人数
           ,max(BLACKLIST_NAME_WITH_IDCARD) as BlackListNameCard--姓名+身份证是否在黑名单中1:是；0：否
            from external_miguan_basic_info v where v.id_credit=p_IdCredit
         )loop
         
            insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             values( p_IdCredit,'External','JuxinliMiguan','ContactByTwoCNT',d.ContactByTwoCNT,v_Seq+1,p_externalCode );  
                        
            insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             values( p_IdCredit,'External','JuxinliMiguan','NameOGRType',d.NameOGRType,v_Seq+1,p_externalCode );   
                        
            insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             values( p_IdCredit,'External','JuxinliMiguan','GrayCnsCntAppl',d.GrayCnsCntAppl,v_Seq+1,p_externalCode ); 
                        
            insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
             values( p_IdCredit,'External','JuxinliMiguan','BlackListNameCard',d.BlackListNameCard,v_Seq+1,p_externalCode );
                          
             v_Seq:=v_Seq + 4;
             
         end loop;       
      end if;

      if p_externalCode = 'XinYanBlackList' or p_externalCode='ALL'  then   
          
           --新颜探针A黑名单建议      BlackListSuggest
           insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
           select p_IdCredit,'External','XinYan','BlackListSuggest',max(result_code),v_Seq+1,p_externalCode
           from XINYAN_PROBEA_BLACKLIST v where v.id_credit=p_IdCredit;  
                   
           v_Seq:=v_Seq + 1;
           
       end if;
       
      if p_externalCode = 'XinYanWhiteList' or p_externalCode='ALL'  then       
           --新颜探针B白名单建议      WhiteListSuggest
           insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
           select p_IdCredit,'External','XinYan','WhiteListSuggest',max(result_code),v_Seq+1,p_externalCode
           from XINYAN_PROBEB_WHITELIST v where v.id_credit=p_IdCredit;   
                  
      end if;
       
       if p_externalCode = 'Antifraud' or p_externalCode='ALL'  then           
        /*在External. Ronghui下添加元素RonghuiAntifraudScore:  yangzhenxian  2019-12-31*/       
        for d in (
            with temp as(
              select to_number(score) as RonghuijinkeScore from ronghui_antifraud r where r.id_credit = p_IdCredit order by r.create_time desc
             )
            select RonghuijinkeScore from temp where rownum=1
          )loop              
              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code,external_code)
               values( p_IdCredit,'External','Ronghui','RonghuiAntifraudScore',d.RonghuijinkeScore,v_Seq+1,p_externalCode );                           
               v_Seq:=v_Seq + 1;
                    
            end loop;            
        end if;
       delete decision_element_data where id_credit=p_IdCredit and element_value is null;       
      
      commit;

       p_ReturnCode:='A';
       return;
    exception
       When others Then
         error_info := sqlerrm;
         p_ReturnCode:='Z-'||error_info||DBMS_UTILITY.format_error_backtrace;
         rollback;    
end;
/

