create procedure prc_collect_element_final_base(p_IdCredit cs_credit.id%type,p_ReturnCode out varchar2) is
       error_info                  varchar2(1000);
       -- Author  : yangzhenxian
       -- Create Date : 2019-09-02
       -- Purpose : 提取终审合同元素;
       v_ContractNo                cs_credit.contract_no%type;
       v_AppDate                   cs_credit.app_date%type;
       v_CommitTime                cs_credit.commit_time%type;
       v_InterCode                 cs_credit.inter_code%type;
       v_IdSa                      cs_credit.id_sa%type;
       v_IdDsm                     number;
       v_SaName                    sys_user_list.user_name%type;
       v_SaMobile                  sys_user_list.phone%type;
       v_SaIdent                   sys_user_list.ident%type;
       v_SaInDate                  sys_user_list.update_time%type;
       v_CreditType                cs_credit.credit_type%type;
       v_PayAmount                 cs_credit.pay_amount%type;
       v_CreditAmount              cs_credit.credit_amount%type;
       v_InitPay                   cs_credit.init_pay%type;
       v_Price                     cs_credit.price%type;
       v_Annuity                   cs_credit.annuity%type;
       v_PreInterCode              cs_credit.pa_inter_code%type;
       v_IdPerson                  cs_person.id%type;
       v_PersonName                cs_person.name%type;
       v_Ident                     cs_person.ident%type;
       v_IdentAuth                 cs_person.ident_auth%type;
       v_IdentExp                  cs_person.ident_exp%type;
       v_CreditModel               cs_credit.credit_model%type;
       v_Birthday                  varchar2(20);
       v_Age                       integer;
       v_Sex                       cs_person.sex%type;
       v_National                  cs_person.national%type;
       v_PersonMobile              varchar2(100);
       v_OfficeTel                 varchar2(100);
       v_CreditSource              cs_credit.credit_source%type;

       v_IdSellerPlace             sellerplace.id%type;
       v_DealerName                sellerplace.name%type;
       v_PosCode                   varchar2(50);
       v_Province                  sellerplace.province%type;
       v_City                      sellerplace.city%type;
       v_DealerActivityStart       sellerplace.activity_start%type;
       v_Address                   sellerplace.address%type;

       v_AreaCode                  cn_city_list.area_code%type;

       v_IdSeller                  seller.id%type;
       v_SellerName                seller.name%type;
       v_SellerActivityStart       seller.activity_start%type;

       v_IdProduct                 product.id%type;
       v_ProdCode                  product.prod_code%type;
       v_ProdName                  product.prod_name%type;
       v_PaymentNum                product.payment_num%type;
       v_ProdType                  product.prod_type%type;
       v_SearchType                product.search_type%type;
       v_ValidFrom                 varchar2(20);
       v_ValidTo                   varchar2(20);
       v_Eir                       product.effective_interest_rate%type;
       v_MonthIr                   product.month_ir%type;
       v_MonthFee                  product.month_fee%type;
       v_AccountFee                product.account_fee%type;
       v_CsFee                     product.cs_fee%type;
       v_OverPayYear               product.overpay_year%type;
       v_CreditFrom                product.credit_from%type;
       v_CreditTo                  product.credit_to%type;

       v_OtherPersonType           registers.reg_val_name%type;

       v_GoodsVolume               number:=0;
       v_MaxGoodsPrice             number:=-1;
       v_MaxGoodsType              goods_type.name%type;
       v_MinGoodsPrice             number:=-1;
       v_MinGoodsType              goods_type.name%type;

       v_Position                  number:=-1;

       v_ElementType               decision_element_data.element_type%type;
       v_Seq                       decision_element_data.sort_code%type;

       v_FamilyPhoneUseCount           number:=0;
       v_OtherPhoneUseCount            number:=0;
       v_FamilyPhoneUseSameCityCount   number:=0;
       v_FamilyPhoneUseSamePosCount    number:=0;
       v_OtherPhoneUseSameCityCount    number:=0;
       v_OtherPhoneUseSamePosCount     number:=0;
       v_UseCity                   sellerplace.city%type;

       v_CurrentAddressCity        wechat_credit_address.current_address_city%type;
       v_CurrentCity               wechat_credit_address.current_city%type;

       v_IsRecall                  number:=0;
       v_SCI_Amount                mv_status_change_information.credit_amount%type;
       v_SCI_Category              mv_status_change_information.goodsnewcategory%type;
       v_NewCategory               varchar2(50);
       v_NewDeductDate                cs_credit.deduct_date%type;

       v_varTemp                   varchar2(100);
       v_IdCredit                  number;
       v_CreditLevel               number;
       v_Count                     integer;
       strSql                      varchar2(4000);
    begin

      delete decision_element_data where id_credit=p_IdCredit;

       prc_save_cs_contact(100000,p_IdCredit,p_ReturnCode);

       v_Seq:=0;

       v_ElementType:='Special';

       insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)
            values(p_IdCredit,v_ElementType,'Random1',round(dbms_random.value(),6),v_Seq+1);

       insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)
            values(p_IdCredit,v_ElementType,'Random2',round(dbms_random.value(),6),v_Seq+2);

       insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)
            values(p_IdCredit,v_ElementType,'Random3',round(dbms_random.value(),6),v_Seq+3);

       insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)
            values(p_IdCredit,v_ElementType,'Random4',round(dbms_random.value(),6),v_Seq+4);

       insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)
            select p_IdCredit,v_ElementType,para_id,para_value,v_Seq+5 from sys_parameters where para_id='BIB';

       insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)
            select p_IdCredit,v_ElementType,para_id,para_value,v_Seq+6 from sys_parameters where para_id='BIB2';

       v_Seq:=v_Seq + 6;

       v_ElementType:='Credit';

       select a.contract_no,a.credit_model,a.app_date,a.commit_time,a.inter_code,nvl(a.id_sa,''),nvl(b.user_name,'') sa_name,nvl(b.ident,'') sa_ident,nvl(b.phone,'') sa_mobile,
       nvl(trunc(b.update_time),trunc(sysdate)),a.credit_amount,a.init_pay,a.price,a.annuity,a.id_sellerplace,a.id_product,a.id_person,a.credit_type,nvl(a.pay_amount,0) pay_amount,pa_inter_code,Credit_Level,a.Credit_Source
         into v_ContractNo,v_CreditModel,v_AppDate,v_CommitTime,v_InterCode,v_IdSa,v_SaName,v_SaIdent,v_SaMobile,v_SaInDate,v_CreditAmount,v_InitPay,v_Price,v_Annuity,v_IdSellerPlace,v_IdProduct,v_IdPerson,v_CreditType,v_PayAmount,v_PreInterCode,v_CreditLevel,v_CreditSource
         from cs_credit a,sys_user_list b where a.id_sa=b.id(+) and a.id=p_IdCredit;

       --2017/03/21 update wangxiaofeng v_AppDate date 改为datetime
       strSql:='insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)
                select '||p_IdCredit||','''||v_ElementType||''','||'''ContractNo'''||','''||v_ContractNo||''','||(v_Seq+1)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''AppDate'''||','''||to_char(v_AppDate,'yyyy-MM-dd HH24:mi:ss')||''','||(v_Seq+2)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''CommitTime'''||','''||to_char(v_CommitTime,'yyyy-MM-dd HH24:mi:ss')||''','||(v_Seq+3)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''InterCode'''||','''||v_InterCode||''','||(v_Seq+4)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''IdSa'''||','''||v_IdSa||''','||(v_Seq+5)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''SaInDate'''||','''||to_char(v_SaInDate,'yyyy-MM-dd')||''','||(v_Seq+6)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''CreditAmount'''||','''||v_CreditAmount||''','||(v_Seq+7)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''InitPay'''||','''||v_InitPay||''','||(v_Seq+8)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''Price'''||','''||v_Price||''','||(v_Seq+9)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''Annuity'''||','''||v_Annuity||''','||(v_Seq+10)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''CreditType'''||','''||v_CreditType||''','||(v_Seq+11)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''PayAmount'''||','''||v_PayAmount||''','||(v_Seq+12)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''PreInterCode'''||','''||v_PreInterCode||''','||(v_Seq+13)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''CreditModel'''||','''||v_CreditModel||''','||(v_Seq+14)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''CreditLevel'''||','''||v_CreditLevel||''','||(v_Seq+15)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''CreditSource'''||','''||v_CreditSource||''','||(v_Seq+16)||' from dual';

       Execute immediate strSql;

       v_Seq:=v_Seq + 16;

       --修改中移产品cs.credit_type='XF'的销售信息生成逻辑  yangzhenxian  2019-05-10
       if v_CreditType='XF'
       then
           for c in(select
            SALES_NAME as SaName,--销售员姓名
            SALES_PHONE as SaMobile,--销售员手机
            SALES_IDCARD as SaIdent---销售员身份证
            from cs_merchant_store where contract_no=v_ContractNo
             )loop

              insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)
                   values(p_IdCredit,v_ElementType,'SaName',c.SaName,v_Seq+1);

              insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)
                   values(p_IdCredit,v_ElementType,'SaMobile',c.SaMobile,v_Seq+1);

              insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)
                   values(p_IdCredit,v_ElementType,'SaIdent',c.SaIdent,v_Seq+1);

              v_SaName:=c.SaName;

              v_SaMobile:=c.SaMobile;

              v_SaIdent:=c.SaIdent;

              v_Seq:=v_Seq + 3;

           end loop;

       else

         strSql:='insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)
                  select '||p_IdCredit||','''||v_ElementType||''','||'''SaName'''||','''||v_SaName||''','||(v_Seq+1)||' from dual
                  union select '||p_IdCredit||','''||v_ElementType||''','||'''SaMobile'''||','''||v_SaMobile||''','||(v_Seq+2)||' from dual
                  union select '||p_IdCredit||','''||v_ElementType||''','||'''SaIdent'''||','''||v_SaIdent||''','||(v_Seq+3)||' from dual';

         v_Seq:=v_Seq + 3;

         Execute immediate strSql;

       end if;

       --享购机元素      yangzhenxian  2019-06-12
           for c in(select
            Supplier as Supplier,--套餐运营商（实际运营商）
            Channel_type as ChannelType,--渠道
            fw_channel as FwChannel--资方批发渠道
            from cs_credit_ext where id_credit=p_IdCredit
             )loop

              insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)
                   values(p_IdCredit,'Credit','Supplier',c.Supplier,v_Seq+1);

              insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)
                   values(p_IdCredit,'Credit','ChannelType',c.ChannelType,v_Seq+1);

              insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)
                   values(p_IdCredit,'Credit','FwChannel',c.FwChannel,v_Seq+1);

              v_Seq:=v_Seq + 3;

           end loop;

       v_ElementType:='Person';

       select name,ident,nvl(ident_auth,''),nvl(ident_exp,''),sex,nvl(fun_getreg_value(790,a.national),'汉')
         into v_PersonName,v_Ident,v_IdentAuth,v_IdentExp,v_Sex,v_National
         from cs_person a where id=v_IdPerson;

       if length(v_Ident)=15 then

           v_Birthday:=to_char(to_date('19'||substr(v_Ident,7,6),'yyyy-MM-dd'),'yyyy-MM-dd');
           select to_number(to_char(sysdate,'yyyy')) - to_number('19'||substr(v_Ident,7,2)) into v_Age from dual;

       else

           v_Birthday:=to_char(to_date(substr(v_Ident,7,8),'yyyy-MM-dd'),'yyyy-MM-dd');

           select to_number(to_char(sysdate,'yyyy')) - to_number(substr(v_Ident,7,4)) into v_Age from dual;

       end if;

       strSql:='insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)
                select '||p_IdCredit||','''||v_ElementType||''','||'''Name'''||','''||v_PersonName||''','||(v_Seq+1)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''IdPerson'''||','''||v_IdPerson||''','||(v_Seq+2)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''Ident'''||','''||v_Ident||''','||(v_Seq+3)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''IdentAuth'''||','''||v_IdentAuth||''','||(v_Seq+4)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''IdentExp'''||','''||to_char(v_IdentExp,'yyyy-MM-dd')||''','||(v_Seq+5)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''Birthday'''||','''||v_Birthday||''','||(v_Seq+6)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''Age'''||','''||v_Age||''','||(v_Seq+7)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''Sex'''||','''||v_Sex||''','||(v_Seq+8)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''National'''||','''||v_National||''','||(v_Seq+9)||' from dual';

       Execute immediate strSql;

       v_Seq:=v_Seq + 9;

       select count(1) into v_Count from sellerplace where id=v_IdSellerPlace;

       v_ElementType:='SellerPlace';

       if v_Count=1 then
           select name,province,city,address,activity_start,id_seller,pos_code,nvl(dsm_id,0)
             into v_DealerName,v_Province,v_City,v_Address,v_DealerActivityStart,v_IdSeller,v_PosCode,v_IdDsm
             from sellerplace where id=v_IdSellerPlace;

           v_UseCity:=v_City;

           insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)
                  select p_IdCredit,v_ElementType,'ActiveDate',decode(min(update_time),null,'',to_char(min(update_time),'yyyy-mm-dd')),v_Seq+1
                  from sellerplace_status_change t where t.new_status=1 and t.id_sellerplace=v_IdSellerPlace;

           v_Seq:=v_Seq + 1;

           strSql:='insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)
                    select '||p_IdCredit||','''||v_ElementType||''','||'''Name'''||','''||v_DealerName||''','||(v_Seq+1)||' from dual
                    union select '||p_IdCredit||','''||v_ElementType||''','||'''Province'''||','''||v_Province||''','||(v_Seq+2)||' from dual
                    union select '||p_IdCredit||','''||v_ElementType||''','||'''PosCode'''||','''||v_PosCode||''','||(v_Seq+3)||' from dual
                    union select '||p_IdCredit||','''||v_ElementType||''','||'''City'''||','''||v_City||''','||(v_Seq+4)||' from dual
                    union select '||p_IdCredit||','''||v_ElementType||''','||'''Address'''||','''||v_Address||''','||(v_Seq+5)||' from dual';
                    --union select '||p_IdCredit||','''||v_ElementType||''','||'''ActiveDate'''||','''||to_char(v_DealerActivityStart,'yyyy-MM-dd')||''','||(v_Seq+6)||' from dual';

           Execute immediate strSql;

           for c in(select area_code from cn_city_list
                     where rownum=1 and province=v_Province and city=v_City
             )loop

              insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)
                   values(p_IdCredit,v_ElementType,'AreaCode',c.area_code,v_Seq+7);

              v_Seq:=v_Seq + 7;

           end loop;

           insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)
             select p_IdCredit,v_ElementType,'RiskCate',risk_cate,v_Seq+1 from mv_df_pos_risk_cate_gl
             where pos_code=v_PosCode;

           insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)
             select p_IdCredit,v_ElementType,'RiskCate_Challenge',risk_cate_Challenge,v_Seq+2 from mv_df_pos_risk_cate_gl
             where pos_code=v_PosCode;

           v_Seq:=v_Seq + 2;

           --wangxiaofeng 2017/03/03 update end----

           v_Seq:=v_Seq + 9;

           v_ElementType:='Seller';

           select name,province,city,activity_start
             into v_SellerName,v_Province,v_City,v_SellerActivityStart
             from seller where id=v_IdSeller;

           strSql:='insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)
                    select '||p_IdCredit||','''||v_ElementType||''','||'''Name'''||','''||v_DealerName||''','||(v_Seq+1)||' from dual
                    union select '||p_IdCredit||','''||v_ElementType||''','||'''Province'''||','''||v_Province||''','||(v_Seq+2)||' from dual
                    union select '||p_IdCredit||','''||v_ElementType||''','||'''City'''||','''||v_City||''','||(v_Seq+3)||' from dual
                    union select '||p_IdCredit||','''||v_ElementType||''','||'''ActiveDate'''||','''||to_char(v_SellerActivityStart,'yyyy-MM-dd')||''','||(v_Seq+4)||' from dual';

           Execute immediate strSql;

           select count(1) into v_Count from sellerplace where id_seller=v_IdSeller;
           strSql:='insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)
                   select '||p_IdCredit||',''Seller'',''DealerCount'','''||v_Count||''','||(v_Seq+5)||' from dual';

           Execute immediate strSql;

       end if;

       v_Seq:=v_Seq + 5;

       ----------------------在SellerPlace下的元素中添加中移消费贷相关逻辑   yangzhenxian  2019-03-08------------------------------

       for c in(select decode(a.business_code,null,b.store_no,a.business_code) as PosCode
                ,b.STORE_NAME as  Name
                ,decode(store_province,null,g.AREA_NAME,store_province) as Province
                ,store_city as City
                ,store_address as Address
                from cs_credit_ext c
                left join cs_merchant_store b on b.contract_no=c.contract_no
                left join bs_area_info g on g.AREA_CODE=c.user_prov_no
                left join (
                select p.business_code ,'中移' as pos_type ---===中移动表
                from mv_bs_store p
                union
                select q.business_code ,'中联' as pos_type ---===中联表
                from mv_xy_bs_store q) a on a.business_code =b.store_no where c.contract_no=v_ContractNo and rownum=1
         )loop

          insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)
               values(p_IdCredit,'SellerPlace','PosCode',c.PosCode,v_Seq+1);

          insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)
               values(p_IdCredit,'SellerPlace','Name',c.Name,v_Seq+1);

          insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)
               values(p_IdCredit,'SellerPlace','Province',c.Province,v_Seq+1);

          insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)
               values(p_IdCredit,'SellerPlace','City',c.City,v_Seq+1);

          insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)
               values(p_IdCredit,'SellerPlace','Address',c.Address,v_Seq+1);

          if v_CreditType in ('XF','XFC')
          then

             v_PosCode:=c.PosCode;

          end if;

          v_Seq:=v_Seq + 5;

       end loop;

           --AfPosCate:反欺诈门店等级类别，取于表RISK_CONTROL.DF_AF_GSPN，当status=a中的字段AF_TYPE 2016/03/16 wangxiaofeng
           insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)
           select p_IdCredit,v_ElementType,'AfPosCate',nvl(max(t.af_type),0),v_Seq+10 from mv_df_af_gspn t
           where t.status='a' and t.ident=v_PosCode;

       --machaochun 2017/10/30 添加生成循环现金贷的元素
       if v_CreditType in ('SC', 'CY','SP','POS') then

         --SCTD_RiskCate：交叉现金贷同盾等级分类 yangzhenxian 2017/08/22
         for w in(with TD as (
            select
            a.associated_id as id_credit
            ,max(case when rule_no in (1044388,1053416) then extra_data end) as extra_data2_3m
            from WFI_FRAUD_METRIX_RESULT  a
            join WFI_FRAUD_METRIX_RULE b on a.id=b.fraud_metrix_result_id
            where a.event_name='Credit' and a.associated_id=p_IdCredit
            group by a.associated_id )
            select a.sctd_riskcate
            from  TD td
            join MV_DF_XS_TD_RISK_CATE_GL a on nvl(td.extra_data2_3m,0)=a.extra_data2_3m
          )loop

           insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
           values( p_IdCredit,'HardCheck','*','SCTD_RiskCate',w.sctd_riskcate,v_Seq+1 );

           v_Seq:=v_Seq + 1;

          end loop;
       end if;

       --wangxiaofeng 2016/11/15
       if v_CreditType in ('SC','POS') then

         for c in(select pos_code
                   from(select b.pos_code,row_number() over(order by a.commit_time desc) num
                        from cs_credit a,sellerplace b
                        where a.id_sellerplace=b.id and a.status in('a','p','k')
                        and a.commit_time<=trunc(sysdate-90) and a.id_person=v_IdPerson)
                   where num=1
           )loop

             --ScPosCode:交叉现金贷对应的pos贷来自的门店
             insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)
             values(p_IdCredit,'SellerPlace','ScPosCode',c.pos_code,v_Seq+1);

             v_Seq:=v_Seq + 1;

             for r in(select t.risk_cate,t.risk_cate_challenge from mv_df_xs_pos_risk_cate_gl t
                       where t.pos_code=c.pos_code and rownum=1
               )loop

                 --ScRiskCate:交叉贷虚拟门店类别
                 insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)
                 values(p_IdCredit,'SellerPlace','ScRiskCate',r.risk_cate,v_Seq+1);

                 v_Seq:=v_Seq + 1;

                 --ScRiskCate_Challenge:交叉贷虚拟门店类别
                 insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)
                 values(p_IdCredit,'SellerPlace','ScRiskCate_Challenge',r.risk_cate_challenge,v_Seq+1);

                 v_Seq:=v_Seq + 1;

                 --wangxiaofeng 2017/03/03
                 --ScRiskCate:交叉贷虚拟门店类别
                 insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)
                 values(p_IdCredit,'SellerPlace','RiskCate',r.risk_cate,v_Seq+1);

                 v_Seq:=v_Seq + 1;

                 --ScRiskCate_Challenge:交叉贷虚拟门店类别
                 insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)
                 values(p_IdCredit,'SellerPlace','RiskCate_Challenge',r.risk_cate_challenge,v_Seq+1);

                 v_Seq:=v_Seq + 1;

                 --wangxiaofeng 2017/03/03
               end loop;

           end loop;

       end if;

       if v_IdProduct!=0 then

         v_ElementType:='Product';

         select prod_code,prod_name,payment_num,decode(valid_from, null, '', to_char(valid_from, 'yyyy-MM-dd')),decode(valid_to, null, '', to_char(valid_to, 'yyyy-MM-dd')),
                effective_interest_rate,month_ir,month_fee,account_fee,cs_fee,overpay_year,init_pay,credit_from,credit_to,prod_type,search_type
           into v_ProdCode,v_ProdName,v_PaymentNum,v_ValidFrom,v_ValidTo,v_Eir,v_MonthIr,v_MonthFee,v_AccountFee,v_CsFee,v_OverPayYear,v_InitPay,v_CreditFrom,v_CreditTo,v_ProdType,v_SearchType
           from product where id=v_IdProduct;

         strSql:='insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)
                  select '||p_IdCredit||','''||v_ElementType||''','||'''ProdCode'''||','''||v_ProdCode||''','||(v_Seq+1)||' from dual
                  union select '||p_IdCredit||','''||v_ElementType||''','||'''ProdName'''||','''||v_ProdName||''','||(v_Seq+2)||' from dual
                  union select '||p_IdCredit||','''||v_ElementType||''','||'''PaymentNum'''||','''||v_PaymentNum||''','||(v_Seq+3)||' from dual
                  union select '||p_IdCredit||','''||v_ElementType||''','||'''InitPay'''||','''||v_InitPay||''','||(v_Seq+4)||' from dual
                  union select '||p_IdCredit||','''||v_ElementType||''','||'''CreditFrom'''||','''||v_CreditFrom||''','||(v_Seq+5)||' from dual
                  union select '||p_IdCredit||','''||v_ElementType||''','||'''CreditTo'''||','''||v_CreditTo||''','||(v_Seq+6)||' from dual
                  union select '||p_IdCredit||','''||v_ElementType||''','||'''EIR'''||','''||v_Eir||''','||(v_Seq+7)||' from dual
                  union select '||p_IdCredit||','''||v_ElementType||''','||'''MonthIr'''||','''||v_MonthIr||''','||(v_Seq+8)||' from dual
                  union select '||p_IdCredit||','''||v_ElementType||''','||'''MonthFee'''||','''||v_MonthFee||''','||(v_Seq+9)||' from dual
                  union select '||p_IdCredit||','''||v_ElementType||''','||'''AccountFee'''||','''||v_AccountFee||''','||(v_Seq+10)||' from dual
                  union select '||p_IdCredit||','''||v_ElementType||''','||'''CsFee'''||','''||v_CsFee||''','||(v_Seq+11)||' from dual
                  union select '||p_IdCredit||','''||v_ElementType||''','||'''OverPayYear'''||','''||v_OverPayYear||''','||(v_Seq+12)||' from dual
                  union select '||p_IdCredit||','''||v_ElementType||''','||'''ProdType'''||','''||v_ProdType||''','||(v_Seq+13)||' from dual
                  union select '||p_IdCredit||','''||v_ElementType||''','||'''ValidFrom'''||','''||v_ValidFrom||''','||(v_Seq+14)||' from dual
                  union select '||p_IdCredit||','''||v_ElementType||''','||'''SearchType'''||','''||v_SearchType||''','||(v_Seq+15)||' from dual';

         Execute immediate strSql;

         v_Seq:=v_Seq + 15;

         if v_ValidTo is not null then

             insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)
             select p_IdCredit,''||v_ElementType||'','ValidTo',''||v_ValidTo||'',(v_Seq+1) from dual;

             v_Seq:=v_Seq + 1;

         end if;

       end if;

       v_ElementType:='Photo';

       for photo in (select file_name,fun_getreg_value(775,a.photo_type) photo_type from cs_fast_photo a where id_credit=p_IdCredit)
       loop

            insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,nvl(photo.photo_type,'#'),photo.file_name,v_Seq+1);

            v_Seq:=v_Seq + 1;

       end loop;

       --元素[Photo.Count]逻辑修改至：不会对同类型照片重复累加 yangzhenxian 2018-04-26 update
       insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)
       select p_IdCredit,v_ElementType,'Count',count(distinct photo_type),v_Seq+1 from cs_fast_photo where id_credit=p_IdCredit;

       v_Seq:=v_Seq + 1;

       v_ElementType:='Goods';

       for goods in (select b.name goods_category,c.name goods_type,producer,brand,goods_price from cs_goods a,goods_category b,goods_type c
              where a.id_goods_category=b.id and a.id_goods_type=c.id and a.id_credit=p_IdCredit)
       loop

           if v_MaxGoodsPrice=-1 or v_MaxGoodsPrice<goods.goods_price then

              v_MaxGoodsPrice:=goods.goods_price;

              v_MaxGoodsType:=goods.goods_type;

           end if;

           if v_MinGoodsPrice=-1 or v_MinGoodsPrice>goods.goods_price then

              v_MinGoodsPrice:=goods.goods_price;

              v_MinGoodsType:=goods.goods_type;

           end if;

           insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,'Category',goods.goods_category,v_Seq+1);

           insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,'GoodsType',goods.goods_type,v_Seq+2);

           insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,'Producer',goods.producer,v_Seq+3);

           insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,'Brand',goods.brand,v_Seq+4);

           v_Seq:=v_Seq + 4;

           v_GoodsVolume:=v_GoodsVolume+1;

       end loop;

       insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,'MaxPrice',v_MaxGoodsPrice,v_Seq+1);

       insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,'MaxGoodsType',v_MaxGoodsType,v_Seq+2);

       insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,'MinGoodsType',v_MinGoodsType,v_Seq+3);

       insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,'GoodsVolume',v_GoodsVolume,v_Seq+4);

       v_Seq:=v_Seq + 3;

       --wangxiaofeng 2017/02/15  update 2017/03/21
       --针对不同手机产品生成官方价格：商品为苹果手机，根据型号Brand取对应的官方价格；
       --商品为非苹果手机，根据品牌Producer取对应的官方价格。
       --如果商品没有对应的官方价格，或申请多个商品，则不生成元素。

         for c in(select b.offical_price
                   from cs_goods a,mv_df_af_goods_price b
                      where a.id_goods_category=7 and a.id_goods_type=52 and b.status=1 and rownum=1
                      and a.producer=b.producer and a.brand=b.brand and a.id_credit=p_IdCredit
                   union
                   select b.offical_price
                   from cs_goods a,mv_df_af_goods_price b,goods_type c
                      where a.id_goods_category=7 and a.id_goods_type=21 and b.status=1 and rownum=1
                      and a.producer=b.producer and a.id_credit=p_IdCredit
           )loop

             insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,'OfficalPrice',c.offical_price,v_Seq+4);

             v_Seq:=v_Seq + 1;

           end loop;

       --2017/03/29 wangxiaofeng 元素Goods.NewCategory，区分手机类型中的苹果与非苹果，其他类型不变
       for c in(with a as (select cc.id id_credit,cg.id_goods_category,cg.producer,
                 c.name goods_category,t.name goods_type,row_number() over(order by cg.goods_price desc) rn
                from cs_credit cc
                join cs_goods cg on cc.id=cg.id_credit
                join goods_category c on cg.id_goods_category=c.id
                join goods_type t on cg.id_goods_type=t.id
                where cc.id=p_IdCredit)
                select case when id_goods_category=7 and (goods_type like '%苹果%' or producer like '%苹果%'
                   or upper(producer) like '%IPHONE%' or upper(producer) like '%APPLE%') THEN '苹果'
                   else to_char(goods_category) end as new_category
                from a where rn=1
         )loop

           insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)
           values(p_IdCredit,v_ElementType,'NewCategory',c.new_category,v_Seq+1);

           v_NewCategory:=c.new_category;

           v_Seq:=v_Seq + 1;

         end loop;
       --2017/03/29 wangxiaofeng 元素Good.AvgPriceSameCityLast1M
       --商品在同一个城市过去一个月的平均价格(商品类型、品牌、型号相同)，如果没有相同的商品，平均价格为0
       for c in(with c as(select a.*,
                case when producer1 in('苹果','苹果手机','iPhone','苹果公司','apple') then '苹果'
                     when producer1 in('OPPO','0pp0','0ppo','opp0') then 'oppo'
                     when producer1 in('vivo','步步高','vlvo','opp0') then 'vivo'
                     when producer1 in('DIY','组装机' ,'组装电脑' ) then '组装'
                     else to_char(lower(producer1)) end as producer,
                case when replace(replace(lower(brand1),' ',''),'-','') in ('r9pius','r9puls','r9p','oppor9plus','r9pus','r9lus','r9，plus','r9（plus）','r9(plus)','r9plas') then 'r9plus'
                 when replace(replace(lower(brand1),' ',''),'-','') in ('oppor9') then 'r9'
                 when replace(replace(lower(brand1),' ',''),'-','') in ('xpialy5','x5play' ) then 'xplay5'
                 when replace(replace(lower(brand1),' ',''),'-','') like '%xplay5%高配%' then 'xplay5高配'
                 when replace(replace(lower(brand1),' ',''),'-','') in('x7pius','x7puls','x7p') then 'x7plus'
                 when replace(replace(lower(brand1),' ',''),'-','') in ('p9pius','p9puls') then 'p9plus'
                 else to_char(replace(replace(replace(lower(brand1),' ',''),'-',''),'红米','') )end as brand
                from
                (select cc.id,cc.contract_no,cg.goods_price,sp.city
                ,cg.id_goods_category,cg.id_goods_type,cg.producer producer1,cg.brand brand1,c.name as goods_category,t.name as goods_type
                ,row_number() over(partition by cc.id order by goods_price desc) as num_id
                from cs_credit cc
                join cs_goods cg on cc.id=cg.ID_CREDIT
                join goods_category c on cg.id_goods_category=c.id
                join goods_type t on cg.id_goods_type=t.id
                join sellerplace sp on cc.id_sellerplace=sp.id
                where cc.id=p_IdCredit
                )a where num_id=1)
                select nvl(max(b.avg_price),0) avg_price from mv_city_goods_avg_price b
                join c on c.city=b.city and c.goods_category=b.goods_category and c.brand=b.brand and c.producer=b.producer
         )loop

           insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,'AvgPriceSameCityLast1M',c.avg_price,v_Seq+1);

           v_Seq:=v_Seq + 1;

         end loop;

         ----PackageInfo  套餐类型          yangzhenxian                          2019-04-28
         for d in(with temp as (
             select PACKAGE_INFO as PackageInfo from cs_goods where id_credit=p_IdCredit order by update_time desc
              )
              select * from temp where rownum=1
         )
         loop

           insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
           values( p_IdCredit,'Goods','*','PackageInfo',d.PackageInfo,v_Seq);

           v_Seq:=v_Seq + 1;

         end loop;

       v_ElementType:='Contact';

       for contact in (select fun_getreg_value(395,t.contact_type) contact_type,t.contact_type cont_type,contact_value from cs_contact t where person_type='1' and id_credit=p_IdCredit)
       loop

           insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,contact.contact_type,contact.contact_value,v_Seq+1);

           v_Seq:=v_Seq + 1;

           if contact.cont_type='3' then

             v_OfficeTel:=contact.contact_value;

           end if;

           if contact.cont_type='2' then

             v_PersonMobile:=contact.contact_value;

           end if;

       end loop;

       --hongbinbin 20190924
       for qq in (
         select
            case when contact_value like '%qq.com' then substr(regexp_substr(contact_value,'[0-9]+'),1,1) end as QQIntDigit---qq号首字母
            ,case when contact_value like '%qq.com' then length(regexp_substr(contact_value,'[0-9]+'))end as QQLength---qq号长度
            from (select a.person_type,a.contact_type,a.contact_value,
                row_number()over (partition by id_credit,person_type,contact_type,contact_value order by  update_time desc) as rank_id
                from cs_contact a where a.id_credit=p_IdCredit) ctpq
            where ctpq.rank_id=1 and ctpq.person_type='1' and ctpq.contact_type='11'
         )loop

          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,'*','QQIntDigit',qq.QQIntDigit,v_Seq+1);

          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,'*','QQLength',qq.QQLength,v_Seq+2);

           v_Seq:=v_Seq + 2;

         end loop;

       v_ElementType:='Address';

       for address in (select decode(address_type,1,'ResidentAddress',2,'CurrentAddress','CompanyAddress') address_type,province,city,region,town,street,building,room
              from cs_address where id_credit=p_IdCredit order by address_type)
       loop

           insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,address.address_type,'Province',address.province,v_Seq+1);

           insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,address.address_type,'City',address.city,v_Seq+2);

           insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,address.address_type,'Region',address.region,v_Seq+3);

           insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,address.address_type,'Town',address.town,v_Seq+4);

           insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,address.address_type,'Street',address.street,v_Seq+5);

           insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,address.address_type,'Building',address.building,v_Seq+6);

           insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,address.address_type,'Room',address.room,v_Seq+7);

           if address.address_type='CurrentAddress' then

             for c in(select area_code from cn_city_list
                      where rownum=1 and province=address.province and city=address.city
               )loop

                 v_AreaCode:=c.area_code;

                 insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                   values(p_IdCredit,v_ElementType,address.address_type,'AreaCode',v_AreaCode,v_Seq);

                 v_Seq:=v_Seq + 8;

               end loop;
           else

               v_Seq:=v_Seq + 7;

           end if;

       end loop;

       v_ElementType:='OtherPerson';

       for otherperson in (select a.name,fun_getreg_value(decode(length(a.person_type),1,265,396),a.person_type) persontype,b.contact_value
              from cs_other_person a,cs_contact b where a.id_credit=b.id_credit and a.person_type=b.person_type and a.id_credit=p_IdCredit order by a.id)
       loop

           if instr(otherperson.persontype,'-')>0 then

              v_OtherPersonType:=substr(otherperson.persontype,1,instr(otherperson.persontype,'-')-1);

           else

              v_OtherPersonType:=otherperson.persontype;

           end if;

           insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,v_OtherPersonType,'Name',otherperson.name,v_Seq+1);

           insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,v_OtherPersonType,'ContactValue',otherperson.contact_value,v_Seq+2);

           v_Seq:=v_Seq + 2;

       end loop;

       v_ElementType:='Career';

       for employer in (select nvl(fun_getreg_value(399,a.company_type),'') as company_type,nvl(fun_getreg_value(397,a.industry),'') as industry,a.position,
              nvl(b.university,a.company_name1) university,nvl(a.department,'') as department,decode(a.start_date, null, '', to_char(a.start_date, 'yyyy-MM-dd')) startdate,decode(a.end_date, null, '', to_char(a.end_date, 'yyyy-MM-dd')) enddate
              from cs_employer a,university b where a.company_name=b.id(+) and a.id_credit=p_IdCredit)
       loop

           v_Position:=employer.position;

           insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,'CompanyType',employer.company_type,v_Seq+1);

           insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,'Industry',employer.Industry,v_Seq+2);

           insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,'Position',employer.position,v_Seq+3);

           insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,'University',pkg_decision.filterStr(employer.university),v_Seq+4);

           insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,'Department',employer.department,v_Seq+5);

           insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,'StartDate',employer.startdate,v_Seq+6);

           if employer.enddate is not null then

               insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)values
                   (p_IdCredit,v_ElementType,'EndDate',employer.enddate,v_Seq+7);

               v_Seq:=v_Seq + 7;

           else

               v_Seq:=v_Seq + 6;

           end if;

       end loop;

       v_ElementType:='Other';

       for experience in (select nvl(a.total_wk_exp,0) total_wk_exp,nvl(a.wk_income,0) wk_income,nvl(a.other_income,0) other_income,nvl(a.family_income,0) family_income,
              nvl(fun_getreg_value(11,a.education),'') education,nvl(ssi,'') ssi,nvl(a.cur_wk_exp,0) cur_wk_exp,fun_getreg_value(776,a.bank_name) bank_name,a.bank_no,a.branch,
              fun_get_ybscity(a.id_ybs_city,a.id_credit) bank_region,nvl(a.is_dd,0) is_dd,nvl(a.is_ssi,0) is_ssi,to_char(a.fst_date_pay, 'yyyy-MM-dd') fst_date_pay
              from cs_experience a where id_credit=p_IdCredit)
       loop

          if v_Position=9 then

               v_varTemp:='LeftGraduateMonth';

          else

               v_varTemp:='CurrentEmpMonth';

          end if;

          insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)values
                 (p_IdCredit,v_ElementType,v_varTemp,experience.total_wk_exp,v_Seq+1);

          insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)values
                 (p_IdCredit,v_ElementType,'PersonIncome',experience.wk_income,v_Seq+2);

          insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)values
                 (p_IdCredit,v_ElementType,'OtherIncome',experience.other_income,v_Seq+3);

          insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)values
                 (p_IdCredit,v_ElementType,'FamilyIncome',experience.family_income,v_Seq+4);

          insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)values
                 (p_IdCredit,v_ElementType,'Education',experience.education,v_Seq+5);

          insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)values
                 (p_IdCredit,v_ElementType,'LengthOfSchooling',experience.ssi,v_Seq+6);

          insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)values
                 (p_IdCredit,v_ElementType,'BankName',experience.bank_name,v_Seq+7);

          insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)values
                 (p_IdCredit,v_ElementType,'BankNo',experience.bank_no,v_Seq+8);

          insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)values
                 (p_IdCredit,v_ElementType,'BankCity',experience.bank_region,v_Seq+9);

          insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)values
                 (p_IdCredit,v_ElementType,'Branch',experience.branch,v_Seq+10);

          insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)values
                 (p_IdCredit,v_ElementType,'IsDD',experience.is_dd,v_Seq+11);

          insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)values
                 (p_IdCredit,v_ElementType,'IsSSI',experience.is_ssi,v_Seq+12);

          insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)values
                 (p_IdCredit,v_ElementType,'SSI',experience.ssi,v_Seq+13);

          insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)values
                 (p_IdCredit,v_ElementType,'FirstPayDate',experience.fst_date_pay,v_Seq+14);

          v_Seq:=v_Seq + 14;

       end loop;

       v_ElementType:='FamilyInfo';

       for familyinfo in (select decode(id_spouse, 1, '未婚', 2, '已婚', '其它') mariage,nvl(child,0) children_count,fun_getreg_value(2, house_type) house_type,expense_month
                   from cs_family_info where id_credit=p_IdCredit)
       loop

          insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)values
                 (p_IdCredit,v_ElementType,'Marriage',familyinfo.mariage,v_Seq+1);

          insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)values
                 (p_IdCredit,v_ElementType,'ChildrenCount',familyinfo.children_count,v_Seq+2);

          insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)values
                 (p_IdCredit,v_ElementType,'HouseType',familyinfo.house_type,v_Seq+3);

          insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)values
                 (p_IdCredit,v_ElementType,'ExpenseMonth',familyinfo.expense_month,v_Seq+4);

          v_Seq:=v_Seq + 4;

       end loop;

       -----------------以下为需要计算的变量-----------------------------------------------

       --2017/03/21 wangxiaofeng  2017/03/29 wangxiaofeng update yangzhenxian 2017-12-22 update TotalAnnuity
       --添加元素Credit.TotalAnnuity，包括以下期款及费用 annuity+power_fee+insurance_fee+screen_fee+post_fee-COUPON_AMOUNT
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'Credit','*','TotalAnnuity',nvl(sum(TotalAnnuity),0),v_Seq+1
       from(select nvl(annuity,0)+nvl(power_fee,0)+nvl(insurance_fee,0)+nvl(broken_screen_service,0)+nvl(stag_insurance_service,0)
             -nvl(coupon_amount,0)+nvl(treasure_box_fee,0)+nvl(COMPREHENSIVE_INSURANCE,0) as TotalAnnuity
       from cs_credit_fee where id_credit=p_IdCredit);

       v_Seq:=v_Seq + 1;

       --2017/7/12 wangxiaofeng Credit.GiveuGlobleLimit 计算客户在申请此合同时即有钱包的总额度GLOBLE_LIMIT
       for c in (select t.total_limit from giveu_credit_eligible t where t.status in(1,2,8) and  t.id_person=v_IdPerson)
       loop

          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)values
                 (p_IdCredit,'Credit','*','GiveuGlobleLimit',c.total_limit,v_Seq+1);

          v_Seq:=v_Seq + 1;

       end loop;

       --IsSAIdent客户申请时,身份证是否属于销售代表/销售经理/门店法人身份证  yangzhenxian 2017-12-06
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'HardCheck','*','IsSAIdent',case when sum(amount)>0 then 1 else 0 end,v_Seq+1
       from (
         select count(1) amount from sys_user_list a where upper(a.role_id) in('SA','DSM','MENTOR') and a.ident=v_Ident
         union
         select count(1) amount from seller where legal_ident=v_Ident);

       v_Seq:=v_Seq + 1;

       --AfSaCate:反欺诈销售等级类别，取于表RISK_CONTROL.DF_AF_GSPN_ABNORMAL，当status=a中的字段AF_TYPE 2016/03/16 wangxiaofeng
       if v_CreditType='XF'
       then

         insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)
         select p_IdCredit,'SellerPlace','AfSaCate',nvl(max(t.af_type),0),v_Seq+6 from mv_df_af_gspn_abnormal t
         where t.status='a' and t.ident=v_SaIdent;

       else

         insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)
         select p_IdCredit,'SellerPlace','AfSaCate',nvl(max(t.af_type),0),v_Seq+6 from mv_df_af_gspn_abnormal t
         where t.status='a' and t.id_sa=v_IdSa;

       end if;

       v_Seq:=v_Seq + 1;

       --IsMysteryIdent 客户申请时身份证是否属于暗访人员白名单(select ident from mv_WHITELIST_MYST_INVE where status='a')
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         select p_IdCredit,'HardCheck','*','IsMysteryIdent',decode(count(1),0,0,1),v_Seq+1
         from mv_WHITELIST_MYST_INVE t where status='a' and t.ident=v_Ident;

       v_Seq:=v_Seq + 1;

       ---客户现行合同的总贷款额---
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         select p_IdCredit,'HardCheck','*','SumActiveCreditAmount',nvl(sum(a.credit_amount),0),v_Seq+1
         from cs_credit a where a.id_person=v_IdPerson and a.status='a' and a.COMMIT_TIME<v_CommitTime;--2017-09-22增加时间范围 ;

       v_Seq:=v_Seq + 1;

       ---客户循环贷现行合同的总贷款额---
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         select p_IdCredit,'HardCheck','*','SumActiveCycleCreditAmount',nvl(sum(a.credit_amount),0),v_Seq+1
         from cycle_credit a where a.id_person=v_IdPerson and a.status='a' and a.CREATE_TIME<v_CommitTime;--2017-09-22增加时间范围 ;

       v_Seq:=v_Seq + 1;

       --此门店第一张合同的申请时间，status<>'r'
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         select p_IdCredit,'SellerPlace','*','FirstAppDate',to_char(nvl(min(trunc(a.commit_time)),trunc(sysdate)),'yyyy-mm-dd'),v_Seq+1
         from cs_credit a where a.id_sellerplace=v_IdSellerPlace and a.id_sa not in('800079','300079') and a.commit_time>to_date('2014-09-01','yyyy-mm-dd') and a.status!='r';

       v_Seq:=v_Seq + 1;

       --客户在申请此合同时，前30天内的合同总次数
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            select p_IdCredit,'HardCheck','*','ApplicationLast30Day',count(1),v_Seq+1 from cs_credit a where a.id_person=v_IdPerson
               and a.id<>p_IdCredit and trunc(a.commit_time)>=trunc(sysdate)-30 and a.COMMIT_TIME<v_CommitTime;--2017-09-22增加时间范围

       v_Seq:=v_Seq + 1;

       --客户在申请此合同时，当天取消的合同总数
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            select p_IdCredit,'HardCheck','*','CancleApplicationSameDay',count(1),v_Seq+1 from cs_credit a where a.id_person=v_IdPerson
               and trunc(a.commit_time)=trunc(sysdate) and a.status='t' and a.id<>p_IdCredit  and a.COMMIT_TIME<v_CommitTime;--2017-09-22增加时间范围

       v_Seq:=v_Seq + 1;

       --客户在申请此合同时前面一张合同的申请时间
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            select p_IdCredit,'HardCheck','*','PrevCommitTime',to_char(max(commit_time),'yyyy-MM-dd HH24:mi:ss'),v_Seq+1 from cs_credit
             where id_person=v_IdPerson and commit_time<=v_CommitTime and id!=p_IdCredit;

       v_Seq:=v_Seq + 1;

       --客户在申请此合同时前面一张通过的合同的申请时间，除拒绝和取消的合同外（状态为d/t/x/u的除外）update_time2016/11/30  2019/01/22 update
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            select p_IdCredit,'HardCheck','*','MaxPrevCommitTime',to_char(max(commit_time),'yyyy-MM-dd HH24:mi:ss'),v_Seq+1 from cs_credit
             where id_person=v_IdPerson and commit_time<=v_CommitTime and credit_type in('SS','SC','XF','SP') and id!=p_IdCredit and status not in('d','t','x','u','r','q','pr','pa','py');

       v_Seq:=v_Seq + 1;

       --MaxPrevSSCommitTime:客户在申请此合同时前面一张消费贷通过的合同的申请时间，除拒绝和取消的合同外（状态为d/t/x的除外）
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            select p_IdCredit,'HardCheck','*','MaxPrevSSCommitTime',to_char(max(commit_time),'yyyy-MM-dd HH24:mi:ss'),v_Seq+1 from cs_credit
             where id_person=v_IdPerson and commit_time<=v_CommitTime and credit_type='SS' and id!=p_IdCredit and status not in ('d','t','x');

       v_Seq:=v_Seq + 1;

       --MaxPrevSCCommitTime:客户在申请此合同时前面一张现金贷通过的合同的申请时间，除拒绝和取消的合同外（状态为d/t/x的除外）
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            select p_IdCredit,'HardCheck','*','MaxPrevSCCommitTime',to_char(max(commit_time),'yyyy-MM-dd HH24:mi:ss'),v_Seq+1 from cs_credit
             where id_person=v_IdPerson and commit_time<=v_CommitTime and credit_type!='SS' and id!=p_IdCredit and status not in ('d','t','x');

       v_Seq:=v_Seq + 1;

       --客户在申请此合同时前面一张拒绝的合同的申请时间（状态为d） 2019/01/22 update
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            select p_IdCredit,'HardCheck','*','RejectPrevCommitTime',to_char(max(commit_time),'yyyy-MM-dd HH24:mi:ss'),v_Seq+1 from cs_credit
             where id_person=v_IdPerson and commit_time<=v_CommitTime and (credit_type in('SS','SC','MQ','XF','SP','XFC') or (credit_type='QB' and id_sa is not null)) and id!=p_IdCredit and status='d';

       v_Seq:=v_Seq + 1;

       --RejectSSPrevCommitTime:客户在申请此合同时前面一张消费贷拒绝的合同的申请时间（状态为d）
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            select p_IdCredit,'HardCheck','*','RejectSSPrevCommitTime',to_char(max(commit_time),'yyyy-MM-dd HH24:mi:ss'),v_Seq+1 from cs_credit
             where id_person=v_IdPerson and commit_time<=v_CommitTime and credit_type='SS' and id!=p_IdCredit and status='d';

       v_Seq:=v_Seq + 1;

       --RejectSCPrevCommitTime:客户在申请此合同时前面一张现金贷拒绝的合同的申请时间（状态为d）
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            select p_IdCredit,'HardCheck','*','RejectSCPrevCommitTime',to_char(max(commit_time),'yyyy-MM-dd HH24:mi:ss'),v_Seq+1 from cs_credit
             where id_person=v_IdPerson and commit_time<=v_CommitTime and credit_type!='SS' and id!=p_IdCredit and status='d';

       v_Seq:=v_Seq + 1;

       --客户在申请此合同时前面一张合同的状态
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            select p_IdCredit,'HardCheck','*','PrevStatus',status,v_Seq+1 from cs_credit where id_person=v_IdPerson
               and id=(select max(id) from cs_credit where id_person=v_IdPerson and id!=p_IdCredit) and commit_time<v_CommitTime;--2017-09-22增加时间范围

       v_Seq:=v_Seq + 1;

       for pre_credit in (select to_char(max(commit_time),'yyyy-MM-dd HH24:mi:ss') commit_time,count(1) sumdue,sum(annuity) annuity from cs_credit where id_person=v_IdPerson and commit_time<=v_CommitTime and id!=p_IdCredit and status ='a')
       loop

           --客户在申请此合同时前面一张现行的合同的申请时间（状态为a)
           insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                values(p_IdCredit,'HardCheck','*','PrevApproveTime',pre_credit.commit_time,v_Seq+1);

           v_Seq:=v_Seq + 1;

           --客户在申请此合同时现行状态的合同数量(状态为a）
           --select count(sum(1)) into v_Count from v_previous_contract where prev_status='a' and id_credit=p_IdCredit group by id_credit;
           insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                values(p_IdCredit,'HardCheck','*','SumDue',pre_credit.sumdue,v_Seq+1);

           v_Seq:=v_Seq + 1;

           --客户在申请此合同时现行状态的合同的每期期款之和(状态为a）
           --select count(sum(prev_annuity)) into v_Count from v_previous_contract where prev_status='a' and id_credit=p_IdCredit group by id_credit;
           insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                values(p_IdCredit,'HardCheck','*','SumSurplusValueInstalment',pre_credit.annuity,v_Seq+1)
                ;
           v_Seq:=v_Seq + 1;

       end loop;

       --客户在申请此合同时通过状态的合同数量（状态为a/k/p）
       for pre_credit in (select count(1) sumdue,sum(credit_amount) sumamount from cs_credit where id_person=v_IdPerson and id!=p_IdCredit and status in ('a','k','p'))
       loop

           insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                values(p_IdCredit,'HardCheck','*','SumPassContract',pre_credit.sumdue,v_Seq+1);

           v_Seq:=v_Seq + 1;

           --客户在申请此合同时通过状态的合同贷款额之和（状态为a/k/p）
           --select count(sum(prev_credit_amount)) into v_Count from v_previous_contract where prev_status in ('a','k','p') and id_credit=p_IdCredit group by id_credit;
           insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                values(p_IdCredit,'HardCheck','*','SumPassCreditAmount',pre_credit.sumamount,v_Seq+1);

           v_Seq:=v_Seq + 1;

       end loop;

       --1. SumAgrSameOffPhoneLast6M:客户在申请此合同时，客户办公号码在过去6个月被其他客户（作为申请人办公号码）
       --使用过的可衡量30天逾期的合同数( select sum(agr_fpd30) from risk_control.df_pd_sum_gl)
       --2. SumDefSameOffPhoneLast6M:客户在申请此合同时，客户办公号码在过去6个月被其他客户（作为申请人办公号码）
       --使用过的出现30天逾期的合同数( select sum(fpd30) from risk_control.df_pd_sum_gl)
       for cs in(select nvl(sum(decode(a.agr_fpd30,null,0,a.agr_fpd30)),0) agr_fpd30,
                 nvl(sum(decode(a.fpd30,null,0,a.fpd30)),0) fpd30
                 from mv_df_pd_sum_gl a
                 join cs_contact b on b.id_credit=a.id_credit
                 where b.contact_type='3'
                 and b.contact_value in(select contact_value from cs_contact c
                                      where c.contact_type='3' and c.person_type='1' and c.id_credit=p_IdCredit)
                 and b.update_time>=trunc(v_CommitTime-180) and b.update_time<=v_CommitTime)
       loop

         insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                values(p_IdCredit,'HardCheck','*','SumAgrSameOffPhoneLast6M',cs.agr_fpd30,v_Seq+1);

           v_Seq:=v_Seq + 1;

         insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                values(p_IdCredit,'HardCheck','*','SumDefSameOffPhoneLast6M',cs.fpd30,v_Seq+1);

           v_Seq:=v_Seq + 1;

       end loop;

       --客户在申请此合同时，非客户本人的手机号码在过去6个月被其他客户用作非本人的手机号码相同且姓名不同的次数（除状态为t，r的合同）
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'HardCheck','*','MobileUseDiffNameCountLast6M',count(1),v_Seq+1
       from cs_credit t
       join cs_contact a on a.id_credit=t.id and a.person_type!='1' and a.contact_type='2'
       join cs_other_person b on b.id_credit=a.id_credit and b.person_type=a.person_type
       join (select e.name,g.contact_value from cs_contact g
            join cs_other_person e on e.id_credit=g.id_credit and e.person_type=g.person_type
            where g.person_type!='1' and g.contact_type='2' and g.id_credit=p_IdCredit
            ) c on c.contact_value=a.contact_value and b.name!=c.name
       where t.id_person!=v_IdPerson and t.status not in('t','r')
       and t.id_sa not in ('800079','888888','300079') and t.credit_type='SS'
       and t.commit_time>v_CommitTime-180 and t.commit_time<v_CommitTime;

       --2017/03/23 wanxiaofeng 新增 HardCheck.MaxCpd,HardCheck.Last3mCpd
       for prev_instalment in
          (select to_char(min(date_due_first),'yyyy-MM-dd') as date_due_first,--客户最早的应还款日期
               max(cpd) as cpd,--客户在申请合同时其他合同的现在的未还的逾期天数，精确到天
               sum(remaining_amount) as remaining_amount, --客户在申请此合同时其他合同剩余的未还期金额（包含未到期的）
               sum(remaining_instal) as remaining_instal, --客户在申请此合同时其他合同剩余的未还期数之和（包含未到期的）
               max(max_dpd) as max_dpd,--客户在申请合同时历史上最大逾期天数，精确到天
               max(last_3m_dpd) as last_3m_dpd, --客户在申请合同时最近三个月（自然月）的最大逾期天数，精确到天
               max(max_cpd) as max_cpd,
               max(last_3m_cpd) as last_3m_cpd,
               to_char(to_date(substr(max(date_3m_dpd),4,8),'yyyy-MM-dd'),'yyyy-MM-dd') as date_3m_dpd,
               sum(m_paid_ndpd) as m_paid_ndpd,--客户在申请此合同前成功还款且没有逾期的期数总合
               sum(m_due) as m_due--客户在申请此合同时前面已经到期的期数之和
              from (
                select a.id_person ,
                date_due_first,--客户最早的应还款日期
                cpd,--客户在申请合同时其他合同的现在的未还的逾期天数，精确到天
                remaining_amount, --客户在申请此合同时其他合同剩余的未还期金额（包含未到期的）
                remaining_instal, --客户在申请此合同时其他合同剩余的未还期数之和（包含未到期的）
                max_dpd,--客户在申请合同时历史上最大逾期天数，精确到天
                last_3m_dpd, --客户在申请合同时最近三个月（自然月）的最大逾期天数，精确到天
                max_cpd,
                last_3m_cpd,
                date_3m_dpd,
                m_paid_ndpd,--客户在申请此合同前成功还款且没有逾期的期数总合
                m_due--客户在申请此合同时前面已经到期的期数之和
                from mv_DF_PD_SUM_GL   a
                join cs_credit c on a.contract_no=c.contract_no and c.credit_channel='GIVEU'

                union

                select b.id as id_person,
                null as date_due_first,--客户最早的应还款日期
                0 as cpd,--客户在申请合同时其他合同的现在的未还的逾期天数，精确到天
                0 as remaining_amount, --客户在申请此合同时其他合同剩余的未还期金额（包含未到期的）
                0 as remaining_instal, --客户在申请此合同时其他合同剩余的未还期数之和（包含未到期的）
                max_dpd,--客户在申请合同时历史上最大逾期天数，精确到天
                last_3m_dpd, --客户在申请合同时最近三个月（自然月）的最大逾期天数，精确到天
                0 as max_cpd,
                0 as last_3m_cpd,
                null as date_3m_dpd,
                0 as m_paid_ndpd,--客户在申请此合同前成功还款且没有逾期的期数总合
                0 as m_due--客户在申请此合同时前面已经到期的期数之和
                from qk_pd_total a
                join cs_person b on a.cust_no=b.IDENT
                --where a.cust_no=v_ident
                )
              where id_person=v_IdPerson)
       loop

          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
              values(p_IdCredit,'HardCheck','*','DateDueFirst',prev_instalment.date_due_first,v_Seq+1);
          v_Seq:=v_Seq + 1;

          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values(p_IdCredit,'HardCheck','*','Cpd',prev_instalment.cpd,v_Seq+1);
          v_Seq:=v_Seq + 1;

          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values(p_IdCredit,'HardCheck','*','RemainingAmount',prev_instalment.remaining_amount,v_Seq+1);
          v_Seq:=v_Seq + 1;

          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values(p_IdCredit,'HardCheck','*','RemainingInstal',prev_instalment.remaining_instal,v_Seq+1);
          v_Seq:=v_Seq + 1;

          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values(p_IdCredit,'HardCheck','*','MaxDpd',prev_instalment.max_dpd,v_Seq+1);
          v_Seq:=v_Seq + 1;

          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values(p_IdCredit,'HardCheck','*','Last3mDpd',prev_instalment.last_3m_dpd,v_Seq+1);
          v_Seq:=v_Seq + 1;

          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values(p_IdCredit,'HardCheck','*','MaxCpd',prev_instalment.max_cpd,v_Seq+1);
          v_Seq:=v_Seq + 1;

          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values(p_IdCredit,'HardCheck','*','Last3mCpd',prev_instalment.last_3m_cpd,v_Seq+1);
          v_Seq:=v_Seq + 1;

          if prev_instalment.date_3m_dpd is not null then
             insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                  values(p_IdCredit,'HardCheck','*','Date3mDpd',prev_instalment.date_3m_dpd,v_Seq+1);
             v_Seq:=v_Seq + 1;
          end if;

          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values(p_IdCredit,'HardCheck','*','MPaidNdpd',prev_instalment.m_paid_ndpd,v_Seq+1);
          v_Seq:=v_Seq + 1;

          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values(p_IdCredit,'HardCheck','*','MDue',prev_instalment.m_due,v_Seq+1);
          v_Seq:=v_Seq + 1;

       end loop;
         commit;
         --Credit.*. EndureAmount：月还款能力  yangzhenxian      2019-04-019
         for d in(with temp as (
             select EndureAmount from (
              select max(a.ENDURE_AMOUNT) as EndureAmount,max(a.create_time)
              from cross_active_detail a
              join cross_active_list b on a.ACTIVE_ID=b.ACTIVE_ID
              where a.ID_PERSON=v_IdPerson and b.START_DATE<v_CommitTime and b.END_DATE>trunc(v_CommitTime)
              order by b.create_time desc)
              )
              select * from temp where rownum=1
              )
         loop

           insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
           values( p_IdCredit,'Credit','*','EndureAmount',d.EndureAmount,v_Seq);

           v_Seq:=v_Seq + 1;

         end loop;

       --2016/11/23 wangxiaofeng 在HardCheck类别里添加元素TdRateSaLAST1M：销售前一个月申请订单中命中同盾的占比 2017/06/22 添加rule_no wangxiaofeng
       if v_CreditType='SS' then

         for c in(with fraud_metrix as (
           select  a.associated_id as id_credit
           ,max(case when t.rule_no in(66218,66214,66222,66220,78586,15724,44140,11532,37334,44130,6826,6822,14128,44124,15728,14130,840080,840106,
                                         840098,2992507,840116,2992511,840072,840076,840096,2992509,840100,2900153,
                                        2901749,2992525,891780,891784,2900089,2992523,2901741,891808,891788,2901719,2992521,
                                        891804,2901711,891814,2901715,891806,891824,5638201,5640421,5640431,5640411)  then 1
           when t.rule_no in(1044388,1053416) and t.extra_data>1 then 1 else 0 end) as td_rule
           from wfi_fraud_metrix_result a
           join wfi_fraud_metrix_rule t on a.id=t.fraud_metrix_result_id
           where a.event_name='Credit' and a.update_time>=trunc(sysdate-30)
             and exists(select 1 from cs_credit cc where cc.commit_time>=trunc(sysdate-30) and cc.commit_time<v_CommitTime+10/24/60/60
             and cc.status not in('t','r')
                   and cc.credit_type='SS' and cc.id_sa=v_IdSa and cc.id=a.associated_id)
           group by a.associated_id)
           select round(sum(td.td_rule)/nvl(count(1),1),4) TdRateSaLAST1M
           from  cs_credit cc
           left join fraud_metrix td on cc.id=td.id_credit
           where cc.commit_time>=trunc(sysdate-30) and cc.commit_time<v_CommitTime+10/24/60/60 and cc.status not in('t','r')
           and cc.credit_type='SS' and cc.id_sa=v_IdSa
         )loop

           insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
           values( p_IdCredit,'HardCheck','*','TdRateSaLAST1M',c.TdRateSaLAST1M,v_Seq);

           v_Seq:=v_Seq + 1;

         end loop;

         --2016/11/23 wangxiaofeng 在HardCheck类别里添加元素InterCodeRateSaLast1M：销售前一个月申请订单中内部代码拒绝的占比
         for c in(with all_list as (
                select case when b.status not in('t','r') then 1 else 0 end as app_num
                ,case when b.status not in('t','r') and b.inter_code in (3,4) then 1 else 0 end as rej_intercode
                from  cs_credit b
                where b.commit_time>=trunc(sysdate-30) and b.commit_time<=v_CommitTime and  b.credit_type='SS'
                and b.status not in('t','r') and b.id_sa=v_IdSa
                )
                select round(sum(rej_intercode)/nvl(sum(app_num),1),4) InterCodeRateSaLast1M
                from all_list a
         )loop

           insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
           values( p_IdCredit,'HardCheck','*','InterCodeRateSaLast1M',c.InterCodeRateSaLast1M,v_Seq);

           v_Seq:=v_Seq + 1;

         end loop;

        ---2017/10/27 machaochun    增加元素HardCheck. SameContactAppr /*客户申请合同填写的非本人联系方式在过去180天对应通过的合同数量*/
        /*2017/11/24 yangzhenxian   当前合同联系人180天内未被使用过则为空，当前合同联系人180天内被使用但使用的合同未被通过则为0
        ，被通过则累计通过次数,需要把0和null的情况区分开来*/
        insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
        select p_IdCredit,'HardCheck','*','SameContactAppr'
        ,sum(case when status in('a','p','k') then 1 when status is not null then 0 end),v_Seq+1 from
        (
        select distinct a.id curId,b.id ConId,b.status from
          (
          --合同联系人
          select c.id,c.commit_time,c.id_person,ct.contact_value from cs_credit c, cs_contact ct
          where c.id=ct.id_credit and ct.contact_type='2' and c.id=p_IdCredit--指定合同ID
          ) a
          left join
          (
          --合同联系人的订单
          select c.id,c.commit_time,c.id_person,ct.contact_value,c.status  from  cs_contact ct , cs_credit c
          where c.id=ct.id_credit and ct.contact_type='2'/* and c.status in ('a','p','k') */
          and c.id_sa not in (300079,800079,899999)--排除 id_sa in (300079,800079,899999)
          ) b
          on a.contact_value=b.contact_value and b.commit_time>a.commit_time-180 and b.commit_time<a.commit_time and a.id_person<>b.id_person
        );

          v_Seq:=v_Seq + 1;

       end if;

       if v_CreditType in ('CY','SC','POS') then
        ---2017/10/30 machaochun
          ---   添加元素HardCheck.MaxPrevSS_Payment_Num:客户在申请此合同时前面一张消费贷通过的合同的期数（状态为a/p/k的合同）
          ---   添加元素HardCheck.MaxPrevSS_Annuity：客户在申请此合同时前面一张消费贷通过的合同的期款，包含各种费用（状态为a/p/k的合同）
          for c in(with base as(
                select  max(a.id) as max_id_ss
                from cs_credit a
                where a.id_person=v_IdPerson and a.commit_time<v_CommitTime
                and  a.credit_type in('SS','XF') and a.status in ('a','p','k')  --获取前一张合同（a.credit_type='SS' 修改为 a.credit_type in('SS','XF')）
              )
              ,element as(
              select distinct a.*,pr.payment_num as MaxPrevSS_Payment_Num
              ,c.annuity+nvl(c.power_fee,0)+nvl(ce.insurance_fee,0)-nvl(ce.COUPON_AMOUNT,0)+nvl(cg.BROKEN_SCREEN_SERVICE,0)+nvl(cg.STAG_INSURANCE_SERVICE,0)
               as MaxPrevSS_Annuity
              from base a
              join cs_credit c on c.id=a.max_id_ss
              join product pr on c.id_product=pr.id
              left join cs_experience ce on a.max_id_ss=ce.id_credit
              left join (select id_credit,sum(BROKEN_SCREEN_SERVICE) as BROKEN_SCREEN_SERVICE,sum(STAG_INSURANCE_SERVICE) as STAG_INSURANCE_SERVICE
                         from cs_goods
                         group by id_credit) cg on a.max_id_ss=cg.id_credit
              )
              select * from element  where rownum=1  --异常时如有多个cs_experience，取最新的
          )loop

             insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'HardCheck','*','MaxPrevSS_Payment_Num',c.MaxPrevSS_Payment_Num,v_Seq);

             v_Seq:=v_Seq + 1;

             insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'HardCheck','*','MaxPrevSS_Annuity',c.MaxPrevSS_Annuity,v_Seq);

             v_Seq:=v_Seq + 1;

          end loop;

          ---2017/10/30 machaochun
          ---   添加元素HardCheck.MaxPrevSS_RiskCate:客户在申请此合同时前面一张消费贷通过的合同的GSPN（状态为a/p/k的合同）
          ---   添加元素HardCheck.MaxPrevSS_PreRG：客户在申请此合同时前面一张消费贷通过的合同的PreRG（状态为a/p/k的合同）
          for c in(
             with base as(
                      select max(a.id) as max_id_ss
                      from cs_credit a
                      where a.id_person=v_IdPerson and a.commit_time<v_CommitTime
                      and  a.credit_type in('SS','XF') and a.status in ('a','p','k') --获取前一张合同（a.credit_type='SS' 修改为 a.credit_type in('SS','XF')）
              )

              ,element as(
              select a.*
              ,case when u.RiskCate is null and u.RiskCate_Challenge is null   then 'new_pos'
                    when u.commit_time<date'2016-02-24' then u.RiskCate---16年2月24号之前在uw_info的表中只有一个字段riskcate
                    when u.commit_time<date'2016-07-20' then u.RiskCate_Challenge
                    else u.RiskCate end MaxPrevSS_RiskCate
              ,u.pre_rg as MaxPrevSS_PreRG
              from base a
              join mv_df_uw_info_gl u on a.max_id_ss=u.id
              )
              select * from element where rownum=1
          )loop

             insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'HardCheck','*','MaxPrevSS_RiskCate',c.MaxPrevSS_RiskCate,v_Seq);

             v_Seq:=v_Seq + 1;

             insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'HardCheck','*','MaxPrevSS_PreRG',c.MaxPrevSS_PreRG,v_Seq);

             v_Seq:=v_Seq + 1;

          end loop;

       end if;

       --2016/11/23 wangxiaofeng 在Credit类别里添加元素limit12:白名单销售内部代码12单量上限来自risk_control.df_uw_sa_whitelist的limit12字段
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'Credit','*','limit12',nvl(max(t.limit12),0),v_Seq
       from mv_df_uw_sa_whitelist t
       where t.status=1 and t.sa_id=v_IdSa;

       v_Seq:=v_Seq + 1;

      /*ORG180D：最近180天查询机构数    yangzhenxian   2018-03-23*/
      for d in (
          with temp as(
          select ORG_CNT_RECENT_180_DAYS as ORG180D from sauron_history a where id_credit=p_IdCredit order by a.create_time desc)
          select * from temp where rownum=1
        )loop

        insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         values( p_IdCredit,'External','SauRon','ORG180D',d.ORG180D,v_Seq+1 );

        v_Seq:=v_Seq + 1;

        end loop;

      if v_CreditType in('SC','POS') then

        /*MaxPrevSS_FraudScoreCate：客户申请此合同时前面一张消费贷的前期评分卡得分50等分  yangzhenxian    2018-03-23*/
        for d in (
            with temp as(
            select c.id,u.prefraudscorecate as MaxPrevSS_FraudScoreCate from cs_credit c--消费贷
            left join mv_df_uw_info_gl u on c.id=u.id
            where c.id_person=v_IdPerson and c.credit_type='SS' and c.status in ('a','p','k')
            and c.app_date<v_AppDate and c.commit_time<v_CommitTime order by c.commit_time desc )
            select MaxPrevSS_FraudScoreCate from temp where rownum=1
          )loop

          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
           values( p_IdCredit,'HardCheck','*','MaxPrevSS_FraudScoreCate',d.MaxPrevSS_FraudScoreCate,v_Seq+1 );

          v_Seq:=v_Seq + 1;

          end loop;

        /*Last3mCpd_Cnt：最近3个月cpd>0的次数  yangzhenxian    2018-03-23*/
          select count(1) into v_Count from cs_credit c
          join df_pd_detail_gl pd on c.contract_no=pd.contract_no
          where c.id_person=v_IdPerson and c.CREDIT_TYPE in ('SS','SC','POS') and c.status in ('a','p','k')
          and c.app_date<v_AppDate and date_due>=add_months(v_AppDate,-3) and date_due < v_AppDate and  max_cpd>0 ;

          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
           values( p_IdCredit,'HardCheck','*','Last3mCpd_Cnt',v_Count,v_Seq+1 );

          v_Seq:=v_Seq + 1;

      end if;

        --20180806 majianfeng
        for hcGood in (select b.name
          from cs_goods a
          join goods_category b
            on a.id_goods_category = b.id
         where a.id_credit in (select max(id)
                                 from cs_credit a
                                where a.id_person = v_IdPerson
                                  and a.credit_type = 'SS'
                                  and a.status in ('a', 'p', 'k')) and rownum=1)
        loop

          --客户申请此合同时前面一张消费贷通过的合同的商品类型
           insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         values( p_IdCredit,'HardCheck','*','MaxPrevSSCategory',hcGood.Name,v_Seq + 1);

          v_Seq:=v_Seq + 1;

        end loop;

      -------begin 2016/08/31 wangxiaofeng-----
      if v_City is not null then

        --CityFirstAppDate 消费贷开业城市提交第一单申请的时间，status<>'r'
        insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         select p_IdCredit,'SellerPlace','*','CityFirstAppDate',to_char(nvl(min(trunc(a.commit_time)),trunc(sysdate)),'yyyy-mm-dd'),v_Seq+1
         from cs_credit a,sellerplace b
         where a.id_sellerplace=b.id and a.id_sa not in(800079,300079)
         and a.commit_time>to_date('2014-09-01','yyyy-mm-dd') and a.status!='r' and b.province=v_Province and b.city=v_City;

        v_Seq:=v_Seq + 1;

        --NewSARateSameDSM: 销售经理名下入职未满一个月的销售人数占比, 销售入职时间用销售提交第一单申请的时间SaFirstAppDate
        insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
        select p_IdCredit,'Credit','*','NewSARateSameDSM',round(max(t.newsacnt)/nvl(max(t.sacnt),1),3),v_Seq+1
        from mv_uw_newsarate_1d t where t.id_dsm=v_IdDsm;

        v_Seq:=v_Seq + 1;

        --SAQuitRateSameDSM60D: 销售经理名下最近60天做单的销售中，离职人数/总人数
        insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
        select p_IdCredit,'Credit','*','SAQuitRateSameDSM60D',round(max(t.sa_quit)/nvl(max(t.sa_cnt),1),3),v_Seq+1
        from mv_uw_saquitrate_60d t where t.id_dsm=v_IdDsm;

        v_Seq:=v_Seq + 1;

      end if;

      -----SauRon  begin yangzhenxian     2017-12-21-----------
      --BlackListIDent:身份证是否命中黑名单
      for d in (
          with temp as(
          select IDCARD_IN_BLACKLIST as BlackListIDent from sauron_risk c
          where c.id_credit=p_IdCredit order by c.create_time desc)
          select * from temp where rownum=1
        )loop
        insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         values( p_IdCredit,'External','SauRon','BlackListIDent',d.BlackListIDent,v_Seq+1 );

        v_Seq:=v_Seq + 1;

        end loop;

      --BlackListMobile：手机号是否命中黑名单
      for d in (
          with temp as(
          select PHONE_IN_BLACKLIST as BlackListMobile from sauron_risk c
          where c.id_credit=p_IdCredit order by c.create_time desc)
          select * from temp where rownum=1
        )loop

        insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         values( p_IdCredit,'External','SauRon','BlackListMobile',d.BlackListMobile,v_Seq+1 );

        v_Seq:=v_Seq + 1;

        end loop;

      --BlackListP2P：是否命中网贷黑名单
      for d in (
          with temp as(
          select IN_P2P_BLACKLIST as BlackListP2P from sauron_risk c
          where c.id_credit=p_IdCredit order by c.create_time desc)
          select * from temp where rownum=1
        )loop

        insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         values( p_IdCredit,'External','SauRon','BlackListP2P',d.BlackListP2P,v_Seq+1 );

        v_Seq:=v_Seq + 1;

        end loop;
      -----SauRon  end---------------
      --DeductDate:首次还款日 yangzhenxian     2017-12-21-----------
      for d in (
          with temp as(
          select DEDUCT_DATE as DeductDate from cs_credit c
          where c.id=p_IdCredit)
          select * from temp where DeductDate is not null
        )loop

        insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         values( p_IdCredit,'Credit','*','DeductDate',to_char(d.DeductDate,'yyyy-MM-dd HH24:mi:ss'),v_Seq+1 );

        v_Seq:=v_Seq + 1;

        end loop;

      --NewDeductDate:首次还款日 yangzhenxian     2018-09-30-----------
      for d in (
          select case when date_due is null then 0 else 1 end isExists--0：没有现行合同，1：有现行合同
          ,case when date_due is null then v_CommitTime else date_due end date_due --没有现行合同时，取当前合同申请日期，有现行合同时还款日期
          from (
          select cc.id,temp.date_due from cs_credit cc --当前合同
          left join
          (
            select i.date_due,i.id_credit,c.id_person from instalment i,cs_credit c where i.id_credit=c.id and i.type_instalment not in (8,100)
            and c.status='a' and c.credit_type in ('SS','SC') and c.id_person=v_IdPerson and trunc(i.date_due)>trunc(v_CommitTime) order by i.id asc
          ) temp--现行合同的还款日期
          on cc.id_person=temp.id_person
          where cc.id=p_IdCredit and cc.credit_type='SC'--当前合同ID
          ) t where rownum=1
        )loop

        if d.isexists=1 then--1.  如果这个客户有现行合同，判断客户现行合同最近一期还款日减去现申请日是否>=15天

          if ROUND(TO_NUMBER(d.date_due - trunc(v_CommitTime)))>=15 then      --1.1 如果>=15天，首次还款日为该现行合同最近一期还款日

             select d.date_due into v_NewDeductDate from dual;

          else   --1.2 如果<15天，首次还款日为该现行合同最近两期还款日

             select add_months(d.date_due,1) into v_NewDeductDate from dual;

          end if;

        else--2.  如果这个客户没有现行合同，判断客户申请日是否为29、30、31
          if extract (day from v_CommitTime) in (29,30,31) then             --2.1 如果申请日落在29、30、31，首次还款日分别为下下个月1、2、3号

             select to_date(to_char(add_months(v_CommitTime,2),'yyyy-MM-')||decode(extract (day from v_CommitTime),29,1,30,2,31,3),'yyyy-MM-dd') into v_NewDeductDate from dual;

          else                                                         --2.2 如果申请日非29、30、31，首次还款日为申请日加一个月

             select add_months(v_CommitTime,1) into v_NewDeductDate from dual;

          end if;

        end if;

        insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         values( p_IdCredit,'Credit','*','NewDeductDate',to_char(v_NewDeductDate,'yyyy-MM-dd'),v_Seq+1 );

        v_Seq:=v_Seq + 1;

      end loop;

    begin --2016/11/03 wangxiaofeng 芝麻信用分--

      --芝麻信用分, ZhimaCreditScore 元素类别External.ZhiMa
      for c in(select t.score from zhima_credit_score t
                where t.id_credit=p_IdCredit
        )loop

          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            values(p_IdCredit,'External','ZhiMa','ZhimaCreditScore',c.score,v_Seq+1);

          v_Seq:=v_Seq + 1;

        end loop;

      --芝麻反欺诈分, ZhimaIvsScore 元素类别External.ZhiMa
      for c in(select t.score from zhima_credit_ivs t
                where t.id_credit=p_IdCredit
        )loop

          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            values(p_IdCredit,'External','ZhiMa','ZhimaIvsScore',c.score,v_Seq+1);

          v_Seq:=v_Seq + 1;

        end loop;

      --是否关注行业名单, CreditWatchList 元素类别External.ZhiMa
      for c in(select t.matched from zhima_credit_watch t
                where t.id_credit=p_IdCredit
        )loop

          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            values(p_IdCredit,'External','ZhiMa','CreditWatchList',c.matched,v_Seq+1);

          v_Seq:=v_Seq + 1;

        end loop;
    end;

    --External.ZhiMa.MultiLoan1D 返回以下规则元素值为1，否则为0 2017-10-09 yangzhenxian
    insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
    select p_IdCredit,'External','ZhiMa','MultiLoan1D',case when count(1)>0 then 1 else 0 end,v_Seq+1
    from zhima_antifraud_risk_hit h
    join ZHIMA_ANTIFRAUD_RISK_DETAIL d
    on h.id=d.risk_id
    where h.id_credit=p_IdCredit and d.code in ('R_CN_JJ_01','R_PH_JJ_01');

    v_Seq:=v_Seq + 1;

    --External.ZhiMa.MultiLoan1W 返回以下规则元素值为1，否则为0 2017-10-09 yangzhenxian
    insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
    select p_IdCredit,'External','ZhiMa','MultiLoan1W',case when count(1)>0 then 1 else 0 end,v_Seq+1
    from zhima_antifraud_risk_hit h
    join ZHIMA_ANTIFRAUD_RISK_DETAIL d
    on h.id=d.risk_id
    where h.id_credit=p_IdCredit and d.code in ('R_CN_JJ_02','R_PH_JJ_02');
    v_Seq:=v_Seq + 1;

    --External.ZhiMa.MultiLoan1M 返回以下规则元素值为1，否则为0 2017-10-09 yangzhenxian
    insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
    select p_IdCredit,'External','ZhiMa','MultiLoan1M',case when count(1)>0 then 1 else 0 end,v_Seq+1
    from zhima_antifraud_risk_hit h
    join ZHIMA_ANTIFRAUD_RISK_DETAIL d
    on h.id=d.risk_id
    where h.id_credit=p_IdCredit and d.code in ('R_CN_JJ_03','R_PH_JJ_03');
    v_Seq:=v_Seq + 1;

    --External.ZhiMa.CnResult 2017-10-09 yangzhenxian
    for c in(select * from(select a.id,b.verify_id,code
      ,decode(description,'姓名与身份证号匹配','匹配'
      ,'姓名与身份证号不匹配','不匹配'
      ,'查询不到身份证信息','无信息','') description
              from zhima_antifraud_verify a
              join zhima_antifraud_verify_detail b on a.id=b.verify_id
              where a.ID_CREDIT=p_IdCredit and instr(code,'V_CN')>0 order by a.create_time desc) b where rownum=1
      )loop

        insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
          values(p_IdCredit,'External','ZhiMa','CnResult',c.description,v_Seq+1);

        v_Seq:=v_Seq + 1;

      end loop;

    --External.ZhiMa.PhResult 2017-10-09 yangzhenxian
    for c in(select * from(select a.id,b.verify_id,code
      ,decode(description,'查询不到电话号码信息','无信息'
      ,'电话号码与本人不匹配','不匹配'
      ,'电话号码与本人匹配，180天内没有使用','匹配未使用180D'
      ,'电话号码与本人匹配，180天内有使用','匹配使用180D'
      ,'电话号码与本人匹配，30天内有使用','匹配使用30D'
      ,'电话号码与本人匹配，90天内有使用','匹配使用90D'
      ,'电话号码与姓名不匹配','姓名不匹配'
      ,'电话号码与姓名匹配，180天内没有使用','姓名匹配未使用180D'
      ,'电话号码与姓名匹配，180天内有使用','姓名匹配使用180D'
      ,'电话号码与姓名匹配，30天内有使用','姓名匹配使用30D'
      ,'电话号码与姓名匹配，90天内有使用','姓名匹配使用90D','') description
              from zhima_antifraud_verify a
              join zhima_antifraud_verify_detail b on a.id=b.verify_id
              where a.ID_CREDIT=p_IdCredit and instr(code,'V_PH')>0 order by a.create_time desc) b where rownum=1
      )loop

        insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
          values(p_IdCredit,'External','ZhiMa','PhResult',c.description,v_Seq+1);

        v_Seq:=v_Seq + 1;

      end loop;

    --内部员工等级 2017/01/19
    insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)
    select p_IdCredit,'Career','Title',t.position,v_Seq+1
    from mv_df_wallet_emplist_abby t
    where months_between(sysdate,start_date)>3 and rownum=1 and t.ident=v_Ident;

    v_Seq:=v_Seq + 1;

    --鹏元电话验证 元素External.PengYuan 电话核查-PhoneResult 姓名核查-NameResult 身份证核查-IdentResult 2016/11/03 wangxiaofeng
    for c in(select t.nameresult,t.phoneresult,t.identresult from cs_pyphone_data t
              where t.event_name=0 and t.person_type='1' and rownum=1 and t.id_credit=p_IdCredit
    )loop

      if c.nameresult is null then

        insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
          values(p_IdCredit,'External','PengYuan','NameResult','未查得',v_Seq+1);

        v_Seq:=v_Seq + 1;

      else

        insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
          values(p_IdCredit,'External','PengYuan','NameResult',c.nameresult,v_Seq+1);

        v_Seq:=v_Seq + 1;

      end if;

      if c.phoneresult is null then

        insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
          values(p_IdCredit,'External','PengYuan','PhoneResult','未查得',v_Seq+1);

        v_Seq:=v_Seq + 1;

      else

        insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
          values(p_IdCredit,'External','PengYuan','PhoneResult',c.phoneresult,v_Seq+1);

        v_Seq:=v_Seq + 1;

      end if;

      if c.identresult is null then

        insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
          values(p_IdCredit,'External','PengYuan','IdentResult','未查得',v_Seq+1);

        v_Seq:=v_Seq + 1;

      else

        insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
          values(p_IdCredit,'External','PengYuan','IdentResult',c.identresult,v_Seq+1);

        v_Seq:=v_Seq + 1;

      end if;

    end loop;

      ---------------手机三项验证----NameResultQB-----IdentrResultQB---------------by yangzhenxian 2017-08-30
      if v_CreditType='MQ' then

      for py in(select nameresult,Identresult from
                  (select phone.nameresult,phone.Identresult
                         from cs_pyphone_data phone,Wallet_Apply_Info wa
                         where phone.id_credit=wa.id and wa.id_credit=p_IdCredit and phone.event_name=1
                         and (phone.person_type='1' or phone.person_type is null)  order by phone.update_time desc) a
                  where rownum=1)
      loop

       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
        values( p_IdCredit,'External','PengYuan','NameResultQB',py.nameresult,v_Seq + 1 );

        v_Seq:=v_Seq + 1;

       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
        values( p_IdCredit,'External','PengYuan','IdentResultQB',py.Identresult,v_Seq + 1 );

        v_Seq:=v_Seq + 1;

      end loop;

      select count(1) into v_Count from cs_credit a
      join wallet_apply_info b on b.id_person=a.id_person
      where a.status in('m','i') and a.credit_type='MQ' and a.commit_time<=v_CommitTime and b.status=3
      and b.factory_id in(select c.factory_id from wallet_apply_info c where c.id_person=v_IdPerson);

      insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
        values(p_IdCredit,'HardCheck','*','SumApprovedSameFactory',v_Count,v_Seq+1);
      v_Seq:=v_Seq + 1;

      --2017/03/21 wanxiaofeng
      for qb in(select a.factory_id,a.recommend_type,a.recommend_person
              from wallet_apply_info a
              join cs_person b on b.id=a.id_person
              join wallet_factory_info c on c.id=a.factory_id
              join cs_credit d on d.id=a.id_credit
              where d.id=p_IdCredit
       )loop

         insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            values(p_IdCredit,'Wallet','*','FactoryId',qb.factory_id,v_Seq+1);

         v_Seq:=v_Seq + 1;

         insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            values(p_IdCredit,'Wallet','*','RecommendType',qb.recommend_type,v_Seq+1);

         v_Seq:=v_Seq + 1;

         insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            values(p_IdCredit,'Wallet','*','RecommendPerson',qb.recommend_person,v_Seq+1);

         v_Seq:=v_Seq + 1;

       end loop;

       end if;

    --银行卡三要素验证结果 2017/03/17 wangxiaofeng
    for c in(select status from(select t.status,row_number() over(order by update_time desc) nums
              from bank_account_verify t
              where t.update_time>=trunc(sysdate) and t.verify_type=0
                     and t.ident=v_Ident and t.account_name=v_PersonName) b where nums=1
      )loop

        insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
          values(p_IdCredit,'External','BankVerify','ThreeFactorStatus',c.status,v_Seq+1);

        v_Seq:=v_Seq + 1;

      end loop;

    --银行卡四要素验证结果 2017/03/17 wangxiaofeng
    for c in(select status from(select t.status,row_number() over(order by update_time desc) nums
              from bank_account_verify t
              where t.update_time>=trunc(sysdate) and t.verify_type=1
                     and t.ident=v_Ident and t.account_name=v_PersonName) b where nums=1
      )loop

        insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
          values(p_IdCredit,'External','BankVerify','FourFactorStatus',c.status,v_Seq+1);

        v_Seq:=v_Seq + 1;

      end loop;

    --交叉现金贷元素
    if v_ProdType in(6,7) then

       --客户第一次参加活动的活动开始时间
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
          select p_IdCredit,'Credit','*','ValidFromFirst',to_char(min(b.start_date),'yyyy-mm-dd'),v_Seq+1
          from cross_active_detail a,cross_active_list b where a.active_id=b.active_id and a.id_person=v_IdPerson;

       v_Seq:=v_Seq + 1;

       --客户正在参加的活动相关信息
       for active in(select a.max_amount,b.start_date,b.end_date,b.active_type,a.person_type from cross_active_detail a,cross_active_list b
       where a.active_id=b.active_id and b.status=1 and a.id_person=v_IdPerson)
       loop

         --当前活动最大额度
         insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
          values(p_IdCredit,'Credit','*','Limit',active.max_amount,v_Seq+1);

         v_Seq:=v_Seq + 1;

         --当前活动开始时间
         insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
          values(p_IdCredit,'Credit','*','ValidFrom',to_char(active.start_date,'yyyy-mm-dd'),v_Seq+1);
         v_Seq:=v_Seq + 1;

         --当前活动结束时间
         insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
          values(p_IdCredit,'Credit','*','ValidTo',to_char(active.end_date,'yyyy-mm-dd'),v_Seq+1);

         v_Seq:=v_Seq + 1;

         --当前活动类型
         insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
          values(p_IdCredit,'Credit','*','ActiveType',active.active_type,v_Seq+1);

         v_Seq:=v_Seq + 1;

          --当前活动客户类型  yangzhenxian   20181119
          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
          values(p_IdCredit,'Credit','*','PersonType',active.person_type,v_Seq+1);

         v_Seq:=v_Seq + 1;

       end loop;

       --2017/05/24 wangxiaofeng MaxPrevSS_LLLM:客户在申请此合同时前面一张消费贷通过的合同的地址，除拒绝和取消的合同外（状态为d/t/r的除外）
        for c in(with reg as(
          select a.province reg_province,a.city reg_city,id_credit
          from cs_address a where a.id_credit=
          (select max(id) id_credit from cs_credit t
          where t.credit_type='SS' and t.status not in ('t','d','r') and t.id_person=v_IdPerson)
          and a.address_type=1
          ),
         cur as(
          select a.province cur_province,a.city cur_city,id_credit
          from cs_address a where a.id_credit=
          (select max(id) id_credit from cs_credit t
          where t.credit_type='SS' and t.status not in ('t','d','r') and t.id_person=v_IdPerson)
          and a.address_type=2
          )
         select case when reg_province=cur_province and reg_city=cur_city then 'LL'
                when reg_province=cur_province and reg_city<>cur_city then 'LLM'
                when reg_province<>cur_province then 'LM'
                else 'NO' end  MaxPrevSS_LLLM from cur c,reg d
          where c.id_credit=d.id_credit
        )loop

          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
          values(p_IdCredit,'HardCheck','*','MaxPrevSS_LLLM',c.MaxPrevSS_LLLM,v_Seq+1);

          v_Seq:=v_Seq + 1;

        end loop;

        --2017/05/24 wangxiaofeng
        --HardCheck FamilyPhoneUpdateCount:客户在申请此合同时该客户之前更改了家庭联系人电话的次数
        --HardCheck ThirdPhoneUpdateCount:客户在申请此合同时该客户之前更改了第三方联系人电话的次数
        for c in(select count(distinct case when person_type in ('其他亲戚','配偶','父母','兄弟姐妹','儿女') then t.contact_value else null end) familyphoneupdatecount
                ,count(distinct case when person_type='第三方' then t.contact_value else null end) thirdphoneupdatecount
                from cs_contact_portion t
                where t.status in(1,3) and t.contact_type='移动电话'
                and t.person_type in('其他亲戚','配偶','父母','兄弟姐妹','儿女','第三方') and t.id_person=v_IdPerson and t.update_time<v_CommitTime--2017-09-22增加时间范围
        )loop

          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
           values(p_IdCredit,'HardCheck','*','FamilyPhoneUpdateCount',c.familyphoneupdatecount,v_Seq+1);

          v_Seq:=v_Seq + 1;

          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
           values(p_IdCredit,'HardCheck','*','ThirdPhoneUpdateCount',c.thirdphoneupdatecount,v_Seq+1);

          v_Seq:=v_Seq + 1;

        end loop;

        --2017-09-07 yangzhenxian
        --HardCheck TotalPhoneUpdateCount:客户在申请此合同时该客户之前所有移动电话总次数
        for c in(select count(distinct contact_value) TotalPhoneUpdateCount
                from cs_contact_portion t
                where t.id_person=v_IdPerson and t.update_time<v_AppDate and t.contact_type='移动电话' and t.status in(1,3)
        )loop

          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
           values(p_IdCredit,'HardCheck','*','TotalPhoneUpdateCount',c.totalphoneupdatecount,v_Seq+1);

          v_Seq:=v_Seq + 1;

        end loop;

     end if;

       -----------黑名单客户------------------------------------

       --如果客户存在黑名单有效期限里,则创建拒绝原因"黑名单."
       --客户身份证黑名单
       select count(1) into v_Count from customer_blacklist where ident=v_Ident;

       if v_Count>0 then

          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
              values(p_IdCredit,'HardCheck','*','BlackListIDent','1',v_Seq+1);

          v_Seq:=v_Seq + 1;

       end if;

       --客户本人手机号码黑名单
       select count(1) into v_Count from customer_blacklist
       where mobile in(select contact_value from cs_contact where id_person=v_IdPerson and person_type='1' and contact_type in('2','3','18','19'));

       if v_Count>0 then

          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
              values(p_IdCredit,'HardCheck','*','BlackListMobile','1',v_Seq+1);

          v_Seq:=v_Seq + 1;

       end if;

       --客户其它手机号码黑名单

       select count(1) into v_Count from customer_blacklist

       where mobile in(select contact_value from cs_contact where id_person=v_IdPerson and person_type<>'1' and contact_type in('2','3','18','19'));
       if v_Count>0 then

          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
              values(p_IdCredit,'HardCheck','*','BlackListOtherMobile','1',v_Seq+1);

          v_Seq:=v_Seq + 1;

       end if;

       --客户家庭电话黑名单
       select count(1) into v_Count from customer_blacklist
       where home_num in(select contact_value from cs_contact where id_person=v_IdPerson and contact_type='18');
       if v_Count>0 then

          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
              values(p_IdCredit,'HardCheck','*','BlackListHomePhone','1',v_Seq+1);

          v_Seq:=v_Seq + 1;

       end if;

       --客户QQ号码黑名单 2016/07/07 wangxiaofeng
       select count(1) into v_Count from cs_contact c
       where c.person_type='1' and c.contact_type='13' and c.id_credit=p_IdCredit
       and exists( select * from customer_blacklist b where b.qq=regexp_substr(c.contact_value,'[0-9]+'));
       if v_Count>0 then

          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
              values(p_IdCredit,'HardCheck','*','BlackListQQ','1',v_Seq+1);

          v_Seq:=v_Seq + 1;

       end if;

       --公司工作电话黑名单
       select count(1) into v_Count from company_blacklist where office_num in(select contact_value from cs_contact where id_person=v_IdPerson and contact_type='3');
       if v_Count>0 then

          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
              values(p_IdCredit,'HardCheck','*','BlackListOfficePhone','1',v_Seq+1);

          v_Seq:=v_Seq + 1;

       end if;

       --公司名称黑名单
       select count(1) into v_Count from company_blacklist where employer_name in(select company_name1 from cs_employer where id_person=v_IdPerson);
       if v_Count>0 then

          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
              values(p_IdCredit,'HardCheck','*','BlackListCompanyName','1',v_Seq+1);

          v_Seq:=v_Seq + 1;

       end if;

       --客户在申请此合同时,历史其他客户使用过的银行账号（除本人外，除状态为t,d,r的合同）
       select count(1) into v_Count from cs_experience a,cs_credit b
       where a.id_credit=b.id and a.id_person<>v_IdPerson and b.status not in('d','t','r') and b.commit_time<=v_CommitTime
       and a.bank_no=(select distinct bank_no from cs_experience where id_credit=p_IdCredit and id_person=v_IdPerson);

       if v_Count>0 then

          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
              values(p_IdCredit,'HardCheck','*','BankAccNo','1',v_Seq+1);

          v_Seq:=v_Seq + 1;

       end if;

       for phone_depository in (select relationship,contact_value,status,contact_type,id_sellerplace,city from v_phone_depository where id_credit=p_IdCredit)
       loop

          if phone_depository.relationship='client' and phone_depository.contact_type='2' then

              --客户在申请此合同时，前6个月内客户手机号码被使用过次数
              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                   select p_IdCredit,'HardCheck','*','SameMobileLast6Month',count(1),v_Seq+1 from v_phone_depository
                    where contact_value=phone_depository.contact_value and contact_type='2' and relationship='client'
                    and id_person!=v_IdPerson and status not in('r','t') and commit_time>=sysdate-180 and commit_time<=v_CommitTime;

              v_Seq:=v_Seq + 1;

              --客户在申请此合同时，客户手机号码被历史其他客户（作为申请人移动电话）使用过的次数（除状态为t,d,r的合同）
              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                   select p_IdCredit,'HardCheck','*','SameMobileHisCount',count(1),v_Seq+1 from v_phone_depository
                    where contact_value=phone_depository.contact_value and contact_type='2' and relationship='client'
                    and id_person!=v_IdPerson and status not in('d','t','r') and commit_time<=v_CommitTime;

              v_Seq:=v_Seq + 1;

              --客户办公电话在过去30天在同个城市被其他人重复使用为办公电话的情况；状态不等于tr 使用过的次数（除状态为t,r的合同）
              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                   select p_IdCredit,'HardCheck','*','MobPhoneUseSameCityCount',count(1),v_Seq+1 from v_phone_depository
                    where contact_value=phone_depository.contact_value and id_person!=v_IdPerson and commit_time>=sysdate-30
                     and commit_time<=v_CommitTime and status not in('t','r') and city=phone_depository.city;

              v_Seq:=v_Seq + 1;

              --客户办公电话在过去30天在同个城市被其他人重复使用为办公电话的情况；状态不等于tr 使用过的次数（除状态为t,r的合同）
              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                   select p_IdCredit,'HardCheck','*','MobPhoneUseSamePosCount',count(1),v_Seq+1 from v_phone_depository
                    where contact_value=phone_depository.contact_value and id_person!=v_IdPerson and commit_time>=sysdate-30
                     and commit_time<=v_CommitTime and status not in('t','r') and id_sellerplace=phone_depository.id_sellerplace;

              v_Seq:=v_Seq + 1;

              --客户在申请此合同时，客户手机号码存在，在职SA移动电话列表
              select count(1) into v_Count from sys_user_list a where upper(a.role_id)='SA' and a.phone=phone_depository.contact_value;

              if v_Count>0 then

                 insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                   values(p_IdCredit,'HardCheck','*','SAMobilelist','1',v_Seq+1);

                 v_Seq:=v_Seq + 1;

              end if;

          elsif phone_depository.relationship='client' and phone_depository.contact_type='18' then

              --客户在申请此合同时，客户家庭固话被历史其他客户（作为家庭固话）使用过的次数（除状态为t,d,r的合同）
              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                   select p_IdCredit,'HardCheck','*','FamilyPhoneHisUseCount',count(1),v_Seq+1 from v_phone_depository
                    where contact_value=phone_depository.contact_value and contact_type='18' and relationship='client'
                     and commit_time<=v_CommitTime and id_person!=v_IdPerson and status not in('d','t','r');

              v_Seq:=v_Seq + 1;

          elsif phone_depository.relationship='family' then

              --家庭成员电话在最近180天被其他不同的客户用作其他所有电话（办公电话除外）的次数
              select count(distinct(id_credit||contact_value)) into v_Count from v_phone_depository
              where contact_value=phone_depository.contact_value and id_person!=v_IdPerson and commit_time>=sysdate-180 and commit_time<=v_CommitTime and status not in('t','r');
              v_FamilyPhoneUseCount:=v_FamilyPhoneUseCount+v_Count;

              --家庭成员电话在过去30天在同个城市被其他人重复使用的情况；状态不等于tr的次数
              select count(distinct(id_credit||contact_value)) into v_Count from v_phone_depository
              where contact_value=phone_depository.contact_value and id_person!=v_IdPerson and commit_time>=sysdate-30 and commit_time<=v_CommitTime and status not in('t','r') and city=phone_depository.city;
              v_FamilyPhoneUseSameCityCount:=v_FamilyPhoneUseSameCityCount+v_Count;

              --家庭成员电话在过去30天在同个门店被其他人重复使用的情况；状态不等于tr的次数
              select count(distinct(id_credit||contact_value)) into v_Count from v_phone_depository
              where contact_value=phone_depository.contact_value and id_person!=v_IdPerson and commit_time>=sysdate-30 and commit_time<=v_CommitTime and status not in('t','r') and id_sellerplace=phone_depository.id_sellerplace;
              v_FamilyPhoneUseSamePosCount:=v_FamilyPhoneUseSamePosCount+v_Count;

          elsif phone_depository.relationship='others' then

              --其他联系人电话在最近180天被其他不同的客户用作其他所有电话（办公电话除外）的次数
              select count(distinct(id_credit||contact_value)) into v_Count from v_phone_depository
              where contact_value=phone_depository.contact_value and id_person!=v_IdPerson and commit_time>=sysdate-180 and commit_time<=v_CommitTime and status not in('t','r');
              v_OtherPhoneUseCount:=v_OtherPhoneUseCount+v_Count;

              v_Seq:=v_Seq + 1;

              --其他联系人电话在过去30天在同个城市被其他人重复使用的情况；状态不等于tr的次数
              select count(distinct(id_credit||contact_value)) into v_Count from v_phone_depository
              where contact_value=phone_depository.contact_value and id_person!=v_IdPerson and commit_time>=sysdate-30 and commit_time<=v_CommitTime and status not in('t','r') and city=phone_depository.city;
              v_OtherPhoneUseSameCityCount:=v_OtherPhoneUseSameCityCount+v_Count;

              v_Seq:=v_Seq + 1;

              --其他联系人电话在过去30天在同个门店被其他人重复使用的情况；状态不等于tr的次数
              select count(distinct(id_credit||contact_value)) into v_Count from v_phone_depository
              where contact_value=phone_depository.contact_value and id_person!=v_IdPerson and commit_time>=sysdate-30 and commit_time<=v_CommitTime and status not in('t','r') and id_sellerplace=phone_depository.id_sellerplace;
              v_OtherPhoneUseSamePosCount:=v_OtherPhoneUseSamePosCount+v_Count;

              v_Seq:=v_Seq + 1;

          end if;

       end loop;

       --家庭成员电话在最近180天被其他不同的客户用作其他所有电话（办公电话除外）总的次数
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            values(p_IdCredit,'HardCheck','*','FamilyPhoneUseCount',v_FamilyPhoneUseCount,v_Seq+1);

       v_Seq:=v_Seq + 1;

       --家庭成员电话在过去30天在同个城市被其他人重复使用的情况；状态不等于tr（办公电话除外）总的次数
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            values(p_IdCredit,'HardCheck','*','FamilyPhoneUseSameCityCount',v_FamilyPhoneUseSameCityCount,v_Seq+1);

       v_Seq:=v_Seq + 1;

       --家庭成员电话在过去30天在同个门店被其他人重复使用的情况；状态不等于tr（办公电话除外）总的次数
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            values(p_IdCredit,'HardCheck','*','FamilyPhoneUseSamePosCount',v_FamilyPhoneUseSamePosCount,v_Seq+1);

       v_Seq:=v_Seq + 1;

       --其他联系人电话在最近180天被其他不同的客户用作其他所有电话（办公电话除外）总的次数
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            values(p_IdCredit,'HardCheck','*','OtherPhoneUseCount',v_OtherPhoneUseCount,v_Seq+1);

       v_Seq:=v_Seq + 1;

       --其他联系人电话在过去30天在同个城市被其他人重复使用的情况；状态不等于tr（办公电话除外）总的次数
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            values(p_IdCredit,'HardCheck','*','OtherPhoneUseSameCityCount',v_OtherPhoneUseSameCityCount,v_Seq+1);

       v_Seq:=v_Seq + 1;

       --其他联系人电话在过去30天在同个门店被其他人重复使用的情况；状态不等于tr（办公电话除外）总的次数
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            values(p_IdCredit,'HardCheck','*','OtherPhoneUseSamePosCount',v_OtherPhoneUseSamePosCount,v_Seq+1);

       v_Seq:=v_Seq + 1;

       --此门店历史上通过的合同数量
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         select p_IdCredit,'HardCheck','*','SumApprovedSamePos',count(1),v_Seq+1 from cs_credit
           where id_person!=v_IdPerson and commit_time<v_CommitTime and status in('a','b','m','n','y','k','p') and id_sellerplace=v_IdSellerplace;

       v_Seq:=v_Seq + 1;

       --客户办公电话在过去30天在同个城市被其他人重复使用为办公电话的情况；状态不等于tr，总的次数
       if nvl(v_IdSellerPlace,0) =0
       then

         select count(1) into v_Count from cs_address where id_credit=p_IdCredit and address_type=2;

         if v_Count >0
         then

           select city into v_UseCity  from cs_address where id_credit=p_IdCredit and address_type=2 and rownum=1;

         end if;

       end if;

       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'HardCheck','*','OffPhoneUseSameCityCount',count(distinct a.id),v_Seq+1 from cs_credit a,cs_contact b,sellerplace c,cs_address ad
         where a.id=b.id_credit(+) and a.id_sellerplace=c.id(+) and b.contact_type='3' and a.id_person!=v_IdPerson
         and a.id=ad.id_credit(+) and ad.address_type=2
         and a.status not in('t','r') and a.commit_time>=sysdate-30  and a.commit_time<=v_CommitTime
         and b.contact_value=nvl(v_OfficeTel,'#') and nvl(c.city,ad.city)=v_UseCity;
       --and b.contact_value in(select t.contact_value from cs_contact t where t.contact_type='3' and t.id_credit=p_IdCredit) and c.city=v_UseCity;

       v_Seq:=v_Seq + 1;

       --客户办公电话在过去30天在同个门店被其他人重复使用为办公电话的情况；状态不等于tr,总的次数
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         select p_IdCredit,'HardCheck','*','OffPhoneUseSamePosCount',count(1),v_Seq+1 from cs_credit a,cs_contact b,sellerplace c
           where a.id=b.id_credit(+) and a.id_sellerplace=c.id(+) and b.contact_type='3' and a.id_person!=v_IdPerson
           and a.status not in('t','r') and a.commit_time>=sysdate-30  and commit_time<=v_CommitTime
           and b.contact_value=nvl(v_OfficeTel,'#') and a.id_sellerplace=v_IdSellerplace;
           --in(select t.contact_value from cs_contact t where t.contact_type='3' and t.id_credit=p_IdCredit)

       v_Seq:=v_Seq + 1;

       --客户此合同一共提供了多少个电话
       select count(1) into v_Count from cs_contact where contact_type in ('2','3','18','19') and id_credit=p_IdCredit;
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            values(p_IdCredit,'HardCheck','*','TotalPhoneCount',v_Count,v_Seq+1);

       v_Seq:=v_Seq + 1;

       --一共提供了多少个家庭联系人电话
       select count(1) into v_Count from cs_contact
       where person_type in(select reg_val_code from registers t where reg_number=265 and status='a' and reg_val_code!='1') and contact_type in('2','3','18','19') and id_credit=p_IdCredit;
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            values(p_IdCredit,'HardCheck','*','TotalFamilyPhoneCount',v_Count,v_Seq+1);

       v_Seq:=v_Seq + 1;

       --一共提供了多少个其他联系人电话
       select count(1) into v_Count from cs_contact
       where person_type in(select reg_val_code from registers t where reg_number=396 and status='a') and contact_type in('2','3','18','19') and id_credit=p_IdCredit;
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            values(p_IdCredit,'HardCheck','*','TotalOtherPhoneCount',v_Count,v_Seq+1);

       v_Seq:=v_Seq + 1;

       --一共提供了多少个家庭联系人电话和其他联系人中亲人的电话
       select count(1) into v_Count from cs_contact a
       where a.contact_type in(2,3,18,19)
        and a.person_type!='1'
        and (a.person_type in('BA','BB','BC','SA','SB','SC','5A','5B','5C')
            or a.person_type in(select reg_val_code from registers b where b.reg_number=265))
        and a.id_credit=p_IdCredit;

       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            values(p_IdCredit,'HardCheck','*','TotalRelativePhoneCount',v_Count,v_Seq+1);

       v_Seq:=v_Seq + 1;

       if v_CreditType='SS' then
         --2016/12/02 wangxiaofeng 在hardcheck类别添加元素IsFpd10SamePhoneLast6M
         --客户在申请合同时，客户号码（不包含办公电话号码）在过去6个月被其他申请人使用时是否出现fpd10 逾期
         insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         select p_IdCredit,'HardCheck','*','IsFpd10SamePhoneLast6M',decode(nvl(sum(m.fpd10),0),0,0,1),v_Seq+1
         from v_phone_depository a
         join mv_df_pd_sum_gl m on m.contract_no=a.contract_no
         where a.credit_type='SS' and a.status in('a','p','k')
         and a.contact_type in('2','18','19') and a.commit_time>=trunc(sysdate-180)
         and a.contact_value in(select b.contact_value from cs_contact b where b.contact_type in('2','18','19') and b.id_credit=p_IdCredit);
         v_Seq:=v_Seq + 1;

       end if;

       --2016/12/13 wangxiaofeng 在HardCheck类别里添加元素系统提单查询SysNciic结果
       for c in(select decode(t.result,null,'无法访问',t.result) results from cs_nciic_data t
                where t.local_flag in(0,1) and t.event_name=0 and t.id_credit=p_IdCredit and rownum=1
        )loop

          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            values(p_IdCredit,'HardCheck','*','SysNciicResult',trim(c.results),v_Seq+1);

          v_Seq:=v_Seq + 1;

        end loop;

       --2016/12/02 wangxiaofeng 在HardCheck类别里添加元素MYST_LEVEL暗访人员级别
       for c in(select t.approve from mv_whitelist_myst_inve t
         where trim(status)='a' and t.ident=v_Ident and rownum=1
        )loop

          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            values(p_IdCredit,'HardCheck','*','MYST_LEVEL',c.approve,v_Seq+1);

          v_Seq:=v_Seq + 1;

        end loop;

       --在HardCheck类别下面添加元素InterCodeRateSamePos。同一个门店再过去90天的内部代码(3,4)占总申请量的比率，status not in（‘t’,‘r’）;
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'HardCheck','*','InterCodeRateSamePos',round(nvl(sum(decode(t.inter_code,3,1,4,1,0)),0)/decode(count(1),0,1,count(1)),6),v_Seq+1
       from cs_credit t
       where t.status not in('t','r') and t.commit_time>=trunc(sysdate-90) and t.commit_time<=v_CommitTime and t.id_sellerplace=v_IdSellerPlace;

       v_Seq:=v_Seq + 1;

       --在Credit类别下面添加元素SaFirstAppDate 销售第一张申请合同的时间，status not in（‘t’,‘r’）
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'Credit','*','SaFirstAppDate',to_char(min(t.commit_time),'yyyy-MM-dd'),v_Seq+1
       from cs_credit t where t.status not in('t','r') and t.id_sa=v_IdSa;

       v_Seq:=v_Seq + 1;

       --是否属于销售白名单SAWhiteList 2015/12/29 wangxiaofeng
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'Credit','*','SAWhiteList',decode(count(1),0,0,1),v_Seq+1
       from mv_df_uw_sa_whitelist t
       where t.status=1 and (case_type='UW' or (case_type<>'UW' and trunc(sysdate) between start_date and end_date)) and t.sa_id=v_IdSa;

       v_Seq:=v_Seq + 1;

       --同一个销售本月使用的特殊代码合同数量SumSpecialSameSALast1M(本月内部代码 =12的数量，status not in('t','r') 2015/12/29 wangxiaofeng
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'Credit','*','SumSpecialSameSALast1M',count(1),v_Seq+1
       from cs_credit t
       where t.status not in('t','r') and t.inter_code='12'
       and t.commit_time between trunc(sysdate,'mm') and trunc(sysdate+31,'mm') and t.id_sa=v_IdSa;

       v_Seq:=v_Seq + 1;

       --同一年龄下在过去3个月（<90天）的QQ平均长度
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'HardCheck','*','Last3MonthQQAvgLen',round(nvl(sum(qq_length),0)/decode(count(1),0,1,count(1)),4),v_Seq+1
       from mv_qq_length t where t.birth_year=substr(v_Ident,7,4);

       --同一年龄下在过去1个月（<30天）的QQ平均长度 2016/07/07 wangxiaofeng
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'HardCheck','*','Last1MonthQQAvgLen',round(nvl(sum(qq_length),0)/decode(count(1),0,1,count(1)),4),v_Seq+1
       from mv_qq_length_30 t where t.birth_year=substr(v_Ident,7,4);

       v_Seq:=v_Seq + 1;

       --客户本人手机号码所属城市
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'Other','*','PhoneNoCity',nvl(max(a.city),'null'),v_Seq+1
       from mv_df_phone_attribution_gl a where a.mobilenumber=substr(v_PersonMobile,1,7);
       --(select substr(contact_value,1,7) from cs_contact t where t.id_credit=p_IdCredit and t.person_type = '1' and t.contact_type='2');

       v_Seq:=v_Seq + 1;

       --FirstTmDate 客户首次电销时间,排除无接通和转接的情况 ,包括inbound和outbound 2016/05/04
       select count(1) into v_Count from tm_outbound_call_result t
       where t.call_result not in (5,6,7,10,11) and t.id_person=v_IdPerson;

       if v_Count>=1 then

         insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         select p_IdCredit,'Other','*','FirstTmDate',to_char(min(update_time),'yyyy-MM-dd HH24:mi:ss'),v_Seq+1
         from tm_outbound_call_result t
         where t.call_result not in (5,6,7,10,11) and t.id_person=v_IdPerson;

       end if;

       v_Count:=0;

       v_Seq:=v_Seq + 1;

       --该客户上一单拒绝原因
       select nvl(max(id),0) into v_IdCredit from cs_credit t where id_person=v_IdPerson and t.id!=p_IdCredit and t.status='d';

       if v_IdCredit!=0 then

         insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         select p_IdCredit,'HardCheck','*','PreRejectReason',case when c.event is null then fun_get_reject_reason(a.id) else replace(replace(fun_getreg_value(779,nvl(c.event,-1)),'[',''),']','') end,v_Seq+1
         from cs_credit a,wfi_final_decision c where a.id=c.id_credit(+) and a.id=v_IdCredit;

       end if;

       v_Seq:=v_Seq + 1;

       --HardCheck.Last1wAmountRate------贷款金额与同类商品过去7天平均贷款金额比值  2018-04-18  yangzhenxian
       if v_CreditType ='SS'
       then

        for d in (
            with base as--获取一周内(不含当天)的合同，包括当前合同
            (
            select id,commit_time,credit_amount from cs_credit cc where cc.status not in('t','r')
            and cc.id_sa not in ('800079','888888','300079') and cc.credit_type='SS'
            and cc.commit_time>=trunc(v_CommitTime-8) and cc.commit_time<trunc(v_CommitTime)
            union
            select id,commit_time,credit_amount from cs_credit where id=p_IdCredit
            ),
            new_base as--商品类目
            (
              select id,commit_time,min(goods_category_new) goods_category_new,credit_amount from
              (
                select cc.id,trunc(cc.commit_time) commit_time
                ,case when gc.name='手机' and (producer like '%苹果%' or upper(producer) like '%APPLE%' or upper(producer) like '%IPHONE%') then '1苹果'
                                  when gc.name='手机' then '2手机' when gc.name='电脑' then '3电脑' when gc.name='摩托车' then '4摩托车'
                                     when gc.name='电动车' then '5电动车'when gc.name='医美' then '6医美' else '7其他' end as goods_category_new
                ,cc.credit_amount
                from base cc
                join cs_goods cg on cc.id=cg.id_credit
                join goods_category gc on cg.id_goods_category =gc.id
              )
              group by id,commit_time ,credit_amount
            )

            select round(credit_amount/(select avg(v_before.credit_amount) from new_base v_before
            where v_before.id<>p_IdCredit and v_before.goods_category_new=cur.goods_category_new)--前一周的合同
            ,2) Last1mAmountRate
            from new_base cur where cur.id=p_IdCredit--当前合同
          )loop

          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
           values( p_IdCredit,'HardCheck','*','Last1mAmountRate',d.Last1mAmountRate,v_Seq+1 );

          v_Seq:=v_Seq + 1;

          end loop;

          /*
            SA_L3M_MAX_1D_RATIO(SA名下单量近3个月CPD大于0的合同数/SA名下单量近3个月需要还款的合同数)
            SA_L6M_CPD0_RATIO(SA名下单近6个月CPD为0的还款次数/SA名下单近6个月需要还款的次数)                         yangzhenxian   2018-10-30
          */

          for d in (
              with sa_list as
              (
              select c.id_sa,
                     c.id,
                     c.contract_no
              from cs_credit c
              where c.credit_type = 'SS' and c.id_sa=v_IdSa
              and c.status in ('a','p','k')
              and c.commit_time <= TRUNC(SYSDATE)
              )

              select sa.id_sa,
                     decode(count(distinct case when d.date_due>=add_months(TRUNC(SYSDATE),-6) then d.contract_no||d.date_due else null end),0,null,
                     count(distinct case when d.date_due>=add_months(TRUNC(SYSDATE),-6) and d.max_cpd = 0 then d.contract_no||d.date_due else null end)/
                     count(distinct case when d.date_due>=add_months(TRUNC(SYSDATE),-6) then d.contract_no||d.date_due else null end)
                     ) AS SA_L6M_CPD0_RATIO,
                     decode(count(distinct case when d.date_due>=add_months(TRUNC(SYSDATE),-3) then d.contract_no else null end),0,null,
                     count(distinct case when d.date_due>=add_months(TRUNC(SYSDATE),-3) and d.max_cpd > 0 then d.contract_no else null end)/
                     count(distinct case when d.date_due>=add_months(TRUNC(SYSDATE),-3) then d.contract_no else null end)
                     ) AS SA_L3M_MAX_1D_RATIO
              from df_pd_detail_gl d
              join sa_list sa on d.id_credit = sa.id
              where d.date_due < trunc(sysdate)
              and trunc(sysdate) < d.date_due+180
              and d.credit_type='SS'
              group by sa.id_sa
              order by 2
            )loop

            if d.sa_l3m_max_1d_ratio is not null then
              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values( p_IdCredit,'HardCheck','*','SA_L3M_MAX_1D_RATIO',round(d.sa_l3m_max_1d_ratio,3),v_Seq+1 );

              v_Seq:=v_Seq + 1;

            end if;

            if d.sa_l6m_cpd0_ratio is not null then

              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values( p_IdCredit,'HardCheck','*','SA_L6M_CPD0_RATIO',round(d.sa_l6m_cpd0_ratio,3),v_Seq+1 );

              v_Seq:=v_Seq + 1;

            end if;

          end loop;

        end if;

        /*自动查询sys_face_result人脸识别结果和sys_citizen_result二要素验证结果  yangzhenxian  2018-11-06*/
        for d in (
          select
          min(case when sys_citizen_result_text='一致' then '1一致'
               when sys_citizen_result_text in ('库中无此号','不一致') then '2不一致'
               when sys_citizen_result_text='无法确定' then '3无法确定' else '4请求异常' end ) as sys_citizen_result
          ,min(case when sys_face_result_text='一致' then '1一致'
                when sys_face_result_text='不一致' then '2不一致'
                when sys_face_result_text='库中无照片' then '3库中无照片' else '4请求异常' end ) as sys_face_result
          from liveness_ident_verify a
          where local_flag=0 and id_credit=p_IdCredit
        )loop

        if d.sys_citizen_result is not null then
            insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'HardCheck','*','SysCitizenResult',d.sys_citizen_result,v_Seq+1 );

            v_Seq:=v_Seq + 1;

        end if;
        if d.sys_face_result is not null then

            insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'HardCheck','*','SysFaceResult',d.sys_face_result,v_Seq+1 );

            v_Seq:=v_Seq + 1;

        end if;

      end loop;

      /*yangzhenxian  2019-03-08*/
      for d in (
          with base as(
          select cs.contract_no as contract_rece,cs.id as id_credit_rece
          ,row_number()over(partition by cs.id_person order by cs.commit_time desc)as ranking
          from cs_credit cs where cs.id_person=v_IdPerson and cs.commit_time<v_CommitTime and cs.status in ('a','p','k') and cs.credit_type in ('SS','SC')
          )
          select MAX(b.prefraudscorecate ) PrefraudscorecateOnce
          ,round(decode(sum(case when cpd=0 then 1 else 0 end),0,-1,
                 sum(case when max_cpd=0 then 1 else 0 end)/sum(case when cpd=0 then 1 else 0 end))
          ,4)  PaidOnRatioSssc
          from base s
          left join df_pd_detail_gl p on s.contract_rece=p.CONTRACT_NO and p.date_due<v_CommitTime
          left join mv_df_uw_info_gl b on s.id_credit_rece=b.id and s.ranking=1

        )loop

            /*HardCheck.*.MaxPrevSSSC_Scorecate：前一张单的scorecate*/
            insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'HardCheck','*','MaxPrevSSSC_Scorecate',d.PrefraudscorecateOnce,v_Seq+1 );

            v_Seq:=v_Seq + 1;

            /*HardCheck.*.PaidOnRatioSssc:按时还款期数占已还款期数的比例*/
            insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'HardCheck','*','PaidOnRatioSssc',d.PaidOnRatioSssc,v_Seq+1 );

            v_Seq:=v_Seq + 1;

        end loop;

        -------------------------------majianfeng 2019-09-12  -------------------------------
        for hard_credit in(
              select c.id,c.id_person,c.contract_no,c.COMMIT_TIME,max(pc.id) as id_credit_ss,max(pc.contract_no) as contract_no_ss
            from cs_credit c
            join cs_credit pc on c.ID_PERSON=pc.ID_PERSON and pc.credit_type IN ('SS','XF')--获取前一张SS合同（pc.credit_type in ('SS') 修改为 pc.credit_type in('SS','XF')）
                and pc.status in ('a','p','k') and pc.COMMIT_TIME<c.COMMIT_TIME
            where c.credit_type in（'SC','CY'） and c.id=p_IdCredit
            group by c.id,c.id_person,c.contract_no,c.COMMIT_TIME
          )
         loop

            ---客户申请此合同时前面一张消费贷通过的合同的产品类型
            insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            select p_IdCredit,'HardCheck','*','MaxPrevSSProducer', max(g.PRODUCER) ,v_Seq+1
            from
            cs_goods g WHERE  hard_credit.id_credit_ss=g.ID_CREDIT;

            v_Seq:=v_Seq + 1;

            ---客户申请此合同时前面一张消费贷通过的合同的申请小时
            insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            select p_IdCredit,'HardCheck','*','MaxPrevSSHour',to_number(to_char(c.commit_time,'hh24')),v_Seq+1
            from  cs_credit c  WHERE hard_credit.id_credit_ss=c.id;

            v_Seq:=v_Seq + 1;

            ---客户申请此合同前面一张消费贷申请后6个月内和客服联系次数
            insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            select
            p_IdCredit,'HardCheck','*','MaxPrevSSCSCnt6M',nvl(sum(case when months_between(ce.update_time,pc.COMMIT_TIME) between 0.01 and 6 then 1 else null end),0) ,v_Seq+1
            from cs_credit pc
            join cus_consult_event_info ce on to_char(hard_credit.contract_no_ss)=ce.CONTRACT_NO and hard_credit.commit_time>ce.UPDATE_TIME
            join cus_consult_event_config ec on ec.id=to_char(ce.consult_event_id)
            WHERE  hard_credit.id_credit_ss=pc.id ;

            v_Seq:=v_Seq + 1;

            ---客户申请此合同时前面一张消费贷通过的合同的民族
            insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            select
            p_IdCredit,'HardCheck','*','MaxPrevSSNational', max(p.NATIONAL),v_Seq+1
            from  cs_person p WHERE  hard_credit.id_person=p.id ;

            v_Seq:=v_Seq + 1;

            ------客户申请此合同时前面一张消费贷通过的合同的maxcpd
            insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            select
            p_IdCredit,'HardCheck','*','MaxPrevSSMaxcpd',max(p.max_cpd),v_Seq+1
            from df_pd_sum_gl p WHERE  hard_credit.contract_no_ss=p.contract_no;

            v_Seq:=v_Seq + 1;

            ------客户申请此合同时前面一张消费贷通过的合同是否使用微信还款
            insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            select
            p_IdCredit,'HardCheck','*','MaxPrevSSPayWXCnt',max(instr(p.trans_type,'w')),v_Seq+1
            from instalment it
            join payinstalment pt  on it.id=pt.ID_INSTALMENT and pt.STATUS='a'
            join payin p on pt.ID_PAYIN=p.ID and p.status ='a'
            where  it.ID_CREDIT=hard_credit.id_credit_ss and  it.STATUS='a' and it.TYPE_INSTALMENT=1 AND p.date_pay<hard_credit.COMMIT_TIME;

            v_Seq:=v_Seq + 1;

            ---客户申请此合同时前面一张消费贷通过的合同的住房情况
            insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            select
            p_IdCredit,'HardCheck','*','MaxPrevSSHouseType',max(f.HOUSE_TYPE),v_Seq+1
            from  cs_family_info f  WHERE  hard_credit.id_credit_ss=f.ID_CREDIT;

            v_Seq:=v_Seq + 1;

            ---客户申请此合同时前面一张消费贷通过的合同的婚姻状况
            insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            select
            p_IdCredit,'HardCheck','*','MaxPrevSSMarrige',max(f.ID_SPOUSE),v_Seq+1
            from cs_family_info f WHERE  hard_credit.id_credit_ss=f.ID_CREDIT;

            v_Seq:=v_Seq + 1;

         end loop;

        ---客户最近一次电销时间
        select count(1) into v_Count from
        cs_credit c
        join tm_outbound_call_result r on  c.id_person=r.id_person and c.COMMIT_TIME>r.UPDATE_TIME
        where r.call_result not in (5,6,7,10,11)--排除无接通和转接的情况  电销call_result 查看tm_outbound_result_combox 电销结果字典表的 COMBOX_RESULT
        and c.id=p_IdCredit;

        if v_Count>=1 then

          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
          select p_IdCredit,'HardCheck','*','MaxTmDate',to_char(max(r.update_time),'yyyy-MM-dd HH24:mi:ss') ,v_Seq+1
          from cs_credit c
          join tm_outbound_call_result r on  c.id_person=r.id_person and c.COMMIT_TIME>r.UPDATE_TIME
          where r.call_result not in (5,6,7,10,11)--排除无接通和转接的情况  电销call_result 查看tm_outbound_result_combox 电销结果字典表的 COMBOX_RESULT
          and c.id=p_IdCredit;

          v_Seq:=v_Seq + 1;

        end if;

        v_Count:=0;

        /*-----客户在申请此合同时通过状态的合同数量（合同贷款类型为SS，SC，CY状态为a/k/p）*/
        insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
        select
          p_IdCredit,'HardCheck','*','SumPassContractSSSCCY',
        count(distinct case when pc.status in ('a','p','k') then pc.ID else null end) ,v_Seq+1
        from cs_credit c
        join (select id_person,id,status,credit_type,COMMIT_TIME
        from cs_credit
        where credit_type in ('SS','SC','CY','XF') and status in ('a','p','k')--获取前一张合同（credit_type in ('SS','SC','CY') 修改为 credit_type in('SS','SC','CY','XF')）
        union
        select id_person,id,status,credit_type,app_date as COMMIT_TIME
        from cycle_credit c
        where credit_type in ('SS','SC','CY','XF') and status in ('a','p','k')) pc on c.ID_PERSON=pc.ID_PERSON and pc.COMMIT_TIME<c.COMMIT_TIME--获取前一张合同（credit_type in ('SS','SC','CY') 修改为 credit_type in('SS','SC','CY','XF')）
         and  c.id=p_IdCredit;

        v_Seq:=v_Seq + 1;

       -- hongbinbin 20190923
        for d in(
           select c.id,c.id_person,c.contract_no,c.commit_time , max(pc2.ID) as id_credit_sssc, max(pc2.contract_no) as contract_no_sssc, max(pc2.COMMIT_TIME) as commit_time_sssc
            from cs_credit c
            join cs_credit pc2 on c.id_person=pc2.id_person and pc2.credit_type in ('SS','SC','XF') and pc2.status in ('a','p','k') and pc2.commit_time<c.commit_time   --获取前一张SSSC合同（a.credit_type in ('SS','SC') 修改为 a.credit_type in('SS','SC','XF')）
            where c.credit_type in ('SC','CY') and c.id=p_IdCredit
            group by c.id,c.id_person,c.contract_no,c.commit_time
        )
        loop
            ---MaxPrevSsScCSCnt3M---客户申请此合同前面一张SSSC申请后3个月内和客服联系次数
            for f in(
              select sum(case when months_between(ce.update_time,d.commit_time_sssc) between 0.01 and 3 then 1 else 0 end) as MaxPrevSsScCSCnt3M,
              sum(case when months_between(ce.update_time,d.commit_time_sssc) between 0.01 and 6 then 1 else 0 end) as MaxPrevSsScCSCnt6M
              from  cus_consult_event_info ce where to_char(d.contract_no_sssc)=ce.CONTRACT_NO and d.commit_time>ce.UPDATE_TIME
            )
            loop
              ---客户申请此合同前面一张SSSC申请后3个月内和客服联系次数
               insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values(p_IdCredit,'HardCheck','*','MaxPrevSsScCSCnt3M',f.MaxPrevSsScCSCnt3M,v_Seq+1);

               ---客户申请此合同前面一张SSSC申请后6个月内和客服联系次数
               insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values(p_IdCredit,'HardCheck','*','MaxPrevSsScCSCnt6M',f.MaxPrevSsScCSCnt6M,v_Seq+2);
               v_Seq:=v_Seq + 2;

            end loop;


            --MaxPrevSSSCPayWXCnt --客户申请此合同时前面一张消费贷交叉现金贷通过的合同是否使用微信还款
            insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            select p_IdCredit, 'HardCheck','*','MaxPrevSSSCPayWXCnt', max(instr(p.trans_type,'w'))  as MaxPrevSSSCPayWXCnt, --客户申请此合同时前面一张消费贷交叉现金贷通过的合同是否使用微信还款
             v_Seq+1
            from instalment it      --最近一单还款情况
            join payinstalment pt  on it.id=pt.ID_INSTALMENT and pt.STATUS='a'
            join payin p on pt.ID_PAYIN=p.ID and p.status ='a'
            where it.STATUS='a' and it.TYPE_INSTALMENT=1 AND p.date_pay<d.commit_time and it.ID_CREDIT=d.id_credit_sssc;
            v_Seq:=v_Seq + 1;

            --MaxPrevSSSCMaxcpd  --客户申请此合同时前面一张消费贷交叉现金贷通过的合同的maxcpd
            insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            select  p_IdCredit, 'HardCheck','*','MaxPrevSSSCMaxcpd',
            max(p.max_cpd) as MaxPrevSSSCMaxcpd , --客户申请此合同时前面一张消费贷交叉现金贷通过的合同的maxcpd
             v_Seq+1
            from  df_pd_sum_gl p
            where d.contract_no_sssc=p.contract_no;
            v_Seq:=v_Seq + 1;

        end loop;

        for d in(
            select c.id,c.id_person,c.contract_no,c.COMMIT_TIME,max(pc.id) as id_credit_ss,max(pc.contract_no) as contract_no_ss
                     ,max(sc.id) as id_credit_sc,max(sc.contract_no) as contract_no_sc
                     ,max(rece.id) as id_credit_rece,max(rece.contract_no) as contract_no_rece
                     ,max(MAX_AMOUNT) as max_amount
              from cs_credit c
              left join cs_credit pc on c.ID_PERSON=pc.ID_PERSON and pc.credit_type in('SS','XF') and pc.status in ('a','p','k') and pc.COMMIT_TIME<c.COMMIT_TIME--获取前一张SS合同（pc.credit_type in ('SS') 修改为 pc.credit_type in('SS','XF')）
              left join cs_credit sc on c.ID_PERSON=sc.ID_PERSON and sc.credit_type='SC' and sc.status in ('a','p','k') and sc.COMMIT_TIME<c.COMMIT_TIME
              left join cs_credit rece on c.ID_PERSON=rece.ID_PERSON and rece.credit_type in ('SC','SS','XF') and rece.status in ('a','p','k') and rece.COMMIT_TIME<c.COMMIT_TIME--获取前一张SSSC合同（rece.credit_type in ('SS','SC') 修改为 rece.credit_type in('SS','SC','XF')）
              left join cross_active_detail cad on cad.id_person = sc.id_person
              left join cross_active_list cal on cal.ACTIVE_ID = cad.ACTIVE_ID and trunc(sc.app_date) between cal.start_date and cal.end_date
              where c.credit_type='CY' and c.id = p_IdCredit
              group by c.id,c.id_person,c.contract_no,c.COMMIT_TIME
            )loop

                ------客户申请此合同时前面一张cy通过的合同的maxcpd
                insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                select  p_IdCredit, 'HardCheck','*','MaxPrevCYMaxcpd',
                max(nvl(p1.max_cpd,0)) as MaxPrevCYMaxcpd, --客户申请此合同时前面一张循环现金贷贷通过的合同的maxcpd
                v_Seq+1
                from cycle_credit f
                join df_pd_sum_gl p1 on f.contract_no=p1.CONTRACT_NO and f.credit_type='CY'    ---取出所有CY
                           where d.id_person=f.ID_PERSON AND d.COMMIT_TIME>f.app_date;

                v_Seq:=v_Seq + 1;

                ---3.SC额度使用率（包含前置）
                insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                select p_IdCredit, 'HardCheck','*','CALimitRateSC'
                 ,pc.CREDIT_AMOUNT/nullif(d.max_amount,0) AS CALimitRateSC,--客户申请此合同时前面一张交叉现金贷的额度使用率
                 v_Seq+1
                from cs_credit pc where d.id_credit_sc=pc.id;

                v_Seq:=v_Seq + 1;

                ---7.催收数据
                insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                select p_IdCredit, 'HardCheck','*','MaxPrevCollMon'
                ,max(case when d.commit_time>s.update_time then ceil(months_between(d.commit_time,trunc(s.update_time))) else null end)
                as MaxPrevCollMon, --最近一次催收月份
                v_Seq+1
                from collection_call s  where  d.id_person=s.id_person and d.commit_time> s.update_time
                and s.status = 1; --有效的call

                v_Seq:=v_Seq + 1;

            end loop;

          --CYIsER---是否为循环现金贷ER客户
          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
          select p_IdCredit,'Cycle','*','CYIsER',case when e.ID_PERSON is not null then 1 else 0 end as CYIsER,---是否为循环现金贷ER客户
          v_Seq+1
          from cs_credit c
          left join giveu_credit_eligible e on c.id_person=e.ID_PERSON and e.CREDIT_CHANNEL='GIVEU' and e.CY_LIMIT_TYPE='ER'
          where c.CREDIT_TYPE='CY' and c.COMMIT_TIME>date'2019-06-01' and c.id=p_IdCredit;

          v_Seq:=v_Seq + 1;

          ---是否身份证过期的循环现金贷客户          2019-11-20                      update
          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
          select  p_IdCredit,'Cycle','*','CYIsExporedIDent'
          ,case when a.id_person is not null then (case when a.ident_exp<c.COMMIT_TIME  then  1 else 0 end )/*Log表数据*/
                 else (case when p.ident_exp<c.COMMIT_TIME then 1 else 0 end )/*person表数据*/ end  as CYIsExporedIDent , ---是否身份证过期的循环现金贷客户
          v_Seq+1
          from cs_credit c
          left join cs_person p on c.id_person=p.id
          left join (select a.*,row_number()over(partition  by id_person order by create_time desc) as rk from cs_person_trilog a)a on c.ID_PERSON=a.id_person and rk=1----取最新一条数据
          where c.CREDIT_TYPE='CY' and c.COMMIT_TIME>date'2019-06-01' and c.id=p_IdCredit;
          v_Seq:=v_Seq + 1;

          ---若距离上一次申请通过(a,p,k,i,aw)合同（SS，SC，CY，SQ）的时间间隔365天以上的客户
          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
          select  p_IdCredit,'Cycle','*','CYIsOutOneYear'
          ,case when rece.commit_time_rece is null then 1
                when trunc(c.COMMIT_TIME)-trunc(rece.commit_time_rece)>=365 then 1 else 0 end as CYIsOutOneYear, --若距离上一次申请通过(a,p,k,i,aw)合同（SS，SC，CY，SQ）的时间间隔365天以上的客户
          v_Seq + 1
          from cs_credit c
          left join (
          select c.ID_PERSON,max(c.COMMIT_TIME) as commit_time_rece
          from cs_credit c
          where c.CREDIT_TYPE in ('SS','SC','CY','SQ') and c.STATUS in ('a','p','k','i','aw')
          group by c.ID_PERSON
          ) rece on c.ID_PERSON=rece.ID_PERSON
          where c.CREDIT_TYPE='CY' and c.COMMIT_TIME>date'2019-06-01'and c.id=p_IdCredit;

          v_Seq:=v_Seq + 1;

       for cs_exp in(select t.total_wk_exp,t.is_ssi,t.insurance_fee from cs_experience t where t.id_credit=p_IdCredit)
         loop

           --是否购买保险
           insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
           values(p_IdCredit,'Other','*','IsInsurance',cs_exp.is_ssi,v_Seq+1);

           v_Seq:=v_Seq + 1;

           --保险费用
           insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
           values(p_IdCredit,'Credit','*','InsuranceFee',cs_exp.insurance_fee,v_Seq+1);

           v_Seq:=v_Seq + 1;

           --距离毕业时间/现公司工作时间（月）
           insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
           values(p_IdCredit,'Career','*','CurrentMonth',cs_exp.total_wk_exp,v_Seq+1);

           v_Seq:=v_Seq + 1;

       end loop;

       /*鲁长江   2015-6-9*/
       select count(1) into v_Count from wechat_credit_address where id_credit=p_IdCredit;

       if v_Count>0 then

          select current_address_city,current_city into v_CurrentAddressCity,v_CurrentCity
            from wechat_credit_address where rownum=1 and id_credit=p_IdCredit;

          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
           values(p_IdCredit,'Other','*','MobTrueCity',v_CurrentAddressCity,v_Seq+1);

          v_Seq:=v_Seq + 1;

          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
           values(p_IdCredit,'Other','*','MobSelectCity',v_CurrentCity,v_Seq+1);

           v_Seq:=v_Seq + 1;

       end if;

      /*合同对应的预审分支名称  yangzhenxian  2019-07-04*/
      for d in (
          with temp as(
          select element_value PreBranch from decision_element_pa_history where id_credit=p_IdCredit and element_type='preResult' and element_name='BranchName' order by create_time desc
           )
          select * from temp where rownum=1
        )loop

            insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'Other','*','PreBranch',d.PreBranch,v_Seq+1 );

            v_Seq:=v_Seq + 1;

        end loop;

         --hongbinbin 20191010
         insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         select p_IdCredit,'Other','*','CreditSource', credit_source as CreditSource, --即速用用户来源渠道
            v_Seq+1
         from jsy_credit_source where id_credit=p_IdCredit;

         v_Seq:=v_Seq + 1;

         for d in(
             select grant_contract_no from cs_credit_ext where id_credit=p_IdCredit
           )loop

            insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
              select p_IdCredit,'Other','*','SPCBranchName',
              max(case when element_type='preResult' and element_name='BranchName' then element_value end) as SPCBranchName,---SPC分支名字
              v_Seq+1
              from cs_credit c
              left join decision_element_data_history  pae on c.ID=pae.ID_CREDIT
              where c.credit_type='SPC' and c.CONTRACT_NO=d.grant_contract_no
              GROUP BY  c.ID,c.CONTRACT_NO;

              v_Seq:=v_Seq + 1;

           end loop;

         for huab in(select  credit_limit,usable_limit from (
                  select b.credit_limit,b.usable_limit from Cs_Credit a  left join external_fs_report_credit b on a.id=b.id_credit
                     where a.id=p_IdCredit  and b.credit_name = '花呗'  order by b.create_time desc )
                where rownum=1) loop

             --花呗授信额度 2018/07/23 majianfeng
             insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
              values(p_IdCredit,'External','FuShu','HbCreditLimit',huab.credit_limit,v_Seq+1);

             v_Seq:=v_Seq + 1;

           --花呗可用额度  2018/07/23 majianfeng
               insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                values(p_IdCredit,'External','FuShu','HbUsableLimit',huab.usable_limit,v_Seq+1);

              v_Seq:=v_Seq + 1;

           end loop;

          /*富数信用卡（主表）  yangzhenxian  2019-06-28*/
          for d in (
            select
            max(CARD_CREDIT_LINE/100)as CardLine--该银行下授信总额度
            ,max(CARD_CREDIT_LIMIT/100)as CardLimit --消费额度
            ,max(CARD_USABLE_CONSUME_LIMIT/100)as CardUsCsLimit--可用消费额度
            ,max(IS_OVERDUE)as Overdue--逾期用户
            from FS_BANK_CREDITS_BASIC a
            where id_credit=p_IdCredit
          )loop

              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values( p_IdCredit,'External','FuShu','CardLine',d.CardLine,v_Seq+1 );

               v_Seq:=v_Seq + 1;

              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values( p_IdCredit,'External','FuShu','CardLimit',d.CardLimit,v_Seq+1 );

               v_Seq:=v_Seq + 1;

              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values( p_IdCredit,'External','FuShu','CardUsCsLimit',d.CardUsCsLimit,v_Seq+1 );

               v_Seq:=v_Seq + 1;

              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values( p_IdCredit,'External','FuShu','Overdue',d.Overdue,v_Seq+1 );

               v_Seq:=v_Seq + 1;

          end loop;

            /*富数信用卡（主表）  yangzhenxian  2019-06-28*/
          for d in (
            with base as(
            select (case when id_credit is not null then 1 else 0 end) as IsCreditCard--是否信用卡客户
            from FS_BANK_CREDITS_BASIC cs where cs.id_credit=p_IdCredit
            )
            select * from base where rownum=1
          )loop

              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values( p_IdCredit,'External','FuShu','IsCreditCard',d.IsCreditCard,v_Seq+1 );

               v_Seq:=v_Seq + 1;

          end loop;

          /*富数网银-信用卡-近一年账单概况  yangzhenxian  2019-06-28*/
          for d in (
            select
            sum(TOTAL_OUTFLOW_TRADE_AMOUNT/100)as TotalOutTradeAmt--总消费金额
            ,sum(TOTAL_INFLOW_TRADE_AMOUNT/100)as TotalInTradeAmt--总还款金额
            from FS_BANK_CR_BILL_FLOW_STATS a
            where id_credit=p_IdCredit
          )loop

              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values( p_IdCredit,'External','FuShu','TotalOutTradeAmt',d.TotalOutTradeAmt,v_Seq+1 );

               v_Seq:=v_Seq + 1;

              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values( p_IdCredit,'External','FuShu','TotalInTradeAmt',d.TotalInTradeAmt,v_Seq+1 );

               v_Seq:=v_Seq + 1;
          end loop;

          /*富数网银-信用卡-流水概况  yangzhenxian  2019-06-28*/
          for d in (
            select
            max(case when AMOUNTS=12 then AMOUNT_AVERAGE_OUTFLOWS/100 else null end )as AmtAvgOutF12M--近12个月平均每笔消费额
            ,max(case when AMOUNTS=12 then AMOUNT_AVERAGEINFLOWS/100  else null end) as AmtAvgInF12M--近12个月平均每笔还款额
            from FS_BANK_CR_FLOW_STAT a
            where id_credit=p_IdCredit
          )loop

              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values( p_IdCredit,'External','FuShu','AmtAvgOutF12M',d.AmtAvgOutF12M,v_Seq+1 );

               v_Seq:=v_Seq + 1;

              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values( p_IdCredit,'External','FuShu','AmtAvgInF12M',d.AmtAvgInF12M,v_Seq+1 );

               v_Seq:=v_Seq + 1;

          end loop;

          /*富数网银-信用卡-已出账单流水概况  yangzhenxian  2019-06-28*/
          for d in (
            select
            sum(REPAY_FLOWS_AMOUNT/100) as TotalRepayFlowAmt--总实际还款金额
            ,max(MAX_TRADE_AMOUNT/100)as MaxTradeAmt--最大消费金额
            from FS_BANK_CR_READY_BILL_FLOWS a
            where id_credit=p_IdCredit
          )loop

              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values( p_IdCredit,'External','FuShu','TotalRepayFlowAmt',d.TotalRepayFlowAmt,v_Seq+1 );

               v_Seq:=v_Seq + 1;

              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values( p_IdCredit,'External','FuShu','MaxTradeAmt',d.MaxTradeAmt,v_Seq+1 );

               v_Seq:=v_Seq + 1;

          end loop;

          /*富数运营商：基础数据表    yangzhenxian   2019-07-03*/
          for d in (
            select
            max(FRIEND_CNT_3M)as FriendCnt3M--近3月朋友联系数量
            ,max(best_friend_cnt_3m)as BestFriendCnt3M---近3月好朋友联系数量（联系10次以上）
            ,max(friend_cnt_6m)as FriendCnt6M--近6月朋友联系数量
            ,max(best_friend_cnt_6m)as BestFriendCnt6M---近6月好朋友联系数量（联系10次以上）
            ,max(interphone_cnt_3m)as InterPhoneCnt3M--近3月互通电话号码数目
            ,max(interphone_cnt_6m)as InterPhoneCnt6M--近6月互通电话号码数目
            from fs_telecom_basic
            where id_credit=p_IdCredit
          )loop

              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values( p_IdCredit,'External','FuShu','FriendCnt3M',d.FriendCnt3M,v_Seq+1 );

               v_Seq:=v_Seq + 1;

              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values( p_IdCredit,'External','FuShu','BestFriendCnt3M',d.BestFriendCnt3M,v_Seq+1 );

               v_Seq:=v_Seq + 1;

              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values( p_IdCredit,'External','FuShu','FriendCnt6M',d.FriendCnt6M,v_Seq+1 );

               v_Seq:=v_Seq + 1;

              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values( p_IdCredit,'External','FuShu','BestFriendCnt6M',d.BestFriendCnt6M,v_Seq+1 );

               v_Seq:=v_Seq + 1;

              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values( p_IdCredit,'External','FuShu','InterPhoneCnt3M',d.InterPhoneCnt3M,v_Seq+1 );

               v_Seq:=v_Seq + 1;

              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values( p_IdCredit,'External','FuShu','InterPhoneCnt6M',d.InterPhoneCnt6M,v_Seq+1 );

               v_Seq:=v_Seq + 1;

          end loop;

          /*富数运营商：通话详详单分析    yangzhenxian   2019-07-03*/
          for d in (
            select count(distinct fc.phone)as ContactCount---联系人手机号在通话详单个数
            from  cs_contact cs
            left join FS_TELECOM_FREQUENT_CALLS fc  on cs.id_credit=fc.id_credit and cs.CONTACT_VALUE=fc.phone
            where cs.person_type != '1' and cs.id_credit=p_IdCredit
          )loop

              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values( p_IdCredit,'External','FuShu','ContactCount',d.ContactCount,v_Seq+1 );

               v_Seq:=v_Seq + 1;

          end loop;

          /*富数运营商：通话详详单分析    yangzhenxian   2019-07-03*/
          for d in (
            select count(distinct m.opposite)as Top3mCount---联系人手机号在联系人top3个数
            from cs_contact cs
            left join FS_TELECOM_TOP3_3M m on cs.id_credit=m.id_credit and cs.CONTACT_VALUE=m.opposite
            where cs.person_type != '1' and cs.id_credit=p_IdCredit
          )loop

              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values( p_IdCredit,'External','FuShu','Top3mCount',d.Top3mCount,v_Seq+1 );

               v_Seq:=v_Seq + 1;

          end loop;

          /*富数运营商：通话活跃     yangzhenxian   2019-07-03*/
          for d in (
            select max(case when PERIOD='1个月' then non_call_rate END)as NonCallRate1M--近一个月无通话天数占比
            ,max(case when PERIOD='1个月' then TOTAL_COUNT end)as TotalCount1M--近一个月通话次数
            ,max(case when PERIOD='1个月' then calling_num end)as CallingNum1M--近一个月主叫通话次数
            ,max(case when PERIOD='1个月' then call_number end)as CallNum1M--近一个月通话号码数
            ,max(case when PERIOD='3个月' then call_number end)as CallNum3M--近一个月通话号码数
            ,max(case when PERIOD='3个月' then interphone_rate end)as InterphoneRate--近一个月互通号码数占比
            ,max(case when PERIOD='1个月' then call_time end)as CallTimet1M--近一个月通话时长
            ,max(case when PERIOD='1个月' then CALLING_TIME end)as CallingTimet1M--近一个月主叫通话时长
            ,max(case when PERIOD='1个月' then call_active_day end)as CallActiveDay1M--近一个月通话活跃天数
            ,max(case when PERIOD='1个月' then morning_count end)as MorningCount1M--近一个月凌晨(0:00-6:00)通话次数
            from FS_TELECOM_PHONALYZR a
            where id_credit=p_IdCredit
          )loop

              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values( p_IdCredit,'External','FuShu','NonCallRate1M',d.NonCallRate1M,v_Seq+1 );

               v_Seq:=v_Seq + 1;

              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values( p_IdCredit,'External','FuShu','TotalCount1M',d.TotalCount1M,v_Seq+1 );

               v_Seq:=v_Seq + 1;

              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values( p_IdCredit,'External','FuShu','CallingNum1M',d.CallingNum1M,v_Seq+1 );

               v_Seq:=v_Seq + 1;

              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values( p_IdCredit,'External','FuShu','CallNum1M',d.CallNum1M,v_Seq+1 );

               v_Seq:=v_Seq + 1;

              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values( p_IdCredit,'External','FuShu','CallNum3M',d.CallNum3M,v_Seq+1 );

               v_Seq:=v_Seq + 1;

              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values( p_IdCredit,'External','FuShu','InterphoneRate',d.InterphoneRate,v_Seq+1 );

               v_Seq:=v_Seq + 1;

              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values( p_IdCredit,'External','FuShu','CallTimet1M',d.CallTimet1M,v_Seq+1 );

               v_Seq:=v_Seq + 1;

              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values( p_IdCredit,'External','FuShu','CallingTimet1M',d.CallingTimet1M,v_Seq+1 );

               v_Seq:=v_Seq + 1;

              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values( p_IdCredit,'External','FuShu','CallActiveDay1M',d.CallActiveDay1M,v_Seq+1 );

               v_Seq:=v_Seq + 1;

              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values( p_IdCredit,'External','FuShu','MorningCount1M',d.MorningCount1M,v_Seq+1 );

               v_Seq:=v_Seq + 1;
          end loop;

          /*富数运营商：用户位置分布     yangzhenxian  2019-07-03*/
          for d in (
              select min(rank) as CityRank--申请城市通话排名
              from (select id_credit,city,row_number()over(partition by id_credit order by days*1 desc)as rank from FS_TELECOM_POSITION) a
              join cs_address ca on a.id_credit=ca.ID_CREDIT  and ca.ADDRESS_TYPE=2 and replace(ca.CITY,'市','')=replace(a.CITY,'市','')
              where ca.id_credit=p_IdCredit
            )loop

                insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                 values( p_IdCredit,'External','FuShu','CityRank',d.CityRank,v_Seq+1 );

                 v_Seq:=v_Seq + 1;

            end loop;

          /*富数运营商：账单数据     yangzhenxian  2019-07-03*/
          for d in (
              select min(a.pay_amount/100) as MinPayAmount --过去三个月最小账单金额
              from FS_TELECOM_BILL_ANALYSIS a
              where  to_date(month||'01','yyyy-mm-dd')>=add_months(trunc(sysdate,'mm'),-3) and id_credit=p_IdCredit
            )loop

                insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                 values( p_IdCredit,'External','FuShu','MinPayAmount',d.MinPayAmount,v_Seq+1 );

                 v_Seq:=v_Seq + 1;

            end loop;

            /*富数运营商：通话详详单分析     yangzhenxian    2019-07-03*/
            for d in (
              select max(nvl(call_count_l3m,0)) as FriendCallCountL3m--2个联系人中任意1人近3月最大联系次数
              ,max(nvl(call_count_l6m,0)) as FriendCallCountL6m--2个联系人中任意1人近6月最大联系次数
              ,min(case when person_type in ('F','M','P')and  a.ID_CREDIT is null then 0 else call_count_l6m *1 end) as ParentCallCountL6m--父母近6个月最小联系次数
              from cs_contact cc
              left join FS_TELECOM_FREQUENT_CALLS  a on a.ID_CREDIT=cc.id_credit and cc.CONTACT_VALUE=a.phone
              where  cc.CONTACT_TYPE=2 and person_type<>'1' and cc.id_credit=p_IdCredit
            )loop

                insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                 values( p_IdCredit,'External','FuShu','FriendCallCountL3m',d.FriendCallCountL3m,v_Seq+1 );

                 v_Seq:=v_Seq + 1;

                insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                 values( p_IdCredit,'External','FuShu','FriendCallCountL6m',d.FriendCallCountL6m,v_Seq+1 );

                 v_Seq:=v_Seq + 1;

                insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                 values( p_IdCredit,'External','FuShu','ParentCallCountL6m',d.ParentCallCountL6m,v_Seq+1 );

                 v_Seq:=v_Seq + 1;

            end loop;

        --hongbinbin 20190927
        if v_CreditType='SSC'
          then
            
           for d in(
                select cc.commit_time, cg.id_goods_category, cg.brand, cg.producer,case when to_char(sp.city) is not null then to_char(sp.city) else
                    case when to_char(cm.STORE_PROVINCE) in('天津市','重庆市','北京市','上海市') then to_char(cm.STORE_PROVINCE) else to_char(cm.STORE_CITY) end end as city
                from cs_credit cc
                  join (select a.*,row_number() over(partition by a.id_credit order by a.GOODS_PRICE desc) as num_id from cs_goods a)cg
                        on cc.id=cg.ID_CREDIT and cg.num_id=1
                  left join sellerplace sp on cc.id_sellerplace=sp.id
                  left join cs_merchant_store cm on cm.CONTRACT_NO=cc.CONTRACT_NO
                  where cc.id=p_IdCredit

           ) loop
               for f in (
                 with y as (
                    select id_credit,min(end_time) as end_time
                    from cs_audit_log2 l
                    join cs_credit cc on l.id_credit=cc.id
                    where to_status='y' and cc.app_date >= trunc(sysdate) -30
                    group by id_credit)

                    ,goodsprice_data as (
                    select cc.CONTRACT_NO,cc.id,cc.commit_time,cc.APP_DATE,cc.status,cg.goods_price, cg.num_id
                    ,case when to_char(sp.city) is not null then to_char(sp.city) else
                        case when to_char(cm.STORE_PROVINCE) in('天津市','重庆市','北京市','上海市') then to_char(cm.STORE_PROVINCE) else to_char(cm.STORE_CITY) end end as city
                    ,cg.id_goods_category,cg.id_goods_type,cg.producer,cg.brand,c.name as good_category,t.name as goods_type
                    from cs_credit cc
                    join (select a.*,row_number() over(partition by a.id_credit order by a.GOODS_PRICE desc) as num_id from cs_goods a)cg
                          on cc.id=cg.ID_CREDIT and cg.num_id=1
                    join goods_category c on cg.id_goods_category=c.id
                    join goods_type t on cg.id_goods_type=t.id
                    left join sellerplace sp on cc.id_sellerplace=sp.id
                    left join cs_merchant_store cm on cm.CONTRACT_NO=cc.CONTRACT_NO
                    where cc.credit_model<>'YD' and cc.app_date >= trunc(sysdate) -30
                          and cg.id_goods_category=d.id_goods_category and upper(cg.brand)=upper(d.brand) and upper(cg.producer)=upper(d.producer)
                          and trunc(cc.commit_time)>trunc(d.commit_time)-30
                          and trunc(cc.commit_time)<trunc(d.commit_time)
                          and cc.status in ('a','p','k','y')
                    )

                    ,goods_price_base as (
                      select a.*,end_time from goodsprice_data a
                      left join y on a.id=y.id_credit and y.end_time<trunc(d.commit_time)
                      where a.num_id=1 and a.city=d.city
                    )

                    select nvl(sum(a.goods_price),0)/decode(count(a.id),0,1,count(a.id)) as L1mAvgPrice from goods_price_base a
                 )loop
                   --过去30天已通过合同在相同城市同品牌同类的产品平均价格
                   insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                   values(p_IdCredit,'HardCheck','*','L1mAvgPrice',f.L1mAvgPrice,v_Seq+1);

                   v_Seq:=v_Seq + 1;

               end loop;

           end loop;

         for d in(
            select a.id, a.commit_time,substr(b.ident,7,4) as birth_year,
              case when nvl(a.ID_SA,'1234') not in ('800079','300079','300076') and a.STATUS not in ('r','j') and a.CREDIT_TYPE<>'SC'
              then
               case when max(case when c.address_type=2 then c.province else null end) in('天津市','重庆市','北京市','上海市') or max(case when c.address_type=3 then c.province else null end) in('天津市','重庆市','北京市','上海市')
                 then max(case when c.address_type=2 then c.province else null end)
                 else
                replace(nvl(max(case when c.address_type=2 then c.city else null end),max(case when c.address_type=3 then c.city else null end)),'市')
              end else null end as city
              from cs_credit a
              join cs_person b on b.id=a.id_person
              left join cs_address c on c.id_credit=a.id
              where a.id=p_IdCredit
              group by a.id,a.commit_time,b.ident,a.ID_SA,a.STATUS,a.CREDIT_TYPE
           )loop

              for f in(
                with y as (
                select id_credit,min(end_time) as end_time from cs_audit_log2 l
                join cs_credit cc on l.id_credit=cc.id and cc.CREDIT_TYPE<>'SC'
                where to_status='y' and cc.commit_time >= trunc(d.commit_time -30) and cc.commit_time < d.commit_time
                group by id_credit)

                ,contract_base as
                  (select crr.id,crr.commit_time,crr.status
                  from cs_credit crr
                  where nvl(crr.ID_SA,'1234') not in ('800079','300079','300076') and crr.STATUS not in ('r','j')
                        and CRR.CREDIT_TYPE<>'SC' and crr.commit_time >= trunc(d.commit_time -30) and crr.commit_time < d.commit_time
                  )

                ,address_detail as(
                    select cb.id,
                    max(case when ca.address_type=2 then province else null end) as cur_province,
                    max(case when ca.address_type=2 then city else null end) as cur_city,
                    max(case when ca.address_type=3 then province else null end) as com_province,
                    max(case when ca.address_type=3 then city else null end) as com_city
                    from cs_address ca
                    join contract_base cb on ca.id_credit=cb.id
                    group by cb.id)

                 ,wkincome_data as (
                    select * from
                    (
                      select cc.CONTRACT_NO,cc.id,cc.commit_time,cc.APP_DATE,cc.status,g.WK_INCOME,substr(ident,7,4) as birth_year
                      ,case when nvl(cur_province,com_province) in('天津市','重庆市','北京市','上海市') then nvl(cur_province,com_province)
                       else replace(nvl(cur_city,cur_city),'市') end as city
                      from cs_credit cc
                      join cs_person a on cc.ID_PERSON=a.ID
                      left join cs_employer ce on ce.ID_CREDIT=cc.ID and ce.STATUS='a' and ce.POSITION<>'9'
                      left join cs_experience g on cc.id=g.ID_CREDIT
                      left join address_detail s on cc.ID=s.ID
                      where credit_type<>'SC' and cc.CREDIT_MODEL<>'YD' and g.wk_income between 1000 and 10000
                            and substr(ident,7,4) = d.birth_year
                            and cc.commit_time>trunc(d.commit_time)-30 and cc.commit_time<trunc(d.commit_time)
                            and cc.status in ('a','p','k','y')
                      )tt where tt.city=d.city
                    )

                  ,wkincome_base as (
                    select a.*,end_time from wkincome_data a
                    left join y on a.id=y.id_credit and y.end_time<trunc(d.commit_time)
                    )

                    select
                     -- nvl(sum(a.WK_INCOME),0) sum_wkincome
                     -- ,sum(case when a.id is not null then 1 else 0 end) cases
                      nvl(sum(a.WK_INCOME),0)/decode(count(a.id),0,1,count(a.id)) as L1mAvgIncome
                      from wkincome_base a
                )loop
                 --L1mAvgIncome 过去30天已通过合同在相同城市同年龄客户的平均收入水平
                 insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                 values(p_IdCredit,'HardCheck','*','L1mAvgIncome',f.L1mAvgIncome,v_Seq+1);
                 v_Seq:=v_Seq + 1;
             end loop;

           end loop;
          end if;

          --hongbinbin 20191010
        for d in (
          with sp_contact as (
            select b.id ,b.id_person, b.app_date, cs.PERSON_TYPE, cs.CONTACT_TYPE, cs.CONTACT_VALUE,  cs.UPDATE_TIME
            from  cs_credit b
            left join cs_contact cs on b.id=cs.id_credit
            where b.credit_type='SP' and b.id=p_IdCredit and cs.PERSON_TYPE='1' and cs.CONTACT_TYPE='2'
            )

            select distinct aa.id,sum(case when bb.ID_CREDIT is not null then 1 else 0 end) as MobileDifTimes
              from sp_contact aa
              left join (
                   select distinct cc.ID_PERSON,cc.UPDATE_TIME,cc.ID_CREDIT,
                          cc.PERSON_TYPE,cc.CONTACT_TYPE,cc.CONTACT_VALUE
                    from cs_contact cc
                    where length(cc.CONTACT_VALUE)>=11
                    and cc.CONTACT_TYPE not in (2,11,17,13)
              ) bb on bb.ID_PERSON=aa.ID_PERSON and aa.CONTACT_VALUE=bb.CONTACT_VALUE
              and aa.id <> bb.ID_CREDIT and bb.UPDATE_TIME < aa.app_date
              group by aa.id,bb.id_credit
          )loop

               --客户在申请此合同时，客户手机号码被本人历史作为非移动电话使用过次数
               insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                 values( p_IdCredit,'HardCheck','*','MobileDifTimes',d.MobileDifTimes,v_Seq+1);

                v_Seq:=v_Seq + 1;

          end loop;

        for d in (
          with sp_contact as (
            select b.id ,b.id_person, b.app_date, cs.PERSON_TYPE, cs.CONTACT_TYPE, cs.CONTACT_VALUE,  cs.UPDATE_TIME
            from  cs_credit b
            left join cs_contact cs on b.id=cs.id_credit
            where b.credit_type='SP' and b.id=p_IdCredit and cs.PERSON_TYPE='1' and cs.CONTACT_TYPE='3'
            )

           select distinct aa.id,sum(case when bb.ID_CREDIT is not null then 1 else 0 end) as ComPhoneUseCount
              from sp_contact aa
              left join (
                   select distinct cc.ID_PERSON,cc.UPDATE_TIME,cc.ID_CREDIT,
                          cc.PERSON_TYPE,cc.CONTACT_TYPE,cc.CONTACT_VALUE
                    from cs_contact cc
                    where length(cc.CONTACT_VALUE)>=11
                    and cc.CONTACT_TYPE = '3'
              ) bb on bb.ID_PERSON<>aa.ID_PERSON and aa.CONTACT_VALUE=bb.CONTACT_VALUE
              and aa.id <> bb.ID_CREDIT and bb.UPDATE_TIME < aa.app_date
              group by aa.id,bb.id_credit
              order by aa.id

          )loop

               --客户办公电话在过去被其他人重复使用为办公电话次数
               insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                 values( p_IdCredit,'HardCheck','*','ComPhoneUseCount',d.ComPhoneUseCount,v_Seq+1);

                v_Seq:=v_Seq + 1;

          end loop;

       delete decision_element_data where id_credit=p_IdCredit and element_value is null;

       --2016/12/21 wanxgxiaofeng 24小时审核元素
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       values(p_IdCredit,'Credit','*','CreditAuto24Hour',pkg_decision.get_24hour_element(p_IdCredit),v_Seq+1);

      -------额度申请类型   2018-04-24 yangzhenxian
      insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         select p_IdCredit,'Credit','*','LimitType',nvl(LimitType,0),v_Seq+1
         from (select case when c.CY_LIMIT_TYPE='ER' then 'ER' else c.POS_LIMIT_TYPE end as LimitType from  giveu_credit_eligible c
         where status2 in (2,3,9)  and credit_channel='GIVEU'and id_person=v_IdPerson order by c.create_time desc) where rownum=1 ;

       v_Seq:=v_Seq + 1;

      --新增元素CyLimitStatus          yangzhenxian                  2019-03-26
      for d in (
          with base as(
          select status2
          from giveu_credit_eligible where id_person=v_IdPerson and credit_channel='GIVEU' order by create_time desc
          )
          select * from base where rownum=1
        )loop

            insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'Credit','*','CyLimitStatus',d.status2,v_Seq+1 );

            v_Seq:=v_Seq + 1;

        end loop;

        --即速用新增元素        yangzhenxian                                          2019-05-15
        if v_CreditType ='SP'
        then

           --是否即有消费贷客户      IsSsPerson
           insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
           select p_IdCredit,'HardCheck','*','IsSsPerson',max(case when ID_PERSON is null then 0 else 1 end),v_Seq+1
           from cs_credit where id_person=v_IdPerson and credit_type='SS' and status in ('a','p','k','d');

          v_Seq:=v_Seq + 1;

        end if;

       --wangxiaofeng 2016-01-25 随机生成客户第一联系人拨打号码
       insert into cs_random_other_person
        (id, id_credit,contract_no,id_person,person_name,contacts_name,relation,contact_mode,contact_value,extension)
       select seq_cs_random_other_person.nextval,id_credit,contract_no,id_person,person_name,contacts_name,
              relation,contact_mode,contact_value,extension
        from (select a.id_credit,b.contract_no,b.id_person,c.name person_name,e.name contacts_name,
                     fun_getreg_value(396, a.person_type) relation,fun_getreg_value(395, a.contact_type) contact_mode,
                     a.contact_value,a.reg_person extension, row_number() over(order by dbms_random.value) rn
                from cs_contact a, cs_credit b, cs_person c, cs_other_person e
               where a.id_credit=b.id and b.id_person=c.id and a.id_credit=e.id_credit
                and a.person_Type=e.person_Type and length(a.person_type)=2 and a.id_credit=p_IdCredit) t
       where t.rn = 1;

       --luchangjiang 20180308
       v_Seq:=v_Seq + 1;

       select count(1) into v_Count from mv_status_change_information where personname=v_PersonName and personident=v_Ident
                                                                         and credit_type=v_CreditType and begin_time<=v_CommitTime and end_time>=v_CommitTime;
       if v_Count=0 then

          v_IsRecall:=0;

       else

          select credit_amount,goodsnewcategory into v_SCI_Amount,v_SCI_Category from mv_status_change_information
           where rownum=1 and personname=v_PersonName and personident=v_Ident;

          if v_CreditAmount<=v_SCI_Amount and v_NewCategory=v_SCI_Category then

             v_IsRecall:=1;

          else

             v_IsRecall:=2;

          end if;

       end if;

       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            values(p_IdCredit,'Credit','*','IsRecall',v_IsRecall,v_Seq+1);

       --先生成一遍外部元素（预审调了外部数据，终审不调外部数据）     yangzhenxian     2019-10-24
       if v_CreditType in ('XF')
         then
           prc_collect_element_final_exnl(p_IdCredit,'ALL',p_ReturnCode);
         end if;
       commit;

       p_ReturnCode:='A';
       return;
    exception
       When others Then
         error_info := sqlerrm;
         p_ReturnCode:='Z-'||error_info||DBMS_UTILITY.format_error_backtrace;
         rollback;
    end;
/

