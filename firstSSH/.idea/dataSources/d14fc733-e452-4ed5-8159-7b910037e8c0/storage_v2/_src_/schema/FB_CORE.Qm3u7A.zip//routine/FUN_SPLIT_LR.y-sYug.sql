create FUNCTION fun_split_lr (p_str IN VARCHAR2, demi_left IN VARCHAR2, demi_right IN VARCHAR2)
  RETURN ty_str_split
IS
  jL INT := 0;
  jR INT := 0;
  i INT := 1;
  len INT := 0;
  len1 INT := 0;
  len2 INT := 0;
  str VARCHAR2 (4000);
  str_split ty_str_split := ty_str_split ();
BEGIN
  len := LENGTH (p_str);
  len1 := LENGTH (demi_left);
  len2 := LENGTH (demi_right);
  WHILE jR < len
  LOOP
      jL := INSTR (p_str, demi_left, i);
      jR := INSTR (p_str, demi_right, jL+len1);
      IF jL > 0 and jR>jL then
          str := SUBSTR (p_str, jL+len1, jR - jL-len2);
          i := jR + len2;
          str_split.EXTEND;
          str_split (str_split.COUNT) := str;
      else
          goto relult;
      END IF;
  END LOOP;
<<relult>>
  RETURN str_split;
END;
/

