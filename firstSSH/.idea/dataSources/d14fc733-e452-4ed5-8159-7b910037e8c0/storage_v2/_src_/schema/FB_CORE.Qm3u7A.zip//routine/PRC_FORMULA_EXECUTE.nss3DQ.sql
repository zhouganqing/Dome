create procedure PRC_FORMULA_EXECUTE
(
mytable varchar2,
hitOnce number:=1,--默认命中一次退出，如果允许命中多个则以，隔开返回
SelRecord out varchar2
)
is
spltRow ty_str_split;
spltColumn ty_str_split;
v_guid varchar2(200);
v_formula varchar2(2000);
v_result number:=0;
begin
  SelRecord:='';
  spltRow:=fun_split(mytable,'##');--行
  for idx in 1..spltRow.Count loop
    begin
      exit when v_result=1 and hitOnce=1;
      spltColumn:=fun_split(spltRow(idx),'#');--列
      if spltColumn.Count=2 then
         v_guid:=spltColumn(1);
         v_formula:=spltColumn(2);
         Execute immediate v_formula into v_result;
          
         if v_result=1 then
           if hitOnce=1 then
                 SelRecord:=v_guid;
                 return;
           else
                 SelRecord:=SelRecord||v_guid||',';
           end if;
         end if;
       end if;
       
     Exception
      when others then
        begin
        continue;    
        end;
    end;
   end loop;
   if SelRecord is not null then
      SelRecord:=rtrim(SelRecord,',');
   end if;
end PRC_FORMULA_EXECUTE;
/

