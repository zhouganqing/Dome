create package body PKG_DECISION is

  -- Author  : wangxiaofeng
  -- Create Date : 2016/10/03
  -- Purpose : get branch id
  function filterStr(p_str  varchar2) return varchar2
    is
  begin
    return trim(replace(replace(replace(p_str,''''),'['),']'));
  exception
   When others Then
     return p_str;
  end filterStr;
  
  -- Author  : wangxiaofeng
  -- Create Date : 2016-12-21
  -- Purpose : 24小时审单元素值
  function get_24hour_element(p_IdCredit cs_credit.id%type)
    return number is
      v_Id                 decision_time_group.time_group_id%type;
      v_TimeGroup          decision_time_group.time_group%type;
      v_Formula            decision_formula_lib.formula%type;
      v_TempFormula        decision_formula_lib.formula%type;

      spltElements         ty_str_split;
      spltElement          ty_str_split;

      v_ElementValue       decision_element_data.element_value%type;
      v_ValueType          decision_element_define.value_type%type;

      v_Temp               varchar2(1000);
      idx                  integer;
      v_Count              integer;
      v_Sql                varchar2(4000);
      cursor cur is select t.time_group_id id,l.formula,t.time_group from decision_time_group t,decision_formula_lib l where t.status=1 and t.formula_id=l.formula_id order by t.sort_code;
    begin
      open cur;
      loop
         fetch cur into v_Id,v_Formula,v_TimeGroup;
         exit when cur%notfound;

         v_TempFormula:=v_Formula;
         spltElements:=fun_split_lr(v_Formula,'[',']');
         if spltElements.Count>0 then
            for idx in 1..spltElements.Count loop
                spltElement:=fun_split(Replace(Replace(spltElements(idx),'*.',''),'..','.'),'.');
                if spltElement.Count=3 then
                    select count(1) into v_Count from decision_element_data where id_credit=p_IdCredit
                       and element_type=spltElement(1) and element_sub_type=spltElement(2) and element_name=spltElement(3);
                    if v_Count>=1 then
                       select filterStr(element_value) into v_ElementValue from decision_element_data where rownum=1 and id_credit=p_IdCredit
                          and element_type=spltElement(1) and element_sub_type=spltElement(2) and element_name=spltElement(3);

                        select value_type into v_ValueType from decision_element_define where element_type=spltElement(1)
                      and element_sub_type=spltElement(2) and element_name=spltElement(3);

                       if v_ValueType='integer' then
                          v_Formula:=replace(v_Formula,'['||spltElements(idx)||']',v_ElementValue);
                       elsif v_ValueType='decimal' then
                          v_Formula:=replace(v_Formula,'['||spltElements(idx)||']',v_ElementValue);
                       elsif v_ValueType='date' then
                          if instr(lower(v_Formula),'to_date([')=0 then
                            v_Formula:=replace(v_Formula,'['||spltElements(idx)||']','to_date('''||v_ElementValue||''',''yyyy-mm-dd'')');
                          else
                            v_Formula:=replace(v_Formula,'['||spltElements(idx)||']',''''||v_ElementValue||'''');
                          end if;
                       elsif v_ValueType='datetime' then
                         if instr(lower(v_Formula),'to_date([')=0 then
                           v_Formula:=replace(v_Formula,'['||spltElements(idx)||']','to_date('''||v_ElementValue||''',''yyyy-mm-dd hh24:mi:ss'')');
                         else
                           v_Formula:=replace(v_Formula,'['||spltElements(idx)||']',''''||v_ElementValue||'''');
                         end if;
                       else
                          v_Formula:=replace(v_Formula,spltElements(idx),v_ElementValue);
                       end if;
                    else
                       v_Formula:=replace(v_Formula,'['||spltElements(idx)||']','null');
                       v_Formula:=replace(v_Formula,'null is null','1=1');
                       v_Formula:=replace(v_Formula,'null is not null','1=2');
                       v_Temp:=lower(replace(replace(replace(v_Formula,'[',''),']',''),' ',''));
                       if instr(v_Temp,'ornullisnull')>=1 or instr(v_Temp,'nullisnullor')>=1 then
                           v_Formula:=replace(v_Formula,'null is null','1=1');
                       elsif instr(v_Temp,'to_date(,',1)>=1 or instr(v_Temp,'nullnot')>0 or instr(v_Temp,'null!=')>0 or instr(v_Temp,'!=null')>0 or instr(v_Temp,'null=')>0 or instr(v_Temp,'null>')>0
                          or instr(v_Temp,'null<')>0 or instr(v_Temp,'nulllike')>0 or instr(v_Temp,'nullin')>0 or instr(v_Temp,'to_date(null',1)>=1 then
                          goto next_loop;
                       end if;
                    end if;
                elsif spltElement.Count=2 then
                    select count(1) into v_Count from decision_element_data where id_credit=p_IdCredit
                       and element_type=spltElement(1) and element_sub_type='*' and element_name=spltElement(2);
                    if v_Count>=1 then
                       select filterStr(element_value) into v_ElementValue from decision_element_data where rownum=1 and id_credit=p_IdCredit
                          and element_type=spltElement(1) and element_sub_type='*' and element_name=spltElement(2);

                       select filterStr(element_value) into v_ElementValue from decision_element_data where rownum=1 and id_credit=p_IdCredit
                        and element_type=spltElement(1) and element_sub_type='*' and element_name=spltElement(2);

                       select value_type into v_ValueType from decision_element_define where element_type=spltElement(1)
                          and element_sub_type='*' and element_name=spltElement(2);
                       if v_ValueType='integer' or v_ValueType='bool' then
                          v_Formula:=replace(v_Formula,'['||spltElements(idx)||']',v_ElementValue);
                       elsif v_ValueType='decimal' then
                          v_Formula:=replace(v_Formula,'['||spltElements(idx)||']',v_ElementValue);
                       elsif v_ValueType='date' then
                          if instr(lower(v_Formula),'to_date([')=0 then
                            v_Formula:=replace(v_Formula,'['||spltElements(idx)||']','to_date('''||v_ElementValue||''',''yyyy-mm-dd'')');
                          else
                            v_Formula:=replace(v_Formula,'['||spltElements(idx)||']',''''||v_ElementValue||'''');
                          end if;
                       elsif v_ValueType='datetime' then
                          if instr(lower(v_Formula),'to_date([')=0 then
                            v_Formula:=replace(v_Formula,'['||spltElements(idx)||']','to_date('''||v_ElementValue||''',''yyyy-mm-dd hh24:mi:ss'')');
                          else
                            v_Formula:=replace(v_Formula,'['||spltElements(idx)||']',''''||v_ElementValue||'''');
                          end if;
                       else
                          v_Formula:=replace(v_Formula,spltElements(idx),v_ElementValue);
                       end if;
                    else
                       v_Formula:=replace(v_Formula,'['||spltElements(idx)||']','null');
                       v_Formula:=replace(v_Formula,'null is null','1=1');
                       v_Formula:=replace(v_Formula,'null is not null','1=2');
                       v_Temp:=lower(replace(replace(replace(v_Formula,'[',''),']',''),' ',''));
                       if instr(v_Temp,'to_date(,',1)>=1 or instr(v_Temp,'nullnot')>0 or instr(v_Temp,'null!=')>0 or instr(v_Temp,'!=null')>0 or instr(v_Temp,'null=')>0 or instr(v_Temp,'null>')>0
                          or instr(v_Temp,'null<')>0 or instr(v_Temp,'nulllike')>0 or instr(v_Temp,'nullin')>0 or instr(v_Temp,'to_date(null',1)>=1 then
                          goto next_loop;
                       end if;
                    end if;
                end if;
            end loop;
         end if;
         v_Sql:='select count(1) from dual where '||replace(replace(replace(v_Formula,'[',''''),']',''''),'''null''','null');
         execute immediate v_Sql into v_Count;
         if v_Count>=1 then
            return v_TimeGroup;
         end if;
        <<next_loop>>
         v_Count:=0;
      end loop;
      close cur;
      return(0);
    exception
     When others Then
       return(0);
    end get_24hour_element;
    
    
  -- Author  : wangxiaofeng
  -- Create Date : 2017-07-10
  -- Purpose : 计算即有钱包额度;
  function get_giveu_wallet_limit(p_IdCredit cs_credit.id%type,
                                     p_BranchId decision_giveu_limit_formula.branch_id%type,
                                     p_LimitType decision_giveu_limit_formula.limit_type%type,
                                     p_ContractStatus decision_giveu_limit_formula.contract_status%type)
      return number is
      v_Id                 decision_giveu_limit_formula.id%type;
      v_LimitAdjust        decision_giveu_limit_formula.limit_adjust%type;
      v_Formula            decision_formula_lib.formula%type;
      v_TempFormula        decision_formula_lib.formula%type;

      spltElements         ty_str_split;
      spltElement          ty_str_split;

      v_ElementValue       decision_element_data.element_value%type;
      v_ValueType          decision_element_define.value_type%type;

      v_Temp               varchar2(1000);
      idx                  integer;
      v_Count              integer;
      v_Sql                varchar2(4000);
      cursor cur is select t.id,l.formula,t.limit_adjust from decision_giveu_limit_formula t,decision_formula_lib l
      where t.formula_id=l.formula_id and (t.branch_id=-1 or t.branch_id=p_BranchId) and t.limit_type=p_LimitType and t.contract_status=p_ContractStatus and t.status=1 order by t.sort_code;
    begin
      open cur;
      loop
         fetch cur into v_Id,v_Formula,v_LimitAdjust;
         exit when cur%notfound;

         v_TempFormula:=v_Formula;
         spltElements:=fun_split_lr(v_Formula,'[',']');
         if spltElements.Count>0 then
            for idx in 1..spltElements.Count loop
                spltElement:=fun_split(Replace(Replace(spltElements(idx),'*.',''),'..','.'),'.');
                if spltElement.Count=3 then
                    select count(1) into v_Count from decision_element_data where id_credit=p_IdCredit
                       and element_type=spltElement(1) and element_sub_type=spltElement(2) and element_name=spltElement(3);
                    if v_Count>=1 then
                       select filterStr(element_value) into v_ElementValue from decision_element_data where rownum=1 and id_credit=p_IdCredit
                          and element_type=spltElement(1) and element_sub_type=spltElement(2) and element_name=spltElement(3);

                        select value_type into v_ValueType from decision_element_define where element_type=spltElement(1)
                      and element_sub_type=spltElement(2) and element_name=spltElement(3);

                       if v_ValueType='integer' then
                          v_Formula:=replace(v_Formula,'['||spltElements(idx)||']',v_ElementValue);
                       elsif v_ValueType='decimal' then
                          v_Formula:=replace(v_Formula,'['||spltElements(idx)||']',v_ElementValue);
                       elsif v_ValueType='date' then
                          if instr(lower(v_Formula),'to_date([')=0 then
                            v_Formula:=replace(v_Formula,'['||spltElements(idx)||']','to_date('''||v_ElementValue||''',''yyyy-mm-dd'')');
                          else
                            v_Formula:=replace(v_Formula,'['||spltElements(idx)||']',''''||v_ElementValue||'''');
                          end if;
                       elsif v_ValueType='datetime' then
                         if instr(lower(v_Formula),'to_date([')=0 then
                           v_Formula:=replace(v_Formula,'['||spltElements(idx)||']','to_date('''||v_ElementValue||''',''yyyy-mm-dd hh24:mi:ss'')');
                         else
                           v_Formula:=replace(v_Formula,'['||spltElements(idx)||']',''''||v_ElementValue||'''');
                         end if;
                       else
                          v_Formula:=replace(v_Formula,spltElements(idx),v_ElementValue);
                       end if;
                    else
                       v_Formula:=replace(v_Formula,'['||spltElements(idx)||']','null');
                       v_Formula:=replace(v_Formula,'null is null','1=1');
                       v_Formula:=replace(v_Formula,'null is not null','1=2');
                       v_Temp:=lower(replace(replace(replace(v_Formula,'[',''),']',''),' ',''));
                       if instr(v_Temp,'ornullisnull')>=1 or instr(v_Temp,'nullisnullor')>=1 then
                           v_Formula:=replace(v_Formula,'null is null','1=1');
                       elsif instr(v_Temp,'to_date(,',1)>=1 or instr(v_Temp,'nullnot')>0 or instr(v_Temp,'null!=')>0 or instr(v_Temp,'!=null')>0 or instr(v_Temp,'null=')>0 or instr(v_Temp,'null>')>0
                          or instr(v_Temp,'null<')>0 or instr(v_Temp,'nulllike')>0 or instr(v_Temp,'nullin')>0 or instr(v_Temp,'to_date(null',1)>=1 then
                          goto next_loop;
                       end if;
                    end if;
                elsif spltElement.Count=2 then
                    select count(1) into v_Count from decision_element_data where id_credit=p_IdCredit
                       and element_type=spltElement(1) and element_sub_type='*' and element_name=spltElement(2);
                    if v_Count>=1 then
                       select filterStr(element_value) into v_ElementValue from decision_element_data where rownum=1 and id_credit=p_IdCredit
                          and element_type=spltElement(1) and element_sub_type='*' and element_name=spltElement(2);

                       select filterStr(element_value) into v_ElementValue from decision_element_data where rownum=1 and id_credit=p_IdCredit
                        and element_type=spltElement(1) and element_sub_type='*' and element_name=spltElement(2);

                       select value_type into v_ValueType from decision_element_define where element_type=spltElement(1)
                          and element_sub_type='*' and element_name=spltElement(2);
                       if v_ValueType='integer' or v_ValueType='bool' then
                          v_Formula:=replace(v_Formula,'['||spltElements(idx)||']',v_ElementValue);
                       elsif v_ValueType='decimal' then
                          v_Formula:=replace(v_Formula,'['||spltElements(idx)||']',v_ElementValue);
                       elsif v_ValueType='date' then
                          if instr(lower(v_Formula),'to_date([')=0 then
                            v_Formula:=replace(v_Formula,'['||spltElements(idx)||']','to_date('''||v_ElementValue||''',''yyyy-mm-dd'')');
                          else
                            v_Formula:=replace(v_Formula,'['||spltElements(idx)||']',''''||v_ElementValue||'''');
                          end if;
                       elsif v_ValueType='datetime' then
                          if instr(lower(v_Formula),'to_date([')=0 then
                            v_Formula:=replace(v_Formula,'['||spltElements(idx)||']','to_date('''||v_ElementValue||''',''yyyy-mm-dd hh24:mi:ss'')');
                          else
                            v_Formula:=replace(v_Formula,'['||spltElements(idx)||']',''''||v_ElementValue||'''');
                          end if;
                       else
                          v_Formula:=replace(v_Formula,spltElements(idx),v_ElementValue);
                       end if;
                    else
                       v_Formula:=replace(v_Formula,'['||spltElements(idx)||']','null');
                       v_Formula:=replace(v_Formula,'null is null','1=1');
                       v_Formula:=replace(v_Formula,'null is not null','1=2');
                       v_Temp:=lower(replace(replace(replace(v_Formula,'[',''),']',''),' ',''));
                       if instr(v_Temp,'to_date(,',1)>=1 or instr(v_Temp,'nullnot')>0 or instr(v_Temp,'null!=')>0 or instr(v_Temp,'!=null')>0 or instr(v_Temp,'null=')>0 or instr(v_Temp,'null>')>0
                          or instr(v_Temp,'null<')>0 or instr(v_Temp,'nulllike')>0 or instr(v_Temp,'nullin')>0 or instr(v_Temp,'to_date(null',1)>=1 then
                          goto next_loop;
                       end if;
                    end if;
                end if;
            end loop;
         end if;
         v_Sql:='select count(1) from dual where '||replace(replace(replace(v_Formula,'[',''''),']',''''),'''null''','null');
         execute immediate v_Sql into v_Count;
         if v_Count>=1 then
            return get_formula_sum(p_IdCredit,v_LimitAdjust);
         end if;
        <<next_loop>>
         v_Count:=0;
      end loop;
      close cur;
      return(0);
    exception
     When others Then
       return(0);
    end get_giveu_wallet_limit;

  -- Author  : wangxiaofeng
  -- Create Date : 2017-07-10
  -- Purpose : 根据公式求和;
  function get_formula_sum(p_IdCredit cs_credit.id%type,
                            p_Formula  varchar2)
    return number is
    v_Formula            varchar2(2000);
    spltElements         ty_str_split;
    spltElement          ty_str_split;

    v_ElementValue       decision_element_data.element_value%type;
    v_ValueType          decision_element_define.value_type%type;

    idx                  integer;
    v_Count              number;
    v_Sql                varchar2(4000);
  begin
     v_Formula:=p_Formula;
     spltElements:=fun_split_lr(v_Formula,'[',']');
     if spltElements.Count>0 then
        for idx in 1..spltElements.Count loop
            spltElement:=fun_split(Replace(Replace(spltElements(idx),'*.',''),'..','.'),'.');
            if spltElement.Count=3 then
                select count(1) into v_Count from decision_element_data where id_credit=p_IdCredit
                   and element_type=spltElement(1) and element_sub_type=spltElement(2) and element_name=spltElement(3);
                if v_Count>=1 then
                   select filterStr(element_value) into v_ElementValue from decision_element_data where rownum=1 and id_credit=p_IdCredit
                      and element_type=spltElement(1) and element_sub_type=spltElement(2) and element_name=spltElement(3);

                   select value_type into v_ValueType from decision_element_define where element_type=spltElement(1)
                    and element_sub_type=spltElement(2) and element_name=spltElement(3);

                   if v_ValueType in('integer','decimal') then
                      v_Formula:=replace(v_Formula,'['||spltElements(idx)||']',v_ElementValue);
                   else
                      v_Formula:=replace(v_Formula,spltElements(idx),0);
                   end if;
                else
                  v_Formula:=replace(v_Formula,spltElements(idx),0);
                  goto next_loop;
                end if;
            elsif spltElement.Count=2 then
                select count(1) into v_Count from decision_element_data where id_credit=p_IdCredit
                   and element_type=spltElement(1) and element_sub_type='*' and element_name=spltElement(2);
                if v_Count>=1 then
                   select filterStr(element_value) into v_ElementValue from decision_element_data where rownum=1 and id_credit=p_IdCredit
                      and element_type=spltElement(1) and element_sub_type='*' and element_name=spltElement(2);

                   select filterStr(element_value) into v_ElementValue from decision_element_data where rownum=1 and id_credit=p_IdCredit
                    and element_type=spltElement(1) and element_sub_type='*' and element_name=spltElement(2);

                   select value_type into v_ValueType from decision_element_define where element_type=spltElement(1)
                      and element_sub_type='*' and element_name=spltElement(2);
                   if v_ValueType in('integer','decimal') then
                      v_Formula:=replace(v_Formula,'['||spltElements(idx)||']',v_ElementValue);
                   else
                      v_Formula:=replace(v_Formula,spltElements(idx),0);
                   end if;
                else
                  v_Formula:=replace(v_Formula,spltElements(idx),0);
                  goto next_loop;
                end if;
            end if;
        end loop;
     end if;
     v_Sql:='select '||replace(replace(v_Formula,'[',''''),']','''') ||' from dual';
     execute immediate v_Sql into v_Count;
     return v_Count;
    <<next_loop>>
     return(0);
  exception
    When others Then
      return(0);
  end get_formula_sum;
end;
/

