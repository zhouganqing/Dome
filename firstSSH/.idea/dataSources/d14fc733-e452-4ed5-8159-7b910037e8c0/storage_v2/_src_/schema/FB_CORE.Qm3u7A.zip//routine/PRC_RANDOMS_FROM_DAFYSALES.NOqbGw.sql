create procedure PRC_RANDOMS_FROM_DAFYSALES
(
p_IdCredit cs_credit.id%type
)
is
begin
  delete decision_element_data where id_credit=p_IdCredit and element_type='Special' and element_name in('Random1','Random2','Random3','Random4');
  insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,create_time,sort_code,element_value,id)
	select id_credit,element_type,element_sub_type,element_name,sysdate,seq,element_value,sys_guid() from old_decision_element_data
  where id_credit=p_IdCredit and element_type='Special' and element_name in('Random1','Random2','Random3','Random4')
  union
	select id_credit,element_type,element_sub_type,element_name,sysdate,seq,element_value,sys_guid() from old_dec_element_data_history
  where id_credit=p_IdCredit and element_type='Special' and element_name in('Random1','Random2','Random3','Random4');

  commit;

Exception
  When others Then
    rollback;
end PRC_RANDOMS_FROM_DAFYSALES;
/

