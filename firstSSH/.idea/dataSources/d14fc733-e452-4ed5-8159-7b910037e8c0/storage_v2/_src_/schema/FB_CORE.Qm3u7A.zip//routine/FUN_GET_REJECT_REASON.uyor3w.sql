create function fun_get_reject_reason(p_id_credit number)
/*
use：wangxiaofeng
date:2015-03-11
purpose:获取系统拒单原因
*/
return varchar2
is
  v_count   number;
  v_reason  varchar2(1000);
begin
  select count(1) into v_count from decision_element_data_history t
  where id_credit=p_id_credit and element_type in('preResult','postResult') and element_name='HardCheck' and t.element_value='1';

  if v_count>0 then
    select t.element_value into v_reason from decision_element_data_history t
    where id_credit=p_id_credit and element_type in('preResult','postResult') and element_name='HardCheckRemark' and rownum=1 order by t.sort_code;

    return v_reason;
  else
    return '';
  end if;

exception
   when others
   then
      return '';
end;
/

