create function fun_cash_get_thread(pay_type varchar2)  return varchar2 is
  res varchar2(1);
  rand_Num number;
begin
    if 1=1  then
      res:=0;

      return(res);
      end if;

 SELECT dbms_random.value into  rand_Num FROM dual;
 if (rand_Num>=0 and  rand_Num<=0.33)
   then
   res:='1';
   elsif(rand_Num>0.3 and  rand_Num<=0.66)
      then
       res:='2';
 else
    res:='3';

 end if;

  return(res);
end ;
/

