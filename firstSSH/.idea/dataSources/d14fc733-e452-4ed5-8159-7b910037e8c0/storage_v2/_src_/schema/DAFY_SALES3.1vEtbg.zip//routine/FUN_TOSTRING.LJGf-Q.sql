create function FUN_TOSTRING(p NUMBER) 
                                 return varchar2 
                                 is 
                                    result VARCHAR(10);
                                 begin
                                   select TO_CHAR(P) into result FROM DUAL; 
                                   return result;
                                 end FUN_TOSTRING;
/

