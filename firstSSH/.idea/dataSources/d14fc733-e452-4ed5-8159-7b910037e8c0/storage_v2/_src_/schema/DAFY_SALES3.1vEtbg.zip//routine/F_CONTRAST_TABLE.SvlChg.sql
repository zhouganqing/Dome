create function f_contrast_table(tablename varchar2)
--该函数根据传入的表名参数，比对开发库和生产库该表结构是否一致
--返回数值如果为0，则表结构一致；返回数值如果大于0，则表结构不一致
  return integer is
  v_tablename varchar2(50);
  v_count     integer;
begin
  --将传入的名称转换为大写字母
  v_tablename := upper(tablename);
  --对比生产库和开发库中，该表结构是否有差异
  --生产库通过dblink进行访问
  select count(*)
    into v_count
    from ((select column_name, data_type, data_length
             from user_tab_columns@dg0
            where table_name = v_tablename
           minus
           select column_name, data_type, data_length
             from user_tab_columns
            where table_name = v_tablename) union
          (select column_name, data_type, data_length
             from user_tab_columns
            where table_name = v_tablename
           minus
           select column_name, data_type, data_length
             from user_tab_columns@dg0
            where table_name = v_tablename));
   --返回比对结果
   return v_count;
end f_contrast_table;
/

