create procedure p_truncate_table(tablename in varchar2)
--该存储过程用于清空表数据
 as
  v_tablename varchar2(50);     --接收传入的表名
  v_sql       varchar2(1000);   --存放游标取得的SQL语句
  --将清空表数据的语句赋予游标c_truncatetable
  cursor c_truncatetable is
    select 'truncate table ' || table_name
      from user_tables
     where table_name = v_tablename;
begin
  --将传入的名称转换为大写字母
  v_tablename := upper(tablename);
  --清空表中现有数据
  open c_truncatetable;
  loop
    fetch c_truncatetable into v_sql;
    exit when c_truncatetable%notfound;
      execute immediate v_sql;
  end loop;
  close c_truncatetable;
end;
/

