create procedure p_drop_table(tablename in varchar2)
--该存储过程用于删除表
 as
  v_tablename varchar2(50);     --接收传入的表名
  v_sql       varchar2(1000);   --存放游标取得的SQL语句
  --将删除表的语句赋予游标c_droptable
  cursor c_droptable is
    select 'drop table ' || table_name || ' cascade constraints'
      from user_tables
     where table_name = v_tablename;
begin
  --将传入的名称转换为大写字母
  v_tablename := upper(tablename);
  --删除表
  open c_droptable;
  loop
    fetch c_droptable into v_sql;
    exit when c_droptable%notfound;
      execute immediate v_sql;
  end loop;
  close c_droptable;
end;
/

