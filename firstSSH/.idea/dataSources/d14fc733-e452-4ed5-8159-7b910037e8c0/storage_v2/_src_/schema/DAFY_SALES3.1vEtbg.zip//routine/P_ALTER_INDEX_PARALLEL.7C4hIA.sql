create procedure p_alter_index_parallel(tablename in varchar2)
--该存储过程用于将索引的并行度修改为1
 as
  v_tablename varchar2(50);     --接收传入的表名
  v_sql       varchar2(1000);   --存放游标取得的SQL语句
  --将修改索引并行度为1的语句赋予游标c_modifyindex
  cursor c_modifyindex is
    select 'alter index ' || index_name || ' parallel 1'
      from user_indexes
     where table_name = v_tablename;
begin
  --将传入的名称转换为大写字母
  v_tablename := upper(tablename);
  --将索引的并行度修改为1
  open c_modifyindex;
  loop
    fetch c_modifyindex into v_sql;
    exit when c_modifyindex%notfound;
      execute immediate v_sql;
  end loop;
  close c_modifyindex;
end;
/

