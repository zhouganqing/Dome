create procedure p_create_table_as(tablename in varchar2)
--该存储过程用于在开发库中创建与生产库相同的表
 as
  v_tablename varchar2(50);     --接收传入的表名
  v_sql       varchar2(1000);   --存放游标取得的SQL语句
  --将重新创建表的语句赋予游标c_createtable
  cursor c_createtable is
    select 'create table ' || table_name || ' as select * from ' ||
           table_name || '@dg0'
      from user_tables@dg0
     where table_name = v_tablename;
begin
  --将传入的名称转换为大写字母
  v_tablename := upper(tablename);
  --重新创建表
  open c_createtable;
  loop
    fetch c_createtable into v_sql;
    exit when c_createtable%notfound;
      execute immediate v_sql;
  end loop;
  close c_createtable;
end;
/

