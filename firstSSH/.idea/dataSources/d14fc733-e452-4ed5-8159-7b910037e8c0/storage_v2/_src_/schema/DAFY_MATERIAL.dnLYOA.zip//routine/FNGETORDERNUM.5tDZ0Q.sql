create FUNCTION               fnGetOrderNum return varchar2 as
  result  varchar2(50);
  strdate varchar2(50);
begin
  select to_char(sysdate, 'YYMMDD') into strdate from dual;
  begin
    select concat(strdate,
                  substr(concat('00000',
                                cast(nvl(max(substr(order_no, -6, 6)), 0) + 1 as
                                     varchar2(50))),
                         -6,
                         6))
      into result
      from order_list
     where substr(order_no, 1, 6) = strdate;
  end;
  return(result);
end fnGetOrderNum;


/

