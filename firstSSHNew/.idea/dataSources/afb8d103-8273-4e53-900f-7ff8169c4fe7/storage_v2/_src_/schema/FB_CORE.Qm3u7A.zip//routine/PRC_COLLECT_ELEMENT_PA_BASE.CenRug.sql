create procedure prc_collect_element_pa_base(p_IdCredit cs_credit.id%type,p_ReturnCode out varchar2) is
       -- Author  : MaJianFeng
       -- Create Date : 2018-06-06
       -- Purpose : put credit data into decision_element_data_pa_PA table;
       error_info                  varchar2(1000);
        v_IdPerson                  cs_person.id%type;
       v_PersonName                cs_person.name%type;
       v_Ident                     cs_person.ident%type;
       v_IdentExp                  cs_person.ident_exp%type;
       v_National                  cs_person.national%type;
       v_CommitTime                cs_credit.commit_time%type;
       v_IdSa                      cs_credit.id_sa%type;
       v_SaName                    sys_user_list.user_name%type;
       v_SaMobile                  sys_user_list.phone%type;
       v_SaIdent                   sys_user_list.ident%type;
       v_CreditType                cs_credit.credit_type%type;
       v_PreInterCode              cs_credit.pa_inter_code%type;
       v_CreditModel               cs_credit.credit_model%type;
       v_PayAmount                 cs_credit.pay_amount%type;
       v_AppDate                   cs_credit.app_date%type;
       v_PosCode                   varchar2(50);
       v_IdSellerPlace             sellerplace.id%type;
       v_Province                  sellerplace.province%type;
       v_City                      sellerplace.city%type;
       v_UseCity                   sellerplace.city%type;
       v_Seq                       decision_element_data_pa.sort_code%type;
       v_IdCredit                  number;
       v_Count                     integer;
       v_GoodsVolume               number:=0;
       v_MaxGoodsPrice             number:=-1;
       v_MaxGoodsType              goods_type.name%type;
       v_MinGoodsPrice             number:=-1;
       v_MinGoodsType              goods_type.name%type;
       v_IsRecall                  number:=0;
       v_CreditAmount              cs_credit.credit_amount%type;
       v_SCI_Amount                status_change_information.credit_amount%type;
       v_SCI_Category              status_change_information.goodsnewcategory%type;
       v_NewCategory               varchar2(50);
       v_ElementType               decision_element_data_pa.element_type%type;
       v_ContractNo                cs_credit.contract_no%type;
       v_Price                     cs_credit.price%type;
       v_Annuity                   cs_credit.annuity%type;
       v_CreditSource              cs_credit.credit_source%type;
       v_Birthday                  varchar2(20);
       v_Age                       integer;
       v_Sex                       cs_person.sex%type;
       v_PersonMobile              varchar2(100);
       v_OfficeTel                 varchar2(100);
       v_IdProduct                 product.id%type;
       v_ProdType                  product.prod_type%type;
       v_SearchType                product.search_type%type;
       v_PaymentNum                product.payment_num%type;
       v_TempVue                   varchar2(50);
       v_Position                  number:=-1;
       v_varTemp                   varchar2(100);
       v_FamilyPhoneUseCount           number:=0;
       v_OtherPhoneUseCount            number:=0;
       v_FamilyPhoneUseSameCityCount   number:=0;
       v_FamilyPhoneUseSamePosCount    number:=0;
       v_OtherPhoneUseSameCityCount    number:=0;
       v_OtherPhoneUseSamePosCount     number:=0;
       strSql                      varchar2(4000);
    begin
      
     delete decision_element_data_pa where id_credit=p_IdCredit;
    
     -- prc_save_cs_contact(100000,p_IdCredit,p_ReturnCode);
     
       v_Seq:=0;
       
       v_ElementType:='Special';
       
       insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
            values(p_IdCredit,v_ElementType,'Random5',round(dbms_random.value(),6),v_Seq+1);
       v_Seq:=v_Seq + 1;
       
       v_ElementType:='Credit';
       
       select a.contract_no,a.credit_model,a.commit_time,nvl(a.id_sa,''),a.credit_amount,a.price,a.annuity,a.id_person,a.credit_type,a.pa_inter_code,a.pay_amount,a.app_date,a.credit_source
         into v_ContractNo,v_CreditModel,v_CommitTime,v_IdSa,v_CreditAmount,v_Price,v_Annuity,v_IdPerson,v_CreditType,v_PreInterCode,v_PayAmount,v_AppDate,v_CreditSource
         from cs_credit a where a.id=p_IdCredit;
         
       --2017/03/21 update wangxiaofeng v_AppDate date 改为datetime
       strSql:='insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
                select '||p_IdCredit||','''||v_ElementType||''','||'''PaContractNo'''||','''||v_ContractNo||''','||(v_Seq+1)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''PaPrice'''||','''||v_Price||''','||(v_Seq+2)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''PaCreditAmount'''||','''||v_CreditAmount||''','||(v_Seq+3)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''PaAnnuity'''||','''||v_Annuity||''','||(v_Seq+4)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''PaCommitTime'''||','''||to_char(v_CommitTime,'yyyy-MM-dd HH24:mi:ss')||''','||(v_Seq+5)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''PaInterCode'''||','''||v_PreInterCode||''','||(v_Seq+6)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''PaIdSa'''||','''||v_IdSa||''','||(v_Seq+7)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''PaCreditType'''||','''||v_CreditType||''','||(v_Seq+8)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''PaCreditModel'''||','''||v_CreditModel||''','||(v_Seq+9)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''PaPayAmount'''||','''||v_PayAmount||''','||(v_Seq+10)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''PaAppDate'''||','''||to_char(v_AppDate,'yyyy-MM-dd HH24:mi:ss')||''','||(v_Seq+11)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''PaCreditSource'''||','''||v_CreditSource||''','||(v_Seq+12)||' from dual';
       
       Execute immediate strSql;
       
       v_Seq:=v_Seq +12;
       
       --修改中移产品cs.credit_type='XF'的销售信息生成逻辑	 yangzhenxian	 2019-05-10
       if v_CreditType='XF'
       then 
                 
           for c in(select 
            SALES_NAME as SaName,--销售员姓名
            SALES_PHONE as SaMobile,--销售员手机
            SALES_IDCARD as SaIdent---销售员身份证
            from cs_merchant_store where contract_no=v_ContractNo
             )loop
             
              insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
                   values(p_IdCredit,v_ElementType,'PaSaName',c.SaName,v_Seq+1);
                   
              insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
                   values(p_IdCredit,v_ElementType,'PaSaMobile',c.SaMobile,v_Seq+1);
                   
              insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
                   values(p_IdCredit,v_ElementType,'PaSaIdent',c.SaIdent,v_Seq+1);
              
              v_SaName:=c.SaName;
              
              v_SaMobile:=c.SaMobile;
              
              v_SaIdent:=c.SaIdent;
              
              v_Seq:=v_Seq + 3;
              
           end loop;
           
       end if;       
       
       --享购机元素      yangzhenxian	2019-06-12
       for c in(select 
        Supplier as Supplier,--套餐运营商（实际运营商）
        Channel_type as ChannelType,--渠道
        fw_channel as FwChannel--资方批发渠道
        from cs_credit_ext where id_credit=p_IdCredit
         )loop
             
          insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
               values(p_IdCredit,'Credit','PaSupplier',c.Supplier,v_Seq+1);
                   
          insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
               values(p_IdCredit,'Credit','PaChannelType',c.ChannelType,v_Seq+1);
                   
          insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
               values(p_IdCredit,'Credit','PaFwChannel',c.FwChannel,v_Seq+1);
              
          v_Seq:=v_Seq + 3;
              
       end loop;
    
      --添加元素Credit.TotalAnnuity，包括以下期款及费用 annuity+power_fee+insurance_fee+screen_fee+post_fee-COUPON_AMOUNT
      insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
      select p_IdCredit,'Credit','*','PaTotalAnnuity',nvl(sum(TotalAnnuity),0),v_Seq
      from(select nvl(annuity,0)+nvl(power_fee,0)+nvl(insurance_fee,0)+nvl(broken_screen_service,0)+nvl(stag_insurance_service,0)
            -nvl(coupon_amount,0)+nvl(treasure_box_fee,0)+nvl(COMPREHENSIVE_INSURANCE,0) as TotalAnnuity
      from cs_credit_fee where id_credit=p_IdCredit);
         
       for fee in(select t.insurance_fee from cs_credit_fee t where t.id_credit=p_IdCredit)
         loop
           
           --保险费用
           insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
           values(p_IdCredit,'Credit','*','PaInsuranceFee',fee.insurance_fee,v_Seq+1);
           
           v_Seq:=v_Seq + 1;
           
       end loop;       
     
       --区分召回客户的决策流程
       select b.name  ,b.ident,b.id,a.credit_amount into v_PersonName,v_Ident,v_IdPerson,v_CreditAmount from cs_credit a join cs_person b on a.id_person=b.id and a.id=p_IdCredit;
       
       select count(1) into v_Count from status_change_information where personname=v_PersonName and personident=v_Ident
                                                                         and credit_type=v_CreditType and begin_time<=v_CommitTime and end_time>=v_CommitTime;
       
       if v_Count=0 then
         
          v_IsRecall:=0;
          
       else
         
          select credit_amount,goodsnewcategory into v_SCI_Amount,v_SCI_Category from status_change_information
           where rownum=1 and personname=v_PersonName and personident=v_Ident;
           
          if v_CreditAmount<=v_SCI_Amount and v_NewCategory=v_SCI_Category then
            
             v_IsRecall:=1;
             
          else
             v_IsRecall:=2;
          end if;
          
       end if;
       
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            values(p_IdCredit,'Credit','*','PaIsRecall',v_IsRecall,v_Seq);
              
       v_ElementType:='Address';
       
       for address in (select decode(address_type,1,'ResidentAddress',2,'CurrentAddress','CompanyAddress') address_type,province,city,region,town,street,building,room
              from cs_address where id_credit=p_IdCredit order by address_type)
       loop
         
           insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,address.address_type,'PaProvince',address.province,v_Seq+1);
           
           insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,address.address_type,'PaCity',address.city,v_Seq+2);
           
           insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,address.address_type,'PaRegion',address.region,v_Seq+3);
           
           insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,address.address_type,'PaTown',address.town,v_Seq+4);
           
           insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,address.address_type,'PaStreet',address.street,v_Seq+5);
           
           insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,address.address_type,'PaBuilding',address.building,v_Seq+6);
           
           insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,address.address_type,'PaRoom',address.room,v_Seq+7);
               
               v_Seq:=v_Seq + 7;
               
       end loop;
       
       v_ElementType:='Career';

       for employer in (select nvl(fun_getreg_value(399,a.company_type),'') as company_type,nvl(fun_getreg_value(397,a.industry),'') as industry,a.position,
              nvl(b.university,a.company_name1) university,nvl(a.department,'') as department,decode(a.start_date, null, '', to_char(a.start_date, 'yyyy-MM-dd')) startdate,decode(a.end_date, null, '', to_char(a.end_date, 'yyyy-MM-dd')) enddate
              from cs_employer a,university b where a.company_name=b.id(+) and a.id_credit=p_IdCredit)
       loop
         
           v_Position:=employer.position;
           
           /*insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,'CompanyType',employer.company_type,v_Seq+1);*/
           insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,'PaIndustry',employer.Industry,v_Seq+1);
               
           v_Seq:=v_Seq + 1;
               
           insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,'PaPosition',employer.position,v_Seq+1);
               
           v_Seq:=v_Seq + 1;
               
           /*insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,'University',pkg_decision.filterStr(employer.university),v_Seq+4);
           insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,'Department',employer.department,v_Seq+5);
           insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,'StartDate',employer.startdate,v_Seq+6);
           if employer.enddate is not null then
               insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
                   (p_IdCredit,v_ElementType,'EndDate',employer.enddate,v_Seq+7);
               v_Seq:=v_Seq + 7;
           else
               v_Seq:=v_Seq + 6;
           end if;*/
           
       end loop;
  
       v_ElementType:='Person';
       
       select name,ident,sex,nvl(ident_exp,''),nvl(fun_getreg_value(790,a.national),'汉')
         into v_PersonName,v_Ident,v_Sex,v_IdentExp,v_National
         from cs_person a where id=v_IdPerson;

       if length(v_Ident)=15 then
         
           v_Birthday:=to_char(to_date('19'||substr(v_Ident,7,6),'yyyy-MM-dd'),'yyyy-MM-dd');
           
           select to_number(to_char(sysdate,'yyyy')) - to_number('19'||substr(v_Ident,7,2)) into v_Age from dual;
           
       else
         
           v_Birthday:=to_char(to_date(substr(v_Ident,7,8),'yyyy-MM-dd'),'yyyy-MM-dd');
           
           select to_number(to_char(sysdate,'yyyy')) - to_number(substr(v_Ident,7,4)) into v_Age from dual;
           
       end if;
       
       strSql:='insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
                select '||p_IdCredit||','''||v_ElementType||''','||'''PaBirthday'''||','''||v_Birthday||''','||(v_Seq+1)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''PaIdPerson'''||','''||v_IdPerson||''','||(v_Seq+2)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''PaAge'''||','''||v_Age||''','||(v_Seq+3)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''PaSex'''||','''||v_Sex||''','||(v_Seq+4)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''PaName'''||','''||v_PersonName||''','||(v_Seq+5)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''PaIdent'''||','''||v_Ident||''','||(v_Seq+6)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''PaIdentExp'''||','''||to_char(v_IdentExp,'yyyy-MM-dd')||''','||(v_Seq+7)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''PaNational'''||','''||v_National||''','||(v_Seq+9)||' from dual';
                
       v_Seq:=v_Seq +6;
       
       Execute immediate strSql;
            
       select a.id_product into  v_IdProduct from cs_credit a where a.id=p_IdCredit;
       
       if v_IdProduct!=0 then
         
         v_ElementType:='Product';
         
         select prod_type,search_type,payment_num
           into v_ProdType,v_SearchType,v_PaymentNum
           from product where id=v_IdProduct;

         strSql:='insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
                  select '||p_IdCredit||','''||v_ElementType||''','||'''PaProdType'''||','''||v_ProdType||''','||(v_Seq+1)||' from dual
                  union select '||p_IdCredit||','''||v_ElementType||''','||'''PaSearchType'''||','''||v_SearchType||''','||(v_Seq+2)||' from dual
                  union select '||p_IdCredit||','''||v_ElementType||''','||'''PaPaymentNum'''||','''||v_PaymentNum||''','||(v_Seq+3)||' from dual';
                  
         Execute immediate strSql;
         
         v_Seq:=v_Seq +3;
         
        end if;    
    
     select a.id_sellerplace into  v_IdSellerPlace from cs_credit a where a.id=p_IdCredit;

       if v_IdSellerPlace>0 then
         
           v_ElementType:='SellerPlace';
           
           select province,city,pos_code
             into v_Province,v_City,v_PosCode
             from sellerplace where id=v_IdSellerPlace;
             
           v_UseCity:=v_City;

           strSql:='insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
                    select '||p_IdCredit||','''||v_ElementType||''','||'''PaProvince'''||','''||v_Province||''','||(v_Seq+1)||' from dual
                    union select '||p_IdCredit||','''||v_ElementType||''','||'''PaPosCode'''||','''||v_PosCode||''','||(v_Seq+2)||' from dual
                    union select '||p_IdCredit||','''||v_ElementType||''','||'''PaCity'''||','''||v_City||''','||(v_Seq+3)||' from dual';

           v_Seq:=v_Seq +3;
           
           Execute immediate strSql;
           
      end if;      

      for c in(select decode(a.business_code,null,b.store_no,a.business_code) as PosCode
                ,b.STORE_NAME as  Name 
                ,decode(store_province,null,g.AREA_NAME,store_province) as Province
                ,store_city as City
                ,store_address as Address
                from cs_credit_ext c
                left join cs_merchant_store b on b.contract_no=c.contract_no
                left join bs_area_info g on g.AREA_CODE=c.user_prov_no 
                left join (
                select p.business_code ,'中移' as pos_type ---===中移动表
                from mv_bs_store p 
                union 
                select q.business_code ,'中联' as pos_type ---===中联表
                from mv_xy_bs_store q) a on a.business_code =b.store_no where c.contract_no=v_ContractNo and rownum=1
         )loop
         
          insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
               values(p_IdCredit,'SellerPlace','PaPosCode',c.PosCode,v_Seq+1);
               
          insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
               values(p_IdCredit,'SellerPlace','PaName',c.Name,v_Seq+1);
               
          insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
               values(p_IdCredit,'SellerPlace','PaProvince',c.Province,v_Seq+1);
               
          insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
               values(p_IdCredit,'SellerPlace','PaCity',c.City,v_Seq+1);
               
          insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
               values(p_IdCredit,'SellerPlace','PaAddress',c.Address,v_Seq+1);
               
          if v_CreditType in ('XF','XFC')
          then
            
             v_PosCode:=c.PosCode;
             
          end if;
          
          v_Seq:=v_Seq + 5;
          
       end loop;      

     insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
     select p_IdCredit,'SellerPlace','PaAfPosCate',nvl(max(t.af_type),0),v_Seq from mv_df_af_gspn t
     where t.status='a' and t.ident=v_PosCode;
     
     v_Seq:=v_Seq +1;

       if v_CreditType='XF'
       then
         
         insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
         select p_IdCredit,'SellerPlace','PaAfSaCate',nvl(max(t.af_type),0),v_Seq from mv_df_af_gspn_abnormal t
         where t.status='a' and t.ident=v_SaIdent;
         
       else
         
         insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
         select p_IdCredit,'SellerPlace','PaAfSaCate',nvl(max(t.af_type),0),v_Seq from mv_df_af_gspn_abnormal t
         where t.status='a' and t.id_sa=v_IdSa;
         
       end if;
       
       v_Seq:=v_Seq + 1;

      insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
      select p_IdCredit,'SellerPlace','PaRiskCate',risk_cate,v_Seq+1 from mv_df_pos_risk_cate_gl
      where pos_code=v_PosCode;

      insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
       select p_IdCredit,'SellerPlace','PaRiskCate_Challenge',risk_cate_Challenge,v_Seq+2 from mv_df_pos_risk_cate_gl
       where pos_code=v_PosCode;

       for c in(with a as (select cc.id id_credit,cg.id_goods_category,cg.producer,
                 c.name goods_category,t.name goods_type,row_number() over(order by cg.goods_price desc) rn
                from cs_credit cc
                join cs_goods cg on cc.id=cg.id_credit
                join goods_category c on cg.id_goods_category=c.id
                join goods_type t on cg.id_goods_type=t.id
                where cc.id=p_IdCredit)
                select case when id_goods_category=7 and (goods_type like '%苹果%' or producer like '%苹果%'
                   or upper(producer) like '%IPHONE%' or upper(producer) like '%APPLE%') THEN '苹果'
                   else to_char(goods_category) end as new_category
                from a where rn=1
         )loop
         
           insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
           values(p_IdCredit,'Goods','PaNewCategory',c.new_category,v_Seq);
           
           v_Seq:=v_Seq + 1;
           
           v_NewCategory:=c.new_category;
           
         end loop;
         
       for goods in (select b.name goods_category,c.name goods_type,producer,brand,goods_price from cs_goods a,goods_category b,goods_type c
              where a.id_goods_category=b.id and a.id_goods_type=c.id and a.id_credit=p_IdCredit)
       loop
         
           if v_MaxGoodsPrice=-1 or v_MaxGoodsPrice<goods.goods_price then
             
              v_MaxGoodsPrice:=goods.goods_price;
              
              v_MaxGoodsType:=goods.goods_type;
              
           end if;

           if v_MinGoodsPrice=-1 or v_MinGoodsPrice>goods.goods_price then
             
              v_MinGoodsPrice:=goods.goods_price;
              
              v_MinGoodsType:=goods.goods_type;
              
           end if;

           insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,'Goods','PaCategory',goods.goods_category,v_Seq+1);
               
           insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,'Goods','PaGoodsType',goods.goods_type,v_Seq+2);
               
           insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,'Goods','PaProducer',goods.producer,v_Seq+3);
               
           v_Seq:=v_Seq + 3;           
           
           v_GoodsVolume:=v_GoodsVolume+1;
           
       end loop;
       
       insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,'Goods','PaMaxPrice',v_MaxGoodsPrice,v_Seq+1);
               
       insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,'Goods','PaMaxGoodsType',v_MaxGoodsType,v_Seq+2);
               
       insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,'Goods','PaMinGoodsType',v_MinGoodsType,v_Seq+3);
               
       insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,'Goods','PaGoodsVolume',v_GoodsVolume,v_Seq+4);
               
        v_Seq:=v_Seq + 4;
       
       v_ElementType:='FamilyInfo';
       
       for familyinfo in (select decode(id_spouse, 1, '未婚', 2, '已婚', '其它') mariage,nvl(child,0) children_count,fun_getreg_value(2, house_type) house_type,expense_month
                   from cs_family_info where id_credit=p_IdCredit)
       loop
         
          insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
                 (p_IdCredit,v_ElementType,'PaMarriage',familyinfo.mariage,v_Seq+1);
                 
          v_Seq:=v_Seq + 1;
          
       end loop;
       
       v_ElementType:='Other';

       for experience in (select nvl(a.total_wk_exp,0) total_wk_exp,nvl(a.wk_income,0) wk_income,nvl(a.other_income,0) other_income,nvl(a.family_income,0) family_income,
              nvl(fun_getreg_value(11,a.education),'') education,nvl(ssi,'') ssi,nvl(a.cur_wk_exp,0) cur_wk_exp,fun_getreg_value(776,a.bank_name) bank_name,a.bank_no,a.branch,
              fun_get_ybscity(a.id_ybs_city,a.id_credit) bank_region,nvl(a.is_dd,0) is_dd,nvl(a.is_ssi,0) is_ssi,to_char(a.fst_date_pay, 'yyyy-MM-dd') fst_date_pay
              from cs_experience a where id_credit=p_IdCredit)
       loop
         
          if v_Position=9 then
            
               v_varTemp:='LeftGraduateMonth';
               
          else
            
               v_varTemp:='CurrentEmpMonth';
               
          end if;
          
          /*insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
                 (p_IdCredit,v_ElementType,v_varTemp,experience.total_wk_exp,v_Seq+1);*/
                 
          insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
                 (p_IdCredit,v_ElementType,'PaPersonIncome',experience.wk_income,v_Seq+2);
                 
          insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
                 (p_IdCredit,v_ElementType,'PaOtherIncome',experience.other_income,v_Seq+3);
                 
          insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
                 (p_IdCredit,v_ElementType,'PaFamilyIncome',experience.family_income,v_Seq+4);
                 
          insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
                 (p_IdCredit,v_ElementType,'PaEducation',experience.education,v_Seq+5);
                 
          insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
                 (p_IdCredit,v_ElementType,'PaBankName',experience.bank_name,v_Seq+6);
                 
          insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
                 (p_IdCredit,v_ElementType,'PaBankNo',experience.bank_no,v_Seq+7);
                 
          insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
                 (p_IdCredit,v_ElementType,'PaBankCity',experience.bank_region,v_Seq+8);

          v_Seq:=v_Seq + 8;
          
       end loop;       
       
       --客户本人手机号码所属城市
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'Other','*','PaPhoneNoCity',nvl(max(a.city),'null'),v_Seq+1
       from mv_df_phone_attribution_gl a where a.mobilenumber=substr(v_PersonMobile,1,7);
       
       --(select substr(contact_value,1,7) from cs_contact t where t.id_credit=p_IdCredit and t.person_type = '1' and t.contact_type='2');
       
       v_Seq:=v_Seq + 1;    
       
       --hongbinbin 20191010
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'Other','*','PaCreditSource', credit_source as CreditSource, --即速用用户来源渠道
          v_Seq+1
       from jsy_credit_source where id_credit=p_IdCredit;
         
       v_Seq:=v_Seq + 1;      

     --客户在申请此合同时，前30天内的合同总次数
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            select p_IdCredit,'HardCheck','*','PaApplicationLast30Day',count(1),v_Seq from cs_credit a where a.id_person=v_IdPerson
               and a.id<>p_IdCredit and trunc(a.create_time)>=trunc(sysdate)-30 and a.create_time<v_CommitTime;--2017-09-22增加时间范围
               
       v_Seq:=v_Seq + 1;
       
       --客户在申请此合同时，当天取消的合同总数
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            select p_IdCredit,'HardCheck','*','PaCancleApplicationSameDay',count(1),v_Seq from cs_credit a where a.id_person=v_IdPerson
               and trunc(a.commit_time)=trunc(sysdate) and a.status='t' and a.id<>p_IdCredit  and a.create_time<v_CommitTime;--2017-09-22增加时间范围
               
       v_Seq:=v_Seq + 1;      
       
       for prev_instalment in
          (select to_char(min(date_due_first),'yyyy-MM-dd') as date_due_first,--客户最早的应还款日期
               max(cpd) as cpd,--客户在申请合同时其他合同的现在的未还的逾期天数，精确到天
               max(max_dpd) as max_dpd,--客户在申请合同时历史上最大逾期天数，精确到天
               max(last_3m_dpd) as last_3m_dpd, --客户在申请合同时最近三个月（自然月）的最大逾期天数，精确到天
               max(max_cpd) as max_cpd,
               max(last_3m_cpd) as last_3m_cpd
              from (
                select a.id_person ,
                date_due_first,--客户最早的应还款日期
                cpd,--客户在申请合同时其他合同的现在的未还的逾期天数，精确到天
                remaining_amount, --客户在申请此合同时其他合同剩余的未还期金额（包含未到期的）
                remaining_instal, --客户在申请此合同时其他合同剩余的未还期数之和（包含未到期的）
                max_dpd,--客户在申请合同时历史上最大逾期天数，精确到天
                last_3m_dpd, --客户在申请合同时最近三个月（自然月）的最大逾期天数，精确到天
                max_cpd,
                last_3m_cpd,
                date_3m_dpd,
                m_paid_ndpd,--客户在申请此合同前成功还款且没有逾期的期数总合
                m_due--客户在申请此合同时前面已经到期的期数之和
                from mv_DF_PD_SUM_GL   a 
                join cs_credit c on a.contract_no=c.contract_no and c.credit_channel='GIVEU'

                union

                select b.id as id_person,
                null as date_due_first,--客户最早的应还款日期
                0 as cpd,--客户在申请合同时其他合同的现在的未还的逾期天数，精确到天
                0 as remaining_amount, --客户在申请此合同时其他合同剩余的未还期金额（包含未到期的）
                0 as remaining_instal, --客户在申请此合同时其他合同剩余的未还期数之和（包含未到期的）
                max_dpd,--客户在申请合同时历史上最大逾期天数，精确到天
                last_3m_dpd, --客户在申请合同时最近三个月（自然月）的最大逾期天数，精确到天
                0 as max_cpd,
                0 as last_3m_cpd,
                null as date_3m_dpd,
                0 as m_paid_ndpd,--客户在申请此合同前成功还款且没有逾期的期数总合
                0 as m_due--客户在申请此合同时前面已经到期的期数之和
                from qk_pd_total a
                join cs_person b on a.cust_no=b.IDENT
                --where a.cust_no=v_ident 
                )
              where id_person=v_IdPerson)
       loop
              
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
              values(p_IdCredit,'HardCheck','*','PaDateDueFirst',prev_instalment.date_due_first,v_Seq+1);                    
          v_Seq:=v_Seq + 1;
       
        --客户在申请合同时其他合同的现在的未还的逾期天数，精确到天
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values(p_IdCredit,'HardCheck','*','PaCpd',prev_instalment.cpd,v_Seq);                     
          v_Seq:=v_Seq + 1;
 
        --客户在申请合同时最近三个月（自然月）的最大逾期天数，精确到天
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values(p_IdCredit,'HardCheck','*','PaLast3mDpd',prev_instalment.last_3m_dpd,v_Seq);               
          v_Seq:=v_Seq + 1;
 
        --客户在申请合同时历史上最大逾期天数，精确到天
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values(p_IdCredit,'HardCheck','*','PaMaxCpd',prev_instalment.max_cpd,v_Seq);               
          v_Seq:=v_Seq + 1;
 
          --客户在申请合同时历史上最大逾期天数，精确到天
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values(p_IdCredit,'HardCheck','*','PaMaxDpd',prev_instalment.max_dpd,v_Seq);               
          v_Seq:=v_Seq + 1;
   
          --客户在申请合同时最近三个月（自然月）的最大逾期天数，精确到天
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values(p_IdCredit,'HardCheck','*','PaLast3mCpd',prev_instalment.last_3m_cpd,v_Seq);               
          v_Seq:=v_Seq + 1;
        
   end loop;       
        commit;
      --客户在申请此合同时前面一张通过的合同的申请时间，除拒绝和取消的合同外（状态为d/t/x/u的除外）update_time2016/11/30
        select to_char(max(create_time),'yyyy-MM-dd HH24:mi:ss') into v_TempVue from cs_credit
             where id_person=v_IdPerson and create_time<=v_CommitTime and credit_type in('SS','SC','XF','SP') and id!=p_IdCredit and status not in('d','t','x','u','r','q');
             
             if v_TempVue is not null then
               
               insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
               values(p_IdCredit,'HardCheck','*','PaMaxPrevCommitTime',v_TempVue,v_Seq );
              /*select p_IdCredit,'HardCheck','*','MaxPrevCommitTime',to_char(max(create_time),'yyyy-MM-dd HH24:mi:ss'),v_Seq from cs_credit
               where id_person=v_IdPerson and create_time<=v_CommitTime and credit_type in('SS','SC') and id!=p_IdCredit and status not in('d','t','x','u','r','q');*/
             
             end if;
             
       v_Seq:=v_Seq + 1;
       
       --该客户上一单拒绝原因
       select nvl(max(id),0) into v_IdCredit from cs_credit t where id_person=v_IdPerson and t.id!=p_IdCredit and t.status='d';
       if v_IdCredit!=0 then
         
         insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         select p_IdCredit,'HardCheck','*','PaPreRejectReason',case when c.event is null then fun_get_reject_reason(a.id) else replace(replace(fun_getreg_value(779,nvl(c.event,-1)),'[',''),']','') end,v_Seq
         from cs_credit a,wfi_final_decision c where a.id=c.id_credit(+) and a.id=v_IdCredit;
         
       end if;
       
       v_Seq:=v_Seq + 1;
       
       --客户在申请此合同时前面一张拒绝的合同的申请时间（状态为d）
       select to_char(max(create_time),'yyyy-MM-dd HH24:mi:ss') into v_TempVue from cs_credit
             where id_person=v_IdPerson and create_time<=v_CommitTime and (credit_type in('SS','SC','MQ','XF','SP') or (credit_type='QB' and id_sa is not null)) and id!=p_IdCredit and status='d';
        
        if  v_TempVue is not null then
          
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                values(p_IdCredit,'HardCheck','*','PaRejectPrevCommitTime',v_TempVue,v_Seq);
                
          v_Seq:=v_Seq + 1;
          
       end if;      
        
      --客户在申请此合同时现行状态的合同数量(状态为a）
      select count(1) into v_Count from cs_credit where id_person=v_IdPerson and create_time<=v_CommitTime and id!=p_IdCredit and status ='a';
      
      insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
           values(p_IdCredit,'HardCheck','*','PaSumDue',v_Count,v_Seq);
           
      v_Seq:=v_Seq + 1;
      
      --IsMysteryIdent 客户申请时身份证是否属于暗访人员白名单(select ident from mv_WHITELIST_MYST_INVE where status='a')
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         select p_IdCredit,'HardCheck','*','PaIsMysteryIdent',decode(count(1),0,0,1),v_Seq
         from mv_WHITELIST_MYST_INVE t where status='a' and t.ident=v_Ident;
         
       v_Seq:=v_Seq + 1;
       
       --客户身份证黑名单
       select count(1) into v_Count from customer_blacklist where ident=v_Ident;
       
       if v_Count>0 then
         
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
              values(p_IdCredit,'HardCheck','*','PaBlackListIDent','1',v_Seq);
              
          v_Seq:=v_Seq + 1;
          
       end if;
       
      --客户本人手机号码黑名单
       select count(1) into v_Count from customer_blacklist
       where mobile in(select contact_value from cs_contact where id_person=v_IdPerson and person_type='1' and contact_type in('2','3','18','19'));
       
       if v_Count>0 then
         
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
              values(p_IdCredit,'HardCheck','*','PaBlackListMobile','1',v_Seq);
              
          v_Seq:=v_Seq + 1;
          
       end if;
       
       --公司名称黑名单
       select count(1) into v_Count from company_blacklist where employer_name in(select company_name1 from cs_employer where id_person=v_IdPerson);
       
       if v_Count>0 then
         
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
              values(p_IdCredit,'HardCheck','*','PaBlackListCompanyName','1',v_Seq+1);
              
          v_Seq:=v_Seq + 1;
          
       end if;       
        
       --客户其它手机号码黑名单
       select count(1) into v_Count from customer_blacklist
       where mobile in(select contact_value from cs_contact where id_person=v_IdPerson and person_type<>'1' and contact_type in('2','3','18','19'));
       
       if v_Count>0 then
         
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
              values(p_IdCredit,'HardCheck','*','PaBlackListOtherMobile','1',v_Seq+1);
              
          v_Seq:=v_Seq + 1;
          
       end if;       
       
       --客户家庭电话黑名单
       select count(1) into v_Count from customer_blacklist
       where home_num in(select contact_value from cs_contact where id_person=v_IdPerson and contact_type='18');
       
       if v_Count>0 then
         
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
              values(p_IdCredit,'HardCheck','*','PaBlackListHomePhone','1',v_Seq+1);
              
          v_Seq:=v_Seq + 1;
          
       end if;
       
       --客户QQ号码黑名单 2016/07/07 wangxiaofeng
       select count(1) into v_Count from cs_contact c
       where c.person_type='1' and c.contact_type='13' and c.id_credit=p_IdCredit
       and exists( select * from customer_blacklist b where b.qq=regexp_substr(c.contact_value,'[0-9]+'));
       
       if v_Count>0 then
         
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
              values(p_IdCredit,'HardCheck','*','PaBlackListQQ','1',v_Seq+1);
              
          v_Seq:=v_Seq + 1;
          
       end if;       
        
       --公司工作电话黑名单
       select count(1) into v_Count from company_blacklist where office_num in(select contact_value from cs_contact where id_person=v_IdPerson and contact_type='3');
       if v_Count>0 then
         
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
              values(p_IdCredit,'HardCheck','*','PaBlackListOfficePhone','1',v_Seq+1);
              
          v_Seq:=v_Seq + 1;
          
       end if;  
       
      --客户此合同一共提供了多少个电话
       select count(1) into v_Count from cs_contact where contact_type in ('2','3','18','19') and id_credit=p_IdCredit;
       
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            values(p_IdCredit,'HardCheck','*','PaTotalPhoneCount',v_Count,v_Seq+1);
            
       v_Seq:=v_Seq + 1;
        
       --一共提供了多少个家庭联系人电话
       select count(1) into v_Count from cs_contact
       where person_type in(select reg_val_code from registers t where reg_number=265 and status='a' and reg_val_code!='1') and contact_type in('2','3','18','19') and id_credit=p_IdCredit;
       
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            values(p_IdCredit,'HardCheck','*','PaTotalFamilyPhoneCount',v_Count,v_Seq+1);
            
       v_Seq:=v_Seq + 1;
        
       --一共提供了多少个其他联系人电话
       select count(1) into v_Count from cs_contact
       where person_type in(select reg_val_code from registers t where reg_number=396 and status='a') and contact_type in('2','3','18','19') and id_credit=p_IdCredit;
       
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            values(p_IdCredit,'HardCheck','*','PaTotalOtherPhoneCount',v_Count,v_Seq+1);
            
       v_Seq:=v_Seq + 1;
        
       --一共提供了多少个家庭联系人电话和其他联系人中亲人的电话
       select count(1) into v_Count from cs_contact a
       where a.contact_type in(2,3,18,19)
        and a.person_type!='1'
        and (a.person_type in('BA','BB','BC','SA','SB','SC','5A','5B','5C')
            or a.person_type in(select reg_val_code from registers b where b.reg_number=265))
        and a.id_credit=p_IdCredit;
        
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            values(p_IdCredit,'HardCheck','*','PaTotalRelativePhoneCount',v_Count,v_Seq+1);
            
       v_Seq:=v_Seq + 1; 
         
         ----PackageInfo  套餐类型          yangzhenxian                          2019-04-28
         for d in(with temp as (
             select PACKAGE_INFO as PackageInfo from cs_goods where id_credit=p_IdCredit order by update_time desc
              )
              select * from temp where rownum=1
         )
         loop
           
           insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
           values( p_IdCredit,'Goods','*','PaPackageInfo',d.PackageInfo,v_Seq);
           
           v_Seq:=v_Seq + 1;
           
         end loop;     
       
       v_ElementType:='Contact';
       
       for contact in (select fun_getreg_value(395,t.contact_type) contact_type,t.contact_type cont_type,contact_value from cs_contact t where person_type='1' and id_credit=p_IdCredit)
       loop
         
           insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,'Pa'||contact.contact_type,contact.contact_value,v_Seq+1);
           v_Seq:=v_Seq + 1;

           if contact.cont_type='3' then
             
             v_OfficeTel:=contact.contact_value;
             
           end if;
           
           if contact.cont_type='2' then
             
             v_PersonMobile:=contact.contact_value;
             
           end if;
           
       end loop;  
       
        --hongbinbin  20190924
       for qq in (
         select 
            case when contact_value like '%qq.com' then substr(regexp_substr(contact_value,'[0-9]+'),1,1) end as QQIntDigit---qq号首字母
            ,case when contact_value like '%qq.com' then length(regexp_substr(contact_value,'[0-9]+'))end as QQLength---qq号长度
            from (select a.person_type,a.contact_type,a.contact_value,
                row_number()over (partition by id_credit,person_type,contact_type,contact_value order by  update_time desc) as rank_id
                from cs_contact a where a.id_credit=p_IdCredit) ctpq
            where ctpq.rank_id=1 and ctpq.person_type='1' and ctpq.contact_type='11'
         )loop
         
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,'*','PaQQIntDigit',qq.QQIntDigit,v_Seq+1);
               
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,'*','PaQQLength',qq.QQLength,v_Seq+2);
       
           v_Seq:=v_Seq + 2;
         
         end loop;              
        
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'HardCheck','*','PaOffPhoneUseSameCityCount',count(distinct a.id),v_Seq+1 from cs_credit a,cs_contact b,sellerplace c,cs_address ad
         where a.id=b.id_credit(+) and a.id_sellerplace=c.id(+) and b.contact_type='3' and a.id_person!=v_IdPerson
         and a.id=ad.id_credit(+) and ad.address_type=2
         and a.status not in('t','r') and a.commit_time>=sysdate-30  and a.commit_time<=v_CommitTime
         and b.contact_value=nvl(v_OfficeTel,'#') and nvl(c.city,ad.city)=v_UseCity;
       --and b.contact_value in(select t.contact_value from cs_contact t where t.contact_type='3' and t.id_credit=p_IdCredit) and c.city=v_UseCity;
       
       v_Seq:=v_Seq + 1;
        
       --其他联系人电话在最近180天被其他不同的客户用作其他所有电话（办公电话除外）总的次数
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            values(p_IdCredit,'HardCheck','*','PaOtherPhoneUseCount',v_OtherPhoneUseCount,v_Seq+1);
            
       v_Seq:=v_Seq + 1;
        
       --其他联系人电话在过去30天在同个城市被其他人重复使用的情况；状态不等于tr（办公电话除外）总的次数
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            values(p_IdCredit,'HardCheck','*','PaOtherPhoneUseSameCityCount',v_OtherPhoneUseSameCityCount,v_Seq+1);
            
       v_Seq:=v_Seq + 1;
        
       --1. SumAgrSameOffPhoneLast6M:客户在申请此合同时，客户办公号码在过去6个月被其他客户（作为申请人办公号码）
       --使用过的可衡量30天逾期的合同数( select sum(agr_fpd30) from risk_control.df_pd_sum_gl)
       --2. SumDefSameOffPhoneLast6M:客户在申请此合同时，客户办公号码在过去6个月被其他客户（作为申请人办公号码）
       --使用过的出现30天逾期的合同数( select sum(fpd30) from risk_control.df_pd_sum_gl)
       for cs in(select nvl(sum(decode(a.agr_fpd30,null,0,a.agr_fpd30)),0) agr_fpd30,
                 nvl(sum(decode(a.fpd30,null,0,a.fpd30)),0) fpd30
                 from mv_df_pd_sum_gl a
                 join cs_contact b on b.id_credit=a.id_credit
                 where b.contact_type='3'
                 and b.contact_value in(select contact_value from cs_contact c
                                      where c.contact_type='3' and c.person_type='1' and c.id_credit=p_IdCredit)
                 and b.update_time>=trunc(v_CommitTime-180) and b.update_time<=v_CommitTime)
       loop
         
         insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                values(p_IdCredit,'HardCheck','*','PaSumAgrSameOffPhoneLast6M',cs.agr_fpd30,v_Seq+1);
                
           v_Seq:=v_Seq + 1;
           
         insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                values(p_IdCredit,'HardCheck','*','PaSumDefSameOffPhoneLast6M',cs.fpd30,v_Seq+1);
                
           v_Seq:=v_Seq + 1;
           
       end loop;
               
       --客户在申请此合同时通过状态的合同数量（状态为a/k/p）
       for pre_credit in (select count(1) sumdue,sum(credit_amount) sumamount from cs_credit where id_person=v_IdPerson and id!=p_IdCredit and status in ('a','k','p'))
       loop
         
           insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                values(p_IdCredit,'HardCheck','*','PaSumPassContract',pre_credit.sumdue,v_Seq+1);
                
           v_Seq:=v_Seq + 1;
           
           --客户在申请此合同时通过状态的合同贷款额之和（状态为a/k/p）
           --select count(sum(prev_credit_amount)) into v_Count from v_previous_contract where prev_status in ('a','k','p') and id_credit=p_IdCredit group by id_credit;
           insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                values(p_IdCredit,'HardCheck','*','PaSumPassCreditAmount',pre_credit.sumamount,v_Seq+1);
                
           v_Seq:=v_Seq + 1;
           
       end loop;
        
       for pre_credit in (select to_char(max(commit_time),'yyyy-MM-dd HH24:mi:ss') commit_time,count(1) sumdue,sum(annuity) annuity from cs_credit where id_person=v_IdPerson and commit_time<=v_CommitTime and id!=p_IdCredit and status ='a')
       loop
         
           --客户在申请此合同时现行状态的合同的每期期款之和(状态为a）
           --select count(sum(prev_annuity)) into v_Count from v_previous_contract where prev_status='a' and id_credit=p_IdCredit group by id_credit;
           insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                values(p_IdCredit,'HardCheck','*','PaSumSurplusValueInstalment',pre_credit.annuity,v_Seq+1);
                
           v_Seq:=v_Seq + 1;
           
       end loop;
               
       for phone_depository in (select relationship,contact_value,status,contact_type,id_sellerplace,city from v_phone_depository where id_credit=p_IdCredit)
       loop
         
          if phone_depository.relationship='client' and phone_depository.contact_type='2' then
            
              --客户在申请此合同时，前6个月内客户手机号码被使用过次数
              insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                   select p_IdCredit,'HardCheck','*','PaSameMobileLast6Month',count(1),v_Seq+1 from v_phone_depository
                    where contact_value=phone_depository.contact_value and contact_type='2' and relationship='client'
                    and id_person!=v_IdPerson and status not in('r','t') and commit_time>=sysdate-180 and commit_time<=v_CommitTime;
                    
              v_Seq:=v_Seq + 1;
              
              --客户在申请此合同时，客户手机号码被历史其他客户（作为申请人移动电话）使用过的次数（除状态为t,d,r的合同）
              insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                   select p_IdCredit,'HardCheck','*','PaSameMobileHisCount',count(1),v_Seq+1 from v_phone_depository
                    where contact_value=phone_depository.contact_value and contact_type='2' and relationship='client'
                    and id_person!=v_IdPerson and status not in('d','t','r') and commit_time<=v_CommitTime;
                    
              v_Seq:=v_Seq + 1;
              
              --客户办公电话在过去30天在同个城市被其他人重复使用为办公电话的情况；状态不等于tr 使用过的次数（除状态为t,r的合同）----------------------
              insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                   select p_IdCredit,'HardCheck','*','PaMobPhoneUseSameCityCount',count(1),v_Seq+1 from v_phone_depository
                    where contact_value=phone_depository.contact_value and id_person!=v_IdPerson and commit_time>=sysdate-30
                     and commit_time<=v_CommitTime and status not in('t','r') and city=phone_depository.city;
                     
              v_Seq:=v_Seq + 1;
              
              --客户办公电话在过去30天在同个城市被其他人重复使用为办公电话的情况；状态不等于tr 使用过的次数（除状态为t,r的合同）
              insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                   select p_IdCredit,'HardCheck','*','MobPhoneUseSamePosCount',count(1),v_Seq+1 from v_phone_depository
                    where contact_value=phone_depository.contact_value and id_person!=v_IdPerson and commit_time>=sysdate-30
                     and commit_time<=v_CommitTime and status not in('t','r') and id_sellerplace=phone_depository.id_sellerplace;
                     
              v_Seq:=v_Seq + 1;
              --客户在申请此合同时，客户手机号码存在，在职SA移动电话列表
              select count(1) into v_Count from sys_user_list a where upper(a.role_id)='SA' and a.phone=phone_depository.contact_value;
              
              if v_Count>0 then
                
                 insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                   values(p_IdCredit,'HardCheck','*','PaSAMobilelist','1',v_Seq+1);
                   
                 v_Seq:=v_Seq + 1;
                 
              end if;
              
          elsif phone_depository.relationship='client' and phone_depository.contact_type='18' then             
          
           --客户在申请此合同时，客户家庭固话被历史其他客户（作为家庭固话）使用过的次数（除状态为t,d,r的合同）--------------------------------------
              insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                   select p_IdCredit,'HardCheck','*','PaFamilyPhoneHisUseCount',count(1),v_Seq+1 from v_phone_depository
                    where contact_value=phone_depository.contact_value and contact_type='18' and relationship='client'
                     and commit_time<=v_CommitTime and id_person!=v_IdPerson and status not in('d','t','r');
                     
              v_Seq:=v_Seq + 1;
              
          elsif phone_depository.relationship='family' then
            
              --家庭成员电话在最近180天被其他不同的客户用作其他所有电话（办公电话除外）的次数
              select count(distinct(id_credit||contact_value)) into v_Count from v_phone_depository
              where contact_value=phone_depository.contact_value and id_person!=v_IdPerson and commit_time>=sysdate-180 and commit_time<=v_CommitTime and status not in('t','r');
              
              v_FamilyPhoneUseCount:=v_FamilyPhoneUseCount+v_Count;
             
              --家庭成员电话在过去30天在同个城市被其他人重复使用的情况；状态不等于tr的次数
              select count(distinct(id_credit||contact_value)) into v_Count from v_phone_depository
              where contact_value=phone_depository.contact_value and id_person!=v_IdPerson and commit_time>=sysdate-30 and commit_time<=v_CommitTime and status not in('t','r') and city=phone_depository.city;
              
              v_FamilyPhoneUseSameCityCount:=v_FamilyPhoneUseSameCityCount+v_Count;
              
              --家庭成员电话在过去30天在同个门店被其他人重复使用的情况；状态不等于tr的次数
              select count(distinct(id_credit||contact_value)) into v_Count from v_phone_depository
              where contact_value=phone_depository.contact_value and id_person!=v_IdPerson and commit_time>=sysdate-30 and commit_time<=v_CommitTime and status not in('t','r') and id_sellerplace=phone_depository.id_sellerplace;
              
              v_FamilyPhoneUseSamePosCount:=v_FamilyPhoneUseSamePosCount+v_Count;
              
          elsif phone_depository.relationship='others' then
            
              --其他联系人电话在最近180天被其他不同的客户用作其他所有电话（办公电话除外）的次数
              select count(distinct(id_credit||contact_value)) into v_Count from v_phone_depository
              where contact_value=phone_depository.contact_value and id_person!=v_IdPerson and commit_time>=sysdate-180 and commit_time<=v_CommitTime and status not in('t','r');
             
              v_OtherPhoneUseCount:=v_OtherPhoneUseCount+v_Count;
              
              v_Seq:=v_Seq + 1;
              
              --其他联系人电话在过去30天在同个城市被其他人重复使用的情况；状态不等于tr的次数
              select count(distinct(id_credit||contact_value)) into v_Count from v_phone_depository
              where contact_value=phone_depository.contact_value and id_person!=v_IdPerson and commit_time>=sysdate-30 and commit_time<=v_CommitTime and status not in('t','r') and city=phone_depository.city;
             
              v_OtherPhoneUseSameCityCount:=v_OtherPhoneUseSameCityCount+v_Count;
              
              v_Seq:=v_Seq + 1;
              
              --其他联系人电话在过去30天在同个门店被其他人重复使用的情况；状态不等于tr的次数
              select count(distinct(id_credit||contact_value)) into v_Count from v_phone_depository
              where contact_value=phone_depository.contact_value and id_person!=v_IdPerson and commit_time>=sysdate-30 and commit_time<=v_CommitTime and status not in('t','r') and id_sellerplace=phone_depository.id_sellerplace;
              
              v_OtherPhoneUseSamePosCount:=v_OtherPhoneUseSamePosCount+v_Count;
              
              v_Seq:=v_Seq + 1;
              
          end if;
          
       end loop;
       
        --2017/05/24 wangxiaofeng
        --HardCheck FamilyPhoneUpdateCount:客户在申请此合同时该客户之前更改了家庭联系人电话的次数
        --HardCheck ThirdPhoneUpdateCount:客户在申请此合同时该客户之前更改了第三方联系人电话的次数
        for c in(select count(distinct case when person_type in ('其他亲戚','配偶','父母','兄弟姐妹','儿女') then t.contact_value else null end) familyphoneupdatecount
                ,count(distinct case when person_type='第三方' then t.contact_value else null end) thirdphoneupdatecount
                from cs_contact_portion t
                where t.status in(1,3) and t.contact_type='移动电话'
                and t.person_type in('其他亲戚','配偶','父母','兄弟姐妹','儿女','第三方') and t.id_person=v_IdPerson and t.update_time<v_CommitTime--2017-09-22增加时间范围
        )loop
        
          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
           values(p_IdCredit,'HardCheck','*','PaFamilyPhoneUpdateCount',c.familyphoneupdatecount,v_Seq+1);
           
          v_Seq:=v_Seq + 1;
          
        end loop;
        
       --家庭成员电话在最近180天被其他不同的客户用作其他所有电话（办公电话除外）总的次数
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            values(p_IdCredit,'HardCheck','*','PaFamilyPhoneUseCount',v_FamilyPhoneUseCount,v_Seq+1);
            
       v_Seq:=v_Seq + 1;
       
       --家庭成员电话在过去30天在同个城市被其他人重复使用的情况；状态不等于tr（办公电话除外）总的次数
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            values(p_IdCredit,'HardCheck','*','PaFamilyPhoneUseSameCityCount',v_FamilyPhoneUseSameCityCount,v_Seq+1);
            
       v_Seq:=v_Seq + 1;       
       
         --2016/12/02 wangxiaofeng 在hardcheck类别添加元素IsFpd10SamePhoneLast6M
         --客户在申请合同时，客户号码（不包含办公电话号码）在过去6个月被其他申请人使用时是否出现fpd10 逾期
         insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         select p_IdCredit,'HardCheck','*','PaIsFpd10SamePhoneLast6M',decode(nvl(sum(m.fpd10),0),0,0,1),v_Seq+1
         from v_phone_depository a
         join mv_df_pd_sum_gl m on m.contract_no=a.contract_no
         where a.credit_type='SS' and a.status in('a','p','k')
         and a.contact_type in('2','18','19') and a.commit_time>=trunc(sysdate-180)
         and a.contact_value in(select b.contact_value from cs_contact b where b.contact_type in('2','18','19') and b.id_credit=p_IdCredit);
         
         v_Seq:=v_Seq + 1;         
        
       --客户在申请此合同时，非客户本人的手机号码在过去6个月被其他客户用作非本人的手机号码相同且姓名不同的次数（除状态为t，r的合同）
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'HardCheck','*','PaMobileUseDiffNameCountLast6M',count(1),v_Seq+1
       from cs_credit t
       join cs_contact a on a.id_credit=t.id and a.person_type!='1' and a.contact_type='2'
       join cs_other_person b on b.id_credit=a.id_credit and b.person_type=a.person_type
       join (select e.name,g.contact_value from cs_contact g
            join cs_other_person e on e.id_credit=g.id_credit and e.person_type=g.person_type
            where g.person_type!='1' and g.contact_type='2' and g.id_credit=p_IdCredit
            ) c on c.contact_value=a.contact_value and b.name!=c.name
       where t.id_person!=v_IdPerson and t.status not in('t','r')
       and t.id_sa not in ('800079','888888','300079') and t.credit_type='SS'
       and t.commit_time>v_CommitTime-180 and t.commit_time<v_CommitTime;
       
       --同一年龄下在过去1个月（<30天）的QQ平均长度 2016/07/07 wangxiaofeng
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'HardCheck','*','PaLast1MonthQQAvgLen',round(nvl(sum(qq_length),0)/decode(count(1),0,1,count(1)),4),v_Seq+1
       from mv_qq_length_30 t where t.birth_year=substr(v_Ident,7,4);
        
       --同一年龄下在过去3个月（<90天）的QQ平均长度
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'HardCheck','*','PaLast3MonthQQAvgLen',round(nvl(sum(qq_length),0)/decode(count(1),0,1,count(1)),4),v_Seq+1
       from mv_qq_length t where t.birth_year=substr(v_Ident,7,4);
        
        /*Last3mCpd_Cnt：最近3个月cpd>0的次数  yangzhenxian    2018-03-23*/
          select count(1) into v_Count from cs_credit c
          join df_pd_detail_gl pd on c.contract_no=pd.contract_no
          where c.id_person=v_IdPerson and c.CREDIT_TYPE in ('SS','SC','POS') and c.status in ('a','p','k')
          and c.app_date<v_AppDate and date_due>=add_months(v_AppDate,-3) and date_due < v_AppDate and  max_cpd>0 ;

          insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
           values( p_IdCredit,'HardCheck','*','PaLast3mCpd_Cnt',v_Count,v_Seq+1 );
           
          v_Seq:=v_Seq + 1;
                    
       --IsSAIdent客户申请时,身份证是否属于销售代表/销售经理/门店法人身份证
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'HardCheck','*','PaIsSAIdent',case when sum(amount)>0 then 1 else 0 end,v_Seq
       from (
         select count(1) amount from sys_user_list a where upper(a.role_id) in('SA','DSM','MENTOR') and a.ident=v_Ident
         union
         select count(1) amount from seller where legal_ident=v_Ident);
         
       v_Seq:=v_Seq + 1;     
 
       for phone_depository in (select relationship,contact_value,status,contact_type,id_sellerplace,city from v_phone_depository where id_credit=p_IdCredit)
       loop
         
          if phone_depository.relationship='client' and phone_depository.contact_type='2' then
            
              --客户在申请此合同时，客户手机号码存在，在职SA移动电话列表
              select count(1) into v_Count from sys_user_list a where upper(a.role_id)='SA' and a.phone=phone_depository.contact_value;
              
              if v_Count>0 then
                
                 insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                   values(p_IdCredit,'HardCheck','*','PaSAMobilelist','1',v_Seq+1);
                   
                 v_Seq:=v_Seq + 1;
                 
              end if;
              
             end if;
             
       end loop;

    --银行卡三要素验证结果 2017/03/17 wangxiaofeng
    for c in(select status from(select t.status,row_number() over(order by update_time desc) nums
              from bank_account_verify t
              where t.update_time>=trunc(sysdate) and t.verify_type=0
                     and t.ident=v_Ident and t.account_name=v_PersonName) b where nums=1
      )loop
      
        insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
          values(p_IdCredit,'External','BankVerify','PaThreeFactorStatus',c.status,v_Seq+1);
          
        v_Seq:=v_Seq + 1;
        
      end loop;
      
    --银行卡四要素验证结果 2017/03/17 wangxiaofeng
    for c in(select status from(select t.status,row_number() over(order by update_time desc) nums
              from bank_account_verify t
              where t.update_time>=trunc(sysdate) and t.verify_type=1
                     and t.ident=v_Ident and t.account_name=v_PersonName) b where nums=1
      )loop
      
        insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
          values(p_IdCredit,'External','BankVerify','PaFourFactorStatus',c.status,v_Seq+1);
          
        v_Seq:=v_Seq + 1;
        
      end loop;      
      
      ---------------手机三项验证----NameResultQB-----IdentrResultQB---------------by yangzhenxian 2017-08-30
      for py in(select nameresult,Identresult from
                  (select phone.nameresult,phone.Identresult
                         from cs_pyphone_data phone,Wallet_Apply_Info wa
                         where phone.id_credit=wa.id and wa.id_credit=p_IdCredit and phone.event_name=1
                         and (phone.person_type='1' or phone.person_type is null)  order by phone.update_time desc) a
                  where rownum=1)
      loop
        
       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
        values( p_IdCredit,'External','PengYuan','PaNameResultQB',py.nameresult,v_Seq + 1 );
        
        v_Seq:=v_Seq + 1;

       insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
        values( p_IdCredit,'External','PengYuan','PaIdentResultQB',py.Identresult,v_Seq + 1 );
        
        v_Seq:=v_Seq + 1;
        
      end loop;    
      
      /*预审随机数，取值再0-1之间   yangzhenxian	  2019-07-04*/
       insert into decision_element_data_pa(id_credit,element_type,element_name,element_value,sort_code)
            values(p_IdCredit,'Special','PaRandom',round(dbms_random.value(),6),v_Seq+1);
            
       v_Seq:=v_Seq + 1;        
       
        /*风控渠道类型     yangzhenxian	  2019-07-15*/
        for d in (
          select 
          sum(case when CHANNEL_TYPE='QIAKE' and VERDICT is not null then 1 when CHANNEL_TYPE='WACAI' and VERDICT is not null then 2 else 0 end) as RiskChannelType
          from RISK_MANAGEMENT
          where id_credit=p_IdCredit
        )loop
        
            insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values( p_IdCredit,'Credit','*','PaRiskChannelType',d.RiskChannelType,v_Seq+1 );
             
            v_Seq:=v_Seq + 1;   
            
        end loop;
    
        --hongbinbin 20190927
           if v_CreditType='SSC'
             then
               for d in(           
                select cc.commit_time, cg.id_goods_category, cg.brand, cg.producer,case when to_char(sp.city) is not null then to_char(sp.city) else 
                    case when to_char(cm.STORE_PROVINCE) in('天津市','重庆市','北京市','上海市') then to_char(cm.STORE_PROVINCE) else to_char(cm.STORE_CITY) end end as city
                from cs_credit cc
                  join (select a.*,row_number() over(partition by a.id_credit order by a.GOODS_PRICE desc) as num_id from cs_goods a)cg 
                        on cc.id=cg.ID_CREDIT and cg.num_id=1
                  left join sellerplace sp on cc.id_sellerplace=sp.id
                  left join cs_merchant_store cm on cm.CONTRACT_NO=cc.CONTRACT_NO
                  where cc.id=p_IdCredit
                                  
           ) loop
               for f in (
                 with y as (
                    select id_credit,min(end_time) as end_time
                    from cs_audit_log2 l
                    join cs_credit cc on l.id_credit=cc.id                   
                    where to_status='y' and cc.app_date >= trunc(sysdate) -30 
                    group by id_credit)

                    ,goodsprice_data as (
                    select cc.CONTRACT_NO,cc.id,cc.commit_time,cc.APP_DATE,cc.status,cg.goods_price, cg.num_id
                    ,case when to_char(sp.city) is not null then to_char(sp.city) else 
                        case when to_char(cm.STORE_PROVINCE) in('天津市','重庆市','北京市','上海市') then to_char(cm.STORE_PROVINCE) else to_char(cm.STORE_CITY) end end as city
                    ,cg.id_goods_category,cg.id_goods_type,cg.producer,cg.brand,c.name as good_category,t.name as goods_type
                    from cs_credit cc
                    join (select a.*,row_number() over(partition by a.id_credit order by a.GOODS_PRICE desc) as num_id from cs_goods a)cg 
                          on cc.id=cg.ID_CREDIT and cg.num_id=1
                    join goods_category c on cg.id_goods_category=c.id
                    join goods_type t on cg.id_goods_type=t.id
                    left join sellerplace sp on cc.id_sellerplace=sp.id
                    left join cs_merchant_store cm on cm.CONTRACT_NO=cc.CONTRACT_NO
                    where cc.credit_model<>'YD' and cc.app_date >= trunc(sysdate) -30 
                          and cg.id_goods_category=d.id_goods_category and upper(cg.brand)=upper(d.brand) and upper(cg.producer)=upper(d.producer)
                          and trunc(cc.commit_time)>trunc(d.commit_time)-30 
                          and trunc(cc.commit_time)<trunc(d.commit_time)                        
                          and cc.status in ('a','p','k','y')
                    )
                    
                    ,goods_price_base as (
                      select a.*,end_time from goodsprice_data a
                      left join y on a.id=y.id_credit and y.end_time<trunc(d.commit_time)
                      where a.num_id=1 and a.city=d.city
                    )
                    
                    select nvl(sum(a.goods_price),0)/decode(count(a.id),0,1,count(a.id)) as L1mAvgPrice from goods_price_base a
                 )loop
                   --过去30天已通过合同在相同城市同品牌同类的产品平均价格
                   insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                   values(p_IdCredit,'HardCheck','*','PaL1mAvgPrice',f.L1mAvgPrice,v_Seq+1);
                   
                   v_Seq:=v_Seq + 1;
                
               end loop;              
              
           end loop;
           
         for d in(
            select a.id, a.commit_time,substr(b.ident,7,4) as birth_year,
              case when nvl(a.ID_SA,'1234') not in ('800079','300079','300076') and a.STATUS not in ('r','j') and a.CREDIT_TYPE<>'SC'
              then 
               case when max(case when c.address_type=2 then c.province else null end) in('天津市','重庆市','北京市','上海市') or max(case when c.address_type=3 then c.province else null end) in('天津市','重庆市','北京市','上海市')
                 then max(case when c.address_type=2 then c.province else null end) 
                 else
                replace(nvl(max(case when c.address_type=2 then c.city else null end),max(case when c.address_type=3 then c.city else null end)),'市')
              end else null end as city
              from cs_credit a
              join cs_person b on b.id=a.id_person
              left join cs_address c on c.id_credit=a.id
              where a.id=p_IdCredit
              group by a.id,a.commit_time,b.ident,a.ID_SA,a.STATUS,a.CREDIT_TYPE     
           )loop
           
              for f in(
                with y as (
                select id_credit,min(end_time) as end_time from cs_audit_log2 l
                join cs_credit cc on l.id_credit=cc.id and cc.CREDIT_TYPE<>'SC'
                where to_status='y' and cc.commit_time >= trunc(d.commit_time -30) and cc.commit_time < d.commit_time
                group by id_credit)
                
                ,contract_base as
                  (select crr.id,crr.commit_time,crr.status
                  from cs_credit crr
                  where nvl(crr.ID_SA,'1234') not in ('800079','300079','300076') and crr.STATUS not in ('r','j')
                        and CRR.CREDIT_TYPE<>'SC' and crr.commit_time >= trunc(d.commit_time -30) and crr.commit_time < d.commit_time
                  )
                  
                ,address_detail as(
                    select cb.id,
                    max(case when ca.address_type=2 then province else null end) as cur_province,
                    max(case when ca.address_type=2 then city else null end) as cur_city,
                    max(case when ca.address_type=3 then province else null end) as com_province,
                    max(case when ca.address_type=3 then city else null end) as com_city
                    from cs_address ca
                    join contract_base cb on ca.id_credit=cb.id
                    group by cb.id)
                    
                 ,wkincome_data as (
                    select * from
                    (
                      select cc.CONTRACT_NO,cc.id,cc.commit_time,cc.APP_DATE,cc.status,g.WK_INCOME,substr(ident,7,4) as birth_year
                      ,case when nvl(cur_province,com_province) in('天津市','重庆市','北京市','上海市') then nvl(cur_province,com_province)
                       else replace(nvl(cur_city,cur_city),'市') end as city
                      from cs_credit cc
                      join cs_person a on cc.ID_PERSON=a.ID
                      left join cs_employer ce on ce.ID_CREDIT=cc.ID and ce.STATUS='a' and ce.POSITION<>'9'
                      left join cs_experience g on cc.id=g.ID_CREDIT
                      left join address_detail s on cc.ID=s.ID
                      where credit_type<>'SC' and cc.CREDIT_MODEL<>'YD' and g.wk_income between 1000 and 10000 
                            and substr(ident,7,4) = d.birth_year
                            and cc.commit_time>trunc(d.commit_time)-30 and cc.commit_time<trunc(d.commit_time) 
                            and cc.status in ('a','p','k','y')
                      )tt where tt.city=d.city
                    ) 
                    
                  ,wkincome_base as (
                    select a.*,end_time from wkincome_data a
                    left join y on a.id=y.id_credit and y.end_time<trunc(d.commit_time)
                    )
                    
                    select
                     -- nvl(sum(a.WK_INCOME),0) sum_wkincome
                     -- ,sum(case when a.id is not null then 1 else 0 end) cases
                      nvl(sum(a.WK_INCOME),0)/decode(count(a.id),0,1,count(a.id)) as L1mAvgIncome
                      from wkincome_base a
                )loop
                 --L1mAvgIncome 过去30天已通过合同在相同城市同年龄客户的平均收入水平
                 insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                 values(p_IdCredit,'HardCheck','*','PaL1mAvgIncome',f.L1mAvgIncome,v_Seq+1);
                 v_Seq:=v_Seq + 1;             
             end loop;
             
           end loop;
             end if;
           
         --hongbinbin 20191010 
        for d in (
          with sp_contact as (
            select b.id ,b.id_person, b.app_date, cs.PERSON_TYPE, cs.CONTACT_TYPE, cs.CONTACT_VALUE,  cs.UPDATE_TIME
            from  cs_credit b 
            left join cs_contact cs on b.id=cs.id_credit
            where b.credit_type='SP' and b.id=p_IdCredit and cs.PERSON_TYPE='1' and cs.CONTACT_TYPE='2'
            )    
                    
            select distinct aa.id,sum(case when bb.ID_CREDIT is not null then 1 else 0 end) as MobileDifTimes
              from sp_contact aa
              left join (
                   select distinct cc.ID_PERSON,cc.UPDATE_TIME,cc.ID_CREDIT,
                          cc.PERSON_TYPE,cc.CONTACT_TYPE,cc.CONTACT_VALUE
                    from cs_contact cc
                    where length(cc.CONTACT_VALUE)>=11
                    and cc.CONTACT_TYPE not in (2,11,17,13)                    
              ) bb on bb.ID_PERSON=aa.ID_PERSON and aa.CONTACT_VALUE=bb.CONTACT_VALUE
              and aa.id <> bb.ID_CREDIT and bb.UPDATE_TIME < aa.app_date              
              group by aa.id,bb.id_credit
          )loop           
              
               --客户在申请此合同时，客户手机号码被本人历史作为非移动电话使用过次数
               insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                 values( p_IdCredit,'HardCheck','*','PaMobileDifTimes',d.MobileDifTimes,v_Seq+1);
                 
                v_Seq:=v_Seq + 1;
          
          end loop;    
          
        for d in (
          with sp_contact as (
            select b.id ,b.id_person, b.app_date, cs.PERSON_TYPE, cs.CONTACT_TYPE, cs.CONTACT_VALUE,  cs.UPDATE_TIME
            from  cs_credit b 
            left join cs_contact cs on b.id=cs.id_credit
            where b.credit_type='SP' and b.id=p_IdCredit and cs.PERSON_TYPE='1' and cs.CONTACT_TYPE='3'
            )    
                    
           select distinct aa.id,sum(case when bb.ID_CREDIT is not null then 1 else 0 end) as ComPhoneUseCount
              from sp_contact aa
              left join (
                   select distinct cc.ID_PERSON,cc.UPDATE_TIME,cc.ID_CREDIT,
                          cc.PERSON_TYPE,cc.CONTACT_TYPE,cc.CONTACT_VALUE
                    from cs_contact cc
                    where length(cc.CONTACT_VALUE)>=11
                    and cc.CONTACT_TYPE = '3'                    
              ) bb on bb.ID_PERSON<>aa.ID_PERSON and aa.CONTACT_VALUE=bb.CONTACT_VALUE
              and aa.id <> bb.ID_CREDIT and bb.UPDATE_TIME < aa.app_date  
              group by aa.id,bb.id_credit    
              order by aa.id         

          )loop       
                        
               --客户办公电话在过去被其他人重复使用为办公电话次数
               insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
                 values( p_IdCredit,'HardCheck','*','PaComPhoneUseCount',d.ComPhoneUseCount,v_Seq+1);
                 
                v_Seq:=v_Seq + 1;
          
          end loop;    
      --以上元素，如果值为空则删除（与终审保持一致）	yangzhenxian    2019-06-18
       delete decision_element_data_pa where id_credit=p_IdCredit and element_value is null;
                
        --即速用新增元素        yangzhenxian                                          2019-05-15
        if v_CreditType ='SP'
        then
          
           --是否即有消费贷客户      PaIsSsPerson
           insert into decision_element_data_pa(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
           select p_IdCredit,'HardCheck','*','PaIsSsPerson',max(case when ID_PERSON is null then 0 else 1 end),v_Seq+1
           from cs_credit where id_person=v_IdPerson and credit_type='SS' and status in ('a','p','k','d');
                   
        end if;
              
       commit;

       p_ReturnCode:='A';
       
       return;
       
    exception
       When others Then
         error_info := sqlerrm;
         p_ReturnCode:='Z-'||error_info||DBMS_UTILITY.format_error_backtrace;
         rollback;
    end;
/

