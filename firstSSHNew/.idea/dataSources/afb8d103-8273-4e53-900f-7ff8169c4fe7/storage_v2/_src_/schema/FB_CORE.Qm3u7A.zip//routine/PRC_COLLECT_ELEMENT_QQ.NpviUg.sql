create procedure prc_collect_element_qq(p_IdCredit cs_credit.id%type,p_IdPerson number,p_ReturnCode out varchar2) is
       error_info                  varchar2(1000);
       v_CommitTime                cs_credit.commit_time%type;


       v_IdPerson                  cs_person.id%type;
       v_Ident                     cs_person.ident%type;
       v_Birthday                  varchar2(20);
       v_Age                       integer;
       v_PersonMobile              varchar2(100);
       v_FamilyPhone               varchar2(100);
       v_OfficeTel                 varchar2(100);


       v_ElementType               decision_element_data.element_type%type;
       v_Seq                       decision_element_data.sort_code%type;

       v_FamilyPhoneUseCount           number:=0;
       v_FamilyPhoneUseSameCityCount   number:=0;

       v_Count                     integer;

       v_OtherPersonType           registers.reg_val_name%type;
    begin
       delete decision_element_data where id_credit=p_IdCredit;
       ---------------------------------------------------------
       prc_save_cs_contact(100000,p_IdCredit,p_ReturnCode);

       v_Seq:=0;
       v_ElementType:='Special';
       insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)
            values(p_IdCredit,v_ElementType,'Random1',round(dbms_random.value(),6),v_Seq+1);
       insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)
            values(p_IdCredit,v_ElementType,'Random2',round(dbms_random.value(),6),v_Seq+2);
       insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)
            values(p_IdCredit,v_ElementType,'Random3',round(dbms_random.value(),6),v_Seq+3);
       insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)
            values(p_IdCredit,v_ElementType,'Tencent',1,v_Seq+1);
       v_Seq:=v_Seq + 1;
       ---------------------------------------------------------
       v_ElementType:='Credit';
       select commit_time into v_CommitTime from cs_credit where id=p_IdCredit;
       insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)
            values(p_IdCredit,v_ElementType,'CommitTime',to_char(v_CommitTime,'yyyy-MM-dd HH24:mi:ss'),v_Seq+1);
       v_Seq:=v_Seq + 1;

       ---------------------------------------------------------
       v_ElementType:='Person';
       v_IdPerson:=p_IdPerson;
       for person in (select name,ident,sex from cs_person  a where id=v_IdPerson and rownum=1)
       loop
         v_Ident:=person.ident;
         if length(v_Ident)=15 then
             v_Birthday:=to_char(to_date('19'||substr(v_Ident,7,6),'yyyy-MM-dd'),'yyyy-MM-dd');
             select to_number(to_char(sysdate,'yyyy')) - to_number('19'||substr(v_Ident,7,2)) into v_Age from dual;
         else
             v_Birthday:=to_char(to_date(substr(v_Ident,7,8),'yyyy-MM-dd'),'yyyy-MM-dd');
             select to_number(to_char(sysdate,'yyyy')) - to_number(substr(v_Ident,7,4)) into v_Age from dual;
         end if;
         insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)
              values(p_IdCredit,v_ElementType,'Name',person.name,v_Seq+1);
         insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)
              values(p_IdCredit,v_ElementType,'Ident',person.ident,v_Seq+2);
         insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)
              values(p_IdCredit,v_ElementType,'Birthday',v_Birthday,v_Seq+3);
         insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)
              values(p_IdCredit,v_ElementType,'Sex',person.sex,v_Seq+4);

         v_Seq:=v_Seq + 4;
       end loop;
       ---------------------------------------------------------
       --增加元素Credit.QQWhiteList，如手Q申请的身份证与白名单表中身份证一致，元素生成1，否则为空 2017-09-15 yangzhenxian
       v_ElementType:='Credit';
       select count(1) into v_Count from mall_white_list where ident=v_Ident;
       if v_Count>0 then
          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
              values(p_IdCredit,v_ElementType,'*','QQWhiteList','1',v_Seq+1);
          v_Seq:=v_Seq + 1;
       end if;

       --增加Credit.CreditSource元素 2017-11-30 yangzhenxian
          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
          select p_IdCredit,v_ElementType,'*','CreditSource',credit_source,v_Seq+1 from cs_credit where id=p_IdCredit;
          v_Seq:=v_Seq + 1;

       ---------------------------------------------------------
       v_ElementType:='Contact';
       for contact in (select fun_getreg_value(395,t.contact_type) contact_type,t.contact_type cont_type,contact_value from cs_contact t where person_type='1' and id_credit=p_IdCredit)
       loop
           insert into decision_element_data(id_credit,element_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,contact.contact_type,contact.contact_value,v_Seq+1);
           v_Seq:=v_Seq + 1;

           if contact.cont_type='3' then
             v_OfficeTel:=contact.contact_value;
           end if;
           if contact.cont_type='2' then
             v_PersonMobile:=contact.contact_value;
           end if;
       end loop;

       ---------------------------------------------------------
       v_ElementType:='OtherPerson';
       for otherperson in (select a.name,fun_getreg_value(decode(length(a.person_type),1,265,396),a.person_type) persontype,b.contact_value
              from cs_other_person a,cs_contact b where a.id_credit=b.id_credit and a.person_type=b.person_type and a.id_credit=p_IdCredit and a.person_type!='1' and length(a.person_type)=1 order by a.id)
       loop
           if instr(otherperson.persontype,'-')>0 then
              v_OtherPersonType:=substr(otherperson.persontype,1,instr(otherperson.persontype,'-')-1);
           else
              v_OtherPersonType:=otherperson.persontype;
           end if;
           insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values(p_IdCredit,v_ElementType,v_OtherPersonType,'Name',otherperson.name,v_Seq+1);
           insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
             values(p_IdCredit,v_ElementType,v_OtherPersonType,'ContactValue',otherperson.contact_value,v_Seq+2);

           v_FamilyPhone:=otherperson.contact_value;
           v_Seq:=v_Seq + 2;
       end loop;
       ---------------------------------------------------------
       v_ElementType:='Address';
       
       for address in (select decode(address_type,1,'ResidentAddress',2,'CurrentAddress','CompanyAddress') address_type,province,city,region,town,street,building,room
              from cs_address where id_credit=p_IdCredit and address_type=3 order by address_type)--由于前端页面存的是工作地址，需要改成3   20170817
       loop
           
           insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,address.address_type,'Province',address.province,v_Seq+1);
           insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)values
               (p_IdCredit,v_ElementType,address.address_type,'City',address.city,v_Seq+2);

               v_Seq:=v_Seq + 2;
       end loop;

       ---------------------------------------------------------
       v_ElementType:='Other';

       --客户本人手机号码所属城市
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,v_ElementType,'*','PhoneNoCity',nvl(max(a.city),'null'),v_Seq+1
       from mv_df_phone_attribution_gl a where a.mobilenumber=substr(v_PersonMobile,1,7);
       v_Seq:=v_Seq + 1;

       --客户本人手机号段 李晓茜确认不需要，20170816
       /*insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)values
           (p_IdCredit,v_ElementType,'*','MobileSegmetNum',substr(v_PersonMobile,1,3),v_Seq+1);
       v_Seq:=v_Seq + 1;*/

       --家庭联系人手机号码所属城市
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,v_ElementType,'*','FamilyPhoneNoCity',nvl(max(a.city),'null'),v_Seq+1
       from mv_df_phone_attribution_gl a where a.mobilenumber=substr(v_FamilyPhone,1,7);
        v_Seq:=v_Seq + 1;

       --客户在申请此合同时前面一张通过的合同的申请时间，除拒绝和取消的合同外（状态为d/t/x的除外）update_time2016/11/30
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'HardCheck','*','MaxPrevCommitTime',to_char(max(commit_time),'yyyy-MM-dd HH24:mi:ss'),v_Seq+1 from cs_credit
       where id_person=v_IdPerson and commit_time<=v_CommitTime and credit_type in('SS','SC') and id!=p_IdCredit and status not in ('t','d','x','c','e','f','r','s','v');

       v_Seq:=v_Seq + 1;

       --客户在申请此合同时前面一张拒绝的合同的申请时间（状态为d）
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'HardCheck','*','RejectPrevCommitTime',to_char(max(commit_time),'yyyy-MM-dd HH24:mi:ss'),v_Seq+1 from cs_credit
       where id_person=v_IdPerson and commit_time<=v_CommitTime and (credit_type in('SS','SC','MQ') or (credit_type='QB' and id_sa is not null)) and id!=p_IdCredit and status='d';
       v_Seq:=v_Seq + 1;

       --客户在申请此激活钱包时前面一次拒绝的合同的申请时间（状态为d，合同类型为'TX'）yangzhenxian
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'HardCheck','*','RejectPrevCommitTimeGU',to_char(max(commit_time),'yyyy-MM-dd HH24:mi:ss'),v_Seq+1 from cs_credit
       where id_person=v_IdPerson and commit_time<=v_CommitTime and (credit_type ='TX') and id!=p_IdCredit and status='d';
       v_Seq:=v_Seq + 1;

       --客户在申请此合同时，非客户本人的手机号码在过去6个月被其他客户用作非本人的手机号码相同且姓名不同的次数（除状态为t，r的合同）
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'HardCheck','*','MobileUseDiffNameCountLast6M',count(1),v_Seq+1
       from cs_credit t
       join cs_contact a on a.id_credit=t.id and a.person_type!='1' and a.contact_type='2'
       join cs_other_person b on b.id_credit=a.id_credit and b.person_type=a.person_type
       join (select e.name,g.contact_value from cs_contact g
            join cs_other_person e on e.id_credit=g.id_credit and e.person_type=g.person_type
            where g.person_type!='1' and g.contact_type='2' and g.id_credit=p_IdCredit
            ) c on c.contact_value=a.contact_value and b.name!=c.name
       where t.id_person!=v_IdPerson and t.status not in('t','r')
       --手Q的id_sa为null
       and ((nvl(t.id_sa,'00000') not in ('800079','888888','300079') and t.credit_type='SS') or t.credit_type!='SS')
       and t.commit_time>v_CommitTime-180 and t.commit_time<v_CommitTime;
       v_Seq:=v_Seq + 1;

       --BlackListCateFraudMetrix:同盾黑名单分类 2015/07/07 wangxiaofeng 2017/06/22由rule_name改为rule_no
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select  p_IdCredit,'HardCheck','*','BlackListCateFraudMetrix',substr(max(case when rule_no in (
          840098,2900153,2901749,2992525,840072,891780,891784,2900089,840080,840116,2992509,2992523,2992511,2901741,840076,
          891788,2901719,2992521,891804,840106,2901711,2992507,840096,891814,2901715,11532,14130,840100,78586,891806,891824,891808,
          5638201,5640421,5640431,5640411) then '9失信名单'
          when rule_no in (840086,2901725,891794,891816,2901743,840108,840118,2901751,891826) then '8灰名单'
          when rule_no in (2900149,891792,2901723,840084,584894) then '7已结案名单'
          when rule_no in (2900083,2901761,2901759,891782,840074,2901713,840082,891790,891802,840094,891812,891832,891834,891836,
            2901731,891828,840120,891830,840122,11534,840104,840126,44126,15726,840124,840128) then '6低风险失信名单'
          else '0其他' end),2,10) BlackListCateFraudMetrix,v_Seq+1
          from WFI_FRAUD_METRIX_RESULT a join WFI_FRAUD_METRIX_RULE t on a.id=t.fraud_metrix_result_id
          where a.event_name='Credit' and a.associated_id=p_IdCredit
          group by a.associated_id;
       v_Seq:=v_Seq + 1;

       --BlackListFraudMetrixContact:联系人命中同盾失信名单 2017/08/01 yangzhenxian 联系人命中同盾失信名单 规则如下，元素值 1 命中，0 未命中
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select  p_IdCredit,'HardCheck','*','BlackListFraudMetrixContact',max(case
         when rule_name in ('新_第一联系人手机号命中网贷黑名单',
                            '新_第一联系人手机号命中贷款黑中介库',
                            '新_第一联系人手机号命中失联名单',
                            '第一联系人手机号命中信贷逾期名单',
                            '第一联系人手机号命中虚假号码或通信小号库') then
          1
         else
          0
       end) as BlackListFraudMetrixContact,v_Seq+1
          from WFI_FRAUD_METRIX_RESULT a join WFI_FRAUD_METRIX_RULE t on a.id=t.fraud_metrix_result_id
          where a.event_name='Credit' and a.associated_id=p_IdCredit
          group by a.associated_id;
       v_Seq:=v_Seq + 1;

       --1天内借款平台数MultiLoanTypeCountFraudMetrix1D: rule_name='新_1天内申请人身份证或手机在多个平台申请借款'，从extra_data中取值
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
              select p_IdCredit,'HardCheck','*','MultiLoanTypeCountFraudMetrix1D',nvl(max(b.extra_data),0),v_Seq+1
              from WFI_FRAUD_METRIX_RESULT a
              join WFI_FRAUD_METRIX_RULE b on a.id=b.fraud_metrix_result_id
              where b.rule_no in(1049650,1053410)
              and a.event_name='Credit' and a.associated_id=p_IdCredit;
       v_Seq:=v_Seq + 1;

       --1个月内借款平台数MultiLoanTypeCountFraudMetrix1M: rule_name='新_1个月内申请人身份证或手机在多个平台申请借款'，从extra_data中取值
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
              select p_IdCredit,'HardCheck','*','MultiLoanTypeCountFraudMetrix1M',nvl(max(b.extra_data),0),v_Seq+1
              from WFI_FRAUD_METRIX_RESULT a
              join WFI_FRAUD_METRIX_RULE b on a.id=b.fraud_metrix_result_id
              where b.rule_no in(1044438,1053414)
              and a.event_name='Credit' and a.associated_id=p_IdCredit;
       v_Seq:=v_Seq + 1;

       --3个月内借款平台数MultiLoanTypeCountFraudMetrix3M: rule_name='新_3个月内申请人身份证或手机在多个平台申请借款'，从extra_data中取值
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
        select p_IdCredit,'HardCheck','*','MultiLoanTypeCountFraudMetrix3M',nvl(max(b.extra_data),0),v_Seq+1
        from WFI_FRAUD_METRIX_RESULT a
        join WFI_FRAUD_METRIX_RULE b on a.id=b.fraud_metrix_result_id
        where b.rule_no in(1044388,1053416)
        and a.event_name='Credit' and a.associated_id=p_IdCredit;
       v_Seq:=v_Seq + 1;

       --2016/09/05 wangxiaofeng
       --是否查得同盾数据FraudMetrixActive (1, 查得; 0, 未查得)
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'HardCheck','*','FraudMetrixActive',decode(count(1),0,0,1),v_Seq+1
       from wfi_fraud_metrix_result t where t.event_name='Credit' and t.associated_id=p_IdCredit;
       v_Seq:=v_Seq + 1;
       -- 过去半小时内同盾未查得合同数FraudMetrixFailedCount 2017/03/03 update
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'HardCheck','*','FraudMetrixFailedCount',count(1),v_Seq+1
       from cs_credit a where not exists(select 1 from wfi_fraud_metrix_result b
                                           where b.event_name='Credit'  and b.associated_id=a.id)
                         and a.status not in('j','l') --and a.inter_code not in(3,4)
                         and a.credit_type='TX'--decode(v_CreditType,'SC','SC','SS')
                         and a.commit_time>=v_CommitTime-35/24/60 and a.commit_time<=v_CommitTime-5/24/60;
       v_Seq:=v_Seq + 1;

       --记录日志--过去半小时内同盾未查得合同
       insert into decision_metrix_result_log
         (id_credit, metrix_result_id_credit,create_time)
       select p_IdCredit,a.id,to_char(Systimestamp,'yyyy-mm-dd hh24:mi:ss.ff4')
       from cs_credit a where not exists(select 1 from wfi_fraud_metrix_result b
                                           where b.event_name='Credit'  and b.associated_id=a.id)
                         and a.status not in('j','l') --and a.inter_code not in(3,4)
                         and a.credit_type='TX'--decode(v_CreditType,'SC','SC','SS')
                         and a.commit_time>=v_CommitTime-35/24/60 and a.commit_time<=v_CommitTime-5/24/60;


       --蜜罐元素数据 2016/06/23 wangxiaofeng
       for mi in(select user_gray_score,contacts_one_blacklist_cnt,contacts_two_blacklist_cnt,
                  blacklist_category,user_register_cnt,iwop_susp_phone
                  from(
                  select nvl(a.user_gray_score,0) user_gray_score,nvl(a.contacts_one_blacklist_cnt,0) contacts_one_blacklist_cnt,
                  nvl(a.contacts_two_blacklist_cnt,0) contacts_two_blacklist_cnt,nvl(a.blacklist_category,'其他') blacklist_category,
                  nvl(a.user_register_cnt,0) user_register_cnt,decode(a.iwop_susp_phone,null,'否','是') iwop_susp_phone
                  from external_miguan_basic_info a
                  where a.create_time>=trunc(sysdate-1) and a.id_credit=p_IdCredit order by user_id desc
                  ) where rownum=1)
       loop
         --一阶联系人黑名单人数
         insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         values( p_IdCredit,'External','JuxinliMiguan','PhoneBlackCNTOne',mi.contacts_one_blacklist_cnt,v_Seq + 1);
         --二阶联系人黑名单人数
         insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         values( p_IdCredit,'External','JuxinliMiguan','PhoneBlackCNTTwo',mi.contacts_two_blacklist_cnt,v_Seq + 2);
         --黑名单类型
         insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         values( p_IdCredit,'External','JuxinliMiguan','BlackType',mi.blacklist_category,v_Seq + 3);
         --身份证是否组合过其他电话号码 返回结果为是否
         insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         values( p_IdCredit,'External','JuxinliMiguan','SameIdentDiffPhone',mi.iwop_susp_phone,v_Seq + 4);
         v_Seq:=v_Seq + 4;
       end loop;

       -------begin 2017/12/01 yangzhenxian-----
      -------1.增加元素External. BaiRong. IdentNBankIteDay/*按身份证号查询，距最近在非银行机构申请的间隔天数*/
    insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select ID_CREDIT,'External','BaiRong','IdentNBankIteDay',nvl(als_lst_id_nbank_inteday,0),v_Seq+1
       from (select ID_CREDIT,t.als_lst_id_nbank_inteday from external_br_applyloan t
       where t.id_credit=p_IdCredit order by t.create_time desc) where rownum=1 ;

      v_Seq:=v_Seq + 1;
      -------2.增加元素External. BaiRong. FlagSpeciallist/*稳定性评估产品输出标识*/
    insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select ID_CREDIT,'External','BaiRong','FlagSpeciallist',nvl(flag_speciallist_c,-1),v_Seq+1
       from (select ID_CREDIT,t.flag_speciallist_c from external_br_speciallist_c t
       where t.id_credit=p_IdCredit order by t.create_time desc) where rownum=1 ;

      v_Seq:=v_Seq + 1;
      -------3.增加元素External. BaiRong. FlagStability/*特殊名单核查产品输出标识*/
    insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select ID_CREDIT,'External','BaiRong','FlagStability',flag_stability_c,v_Seq+1
       from (select ID_CREDIT,t.flag_stability_c from external_br_stability_c t
       where t.id_credit=p_IdCredit order by t.create_time desc) where rownum=1 ;

      v_Seq:=v_Seq + 1;
      -------4.增加元素External. BaiRong. MobChangeIteDay/*身份证关联的手机号最近一次变动距今天数*/
    insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select ID_CREDIT,'External','BaiRong','MobChangeIteDay',nvl(ir_id_x_cell_lastchg_days,0),v_Seq+1
       from (select ID_CREDIT,t.ir_id_x_cell_lastchg_days from external_br_inforelation t
       where t.id_credit=p_IdCredit order by t.create_time desc) where rownum=1 ;
      v_Seq:=v_Seq + 1;
      ---BaiRong   end------

      -----灰猫begin yangzhenxian     2017-12-01-----------
      --在元素类比External下面添加元素子类=HuiMao，元素名称FlagOverDue(是否命中逾期平台数据)
    insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'External','HuiMao','FlagOverDue',nvl(case when FlagOverDue>1 then 1 else FlagOverDue end,-1),v_Seq+1
       from (select sum(case when c2.QUERY_REPORT_ID is not null then 1 when c1.order_no is not null then 0 else null end) as FlagOverDue
        from GREYCAT_APPLY_REPORT c
        left join GREYCAT_QUERY_REPORT c1 on c.order_no=c1.order_no
        left join GREYCAT_OVERDUE_DETAIL c2 on c1.id=c2.QUERY_REPORT_ID
        where c.id_credit=p_IdCredit
        ) ;
      v_Seq:=v_Seq + 1;

      --在元素类比External下面添加元素子类=HuiMao，元素名称FlagApply(是否命中申请平台数据)
    insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'External','HuiMao','FlagApply',nvl(case when FlagApply>1 then 1 else FlagApply end,-1),v_Seq+1
       from (select sum(case when c2.QUERY_REPORT_ID is not null then 1 when c1.order_no is not null then 0 else null end) as FlagApply
        from GREYCAT_APPLY_REPORT c
        left join GREYCAT_QUERY_REPORT c1 on c.order_no=c1.order_no
        left join GREYCAT_APPLY_LOAN_DETAIL c2 on c1.id=c2.QUERY_REPORT_ID
        where c.id_credit=p_IdCredit
        ) ;
      v_Seq:=v_Seq + 1;

      --在元素类比External下面添加元素子类=HuiMao，元素名称FlagPay(是否命中还款平台数据)
    insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'External','HuiMao','FlagPay',nvl(case when FlagApply>1 then 1 else FlagApply end,-1),v_Seq+1
       from (select sum(case when c2.QUERY_REPORT_ID is not null then 1 when c1.order_no is not null then 0 else null end) as FlagApply
        from GREYCAT_APPLY_REPORT c
        left join GREYCAT_QUERY_REPORT c1 on c.order_no=c1.order_no
        left join GREYCAT_APPLY_LOAN_DETAIL c2 on c1.id=c2.QUERY_REPORT_ID and c2.apply_sum_money='0.00'
        where c.id_credit=p_IdCredit
        ) ;
      v_Seq:=v_Seq + 1;

      --在元素类比External下面添加元素子类=HuiMao，元素名称Score(灰猫评分)
    insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'External','HuiMao','Score',score,v_Seq+1
       from (select c1.score
          from GREYCAT_APPLY_REPORT c
          join GREYCAT_QUERY_REPORT c1 on c.ORDER_NO=c1.ORDER_NO
       where c.id_credit=p_IdCredit order by c1.create_time desc) where rownum=1 ;

      v_Seq:=v_Seq + 1;

      -----灰猫end---------------

       --芝麻反欺诈评分
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
       select p_IdCredit,'External','ZhiMa','IvsScore',nvl(sum(score),0),v_Seq + 1 from ZHIMA_ANTIFRAUD_SCORE where id_credit=p_IdCredit;
       v_Seq:=v_Seq + 1;

       --芝麻反欺诈关注名单
       for zm in(select risk_level,level_code
                from(
                select risk_level,decode(risk_level,'低风险',1,'中风险',2,3) level_code
                from ZHIMA_ANTIFRAUD_RISK_HIT hit ,ZHIMA_ANTIFRAUD_RISK_DETAIL detail
                where hit.id=detail.risk_id and hit.hit='yes' and hit.id_credit=p_IdCredit order by level_code desc
                ) where rownum=1)
       loop
         insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
         values( p_IdCredit,'External','ZhiMa','IvsRisk',zm.risk_level,v_Seq + 1 );
         v_Seq:=v_Seq + 1;
       end loop;

      --External.ZhiMa.MultiLoan1D 返回以下规则元素值为1，否则为0 2017-10-09 yangzhenxian
      insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
      select p_IdCredit,'External','ZhiMa','MultiLoan1D',case when count(1)>0 then 1 else 0 end,v_Seq+1
      from zhima_antifraud_risk_hit h
      join ZHIMA_ANTIFRAUD_RISK_DETAIL d
      on h.id=d.risk_id
      where h.id_credit=p_IdCredit and d.code in ('R_CN_JJ_01','R_PH_JJ_01');
      v_Seq:=v_Seq + 1;

      --External.ZhiMa.MultiLoan1W 返回以下规则元素值为1，否则为0 2017-10-09 yangzhenxian
      insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
      select p_IdCredit,'External','ZhiMa','MultiLoan1W',case when count(1)>0 then 1 else 0 end,v_Seq+1
      from zhima_antifraud_risk_hit h
      join ZHIMA_ANTIFRAUD_RISK_DETAIL d
      on h.id=d.risk_id
      where h.id_credit=p_IdCredit and d.code in ('R_CN_JJ_02','R_PH_JJ_02');
      v_Seq:=v_Seq + 1;

      --External.ZhiMa.MultiLoan1M 返回以下规则元素值为1，否则为0 2017-10-09 yangzhenxian
      insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
      select p_IdCredit,'External','ZhiMa','MultiLoan1M',case when count(1)>0 then 1 else 0 end,v_Seq+1
      from zhima_antifraud_risk_hit h
      join ZHIMA_ANTIFRAUD_RISK_DETAIL d
      on h.id=d.risk_id
      where h.id_credit=p_IdCredit and d.code in ('R_CN_JJ_03','R_PH_JJ_03');
      v_Seq:=v_Seq + 1;

      --External.ZhiMa.CnResult 2017-10-09 yangzhenxian
      for c in(select * from(select a.id,b.verify_id,code
        ,decode(description,'姓名与身份证号匹配','匹配'
        ,'姓名与身份证号不匹配','不匹配'
        ,'查询不到身份证信息','无信息','') description
                from zhima_antifraud_verify a
                join zhima_antifraud_verify_detail b on a.id=b.verify_id
                where a.ID_CREDIT=p_IdCredit and instr(code,'V_CN')>0 order by a.create_time desc) b where rownum=1
        )loop
          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            values(p_IdCredit,'External','ZhiMa','CnResult',c.description,v_Seq+1);
          v_Seq:=v_Seq + 1;
        end loop;

      --External.ZhiMa.PhResult 2017-10-09 yangzhenxian
      for c in(select * from(select a.id,b.verify_id,code
        ,decode(description,'查询不到电话号码信息','无信息'
        ,'电话号码与本人不匹配','不匹配'
        ,'电话号码与本人匹配，180天内没有使用','匹配未使用180D'
        ,'电话号码与本人匹配，180天内有使用','匹配使用180D'
        ,'电话号码与本人匹配，30天内有使用','匹配使用30D'
        ,'电话号码与本人匹配，90天内有使用','匹配使用90D'
        ,'电话号码与姓名不匹配','姓名不匹配'
        ,'电话号码与姓名匹配，180天内没有使用','姓名匹配未使用180D'
        ,'电话号码与姓名匹配，180天内有使用','姓名匹配使用180D'
        ,'电话号码与姓名匹配，30天内有使用','姓名匹配使用30D'
        ,'电话号码与姓名匹配，90天内有使用','姓名匹配使用90D','') description
                from zhima_antifraud_verify a
                join zhima_antifraud_verify_detail b on a.id=b.verify_id
                where a.ID_CREDIT=p_IdCredit and instr(code,'V_PH')>0 order by a.create_time desc) b where rownum=1
        )loop
          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            values(p_IdCredit,'External','ZhiMa','PhResult',c.description,v_Seq+1);
          v_Seq:=v_Seq + 1;
        end loop;


       -----------黑名单客户------------------------------------
       --如果客户存在黑名单有效期限里,则创建拒绝原因"黑名单."
       --客户身份证黑名单
       select count(1) into v_Count from customer_blacklist where ident=v_Ident;
       if v_Count>0 then
          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
              values(p_IdCredit,'HardCheck','*','BlackListIDent','1',v_Seq+1);
          v_Seq:=v_Seq + 1;
       end if;
       --客户本人手机号码黑名单
       select count(1) into v_Count from customer_blacklist
       where mobile in(select contact_value from cs_contact where id_person=v_IdPerson and person_type='1' and contact_type in('2','3','18','19'));
       if v_Count>0 then
          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
              values(p_IdCredit,'HardCheck','*','BlackListMobile','1',v_Seq+1);
          v_Seq:=v_Seq + 1;
       end if;
       --客户其它手机号码黑名单
       select count(1) into v_Count from customer_blacklist
       where mobile in(select contact_value from cs_contact where id_person=v_IdPerson and person_type<>'1' and contact_type in('2','3','18','19'));
       if v_Count>0 then
          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
              values(p_IdCredit,'HardCheck','*','BlackListOtherMobile','1',v_Seq+1);
          v_Seq:=v_Seq + 1;
       end if;
       --客户家庭电话黑名单
       select count(1) into v_Count from customer_blacklist
       where home_num in(select contact_value from cs_contact where id_person=v_IdPerson and contact_type='18');
       if v_Count>0 then
          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
              values(p_IdCredit,'HardCheck','*','BlackListHomePhone','1',v_Seq+1);
          v_Seq:=v_Seq + 1;
       end if;

       for phone_depository in (select contact_value,status,city from v_phone_depository_qq where id_credit=p_IdCredit and relationship='family')
       loop
          --家庭成员电话在最近180天被其他不同的客户用作其他所有电话（办公电话除外）的次数
          select count(distinct(id_credit||contact_value)) into v_Count from v_phone_depository_qq
          where contact_value=phone_depository.contact_value and id_person!=v_IdPerson and commit_time>=sysdate-180 and commit_time<=v_CommitTime and status not in('t','r');
          v_FamilyPhoneUseCount:=v_FamilyPhoneUseCount+v_Count;
          --家庭成员电话在过去30天在同个城市被其他人重复使用的情况；状态不等于tr的次数
          select count(distinct(id_credit||contact_value)) into v_Count from v_phone_depository_qq
          where contact_value=phone_depository.contact_value and id_person!=v_IdPerson and commit_time>=sysdate-30 and commit_time<=v_CommitTime and status not in('t','r') and city=phone_depository.city;
          v_FamilyPhoneUseSameCityCount:=v_FamilyPhoneUseSameCityCount+v_Count;
       end loop;

       --家庭成员电话在最近180天被其他不同的客户用作其他所有电话（办公电话除外）总的次数
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            values(p_IdCredit,'HardCheck','*','FamilyPhoneUseCount',v_FamilyPhoneUseCount,v_Seq+1);
       v_Seq:=v_Seq + 1;

       --家庭成员电话在过去30天在同个城市被其他人重复使用的情况；状态不等于tr（办公电话除外）总的次数
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,sort_code)
            values(p_IdCredit,'HardCheck','*','FamilyPhoneUseSameCityCount',v_FamilyPhoneUseSameCityCount,v_Seq+1);

       commit;
       p_ReturnCode:='A';
       return;
    exception
       When others Then
         error_info := sqlerrm;
         p_ReturnCode:='Z-'||error_info;
         rollback;
    end;
/

