create PACKAGE       ROLE$_priv AS

  TYPE attribute_rec IS RECORD (
      ID# ROLE$.ID#%TYPE
    , ROLE ROLE$.ROLE%TYPE
    , RULE_SET_ID# ROLE$.RULE_SET_ID#%TYPE
    , ENABLED ROLE$.ENABLED%TYPE
  );

  TYPE attribute_list IS VARRAY(4096) OF attribute_rec;

  -- Create method
  PROCEDURE create_row(
    p_ROLE IN VARCHAR2,
    p_RULE_SET_ID# IN NUMBER,
    p_ENABLED IN VARCHAR2,
    x_id# OUT number);

  -- Read method
  PROCEDURE read_row(p_id#        IN     number,
      x_ID# OUT NUMBER
    , x_ROLE OUT VARCHAR2
    , x_RULE_SET_ID# OUT NUMBER
    , x_ENABLED OUT VARCHAR2
    );

  PROCEDURE read_by_RULE_SET_ID#_(
    p_RULE_SET_ID# IN number,
    x_attribute_list OUT attribute_list);

  -- Update method
  PROCEDURE update_row(
      p_id# NUMBER
    , p_ROLE IN VARCHAR2
    , p_RULE_SET_ID# IN NUMBER
    , p_ENABLED IN VARCHAR2
    );

  -- Delete method
  PROCEDURE delete_row(p_id# IN number,
                    p_delete_children IN boolean := false);

  PROCEDURE delete_by_RULE_SET_ID#_(
    p_RULE_SET_ID# IN number,
    p_delete_children IN boolean := false);

END;
/

