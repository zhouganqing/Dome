create FUNCTION       check_ts_dvauth
                             (ts_name IN VARCHAR2) RETURN BINARY_INTEGER
IS
BEGIN
  RETURN dvsys.dbms_macutl.check_ts_dvauth(ts_name);
END;
/

