create PACKAGE       IDENTITY_MAP$_priv AS

  TYPE attribute_rec IS RECORD (
      ID# IDENTITY_MAP$.ID#%TYPE
    , IDENTITY_ID# IDENTITY_MAP$.IDENTITY_ID#%TYPE
    , FACTOR_LINK_ID# IDENTITY_MAP$.FACTOR_LINK_ID#%TYPE
    , OPERATION_CODE_ID# IDENTITY_MAP$.OPERATION_CODE_ID#%TYPE
    , OPERAND1 IDENTITY_MAP$.OPERAND1%TYPE
    , OPERAND2 IDENTITY_MAP$.OPERAND2%TYPE
  );

  TYPE attribute_list IS VARRAY(4096) OF attribute_rec;

  -- Create method
  PROCEDURE create_row(
    p_IDENTITY_ID# IN NUMBER,
    p_FACTOR_LINK_ID# IN NUMBER,
    p_OPERATION_CODE_ID# IN NUMBER,
    p_OPERAND1 IN VARCHAR2,
    p_OPERAND2 IN VARCHAR2,
    x_id# OUT number);

  -- Read method
  PROCEDURE read_row(p_id#        IN     number,
      x_ID# OUT NUMBER
    , x_IDENTITY_ID# OUT NUMBER
    , x_FACTOR_LINK_ID# OUT NUMBER
    , x_OPERATION_CODE_ID# OUT NUMBER
    , x_OPERAND1 OUT VARCHAR2
    , x_OPERAND2 OUT VARCHAR2
    );

  PROCEDURE read_by_IDENTITY_ID#_(
    p_IDENTITY_ID# IN number,
    x_attribute_list OUT attribute_list);

  PROCEDURE read_by_FACTOR_LINK_ID#_(
    p_FACTOR_LINK_ID# IN number,
    x_attribute_list OUT attribute_list);

  PROCEDURE read_by_OPERATION_CODE_ID#_(
    p_OPERATION_CODE_ID# IN number,
    x_attribute_list OUT attribute_list);

  -- Update method
  PROCEDURE update_row(
      p_id# NUMBER
    , p_IDENTITY_ID# IN NUMBER
    , p_FACTOR_LINK_ID# IN NUMBER
    , p_OPERATION_CODE_ID# IN NUMBER
    , p_OPERAND1 IN VARCHAR2
    , p_OPERAND2 IN VARCHAR2
    );

  -- Delete method
  PROCEDURE delete_row(p_id# IN number,
                    p_delete_children IN boolean := false);

  PROCEDURE delete_by_IDENTITY_ID#_(
    p_IDENTITY_ID# IN number,
    p_delete_children IN boolean := false);

  PROCEDURE delete_by_FACTOR_LINK_ID#_(
    p_FACTOR_LINK_ID# IN number,
    p_delete_children IN boolean := false);

  PROCEDURE delete_by_OPERATION_CODE_ID#_(
    p_OPERATION_CODE_ID# IN number,
    p_delete_children IN boolean := false);

END;
/

