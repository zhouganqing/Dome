create PACKAGE       dbms_macsec_role_admin AS

  /**
  * Creates a DV Secure Application Role, which controls the ability for users to
  * access the role based on a Rule Set.  Essentially, the following command is
  * issued:
  *
  * CREATE ROLE <role name> IDENTIFIED USING dvsys.dbms_macsec_roles;
  *
  * @param p_role Name of role to create
  */
  PROCEDURE create_role(p_role IN VARCHAR2);

  /**
  * Drops a DV Secure Application Role
  *
  * @param p_role Name of role to drop
  */
  PROCEDURE drop_role(p_role IN VARCHAR2);

END;
/

