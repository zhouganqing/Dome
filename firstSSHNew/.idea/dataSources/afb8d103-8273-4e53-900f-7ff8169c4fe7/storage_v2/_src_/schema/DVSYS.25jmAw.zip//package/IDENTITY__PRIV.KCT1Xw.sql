create PACKAGE       IDENTITY$_priv AS

  TYPE attribute_rec IS RECORD (
      ID# IDENTITY$.ID#%TYPE
    , FACTOR_ID# IDENTITY$.FACTOR_ID#%TYPE
    , VALUE IDENTITY$.VALUE%TYPE
    , TRUST_LEVEL IDENTITY$.TRUST_LEVEL%TYPE
  );

  TYPE attribute_list IS VARRAY(4096) OF attribute_rec;

  -- Create method
  PROCEDURE create_row(
    p_FACTOR_ID# IN NUMBER,
    p_VALUE IN VARCHAR2,
    p_TRUST_LEVEL IN NUMBER,
    x_id# OUT number);

  -- Read method
  PROCEDURE read_row(p_id#        IN     number,
      x_ID# OUT NUMBER
    , x_FACTOR_ID# OUT NUMBER
    , x_VALUE OUT VARCHAR2
    , x_TRUST_LEVEL OUT NUMBER
    );

  PROCEDURE read_by_FACTOR_ID#_(
    p_FACTOR_ID# IN number,
    x_attribute_list OUT attribute_list);

  -- Update method
  PROCEDURE update_row(
      p_id# NUMBER
    , p_FACTOR_ID# IN NUMBER
    , p_VALUE IN VARCHAR2
    , p_TRUST_LEVEL IN NUMBER
    );

  -- Delete method
  PROCEDURE delete_row(p_id# IN number,
                    p_delete_children IN boolean := false);

  PROCEDURE delete_by_FACTOR_ID#_(
    p_FACTOR_ID# IN number,
    p_delete_children IN boolean := false);

END;
/

