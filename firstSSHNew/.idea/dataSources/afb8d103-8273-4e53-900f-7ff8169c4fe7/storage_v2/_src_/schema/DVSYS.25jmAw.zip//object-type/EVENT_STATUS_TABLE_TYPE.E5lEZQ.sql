create TYPE       event_status_table_type
  AS TABLE OF DVSYS.event_status_row_type
/

