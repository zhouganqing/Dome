create procedure GetActiveRegion is
a date;
begin
 select sysdate into a from dual;
 commit;
end ;
/

