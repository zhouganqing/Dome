create procedure PRO_Monthly (p_ReturnCode out number)
 is
 
  --获取所有待月结的单据
     cursor curBonus is select cb.id, cb.collection_id, cb.amount, cb.status from  coll_bonus_detail cb where cb.status = 0 and
                        trunc(cb.settlement_date) = trunc(sysdate+3);
     
begin
  --月结单据的处理
  for c in curBonus loop
    BEGIN
         
        --添加奖金到催收员的账号
        update coll_client cl  set cl.balance=cl.balance + c.amount where cl.id = c.collection_id;
        --修改待月结单据的状态
        update    coll_bonus_detail d set d.status =1, d.update_time = sysdate  where d.id = c.id ;    
        
    END;
    end loop;
   
    commit;
    p_ReturnCode:=1;
   return;
  
end PRO_Monthly;
/

