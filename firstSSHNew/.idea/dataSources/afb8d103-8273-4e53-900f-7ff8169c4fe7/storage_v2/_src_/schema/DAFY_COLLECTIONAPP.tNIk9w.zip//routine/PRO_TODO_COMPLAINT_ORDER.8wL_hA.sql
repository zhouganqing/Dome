create procedure PRO_TODO_COMPLAINT_ORDER(
                                                 p_Oper      varchar2,
                                                 p_CreditId   number,
                                                 p_ComplaintId number,
                                                 p_CollectionId number,
                                                 p_UserId number,
                                                 p_ReturnCode  out varchar2) is
   error_info  varchar2(4000);
--create user:Tianxiangchuan
--use: 投诉订单操作
begin
   if p_Oper='DJ' then    ---订单冻结
     update delegate_receive set is_frozen=1,update_user=p_UserId,update_time=sysdate where credit_id=p_CreditId and collection_id=p_CollectionId;
     update coll_complaint set handle_time=sysdate,update_time=sysdate,update_user=p_UserId,handle_result='订单冻结',status=1 where id=p_ComplaintId;
   elsif p_Oper='HF' then    ---订单恢复
     update delegate_receive set is_frozen=0,update_user=p_UserId,update_time=sysdate where credit_id=p_CreditId and collection_id=p_CollectionId;
     update coll_complaint set handle_time=sysdate,update_time=sysdate,update_user=p_UserId,handle_result='订单恢复',status=1 where id=p_ComplaintId;
   elsif p_Oper='CH' then    ---订单撤回
     update delegate_receive set status=6,update_user=p_UserId,update_time=sysdate where credit_id=p_CreditId and collection_id=p_CollectionId;
     update coll_complaint set handle_time=sysdate,update_time=sysdate,update_user=p_UserId,handle_result='订单撤回',status=1 where id=p_ComplaintId;
   end if;
   commit;
   p_ReturnCode:='A';
   return;
exception 
   when others Then
     error_info := sqlerrm;
     p_ReturnCode:='Z-'||error_info;
     rollback;
end;
/

