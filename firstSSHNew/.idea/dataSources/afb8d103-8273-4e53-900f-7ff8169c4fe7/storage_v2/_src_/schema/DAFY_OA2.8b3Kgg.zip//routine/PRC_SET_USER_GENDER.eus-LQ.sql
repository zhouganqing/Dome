create procedure PRC_SET_USER_GENDER is
   v_GenderNum   char(1);
   v_Gender      sys_user_list.gender%type;
begin
   for cur in (select id,ident from sys_user_list where gender is null)
   loop
       if fun_checkidcard(cur.ident)=1 then
           if Length(cur.ident)=15 then
               v_GenderNum:=substr(cur.ident,15);
           else
               v_GenderNum:=substr(cur.ident,17,1);
           end if;
           if v_GenderNum in (0,2,4,6,8) then
               v_Gender:='女';
           else
               v_Gender:='男';
           end if;
           update sys_user_list set gender=v_Gender where id=cur.id;
           commit;
       end if;
   end loop;
end;
/

