create procedure prc_user_Tree(p_ReturnCode out varchar2) is

  /*创建日期：  2015/7/20   作者： lishan
    功能描述：  生成用户树
  */
  error_info varchar2(1000);
begin

  execute immediate 'truncate table sys_user_treepath';
  for hard_check_pre in (select id,
                                user_name,
                                role_id,
                                phone,
                                email,
                                ident,
                                status
                           from sys_user_list) loop
    insert into sys_user_treepath
      (id,
       user_id,
       role_id,
       user_name,
       phone,
       email,
       ident,
       status,
       parent_userid,
       parent_role_id,
       parent_name,
       parent_phone,
       parent_email,
       parent_ident,
       parent_status,
       path_length)
    values
      (SEQ_SYS_USER_TREEPATH.NEXTVAL,
       hard_check_pre.id,
       hard_check_pre.role_id,
       hard_check_pre.user_name,
       hard_check_pre.phone,
       hard_check_pre.email,
       hard_check_pre.ident,
       hard_check_pre.status,
       hard_check_pre.id,
       hard_check_pre.role_id,
       hard_check_pre.user_name,
       hard_check_pre.phone,
       hard_check_pre.email,
       hard_check_pre.ident,
       hard_check_pre.status,
       0);
  
    declare
      n        number := 0;
      c        number := 1;
      x        number := 0; --n c x 临时变量
      parentid number := 0;
      parent_org_id number :=0;
    begin
      parentid := hard_check_pre.id;
      while c > 0 loop
        n := n + 1;
        select count(*), max(b.user_id),max(b.org_id)
          into c, x,parent_org_id
          from sys_user_organize b
         where b.org_id in
               (select pid
                  from sys_organize
                 where id IN (select org_id
                                from sys_user_organize
                               where user_id = parentid))
           and user_id <> parentid;
        if (c > 0) then
          insert into sys_user_treepath
            (id,
             user_id,
             role_id,
             user_name,
             phone,
             email,
             ident,
             status,
             parent_userid,
             parent_role_id,
             parent_name,
             parent_phone,
             parent_email,
             parent_ident,
             parent_status,
             path_length)
            select SEQ_SYS_USER_TREEPATH.NEXTVAL,
                   hard_check_pre.id,
                   hard_check_pre.role_id,
                   hard_check_pre.user_name,
                   hard_check_pre.phone,
                   hard_check_pre.email,
                   hard_check_pre.ident,
                   hard_check_pre.status,
                   a.id,
                   a.role_id,
                   a.user_name,
                   a.phone,
                   a.email,
                   a.ident,
                   a.status,
                   n
              from sys_user_list a
              join sys_user_organize b
                on a.id = b.user_id
             where b.org_id =parent_org_id;
          parentid := x;
        end if;
        if (c <= 0) then
          c := 0;
        end if;
      end loop;
    end;
  end loop;
  commit;
  p_ReturnCode := 'A';
  return;
Exception
  When others Then
    error_info   := sqlerrm;
    p_ReturnCode := 'Z-' || error_info;
    rollback;
end;
/

