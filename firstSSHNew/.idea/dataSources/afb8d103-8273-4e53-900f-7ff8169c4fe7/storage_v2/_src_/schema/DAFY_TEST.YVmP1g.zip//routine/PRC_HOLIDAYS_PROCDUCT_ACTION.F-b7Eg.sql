create procedure prc_holidays_procduct_action(p_ReturnCode  out varchar2) is
  -- Author  : wangxiaofeng
  -- Created : 2015/08/11
  -- Purpose : 特殊产品的节假日启用与禁用 每天执行一次
  error_info  varchar2(1000);

  v_Count   number(10);
begin
  select count(1) into v_Count from sys_holiday t
  where t.holiday_date=trunc(sysdate);
  --如果存在此日期，则启用产品，否则冻结产品
  if v_Count>=1 then
    update product t set t.status=1,t.create_time=sysdate where t.holidays_flag=1 and t.status!=0;
  else
    update product t set t.status=2,t.create_time=sysdate where t.holidays_flag=1 and t.status!=0;
  end if;

  commit;
  p_ReturnCode:='A';
  return;
Exception
  When others Then
    error_info := sqlerrm;
    Rollback;

    p_ReturnCode := 'Z-'||error_info;
end prc_holidays_procduct_action;


/

