create procedure SAVE_USER_DSM(p_IdDsm          user_dsm.id_dsm%type,
                                          p_IdSaList       varchar2,                                            
                                          p_ReturnCode     out varchar2) is
  error_info      varchar2(1000);
  spltIdSaList    ty_str_split;
  idx             integer:=0;
begin
  delete user_dsm where id_dsm=p_IdDsm;
  if p_IdSaList is not null then
     spltIdSaList:=fun_split(p_IdSaList,',');
     for idx in 1..spltIdSaList.Count loop        
        insert into user_dsm(id_dsm,id_sa,update_time)
             values(p_IdDsm,to_number(spltIdSaList(idx)),sysdate);
     end loop;
  end if;
  commit;
  p_ReturnCode:='A';
  return;
Exception
  When others Then
    error_info := sqlerrm;
    Rollback;

    p_ReturnCode := 'Z-'||error_info;
end SAVE_USER_DSM;


/

