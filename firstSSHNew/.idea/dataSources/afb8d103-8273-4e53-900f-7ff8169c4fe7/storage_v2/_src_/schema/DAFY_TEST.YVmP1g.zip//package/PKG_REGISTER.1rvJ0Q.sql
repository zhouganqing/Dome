create package PKG_REGISTER is

  -- Author  : wangxiaofeng
  -- Created : 2015/6/13 10:10:43
  -- Purpose : 注册部管理
  
  type RefCursor is ref cursor;
  
  -- author  : wangxiaofeng
  -- created : 2015/6/20
  -- purpose : 获取最后一次hold备注
  function fun_reg_hold_remark(p_ContractNo varchar2)
    return varchar2;
  
  --注册扫描合同
  procedure prc_scan_contract(p_ContractNo         varchar2,
                              p_UpdateUser         number,
                              p_ReturnCode         out varchar2);
  
  -- author  : wangxiaofeng
  -- created : 2015/6/21
  -- purpose : 注册部hold 记录  多个合同号以逗号隔开                           
  procedure prc_set_hold(p_ContractNo  clob,
                         p_Remark      varchar2,
                         p_Flag        number,
                         p_UpdateUser  number,
                         p_ReturnCode  out varchar2);
                         
  -- author  : wangxiaofeng
  -- created : 2015/6/21
  -- purpose : 接单检查                       
  procedure prc_process_check_contract(p_ContractNo   number,
                                       p_CheckStatus  varchar2,
                                       p_Flag         number,
                                       p_UpdateUser   number,
                                       p_ReturnCode   out varchar2);  
                         
  -- author  : wangxiaofeng
  -- created : 2015/6/21
  -- purpose : 保存检查结果                           
  procedure prc_save_check_result(p_Xml          clob,
                                  p_IdCredit     number,
                                  p_ContractNo   number,
                                  p_CheckStatus  varchar2,
                                  p_ProductType  varchar2,
                                  p_UpdateUser   number,
                                  p_ReturnCode   out varchar2);                                                    
  
  -- author  : wangxiaofeng
  -- created : 2015/6/21
  -- purpose : 合同问题，或者检查者问题，合同返回待审池                      
  procedure prc_return_check_contract(p_ContractNo   number,
                                      p_CheckStatus  varchar2,
                                      p_Remark       varchar2,
                                      p_UpdateUser   number,
                                      p_ReturnCode   out varchar2);                                     
  
  -- author  : wangxiaofeng
  -- created : 2015/6/23
  -- purpose : 注册复查状态变更为结束状态                      
  procedure prc_auto_change_status(p_ReturnCode  out varchar2); 
                                                                          
end PKG_REGISTER;


/

