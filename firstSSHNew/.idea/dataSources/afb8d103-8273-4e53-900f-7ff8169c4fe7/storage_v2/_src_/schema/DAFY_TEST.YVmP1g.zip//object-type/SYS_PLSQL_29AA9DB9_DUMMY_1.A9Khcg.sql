create type             SYS_PLSQL_29AA9DB9_DUMMY_1 as table of number;
/

