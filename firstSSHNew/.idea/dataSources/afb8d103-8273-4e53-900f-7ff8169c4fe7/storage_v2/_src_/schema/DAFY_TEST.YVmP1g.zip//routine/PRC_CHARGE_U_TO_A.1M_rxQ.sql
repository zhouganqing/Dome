create procedure PRC_CHARGE_U_TO_A(p_ReturnCode out varchar2) is

----查找已回盘状态还是上传中的合同，修改状态为等待代扣。by 庾文峰

error_info            varchar2(1000);  

begin
  
update instalment set paystatus='a' where id in(
select id from instalment where status='a' and paystatus='u' and id_credit not in
(select contractno from checkoff_batch_detail where procode='代扣中'));
commit;

   p_ReturnCode:='A';
   return;
Exception
   When others Then
     error_info := sqlerrm;
     p_ReturnCode:='Z-'||error_info;
     rollback;
end;


/

