create procedure prc_save_cus_consult_enevt(p_EventId        varchar2,
                                                       P_ContractNo     varchar2,
                                                       p_IdPerson       number,
                                                       p_Remark         varchar2,
                                                       p_UpdateUser     varchar2,
                                                       p_ReturnCode     out varchar2)
is
  error_info      varchar2(1000);
--create user:WangXiaoFeng
--create time:2015-02-02
--use: 保存客户，销售，商户等咨询事件
begin
  insert into cus_consult_event_info(consult_event_id,contract_no,id_person,update_user,remark)
  values(p_EventId,P_ContractNo,p_IdPerson,p_UpdateUser,p_Remark);

  commit;
  p_ReturnCode:='A';
  return;
Exception
  When others Then
    error_info := sqlerrm;
    Rollback;

    p_ReturnCode := 'Z-'||error_info;
end prc_save_cus_consult_enevt;


/

