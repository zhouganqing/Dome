create function fun_get_cyclecontractno_by_id(p_id cycle_credit.id%type) return number is
  v_contractno number;
begin
  v_contractno:=0;
  select contract_no into v_contractno from cycle_credit where id=p_id;
  return(v_contractno);
  Exception
 When others Then
   return(v_contractno);
end fun_get_cyclecontractno_by_id;


/

