create procedure PRC_AUTO_DAILY_OVERDUE(p_ReturnCode  out varchar2) is
   error_info            varchar2(1000);
   v_IdCredit            cs_credit.id%type;
   v_ContractNo          cs_credit.contract_no%type;
   v_IdPerson            cs_credit.id_person%type;
   v_DateDue             instalment.date_due%type;
   v_Amount              instalment.value_instalment%type;
   --v_Paid                payinstalment.amount_pay%type;
   v_NumInstalment       instalment.num_instalment%type;
   v_OverAmount          instalment.value_instalment%type;
   v_OverDays            number;
   v_Count               number;

   --获取所有逾期合同大于等于1的合同
   cursor cur is select a.id_credit,b.contract_no,b.id_person,min(trunc(date_due)),a.num_instalment,
                   sum(a.value_instalment)-sum(a.value_pay) amount,trunc(sysdate)-min(trunc(a.date_due)) over_days
                 from instalment a,cs_credit b
                 where a.id_credit=b.id and a.status='a' and a.paystatus<>'k' and a.type_instalment<>'8'
                 and trunc(sysdate)-trunc(a.date_due)>=1 --and id_credit=120317
                 group by a.id_credit,a.num_instalment,b.contract_no,b.id_person
                 order by a.id_credit,a.num_instalment asc;

begin
   open cur;
   loop
      fetch cur into v_IdCredit,v_ContractNo,v_IdPerson,v_DateDue,v_NumInstalment,v_Amount,v_OverDays;
      exit when cur%notfound;

      /*select nvl(sum(amount_pay),0) into v_Paid from payinstalment a,instalment b where a.id_instalment=b.id
         and b.id_credit=v_IdCredit and b.num_instalment=v_NumInstalment and b.type_instalment!=8;

      if v_Paid>0 then
        v_Amount:=v_Amount-v_Paid;
      end if;*/
      select count(1) into v_Count from cs_cancel_instalment where id_credit=v_IdCredit and flag=1;
      if v_Count>=1 then
        v_Amount:=0;
      end if;

      --除去滞纳金，欠款多余50，则计算滞纳金，否则不计算
      if v_Amount>=50 then
        if v_OverDays=10 then
          v_OverAmount:=30;
        elsif v_OverDays=30 then
          v_OverAmount:=80;
        elsif v_OverDays=60 then
          v_OverAmount:=130;
        elsif v_OverDays=90 then
          v_OverAmount:=130;
        else
          v_OverAmount:=0;
        end if;

        if v_OverAmount>0 then
          if v_NumInstalment>1 then
            select (sum(a.value_instalment)-nvl(sum(a.value_pay),0)) into v_Count from instalment a
            where a.id_credit=v_IdCredit and a.num_instalment=v_NumInstalment-1 and a.status='a';

            if v_Count<50 then
              select count(1) into v_Count from instalment
              where id_credit=v_IdCredit and trunc(date_due)=trunc(v_DateDue)+v_OverDays and num_instalment>99;
              if v_Count<=0 then
                select max(num_instalment) into v_Count from instalment where id_credit = v_IdCredit;
                if v_Count<100 then
                  v_Count:=100;
                else
                  v_Count:=v_Count+1;
                end if;

                insert into instalment(id,id_credit,date_due,num_instalment,priority,status,type_instalment,value_instalment,version,ins_time,paystatus,paytype,update_time)
                  values(seq_instalment.nextval,v_IdCredit,trunc(v_DateDue)+v_OverDays,v_Count,5,'a',8,v_OverAmount,1,v_DateDue-10,'a','1',sysdate);
              end if;
            end if;
          else
            select count(1) into v_Count from instalment
            where id_credit=v_IdCredit and trunc(date_due)=trunc(v_DateDue)+v_OverDays and num_instalment>99;
            if v_Count<=0 then
              select max(num_instalment) into v_Count from instalment where id_credit = v_IdCredit;
              if v_Count<100 then
                v_Count:=100;
              else
                v_Count:=v_Count+1;
              end if;

              insert into instalment(id,id_credit,date_due,num_instalment,priority,status,type_instalment,value_instalment,version,ins_time,paystatus,paytype,update_time)
                values(seq_instalment.nextval,v_IdCredit,trunc(v_DateDue)+v_OverDays,v_Count,50,'a',8,v_OverAmount,1,v_DateDue-10,'a','1',sysdate);
            end if;
          end if;
        end if;
      end if;

      --除去滞纳金，欠款大于0时，计算逾期天数
      if v_Amount>0 then
        update instalment_overdue set num_instalment=v_NumInstalment,over_days=v_OverDays,over_amount=0,update_time=sysdate
        where contract_no=v_ContractNo;

        if sql%rowcount=0 then
          insert into instalment_overdue(id_credit,num_instalment,over_days,over_amount,date_due,update_time,contract_no,id_person)
          values(v_IdCredit,v_NumInstalment,v_OverDays,0,v_DateDue,sysdate,v_ContractNo,v_IdPerson);
        end if;
      end if;

      /*if v_OverDays > 1 then
        update instalment set paytype='3' where id_credit = v_IdCredit and num_instalment=v_NumInstalment and paystatus='j';
      end if;*/
   end loop;
   close cur;
   commit;
   prc_auto_collection_date_temp(p_ReturnCode);
   p_ReturnCode:='A';
   return;
Exception
   When others Then
     error_info := sqlerrm;
     p_ReturnCode:='Z-'||error_info;
     rollback;
end;


/

