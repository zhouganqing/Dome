create function FUN_GET_WORKFLOWNAME(p_WfiId decision_work_flow.id%type)
                                          return varchar2 is
  v_FlowName   decision_work_flow.flow_name%type;
begin
   select flow_name into v_FlowName from decision_work_flow where id=p_WfiId;
   return(v_FlowName);
end;


/

