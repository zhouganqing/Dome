create function fun_get_uncalled_days(p_id_credit cs_credit.id%type) return number is

--create time;2015/03/27
--create user:WangXiaoFeng
--use:获取催收案件未呼叫天数
  v_Count         number;
  v_Count1         number;
  v_Days          number(4):=0;
begin
  select count(1) into v_Count from collection_data_temp t where t.id_credit=p_id_credit;
  if v_Count<=0 then
    return v_Days;
  else
    select t.over_days into v_Count from collection_data_temp t where t.id_credit=p_id_credit;
    if v_Count<=2 then
      return v_Days;
    else
      select count(1) into v_Count1 from collection_call t where t.status=1 and t.id_credit=p_id_credit;
      if v_Count1<=0 then
        return v_Count-2;
      end if;

      for coll in(select update_time,ptp_time from (select trunc(t.update_time) update_time,trunc(t.ptp_time) ptp_time from collection_call t where t.id_credit=p_id_credit and t.status=1 order by t.id desc) where rownum=1)
        loop
          if coll.ptp_time is null then
            if coll.update_time>=trunc(sysdate) then
              return v_Days;
            elsif trunc(sysdate)-coll.update_time>=v_Count then
              return v_Count-2;
            else
              return trunc(sysdate)-coll.update_time-1;
            end if;
          else
            if coll.ptp_time>=trunc(sysdate) then
              return v_Days;
            elsif trunc(sysdate)-coll.ptp_time>=v_Count then
              return v_Count-2;
            else
              return trunc(sysdate)-coll.ptp_time-1;
            end if;
         end if;
       end loop;
    end if;
  end if;
Exception
 When others Then
   return(v_Days);
end fun_get_uncalled_days;


/

