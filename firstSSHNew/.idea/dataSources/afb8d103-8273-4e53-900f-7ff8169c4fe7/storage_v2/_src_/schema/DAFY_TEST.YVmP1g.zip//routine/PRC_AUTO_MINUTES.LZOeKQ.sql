create procedure PRC_AUTO_MINUTES(p_ReturnCode      out varchar2) is
   -- Author  : Luchangjiang
   -- Create Date : 2014-8-23
   -- Purpose : Hard check for decision_flag=0;
   v_IdCredit            cs_credit.id%type;
   v_AppDate             cs_credit.app_date%type;
   v_InterCode           cs_credit.inter_code%type;
   v_IdProduct           cs_credit.id_product%type;

   v_IdPerson            cs_person.id%type;
   v_Ident               cs_person.ident%type;
   v_IdentExp            cs_person.ident_exp%type;
   v_Birthday            date;
   v_ProdType            product.prod_type%type;

   v_UniversityCity      university.region%type;
   v_SellerCity          sellerplace.city%type;

   v_AreaCode            cn_city_list.area_code%type;
   v_AreaCode2           cn_city_list.area_code%type;
   v_ContactValue        cs_contact.contact_value%type;
   v_Count               integer;
   v_Status              cs_credit.status%type:='s';
   v_Seq                 decision_element_data.seq%type;

   error_info            varchar2(1000);
   cursor curS is select id,id_person,app_date,nvl(inter_code,1),id_product from cs_credit where status='s' and decision_flag=0;
   cursor curX is select id from cs_credit where status='x' and commit_time<=sysdate-15/24/60 and decision_flag=0;
begin
   open curS;
   loop
      fetch curS into v_IdCredit,v_IdPerson,v_AppDate,v_InterCode,v_IdProduct;
      exit when curS%notfound;

      select prod_type into v_ProdType from product where id=v_IdProduct;

      select nvl(max(seq),0) into v_Seq from decision_element_data where id_credit=v_IdCredit;

      delete wfi_ck_result where id_credit=v_IdCredit;
      select ident into v_Ident from cs_person where id=v_IdPerson;
      --v_Birthday:=to_date(substr(v_Ident,7,8),'yyyyMMdd');

      v_Status:='s';
      if fun_checkidcard(v_Ident)=0 then
          insert into wfi_ck_result(id,id_credit,id_wfi_items,id_wfi_result,user_name,comments,score,reject_flag)
               select seq_wfi_ck_result.nextval,v_IdCredit,1,1,100000,'身份证校验失败',-100,1 from dual;
          v_Status:='x';
          goto loop_Result;  
      end if;
            
      if length(v_Ident)=18 then
         v_Birthday:=to_date(substr(v_Ident,7,8),'yyyyMMdd');
      else
         v_Birthday:=to_date(substr(v_Ident,7,6),'yyMMdd');
      end if;
      -------------最小年龄限制--------------------------
      --如果申请时间与出生时间的天数差/365.25<18, 则创建拒绝原因"年龄小"
      if (v_AppDate-v_Birthday)<18*365.25 then
         insert into wfi_ck_result(id,id_credit,id_wfi_items,id_wfi_result,user_name,comments,score,reject_flag)
         select seq_wfi_ck_result.nextval,v_IdCredit,1,1,100000,'年龄小',-100,1 from dual;

         v_Status:='x';
         --goto loop_Result;
      end if;
      
      -------------最大年龄限制--------------------------
      --如果申请时间与出生时间的天数差/365.25>50, 则创建拒绝原因"年龄大"
      if (v_AppDate-v_Birthday)>50*365.25 then
         insert into wfi_ck_result(id,id_credit,id_wfi_items,id_wfi_result,user_name,comments,score,reject_flag)
         select seq_wfi_ck_result.nextval,v_IdCredit,1,2,100000,'年龄大',-100,1 from dual;

         v_Status:='x';
         --goto loop_Result;
      end if;
      ------------控制合同数量-------------------------------
      --如果客户剩余未偿还期数>=2,则创建拒绝原因"剩余期数"


      -----------历史逾期-------------------------
      --如果客户曾经在我们公司存在某一期逾期超过30天没有还款的,则创建拒绝原因"历史逾期

      -----------过去三个月最大逾期天数----------------------------------
      --系统时间往回算90天，如果客户存在逾期>10天,则创建拒绝原因"三个月逾期"

      -----------当前逾期天数----------------------------------
      --客户当前存在到期但未偿还期数的, 则创建拒绝原因"当前逾期"

      -----------黑名单客户------------------------------------
      --如果客户存在黑名单有效期限里,则创建拒绝原因"黑名单."
      --客户身份证黑名单
      select count(1) into v_Count from customer_blacklist where ident=v_Ident;
      if v_Count>0 then
         insert into wfi_ck_result(id,id_credit,id_wfi_items,id_wfi_result,user_name,comments,score,reject_flag)
         select seq_wfi_ck_result.nextval,v_IdCredit,1,7,100000,'客户身份证黑名单',-100,1 from dual;

         v_Status:='x';
         --goto loop_Result;
      end if;
      --客户本人手机号码黑名单
      select count(1) into v_Count from customer_blacklist where mobile in(select contact_value from cs_contact where id_person=v_IdPerson and person_type='1' and contact_type in(2,3,18,19));
      if v_Count>0 then
         insert into wfi_ck_result(id,id_credit,id_wfi_items,id_wfi_result,user_name,comments,score,reject_flag)
         select seq_wfi_ck_result.nextval,v_IdCredit,1,7,100000,'客户本人手机号码黑名单',-100,1 from dual;

         v_Status:='x';
         --goto loop_Result;
      end if;
       --客户其它手机号码黑名单
      select count(1) into v_Count from customer_blacklist where mobile in(select contact_value from cs_contact where id_person=v_IdPerson and person_type<>'1' and contact_type in(2,3,18,19));
      if v_Count>0 then
         insert into wfi_ck_result(id,id_credit,id_wfi_items,id_wfi_result,user_name,comments,score,reject_flag)
         select seq_wfi_ck_result.nextval,v_IdCredit,1,7,100000,'客户其它手机号码黑名单',-100,1 from dual;

         v_Status:='x';
         --goto loop_Result;
      end if;
      --客户家庭电话黑名单
      select count(1) into v_Count from customer_blacklist where home_num in(select contact_value from cs_contact where id_person=v_IdPerson and contact_type=18);
      if v_Count>0 then
         insert into wfi_ck_result(id,id_credit,id_wfi_items,id_wfi_result,user_name,comments,score,reject_flag)
         select seq_wfi_ck_result.nextval,v_IdCredit,1,7,100000,'客户家庭电话黑名单',-100,1 from dual;

         v_Status:='x';
         --goto loop_Result;
      end if;
      --公司工作电话黑名单
      select count(1) into v_Count from company_blacklist where office_num in(select contact_value from cs_contact where id_person=v_IdPerson and contact_type=3);
      if v_Count>0 then
         insert into wfi_ck_result(id,id_credit,id_wfi_items,id_wfi_result,user_name,comments,score,reject_flag)
         select seq_wfi_ck_result.nextval,v_IdCredit,1,7,100000,'公司工作电话黑名单',-100,1 from dual;

         v_Status:='x';
         --goto loop_Result;
      end if;
      --公司名称黑名单
      select count(1) into v_Count from company_blacklist where employer_name in(select company_name1 from cs_employer where id_person=v_IdPerson);
      if v_Count>0 then
         insert into wfi_ck_result(id,id_credit,id_wfi_items,id_wfi_result,user_name,comments,score,reject_flag)
         select seq_wfi_ck_result.nextval,v_IdCredit,1,7,100000,'公司名称黑名单',-100,1 from dual;

         v_Status:='x';
         --goto loop_Result;
      end if;

      ------------内部代码------------------------------------
      --如果内部代码为3,则创建拒绝原因"内部代码"--------------
      if v_InterCode=3 then
         insert into wfi_ck_result(id,id_credit,id_wfi_items,id_wfi_result,user_name,comments,score,reject_flag)
         select seq_wfi_ck_result.nextval,v_IdCredit,1,8,100000,'内部代码',-100,1 from dual;

         v_Status:='x';
         --goto loop_Result;
      end if;
      ------------选择代扣-----------------------------------
      --当前客户必须在申请表上选择"代扣",如果不选则创建拒绝原因"代扣"
      /*select count(1) into v_Count from cs_experience where id_credit=v_IdCredit and is_dd=1;
      if v_Count=0 then
         insert into wfi_ck_result(id,id_credit,id_wfi_items,id_wfi_result,user_name,comments,score,reject_flag)
         select seq_wfi_ck_result.nextval,v_IdCredit,1,9,100000,'代扣',-100,1 from dual;

         v_Status:='x';
         --goto loop_Result;
      end if;*/
      ------------只限当地人-------------------------------
      --客户的现居住地址必须和POS点在同一个城市,如果不同则创建拒绝原因"非当地人"
      if v_ProdType!=5 then
          select count(1) into v_Count from cs_credit a,cs_address b,sellerplace c where a.id=b.id_credit and a.id_sellerplace=c.id
             and b.province=c.province and b.city=c.city and b.address_type=2 and b.id_credit=v_IdCredit;
          if v_Count=0 then
              v_AreaCode:=null;
              v_AreaCode2:=null;
              select count(1) into v_Count from cs_credit a,cs_address b,cn_city_list c where a.id=b.id_credit and b.province=c.province
                 and b.city=c.city and b.address_type=2 and b.id_credit=v_IdCredit;
              if v_Count>=1 then
                  select c.area_code into v_AreaCode from cs_credit a,cs_address b,cn_city_list c where rownum=1 and a.id=b.id_credit and b.province=c.province
                     and b.city=c.city and b.address_type=2 and b.id_credit=v_IdCredit;
              end if;
              select count(1) into v_Count from cs_credit a,sellerplace b,cn_city_list c where a.id_sellerplace=b.id and b.province=c.province
                 and b.city=c.city and a.id=v_IdCredit;
              if v_Count>=1 then
                  select c.area_code into v_AreaCode2 from cs_credit a,sellerplace b,cn_city_list c where rownum=1 and a.id_sellerplace=b.id and b.province=c.province
                     and b.city=c.city and a.id=v_IdCredit;
              end if;
              if v_AreaCode is null or v_AreaCode2 is null or v_AreaCode<>v_AreaCode2 then
                  insert into wfi_ck_result(id,id_credit,id_wfi_items,id_wfi_result,user_name,comments,score,reject_flag)
                       select seq_wfi_ck_result.nextval,v_IdCredit,1,10,100000,'非当地人',-100,1 from dual;

                  v_Status:='x';
              end if;
          end if;
      end if;
      ------------控制申请单量-------------------------------
      --如果在过去30天内申请超过3次(>3),则创建拒绝原因"申请单量"
      select count(1) into v_Count from cs_credit a,cs_person b where a.id_person=b.id and b.ident=v_Ident and a.id!=v_IdCredit;
      if v_Count>3 then
         insert into wfi_ck_result(id,id_credit,id_wfi_items,id_wfi_result,user_name,comments,score,reject_flag)
         select seq_wfi_ck_result.nextval,v_IdCredit,1,11,100000,'申请单量',-100,1 from dual;

         v_Status:='x';
         --goto loop_Result;
      end if;
      -----------控制合同取消--------------------------------
      --当天取消合同次数超过2次,则创建拒绝原因"合同取消"-----
      select count(1) into v_Count from cs_credit a,cs_person b where a.id_person=b.id and trunc(a.commit_time)=trunc(sysdate) and a.status='t'
         and b.ident=v_Ident and a.id<>v_IdCredit;
      if v_Count>2 then
         insert into wfi_ck_result(id,id_credit,id_wfi_items,id_wfi_result,user_name,comments,score,reject_flag)
         select seq_wfi_ck_result.nextval,v_IdCredit,1,12,100000,'多次合同取消',-100,1 from dual;

         v_Status:='x';
         --goto loop_Result;
      end if;
      -----------距离最近一次申请被拒绝时间------------------
      --如果客户当次申请距离最近一次申请被拒绝时间<=90 天,则创建拒绝原因"历史拒绝"
      select count(1) into v_Count from cs_credit a,cs_person b where a.id_person=b.id and trunc(a.commit_time)>=trunc(sysdate)-90
         and a.status='d' and b.ident=v_Ident and a.id<>v_IdCredit;
      if v_Count>=1 then
         insert into wfi_ck_result(id,id_credit,id_wfi_items,id_wfi_result,user_name,comments,score,reject_flag)
         select seq_wfi_ck_result.nextval,v_IdCredit,1,13,100000,'历史拒绝',-100,1 from dual;

         v_Status:='x';
         --goto loop_Result;
      end if;
      -----------距离最近一次申请被通过时间------------------
      --如果客户当次申请距离最近一次申请被通过时间<=90 天,则创建拒绝原因"历史通过"
      select count(1) into v_Count from cs_credit a,cs_person b where a.id_person=b.id and trunc(a.commit_time)>=trunc(sysdate)-90
         and a.status='d' and b.ident=v_Ident and a.status in ('s','c','e','n','y','a') and a.id!=v_IdCredit;
      if v_Count>=1 then
         insert into wfi_ck_result(id,id_credit,id_wfi_items,id_wfi_result,user_name,comments,score,reject_flag)
         select seq_wfi_ck_result.nextval,v_IdCredit,1,14,100000,'历史通过',-100,1 from dual;

         v_Status:='x';
         --goto loop_Result;
      end if;
      -----------手机电话审核--------------------------------
      --如果客户的手机在过去六个月内被其他申请人用为手机,则创建拒绝原因"非本人"
      select count(1) into v_Count from cs_contact where id_credit=v_IdCredit and contact_type=2;
      if v_Count>0 then
         select contact_value into v_ContactValue from cs_contact where rownum=1 and id_credit=v_IdCredit and contact_type='2' and person_type='1';
         select count(1) into v_Count from cs_contact a,cs_person b,cs_credit c where a.id_credit=c.id and b.id=c.id_person
            and c.id<>v_IdCredit and a.contact_type='2' and a.person_type='1' and a.contact_value=v_ContactValue
            and b.ident<>v_Ident and c.status not in ('d','t');
         if v_count>0 then
            insert into wfi_ck_result(id,id_credit,id_wfi_items,id_wfi_result,user_name,comments,score,reject_flag)
            select seq_wfi_ck_result.nextval,v_IdCredit,1,15,100000,'非本人',-100,1 from dual;

            v_Status:='x';
            --goto loop_Result;
         end if;
      end if;

      -----------职位审核------------------------------------
      --门店代码62010000018 & 非学生，则拒绝
      select count(1) into v_Count from cs_employer where id_credit=v_IdCredit and position!='9';
      if v_Count=1 then
         select count(1) into v_Count from sellerplace where pos_code='62010000018' and id=(select id_sellerplace
           from cs_credit where id=v_IdCredit);
         if v_Count=1 then
             insert into wfi_ck_result(id,id_credit,id_wfi_items,id_wfi_result,user_name,comments,score,reject_flag)
                select seq_wfi_ck_result.nextval,v_IdCredit,1,16,100000,'职位',-100,1 from dual;

             v_Status:='x';
         end if;
         --goto loop_Result;
      end if;
      -----------身份证有效期--------------------------------
      --身份证有效期日需在申请日之后
      if v_ProdType!=5 then
          select ident_exp into v_IdentExp from cs_person where id=v_IdPerson;
          if v_IdentExp<v_AppDate then
             insert into wfi_ck_result(id,id_credit,id_wfi_items,id_wfi_result,user_name,comments,score)
             select seq_wfi_ck_result.nextval,v_IdCredit,1,17,100000,'身份证有效期',-100 from dual;

             v_Status:='x';
             --goto loop_Result;
          end if;
      end if;
      -----最终结果--------------------------------------------------
<<loop_Result>>
      if v_Status<>'x' then
         --如果审核项目中有运营审核,则进入运营审核池;否则,进入专家审核池
         v_Status:='c';   --运营审核池
      end if;
      update cs_credit set status=v_Status,update_time=sysdate where id=v_IdCredit;
      /*insert into cs_audit_log(id_credit,status,update_user,update_time)values(v_IdCredit,v_Status,100000,sysdate);
      insert into cs_audit_log2(id,id_credit,from_status,to_status,begin_time,end_time,update_user,update_time)
           values(seq_cs_audit_log2.nextval,v_IdCredit,'s',v_Status,sysdate,sysdate,100000,sysdate);*/
   end loop;
   close curS;
   commit;

   open curX;
   loop
      fetch curX into v_IdCredit;
      exit when curX%notfound;

      update cs_credit set status='d',update_time=sysdate where id=v_IdCredit;
      insert into decision_log(id,id_credit,status,item_name,result,remark,formula,update_time)
              values(seq_decision_log.nextval,v_IdCredit,'x','status','d',fun_getreg_value(15,'d'),'x->d',sysdate);
      delete decision_element_data_history where id_credit=v_IdCredit;
      insert /*+ append */ into decision_element_data_history select * from decision_element_data where id_credit=v_IdCredit;
      delete decision_element_data where id_credit=v_IdCredit;
      commit;
   end loop;
   close curX;

   p_ReturnCode:='A';
   return;
Exception
   When others Then
     error_info := sqlerrm;
     rollback;
     p_ReturnCode:='Z-'||error_info;
end;


/

