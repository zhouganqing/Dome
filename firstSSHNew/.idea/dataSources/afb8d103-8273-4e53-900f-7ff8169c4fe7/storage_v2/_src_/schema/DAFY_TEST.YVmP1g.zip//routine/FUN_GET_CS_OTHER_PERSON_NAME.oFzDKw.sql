create function fun_get_cs_other_person_name(p_id_credit    cs_credit.id%type,
                                                        p_person_type  cs_other_person.person_type%type)
                                                        return varchar2 is
v_Count  number;                                                      
v_Name   varchar2(50);
--Create User:wangxiaofeng;
--Use:根据客户关系获取客户关系人的姓名
begin
  select count(1) into v_Count from cs_other_person a  where a.id_credit=p_id_credit and a.person_type=p_person_type;
  if v_Count<=0 then
    v_Name:='';
  else    
    select a.name into v_Name from cs_other_person a where a.id_credit=p_id_credit and a.person_type=p_person_type and rownum=1;
  end if;
  return(v_Name);
end fun_get_cs_other_person_name;


/

