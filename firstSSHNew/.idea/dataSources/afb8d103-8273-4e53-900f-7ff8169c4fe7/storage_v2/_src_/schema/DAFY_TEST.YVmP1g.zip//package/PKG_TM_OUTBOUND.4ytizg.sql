create package PKG_TM_OUTBOUND is

  --电销管理模块
  -- Author  : 100064
  -- Created : 2015/4/27 16:20:54
  -- Purpose : 
  
  --更改交叉现金贷活动表及客户活动信息表状态
  procedure prc_auto_active_status(p_ReturnCode out varchar2);
  
  --生成电销Call 1阶段等待拨打列表
  procedure prc_get_tm_wait_call_list( p_ReturnCode   out varchar2);
  
  --生成每天拨打列表                                   
  procedure prc_tm_day_call_list(p_CallWaitDate   date,
                                 p_ReturnCode     out varchar2);
                                 
  --保存拨打结果
  procedure prc_save_tm_call_result(p_IdPerson           number,
                                    p_ClientIdent        varchar2,
                                    p_ClientName         varchar2,
                                    p_ClientSex          varchar2,
                                    p_ClientPhone        varchar2,
                                    P_CallResult         number,
                                    p_CallDetailResult   number,
                                    p_CallResultType     varchar2,
                                    p_ActiveId           number,
                                    p_Remark             varchar2,
                                    p_IsReservation      number,
                                    p_ReservatioTime     date,
                                    p_UpdateUser         number,
                                    p_CallType           number,
                                    p_CallStage          varchar2,
                                    p_ReturnCode         out varchar2); 
  
  -- author  : wangxiaofeng
  -- created : 2015/08/10
  -- purpose : 验证是否意向客户
  function fun_tm_check_R1(p_IdPerson  number)
    return number;                                   

end PKG_TM_OUTBOUND;


/

