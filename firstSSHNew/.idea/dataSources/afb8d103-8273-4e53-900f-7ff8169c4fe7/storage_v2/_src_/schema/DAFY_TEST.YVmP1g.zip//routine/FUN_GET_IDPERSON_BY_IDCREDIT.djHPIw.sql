create function fun_get_idperson_by_idcredit(p_id cs_credit.id%type) return number is
  v_idperson number;
begin
  v_idperson:=0;
  select id_person into v_idperson from cs_credit where id=p_id;
  return(v_idperson);
  Exception
 When others Then
   return(v_idperson);
end fun_get_idperson_by_idcredit;


/

