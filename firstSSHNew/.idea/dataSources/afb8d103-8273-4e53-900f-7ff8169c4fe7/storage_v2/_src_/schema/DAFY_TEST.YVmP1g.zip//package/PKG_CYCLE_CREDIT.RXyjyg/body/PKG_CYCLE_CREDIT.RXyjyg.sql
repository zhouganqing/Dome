create package body PKG_CYCLE_CREDIT is
    procedure PRC_DAILY_CYCLE_STATUS(p_CalcDate     date,
                                     p_ReturnCode   out varchar2) is
       /*2015-8-11  鲁长江
        循环现金贷合同状态逻辑处理*/
       error_info               varchar2(1000);
       v_ProgramName            cycle_daily_run_log.program_name%type;
       v_LogId                  number;
       v_Count                  number;
    
       v_CalcDate    date:=trunc(p_CalcDate);
       
    begin
       v_ProgramName:='PRC_DAILY_CYCLE_STATUS';
       select count(1) into v_Count from cycle_daily_run_log where program_name=v_ProgramName and run_date=v_CalcDate;
       if v_Count=0 then
           --前一天的数据如果没有运行，则发邮件报警
           select count(1) into v_Count from cycle_daily_run_log where program_name=v_ProgramName and run_date=v_CalcDate-1;
           if v_Count=0 then
              insert into sys_email_list(id,mail_type,key_word,from_user,mail_to,cc_to,subject,email_boby,status,create_time,plan_time)
                   values(seq_sys_email_list.nextval,'P1','数据不正确','cycle@dafycredit.com','luchangjiang@dafycredit.com,yuwenfeng@dafycredit.com,wangxiaofeng@dafycredit.com','',
                   '循环现金贷合同状态逻辑处理报警','循环现金贷合同状态逻辑处理程序前一天数据没有运行，导致合同状态逻辑处理数据不正确',0,sysdate,sysdate);
           end if;

           select seq_cycle_daily_run_log.nextval into v_LogId from dual;
           insert into cycle_daily_run_log(id,program_name,run_date,status,create_time)
                values(v_LogId,v_ProgramName,v_CalcDate,1,sysdate);

           update cycle_eligible set status=4,update_user=100000 where status =0 and end_date<=v_CalcDate;  --有效期是否已过,4-到期关闭
           for cur in (select id,id_person,status,available_amount from cycle_eligible where status in (1,2))
           loop
               select count(1) into v_Count from cycle_eligible where id_person=cur.id_person and status in (1,2);
               if v_Count>=1 then
                  select count(1) into v_Count from decision_log a,cs_credit b where a.id_credit=b.id and b.id_person=cur.id_person
                     and a.item_name='preHardCheck' and a.result='1' and (a.remark ='内部代码' or a.remark like '%黑名单%');
                  if v_Count >= 1 then
                      update cycle_eligible set status=3,update_user=100000 where id_person=cur.id_person and status in (1,2);
                  else
                      select count(1) into v_Count from collection_data_temp where id_person=cur.id_person;
                      if v_Count>0 then
                          select max(over_days) into v_Count from collection_data_temp where id_person=cur.id_person;
                          if v_Count>=30 then  --计算逾期天数
                              update cycle_eligible set status=3,update_user=100000 where id_person=cur.id_person and status in (1,2);  --3-异常关闭
                          else
                              update cycle_eligible set status=2,update_user=100000 where id_person=cur.id_person and status in (1,2);  --2-冻结
                          end if;
                      else
                          select count(1) into v_Count from decision_log a,cs_credit b where a.id_credit=b.id and b.id_person=cur.id_person
                             and ((a.item_name='preHardCheck' and a.remark <>'内部代码' and a.remark not like '%黑名单%') or a.item_name='postHardCheck') and a.result='1'
                             and a.update_time>=v_CalcDate-90;
                          if v_Count>=1 then
                             update cycle_eligible set status=2,update_user=100000 where id_person=cur.id_person and status in (1,2);  --2-冻结
                          else
                             update cycle_eligible set status=1,update_user=100000 where id_person=cur.id_person and status in (1,2);  --1-启用
                          end if;
                      end if;
                  end if;
               end if;
           end loop;
           update cycle_daily_run_log set status=2 where id=v_LogId;
           commit;
           p_ReturnCode:='A';
       else
           p_ReturnCode:='B-今天的数据已经处理，无需重复处理';
       end if;
       return;
    Exception
       When others Then
         error_info := sqlerrm;
         p_ReturnCode:='Z-'||error_info;
         rollback;
    end PRC_DAILY_CYCLE_STATUS;


    procedure PRC_DAILY_CYCLE_INSTALMENT(p_CalcDate        date,
                                         p_ReturnCode      out varchar2) is
       /*2015-8-7  鲁长江
        循环现金贷每日还款更新*/
       error_info               varchar2(1000);
       v_ProgramName            cycle_daily_run_log.program_name%type;
       v_LogId                  number;
       v_Count                  number;
       
       v_PrincipalAmount        number;    --本金
       v_LeftPrincipal          number;    --剩余本金
       v_OverDays               number;    --逾期天数;
       v_TotalOver              number;
       v_OverAmount             cycle_instalment.over_amount%type;     --滞纳金
       v_MinOver                number;
       v_CalcDate               date:=trunc(p_CalcDate);
    begin
       --当天如果已有生成，则删除
       v_ProgramName:='PRC_DAILY_CYCLE_INSTALMENT';
       select count(1) into v_Count from cycle_daily_run_log where program_name=v_ProgramName and run_date=v_CalcDate;
       if v_Count=0 then
           --前一天的数据有没有运行，如果没有，则发邮件报警
           select count(1) into v_Count from cycle_daily_run_log where program_name=v_ProgramName and run_date=v_CalcDate-1;
           if v_Count=0 then
              insert into sys_email_list(id,mail_type,key_word,from_user,mail_to,cc_to,subject,email_boby,status,create_time,plan_time)
                   values(seq_sys_email_list.nextval,'P2','测试','cycle@dafycredit.com','luchangjiang@dafycredit.com,yuwenfeng@dafycredit.com,wangxiaofeng@dafycredit.com','',
                   '循环现金贷还款计划报警','循环现金贷还款计划程序前一天数据没有运行，导致还款计划表数据缺失',0,sysdate,sysdate);
           end if;

           select seq_cycle_daily_run_log.nextval into v_LogId from dual;
           insert into cycle_daily_run_log(id,program_name,run_date,status,create_time)
                values(v_LogId,v_ProgramName,v_CalcDate,1,sysdate);

           for cur in (select id,date_due,credit_amount,interest_fee,service_fee,finance_fee from cycle_credit where status='a')
           loop
              select count(1) into v_Count from cycle_instalment where id_credit=cur.id;
              if v_Count=0 then  --首次需插入本金
                 v_PrincipalAmount:=cur.credit_amount;
                 v_LeftPrincipal:=cur.credit_amount;
              else   --非首次本金插入 0
                 v_PrincipalAmount:=0;
                 select sum(principal_amount*ad_flag) into v_LeftPrincipal from cycle_instalment where id_credit=cur.id and calc_date<v_CalcDate;
                 if v_LeftPrincipal<50 and v_LeftPrincipal>=1 then
                     v_LeftPrincipal:=50;
                 end if;
              end if;

              v_OverAmount:=0;
              if v_CalcDate>cur.date_due then   --计算滞纳金
                  select nvl(sum(principal_amount * ad_flag),0) into v_TotalOver from cycle_instalment where id_credit=cur.id;
                  if v_TotalOver>=50 then
                      v_OverDays:=v_CalcDate - cur.date_due;
                      v_OverAmount:=v_TotalOver * 5 / 100;
                      if v_OverDays=10 then
                         v_MinOver:=30;
                      elsif v_OverDays=30 then
                         v_MinOver:=80;
                      elsif v_OverDays=60 then
                         v_MinOver:=130;
                      elsif v_OverDays=90 then
                         v_MinOver:=130;
                      else
                         v_OverAmount:=0;
                         v_MinOver:=0;
                      end if;

                      --滞纳金按本金5%收取，但不能低于最低限额
                      if v_OverAmount<v_MinOver then
                         v_OverAmount:=v_MinOver;
                      end if;
                  end if;
               end if;
               if v_LeftPrincipal>0 then
                  insert into cycle_instalment(id,id_credit,calc_date,ad_flag,instalment_type,principal_amount,interest_amount,service_amount,finance_amount,over_amount,update_user,update_time)
                       values(seq_cycle_instalment.nextval,cur.id,v_CalcDate,1,1,v_PrincipalAmount,v_LeftPrincipal*cur.interest_fee/100,v_LeftPrincipal*cur.service_fee/100,v_LeftPrincipal*cur.finance_fee/100,v_OverAmount,100000,sysdate);
               end if;
           end loop;
           update cycle_daily_run_log set status=2 where id=v_LogId;
           p_ReturnCode:='A';
           commit;
       else
           p_ReturnCode:='B-今天的数据已经处理，无需重复处理';
       end if;
       return;
    Exception
       When others Then
         error_info := sqlerrm;
         p_ReturnCode:='Z-'||error_info;
         rollback;
    end PRC_DAILY_CYCLE_INSTALMENT;
end;
/

