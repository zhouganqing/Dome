create procedure PRC_CHECK_MONEY(p_ReturnCode out varchar2) is

--check date for each credit  by yuwenfeng
error_info            varchar2(1000);  
instalment_value        instalment.value_pay%type;
payinstalment_value     instalment.value_pay%type;
payin_value              instalment.value_pay%type;
incomelist_value        instalment.value_pay%type;
chekcoff_value          instalment.value_pay%type;

iq  instalment.value_pay%type;
im  instalment.value_pay%type;
ib  instalment.value_pay%type;

pq  instalment.value_pay%type;
pm  instalment.value_pay%type;
pb  instalment.value_pay%type;


begin
  for branch in(select distinct a.id from cs_person a,cs_credit b where a.id=b.id_person and b.status in('a','p','k')
    and not exists(select t.id_person from checkoff_temp t where t.id_person=a.id))
    loop
      
select nvl(sum(money),0) into chekcoff_value  from checkoff_batch_detail where rstatus='00' and contractno in(select id from cs_credit where id_person=branch.id);
select nvl(sum(value_pay),0) into instalment_value from instalment where status='a' and id_credit in(select id from cs_credit where id_person=branch.id);
select nvl(sum(amount_pay),0) into payinstalment_value from payinstalment where status='a' and id_payin in(select id from payin where status='a' and id_credit in (select id from cs_credit where id_person=branch.id));

for b1 in(
select 
sum(decode(incometype,'q',totalamount,0)) iq,
sum(decode(incometype,'m',totalamount,0)) im,
sum(decode(incometype,'b',totalamount,0)) ib,
nvl(sum(totalamount),0) incomelist_value 
from instalment_incomelist where status=1 and id in(select internal_id from payin where status='a' and id_credit in (select id from cs_credit where id_person=branch.id))
)
loop
  iq:=b1.iq;
  im:=b1.im;
  ib:=b1.ib;
  incomelist_value:=b1.incomelist_value;
end loop;

for b2 in(
select 
sum(decode(trans_type,'q',value_pay,0)) pq,
sum(decode(trans_type,'m',value_pay,0)) pm,
sum(decode(trans_type,'b',value_pay,0)) pb,
nvl(sum(value_pay),0) payin_value 
from payin where status='a' and id_credit in (select id from cs_credit where id_person=branch.id)
)
loop
  pq:=b2.pq;
  pm:=b2.pm;
  pb:=b2.pb;
  payin_value:=b2.payin_value;
end loop;



insert into checkoff_temp(id_person,instalment_value,payin_value,payinstalment_value,incomelist_value,checkoff_value,pq,pm,pb,iq,im,ib)
values(to_char(branch.id),instalment_value,payin_value,payinstalment_value,incomelist_value,chekcoff_value,pq,pm,pb,iq,im,ib);

commit;
end loop;
    
p_ReturnCode:='A';

    return;
Exception
   When others Then
     error_info := sqlerrm;
     p_ReturnCode:='Z-'||error_info;
     rollback;
end;


/

