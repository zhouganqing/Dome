create procedure prc_save_instalment_p2p_match(
                                                 p_loan_date       varchar2,
                                                 p_release_loan     varchar2,
                                                 p_contract_no    varchar2,
                                                 p_release_contract varchar2,
                                                 p_credit_model varchar2,
                                                 p_update_user   varchar2,
                                                 p_update_ip         varchar2,
                                                 p_ReturnCode     out varchar2) is
  c_count number;
  error_info      varchar2(1000);
  --还款日匹配，保证合同编号或者现行日期是惟一
  --by tujiansheng 20150921
begin

   if p_contract_no is not null and p_release_contract is not null then
        select count(1) into c_count from instalment_p2p_rrjc_match where contract_no = p_contract_no and credit_model = p_credit_model;
        if c_count > 0 then
          delete from instalment_p2p_rrjc_match
           where  contract_no = p_contract_no
             and credit_model = p_credit_model;
        end if;
   end if;
   if p_loan_date is not null and p_release_loan is not null then
        select count(1) into c_count from instalment_p2p_rrjc_match where loan_date = p_loan_date and credit_model = p_credit_model;
        if c_count > 0 then
          delete from instalment_p2p_rrjc_match
           where loan_date = p_loan_date
             and credit_model = p_credit_model;
        end if;
   end if;
   insert into instalment_p2p_rrjc_match
        (id,
         loan_date,
         release_loan,
         contract_no,
         release_contract,
         update_time,
         update_user,
         update_ip,
         credit_model)
      values
        (seq_instalment_p2p_rrjc_match.nextval,
         p_loan_date,
         p_release_loan,
         p_contract_no,
         p_release_contract,
         sysdate,
         p_update_user,
         p_update_ip,
         p_credit_model);
  commit;
  p_ReturnCode:='A';
  return;
Exception
  When others Then
    error_info := sqlerrm;
    Rollback;

    p_ReturnCode := 'Z-'||error_info;
end prc_save_instalment_p2p_match;
/

