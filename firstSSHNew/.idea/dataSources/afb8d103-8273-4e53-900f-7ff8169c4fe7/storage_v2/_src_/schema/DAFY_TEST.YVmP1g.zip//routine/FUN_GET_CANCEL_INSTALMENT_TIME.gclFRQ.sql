create function fun_get_cancel_instalment_time(p_id_credit cs_credit.id%type) return varchar2 is
  v_cancel_instalment_time  varchar2(30);
--create time;2015/01/22
--create user:WangXiaoFeng
--use:获取合同取消分期日
begin
  v_cancel_instalment_time:='';
  select to_char(update_time,'yyyy/mm/dd hh24:mi:ss') into v_cancel_instalment_time from cs_cancel_instalment where id_credit=p_id_credit and flag=1;
  return(v_cancel_instalment_time);
Exception
 When others Then
   return(v_cancel_instalment_time);
end fun_get_cancel_instalment_time;


/

