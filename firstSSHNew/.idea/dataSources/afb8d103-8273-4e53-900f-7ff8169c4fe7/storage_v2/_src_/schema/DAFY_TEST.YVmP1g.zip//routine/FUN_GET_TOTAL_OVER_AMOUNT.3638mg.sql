create function fun_get_total_over_amount(p_id_credit payin.id_credit%type)
                                          return number is
  v_over_amount   payin.value_pay%type;
begin
   select sum(decode(t.type_instalment,'8',t.value_instalment,0)) into v_over_amount from instalment t
   where t.status='a' and t.id_credit=p_id_credit;
  return(v_over_amount);
end fun_get_total_over_amount;


/

