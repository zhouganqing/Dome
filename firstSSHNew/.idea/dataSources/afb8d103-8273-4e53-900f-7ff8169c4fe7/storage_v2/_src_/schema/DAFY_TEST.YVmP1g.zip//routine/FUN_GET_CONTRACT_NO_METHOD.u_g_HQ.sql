create function fun_get_contract_no_method(p_id_credit cs_credit.id%type) return varchar2 is
  v_contract_no_method  varchar2(20);
  v_count               number;
--create time;2015/01/22
--create user:WangXiaoFeng
--use:获取客户的合同方法
begin
  v_contract_no_method:='';
  select count(1) into v_count from collection_data_diffcult where id_credit=p_id_credit;
  if v_count>=1 then
    v_contract_no_method:='疑难案件';
  else
    select count(1) into v_count from collection_data_stop where id_credit=p_id_credit;
    if v_count>=1 then
      v_contract_no_method:='停催案件';
    end if;
  end if;
  return(v_contract_no_method);
Exception
 When others Then
   return(v_contract_no_method);
end fun_get_contract_no_method;


/

