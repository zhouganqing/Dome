create function fun_get_consult_event_type(p_Id  varchar2)
                                          return varchar2 is
  v_Count       varchar2(50);
  v_Event_Type  varchar2(200);
  v_Temp        varchar2(200);
  --Create User:wangxiaofeng;
  --Use:获取拼接客户咨询事件（待优化，需要写到程序中）
begin
   select a.parent_id into v_Count from cus_consult_event_config a where a.id=p_Id;
   select a.event_type into v_Temp from cus_consult_event_config a where a.id=p_Id;
   if v_Count='0' then
     v_Event_Type:=v_Temp;
   else
     v_Event_Type:=v_Temp;
     while v_Count!='0' loop
       select a.event_type into v_Temp from cus_consult_event_config a where a.id=v_Count;
       select a.parent_id into v_Count from cus_consult_event_config a where a.id=v_Count;
       v_Event_Type:=v_Temp||'-'||v_Event_Type;
     end loop;
   end if;
   return(v_Event_Type);
end fun_get_consult_event_type;


/

