create function fun_get_overdue_amount(p_id_credit cs_credit.id%type)
                                          return number is
  v_overdue_amount   number;
--Create User:wangxiaofeng;
--Use:获取合同逾期未还滞纳金欠款金额
begin
  /*select nvl(sum(a.value_instalment),0) into v_overdue_amount
         from instalment a,(select a.id_instalment,sum(a.amount_pay) amount_pay from payinstalment a group by a.id_instalment) d
         where a.id_credit=p_id_credit
         and a.type_instalment=8
         and a.id = d.id_instalment(+)
         --and a.date_due < sysdate
         and not exists
                 (select '#'
                         from (select a.id_instalment,sum(a.amount_pay) amount_pay from payinstalment a group by a.id_instalment) b
                         where b.id_instalment = a.id
                         and b.amount_pay >= a.value_instalment)
   group by a.id_credit;--,a.num_instalment;*/
   select nvl(sum(value_instalment-value_pay),0) into v_overdue_amount 
   from instalment a 
   where a.type_instalment=8 and a.status='a' and a.paystatus in('a','u') and a.id_credit=p_id_credit;

   return(v_overdue_amount);
Exception
 When others Then
   return(0);
end fun_get_overdue_amount;


/

