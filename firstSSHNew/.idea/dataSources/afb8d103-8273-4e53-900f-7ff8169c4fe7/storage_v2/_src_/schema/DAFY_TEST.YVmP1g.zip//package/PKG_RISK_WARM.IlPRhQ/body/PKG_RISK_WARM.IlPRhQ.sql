create package body PKG_RISK_WARM is

  --查询与计算各种风险提示信息
  procedure prc_add_risk_warm(p_IdCredit      cs_credit.id%type,
                              p_UpdateUser    number,
                              p_ReturnCode    out varchar2)
    is
    v_IdPerson        number;
    v_SaId            number;
    v_IdSellerlace    number;
    v_Position        number;
    v_CompanyName     varchar2(500);
    v_DueDate         date;
    v_InterCode       number;
    v_Count           number;
    error_info        varchar2(2000);
  begin
    delete from risk_warm_info where id_credit=p_IdCredit;
    select count(1) into v_Count from risk_warm_config t where t.is_parent=1 and t.status=1 and t.parent_id=0;  
    if v_Count>=1 then
      select a.id_person,a.id_sa,a.id_sellerplace,a.inter_code,b.position,b.company_name1 
        into v_IdPerson,v_SaId,v_IdSellerlace,v_InterCode,v_Position,v_CompanyName
        from cs_credit a,cs_employer b where a.id=b.id_credit and a.id=p_IdCredit;
         
      for risk in(select t.id from risk_warm_config t where t.is_parent=1 and t.status=1 and t.parent_id=0)
        loop
          if risk.id=1 then
            for cur in(select id_credit,
            cred.id_person,
            reg.reg_val_code,
            reg.reg_val_name person_type_name,
            contact_type,
            reg2.reg_val_name contact_type_name,
            contact_value,
            cred.id_sellerplace id_sellerplace,
            sell.city
            from cs_credit cred
            join cs_contact con on cred.id=con.id_credit
            left join registers reg on con.person_type=reg.reg_val_code and reg.reg_number in (265,396)
            left join registers reg2 on con.contact_type=reg2.reg_val_code and reg2.reg_number=395
            left join sellerplace sell on sell.id=cred.id_sellerplace
            where reg2.reg_val_code in (2,3,13,18,19) and cred.id=p_IdCredit)
            loop
              v_Count:=0;
              --联系号码（学生和除富士康办公电话除外） 在N个合同中被使用,请关联电话查询
              if cur.contact_type=3 and v_Position!=9 and v_CompanyName not like '%富士康%' then
                select count(1) into v_Count
                from cs_credit cred
                join cs_contact con on cred.id=con.id_credit and id_sa<>'800079' --测试账号，正式数据库不能去除
                left join registers reg on con.person_type=reg.reg_val_code and reg.reg_number in (265,396)
                left join registers reg2 on con.contact_type=reg2.reg_val_code and reg2.reg_number=395
                where reg2.reg_val_code=3 and cred.commit_time>=trunc(sysdate)-30 and cred.id_person!=cur.id_person and con.contact_value=cur.contact_value;
                --如果出现5次以上表示同一公司申请人很多，不加入风险提示
                if v_Count>=1 and v_Count<=6 then
                  insert into risk_warm_info(id_credit,risk_warm_id,risk_warm_content,update_user,contract_no)
                  select p_IdCredit,1,'联系号码 '||cur.person_type_name||'-'||cur.contact_type_name||'-'||cur.contact_value||'在：'||cred.contract_no||'合同中被他人使用;',
                  p_UpdateUser,cred.contract_no  
                  from cs_credit cred
                  join cs_contact con on cred.id=con.id_credit and id_sa<>'800079' --测试账号，正式数据库不能去除
                  left join registers reg on con.person_type=reg.reg_val_code and reg.reg_number in (265,396)
                  left join registers reg2 on con.contact_type=reg2.reg_val_code and reg2.reg_number=395
                  where reg2.reg_val_code=3 and cred.commit_time>=trunc(sysdate)-30 and cred.id_person!=cur.id_person and con.contact_value=cur.contact_value;
                end if;
              elsif cur.contact_type=13 then
                select count(1) into v_Count
                from cs_credit cred
                join cs_contact con on cred.id=con.id_credit and id_sa<>'800079' --测试账号，正式数据库不能去除
                left join registers reg on con.person_type=reg.reg_val_code and reg.reg_number in (265,396)
                left join registers reg2 on con.contact_type=reg2.reg_val_code and reg2.reg_number=395
                where reg2.reg_val_code=13 and cred.id_person!=cur.id_person and con.contact_value=cur.contact_value;
                if v_Count>=1 then
                  insert into risk_warm_info(id_credit,risk_warm_id,risk_warm_content,update_user,contract_no)
                  select p_IdCredit,1,'联系号码 '||cur.person_type_name||'-'||cur.contact_type_name||'-'||cur.contact_value||'在：'||cred.contract_no||'合同中被他人使用;',
                  p_UpdateUser,cred.contract_no  
                  from cs_credit cred
                  join cs_contact con on cred.id=con.id_credit and id_sa<>'800079' --测试账号，正式数据库不能去除
                  left join registers reg on con.person_type=reg.reg_val_code and reg.reg_number in (265,396)
                  left join registers reg2 on con.contact_type=reg2.reg_val_code and reg2.reg_number=395
                  where reg2.reg_val_code=13 and cred.id_person!=cur.id_person and con.contact_value=cur.contact_value;
                end if;
              else    
                select count(1) into v_Count
                from cs_credit cred
                join cs_contact con on cred.id=con.id_credit and id_sa<>'800079' --测试账号，正式数据库不能去除
                left join registers reg on con.person_type=reg.reg_val_code and reg.reg_number in (265,396)
                left join registers reg2 on con.contact_type=reg2.reg_val_code and reg2.reg_number=395
                where reg2.reg_val_code in (2,18,19) and cred.id_person!=cur.id_person and con.contact_value=cur.contact_value;
                if v_Count>=1 then
                  insert into risk_warm_info(id_credit,risk_warm_id,risk_warm_content,update_user,contract_no)
                  select p_IdCredit,1,'联系号码 '||cur.person_type_name||'-'||cur.contact_type_name||'-'||cur.contact_value||'在：'||cred.contract_no||'合同中被他人使用;',
                  p_UpdateUser,cred.contract_no  
                  from cs_credit cred
                  join cs_contact con on cred.id=con.id_credit and id_sa<>'800079' --测试账号，正式数据库不能去除
                  left join registers reg on con.person_type=reg.reg_val_code and reg.reg_number in (265,396)
                  left join registers reg2 on con.contact_type=reg2.reg_val_code and reg2.reg_number=395
                  where reg2.reg_val_code in (2,18,19) and cred.id_person!=cur.id_person and con.contact_value=cur.contact_value;
                end if;
              end if; 
            end loop;
          end if;
          
          v_Count:=0;
          if risk.id=2 then
            for cur in(select id_credit,
            cred.id_person,
            reg.reg_val_code,
            reg.reg_val_name person_type_name,
            contact_type,
            reg2.reg_val_name contact_type_name,
            contact_value,
            cred.id_sellerplace id_sellerplace,
            sell.city,
            cred.id_sa
            from cs_credit cred
            join cs_contact con on cred.id=con.id_credit
            left join registers reg on con.person_type=reg.reg_val_code and reg.reg_number in (265,396)
            left join registers reg2 on con.contact_type=reg2.reg_val_code and reg2.reg_number=395
            left join sellerplace sell on sell.id=cred.id_sellerplace
            where reg2.reg_val_code=2 and cred.id=p_IdCredit)
            loop    
              --提交此申请合同的SA或销售点(包括邻近销售点)最近30天内有N个合同中出现相似字段手机号码,请关联电话查询相似字段：13870881(比对前8位一致)
              select count(1) into v_Count
              from cs_credit cred
              join cs_contact con on cred.id=con.id_credit and id_sa<>'800079' --测试账号，正式数据库不能去除
              left join registers reg on con.person_type=reg.reg_val_code and reg.reg_number in (265,396)
              left join registers reg2 on con.contact_type=reg2.reg_val_code and reg2.reg_number=395
              left join sellerplace sell on sell.id=cred.id_sellerplace
              where reg2.reg_val_code=2 and cred.id_person!=cur.id_person and substr(con.contact_value,1,9)=substr(cur.contact_value,1,9) 
              and cred.commit_time>=trunc(sysdate)-30 and (cred.id_sa=cur.id_sa or sell.city=cur.city);
                
              if v_Count>=1 then
                insert into risk_warm_info(id_credit,risk_warm_id,risk_warm_content,update_user,contract_no)
                select p_IdCredit,2,'手机号码 '||cur.contact_value||'在：'||cred.contract_no||'合同中出现此号码前9位相似;',p_UpdateUser,cred.contract_no  
                from cs_credit cred
                join cs_contact con on cred.id=con.id_credit and id_sa<>'800079' --测试账号，正式数据库不能去除
                left join registers reg on con.person_type=reg.reg_val_code and reg.reg_number in (265,396)
                left join registers reg2 on con.contact_type=reg2.reg_val_code and reg2.reg_number=395
                left join sellerplace sell on sell.id=cred.id_sellerplace
                where reg2.reg_val_code=2 and cred.id_person!=cur.id_person and substr(con.contact_value,1,9)=substr(cur.contact_value,1,9) 
                and cred.commit_time>=trunc(sysdate)-30 and (cred.id_sa=cur.id_sa or sell.city=cur.city)
                and not exists(select '#' from risk_warm_info r where r.contract_no=cred.contract_no and r.id_credit=p_IdCredit);
              end if;
            end loop;
          end if;
          
          v_Count:=0;
          if risk.id=3 then
            --客户有2次申请记录，最近一次提交申请是在2014/1/10日,请在客户合同信息比对页面输入客户身份证号码查看原因和进行信息比对 例如撤销1次;被拒绝0次;现行1次;完成0次  
            select count(1) into v_Count from cs_credit where id_person=v_IdPerson;
            if v_Count>=2 then 
              for csc in(select trunc(max(app_date)) app_date,sum(cancels) cancels,sum(rejects) rejects,sum(due) due,sum(finishs) finishs from
                          (select t.app_date,decode(t.status,'t',1,0) cancels,decode(t.status,'d',1,0) rejects,decode(t.status,'a',1,0) due,decode(t.status,'k',1,'p',1,0) finishs 
                          from cs_credit t where t.id!=p_IdCredit and t.id_person=v_IdPerson))
              loop
                insert into risk_warm_info(id_credit,risk_warm_id,risk_warm_content,update_user)
                  values(p_IdCredit,3,'最近一次申请日期：'||to_char(csc.app_date,'yyyy/mm/dd')||'撤销'||csc.cancels||'次,拒绝'||csc.rejects||'次,现行'||csc.due||'次,完结'||csc.finishs||'次;',p_UpdateUser);
              end loop;
            end if;
          end if;
          
          v_Count:=0;
          if risk.id=4 then
            --客户有1次逾期记录,最近一次逾期时间是在2014/1/10日,请查看还款计划表的逾期、电话会谈结果
            select max(t.date_due),count(1) into v_DueDate,v_Count from instalment t where t.id_credit=p_IdCredit and t.type_instalment='8';
            if v_Count>=1 then
              insert into risk_warm_info(id_credit,risk_warm_id,risk_warm_content,update_user)
              values(p_IdCredit,4,'有'||v_Count||'次逾期记录,最近一次逾期时间：'||v_DueDate,p_UpdateUser);
            end if; 
          end if;
          
          if risk.id=5 then
            --客户的身份证地址与以下申请合同中出现地址相似，请使用客户合同信息比对页面查看是否有可疑: (富士康现住址除外)合同：xxxxxxxx,xxxxxxxxx,xxxxxxxxxx
          for cad in(select a.province,a.city,a.region,a.town,a.street,a.building from cs_address a,cs_employer b 
                     where a.id_credit=b.id_credit and a.address_type=1 and b.position!=9 and b.company_name1 not like '%富士康%' and a.id_credit=p_IdCredit)
            loop
              select count(1) into v_Count from cs_address a,cs_employer b 
                 where a.id_credit=b.id_credit and a.address_type in(1,2) and b.position!=9 
                 and b.company_name1 not like '%富士康%' and a.id_person!=v_IdPerson
                 and a.province=cad.province
                 and a.city=cad.city
                 and a.region=cad.region
                 and replace(replace(a.town,' ',''),'*','')=replace(replace(cad.town,' ',''),'*','')
                 and replace(replace(a.street,' ',''),'*','')=replace(replace(cad.street,' ',''),'*','') 
                 and replace(replace(a.building,' ',''),'*','')=replace(replace(cad.building,' ',''),'*','');
              --地址过多相同，可能是同一公司、学校、工厂等的人，不用风险提示
              if v_Count>=1 and v_Count<=3 then 
                insert into risk_warm_info(id_credit,risk_warm_id,risk_warm_content,update_user,contract_no)
                select distinct p_IdCredit,5,'合同：'||c.contract_no||'与申请客户的身份证地址出现相似;',p_UpdateUser,c.contract_no 
                from cs_address a,cs_employer b,cs_credit c 
                 where a.id_credit=b.id_credit and a.id_credit=c.id and a.address_type in(1,2) and b.position!=9 
                 and b.company_name1 not like '%富士康%' and a.id_person!=v_IdPerson
                 and a.province=cad.province
                 and a.city=cad.city
                 and a.region=cad.region
                 and replace(replace(a.town,' ',''),'*','')=replace(replace(cad.town,' ',''),'*','')
                 and replace(replace(a.street,' ',''),'*','')=replace(replace(cad.street,' ',''),'*','') 
                 and replace(replace(a.building,' ',''),'*','')=replace(replace(cad.building,' ',''),'*','')
                 and not exists(select '#' from risk_warm_info r where r.contract_no=c.contract_no and r.id_credit=p_IdCredit);
              end if;
            end loop;
          end if;
          
          if risk.id=101 then
            --客户的现住址与以下申请合同中出现地址相似，请使用客户合同信息比对页面查看是否有可疑: (富士康现住址除外)合同：xxxxxxxx,xxxxxxxxx,xxxxxxxxxx
          for cad in(select a.province,a.city,a.region,a.town,a.street,a.building from cs_address a,cs_employer b 
                     where a.id_credit=b.id_credit and a.address_type=2 and b.position!=9 and b.company_name1 not like '%富士康%' and a.id_credit=p_IdCredit)
            loop
              select count(1) into v_Count from cs_address a,cs_employer b 
                 where a.id_credit=b.id_credit and a.address_type in(1,2) and b.position!=9 
                 and b.company_name1 not like '%富士康%' and a.id_person!=v_IdPerson
                 and a.province=cad.province
                 and a.city=cad.city
                 and a.region=cad.region
                 and replace(replace(a.town,' ',''),'*','')=replace(replace(cad.town,' ',''),'*','')
                 and replace(replace(a.street,' ',''),'*','')=replace(replace(cad.street,' ',''),'*','') 
                 and replace(replace(a.building,' ',''),'*','')=replace(replace(cad.building,' ',''),'*','');
              --地址过多相同，可能是同一公司、学校、工厂等的人，不用风险提示
              if v_Count>=1 and v_Count<=3 then 
                insert into risk_warm_info(id_credit,risk_warm_id,risk_warm_content,update_user,contract_no)
                select distinct p_IdCredit,5,'合同：'||c.contract_no||'与申请客户的现住址出现相似;',p_UpdateUser,c.contract_no 
                from cs_address a,cs_employer b,cs_credit c 
                 where a.id_credit=b.id_credit and a.id_credit=c.id and a.address_type in(1,2) and b.position!=9 
                 and b.company_name1 not like '%富士康%' and a.id_person!=v_IdPerson
                 and a.province=cad.province
                 and a.city=cad.city
                 and a.region=cad.region
                 and replace(replace(a.town,' ',''),'*','')=replace(replace(cad.town,' ',''),'*','')
                 and replace(replace(a.street,' ',''),'*','')=replace(replace(cad.street,' ',''),'*','') 
                 and replace(replace(a.building,' ',''),'*','')=replace(replace(cad.building,' ',''),'*','')
                 and not exists(select '#' from risk_warm_info r where r.contract_no=c.contract_no and r.id_credit=p_IdCredit);
              end if;   
            end loop;
          end if;
          
          if risk.id=7 then
            --此申请合同内部代码为2
            if v_InterCode=2 then
              insert into risk_warm_info(id_credit,risk_warm_id,risk_warm_content,update_user)
              values(p_IdCredit,7,'此申请合同内部代码为2',p_UpdateUser);
            end if;
          end if;
          
          if risk.id=8 then
            --提交此申请合同的SA或销售点最近30天内有2单以上的不同身份证申请但申请表有相同的姓名出现 相同姓名为：xxx 合同号：xxxxxxxx,xxxxxxxxx,xxxxxxxxxx
            for cso in(select b.name,a.contract_no 
                        from cs_credit a,cs_other_person b,(select name from cs_other_person c where c.id_credit=p_IdCredit) d 
                        where a.id=b.id_credit and b.name=d.name
                        and a.id_person!=v_IdPerson and a.commit_time>=trunc(sysdate)-30 
                        and (a.id_sa=v_SaId or a.id_sellerplace=v_IdSellerlace)
                        group by b.name,a.contract_no)
              loop
                insert into risk_warm_info(id_credit,risk_warm_id,risk_warm_content,update_user,contract_no)
                select distinct p_IdCredit,8,'姓名：'||cso.name||' 在合同：'||a.contract_no||' 中出现;',p_UpdateUser,a.contract_no
                from cs_credit a,cs_other_person b,(select name from cs_other_person c where c.id_credit=p_IdCredit) d 
                where a.id=b.id_credit and b.name=d.name
                and a.id_person!=v_IdPerson and a.commit_time>=trunc(sysdate)-30 
                and (a.id_sa=v_SaId or a.id_sellerplace=v_IdSellerlace)
                and not exists(select '#' from risk_warm_info r where r.contract_no=a.contract_no and r.id_credit=p_IdCredit)
                group by b.name,a.contract_no;
              end loop;
          end if;
          
          --命中同盾多平台借款
          if risk.id=109 then
            select nvl(max(t.element_value),0) into v_Count from decision_element_data t 
            where t.element_name='MultiLoanFraudMetrix' and t.id_credit=p_IdCredit;
                
            if v_Count>=1 then
              insert into risk_warm_info(id_credit,risk_warm_id,risk_warm_content,update_user,contract_no)
              values(p_IdCredit,109,'命中同盾多平台借款',p_UpdateUser,'');
            end if;
          end if;
        end loop;
    end if;
  commit;
    p_ReturnCode := 'A';
    return;
  exception
    When others Then
      error_info := sqlerrm;
      Rollback;

      p_ReturnCode := 'Z-' || error_info;  
  end prc_add_risk_warm;
  
  
  procedure prc_uw_office_call(p_IdCredit     cs_credit.id%type,
                               p_UpdateUser   number,
                               p_RiskWarmId   number,
                               p_Flag         number,
                               p_ReturnCode   out varchar2)
    is
    v_Count     number;
    error_info  varchar2(2000);
  begin
    if p_RiskWarmId=6 then
      select count(1) into v_Count from risk_warm_config t where t.is_parent=1 and t.status=1 and t.parent_id=0 and t.id=6;
      if v_Count=1 then
        if p_Flag=1 then
           delete from risk_warm_info t where t.id_credit=p_IdCredit and t.risk_warm_id=6;
        insert into risk_warm_info(id_credit,risk_warm_id,risk_warm_content,update_user)
          values(p_IdCredit,6,'此申请合同的办公电话UW致电结果为信息验证失败或停机/号码不存在;',p_UpdateUser);
        else
          delete from risk_warm_info t where t.id_credit=p_IdCredit and t.risk_warm_id=6;
        end if;
      end if;
    else
      select count(1) into v_Count from risk_warm_config t where t.is_parent=1 and t.status=1 and t.parent_id=0 and t.id=69;
      if v_Count=1 then
        if p_Flag=1 then
           delete from risk_warm_info t where t.id_credit=p_IdCredit and t.risk_warm_id=69;
        insert into risk_warm_info(id_credit,risk_warm_id,risk_warm_content,update_user)
          values(p_IdCredit,69,'此申请合同的办公电话核查UW致电结果为名称和地址均不一致或名称不一致,无地址信息;',p_UpdateUser);
        else
          delete from risk_warm_info t where t.id_credit=p_IdCredit and t.risk_warm_id=6;
        end if;
      end if;
    end if;
  commit;
    p_ReturnCode := 'A';
    return;
  exception
    When others Then
      error_info := sqlerrm;
      Rollback;

      p_ReturnCode := 'Z-' || error_info;  
  end prc_uw_office_call;
end PKG_RISK_WARM;
/

