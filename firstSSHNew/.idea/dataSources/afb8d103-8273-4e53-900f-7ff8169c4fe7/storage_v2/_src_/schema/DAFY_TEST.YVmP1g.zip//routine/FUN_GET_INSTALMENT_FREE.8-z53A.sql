create function fun_get_instalment_free(p_id_credit cs_credit.id%type)
                                          return number is
  v_Sum  number;
--Create User:wangxiaofeng;
--Use:获取合同豁免金额
begin
   select count(1) into v_Sum from instalment_free a where a.id_credit=p_id_credit and a.status=1;
   if v_sum !=0 then
     select sum(a.amount) into v_Sum from instalment_free a where a.id_credit=p_id_credit and a.status=1;
   end if;
   return(v_Sum);
end fun_get_instalment_free;


/

