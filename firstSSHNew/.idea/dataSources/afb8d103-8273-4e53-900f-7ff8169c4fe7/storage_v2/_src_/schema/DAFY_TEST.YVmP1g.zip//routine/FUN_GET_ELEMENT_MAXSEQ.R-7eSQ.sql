create function fun_get_element_maxseq(p_IdCredit    decision_element_data.id_credit%type) return integer is
  v_Seq integer:=0;
begin
  select nvl(max(seq),0) into v_Seq from decision_element_data where id_credit=p_IdCredit;
  return(v_Seq);
end;


/

