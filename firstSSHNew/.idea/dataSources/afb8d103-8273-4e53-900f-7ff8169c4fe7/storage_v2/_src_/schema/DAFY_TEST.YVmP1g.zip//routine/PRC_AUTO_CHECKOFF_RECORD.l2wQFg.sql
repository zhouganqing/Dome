create procedure PRC_AUTO_CHECKOFF_RECORD(p_ReturnCode out varchar2) is
---记账流水 庾文峰
  error_info            varchar2(1000);
  collect_account       varchar2(30);
  
  m79balance            checkoff_record.balance%type; --进出
  m7901balance          checkoff_record.balance%type; --出
  m91balance            checkoff_record.balance%type; --进
  m9101balance          checkoff_record.balance%type; --进
  mc8balance            checkoff_record.balance%type; --进
  mc9balance            checkoff_record.balance%type; 
  mf3balance            checkoff_record.balance%type; 
  
  transfer              checkoff_record.balance%type; --进
  hzy                   checkoff_record.balance%type; --进
  DL                    checkoff_record.balance%type; --进
  
  balance               checkoff_record.balance%type;
  
begin
  
     select nvl(sum(t.income-t.spending)+1984615.96,0) into m79balance from checkoff_record t where t.collect_account='M79' ;
     select nvl(sum(t.income-t.spending),0) into m7901balance from checkoff_record t where t.collect_account='M7901' ;
     select nvl(sum(t.income-t.spending),0) into m91balance from checkoff_record t where t.collect_account='M91';
     select nvl(sum(t.income-t.spending),0) into m9101balance from checkoff_record t where t.collect_account='M9101';

     select nvl(sum(t.income-t.spending),0) into mc8balance from checkoff_record t where t.collect_account='MC8' ;
     
     select nvl(sum(t.income-t.spending),0) into mc9balance from checkoff_record t where t.collect_account='MC9' ;
     
     select nvl(sum(t.income-t.spending),0) into mf3balance from checkoff_record t where t.collect_account='MF3' ;
      
     select nvl(sum(t.income-t.spending),0) into transfer from checkoff_record t where t.collect_account='transfer';
     select nvl(sum(t.income-t.spending),0) into hzy from checkoff_record t where t.collect_account='hzy';
     select nvl(sum(t.income-t.spending),0) into DL from checkoff_record t where t.collect_account='DL';
     
     
    --代扣入账 
    for branch in
    (select a.id, a.contractno,a.bankno,a.accno,a.accname,a.update_time,a.remark,a.money,a.outid,a.my_acc_code,b.credit_model 
    from checkoff_batch_detail a,cs_credit b where a.contractno=b.id and a.rstatus='00'
    and trunc(a.update_time)=trunc(sysdate-1) order by a.update_time asc)
    --and trunc(a.update_time) between date'2015-5-1' and date'2015-8-3' order by update_time asc)
    loop

    
     if branch.my_acc_code='M79' then
      collect_account:='M79';
      m79balance:=m79balance+branch.money;
      balance:=m79balance;

    elsif branch.my_acc_code='M91' then
      collect_account:='M91';
      m91balance:=m91balance+branch.money;
      balance:=m91balance;
      
      elsif branch.my_acc_code='M9101' then
      collect_account:='M9101';
      m9101balance:=m9101balance+branch.money;
      balance:=m9101balance;
      
    elsif branch.my_acc_code='MC8' then
      collect_account:='MC8';
      mc8balance:=mc8balance+branch.money;
      balance:=mc8balance;
      
    elsif branch.my_acc_code='MF3' then
      collect_account:='MF3';
      mf3balance:=mf3balance+branch.money;
      balance:=mf3balance;
    end if;
  
      insert into checkoff_record(id,collect_account,id_credit,record_date,record_time,account_name,account_no,bank_name,batno,income,spending,balance,remark,update_user,create_time)
      values(seq_checkoff_record.nextval,collect_account,branch.contractno,to_char(branch.update_time,'yyyy-MM-dd'),to_char(branch.update_time,'hh24:mi:ss'),branch.accname,
      branch.accno,branch.bankno,branch.outid,branch.money,0,balance,branch.remark,100000,branch.update_time);
         commit; 
    end loop;
    
     
    
    --放款出账
    for branch in
    (select a.id, a.accountname,a.accountno,a.bankname,a.id_credit,a.money,a.remark,a.release_time,a.batno,a.my_acc_code,b.credit_model 
     from checkoff_single a,cs_credit b where a.id_credit=b.id(+) and a.paystatus='k' 
     and trunc(a.release_time)=trunc(sysdate-1) order by a.release_time asc)
     --and trunc(a.release_time) between date'2015-5-1' and date'2015-8-3' order by release_time asc)
    loop
    
    if branch.my_acc_code='M79' then
      collect_account:='M79';
      m79balance:=m79balance-branch.money;
      balance:=m79balance;
    elsif branch.My_Acc_Code='M7901' then
      collect_account:='M7901';
      m7901balance:=m7901balance-branch.money;
      balance:=m7901balance;
    elsif branch.My_Acc_Code='MC8' then
      collect_account:='MC8';
      mc8balance:=mc8balance-branch.money;
      balance:=mc8balance;
    elsif branch.My_Acc_Code='MF3' then
      collect_account:='MF3';
      mf3balance:=mf3balance-branch.money;
      balance:=mf3balance;
    end if;

      insert into checkoff_record(id,collect_account,id_credit,record_date,record_time,account_name,account_no,bank_name,batno,income,spending,balance,remark,update_user,create_time)
      values(seq_checkoff_record.nextval,collect_account,branch.id_credit,to_char(branch.release_time,'yyyy-MM-dd'),to_char(branch.release_time,'hh24:mi:ss'),branch.accountname,
      branch.accountno,branch.bankname,branch.batno,0,branch.money,balance,branch.remark,100000,branch.release_time);           
     commit;
     
    end loop;
     
      
    --手动入账
    for branch in
    (select t.accountname,t.accountno,t.bankname,t.totalamount,t.in_time,t.id_income,t.remark from instalment_incomelist t 
     where t.incometype='b' and t.status in(1,0) and trunc(t.in_time) 
     =trunc(sysdate-1) order by t.in_time asc)
     --between date'2015-5-1' and date'2015-8-3' order by in_time asc)
    loop
      
    if branch.id_income=0 then
      collect_account:='hzy';
      hzy:=hzy+branch.totalamount;
      balance:=hzy;
    else
      collect_account:='transfer';
      transfer:=transfer+branch.totalamount;
      balance:=transfer;
    end if;
    
      insert into checkoff_record(id,collect_account,id_credit,record_date,record_time,account_name,account_no,bank_name,batno,income,spending,balance,remark,update_user,create_time)
      values(seq_checkoff_record.nextval,collect_account,'',to_char(branch.in_time,'yyyy-MM-dd'),to_char(branch.in_time,'hh24:mi:ss'),branch.accountname,
      branch.accountno,branch.bankname,'',branch.totalamount,0,balance,branch.remark,100000,branch.in_time);
          commit;
    end loop;
    
    
    --充值入账
    for branch in
    (select t.pay_time,t.recharge_amout,t.bank_name,t.accout_name,t.accout_no,t.my_acc_code,t.serial_number,t.remark  
     from p2p_recharge_record t where t.pay_status='k' and trunc(t.pay_time)
     =trunc(sysdate-1) order by t.pay_time asc 
     --between date'2015-5-1' and date'2015-8-3' order by t.pay_time asc
     )

    loop
      
    if branch.my_acc_code='M79' then
      collect_account:='M79';
      m79balance:=m79balance+branch.recharge_amout;
      balance:=m79balance;
    elsif branch.my_acc_code='DL' then 
      collect_account:='DL';
      DL:=DL+branch.recharge_amout;
      balance:=DL; 
    end if;
    
      insert into checkoff_record(id,collect_account,id_credit,record_date,record_time,account_name,account_no,bank_name,batno,income,spending,balance,remark,update_user,create_time)
      values(seq_checkoff_record.nextval,collect_account,'',to_char(branch.pay_time,'yyyy-MM-dd'),to_char(branch.pay_time,'hh24:mi:ss'),branch.accout_name,
      branch.accout_no,branch.bank_name,branch.serial_number,branch.recharge_amout,0,balance,branch.remark,100000,branch.pay_time);
          commit;
    end loop;
    
    
    ----提现出账
    for branch in
    (select t.pay_time,t.present_amount,t.bank_name,t.accout_name,t.accout_no,t.my_acc_code,t.serial_number,t.remark  
     from p2p_present_record t where t.pay_status='k' and trunc(t.pay_time)
     =trunc(sysdate-1) order by t.pay_time asc 
     --between date'2015-5-1' and date'2015-8-3' order by t.pay_time asc
     )

    loop
      
    if branch.my_acc_code='M79' then
      collect_account:='M79';
      m79balance:=m79balance-branch.present_amount;
      balance:=m79balance;
    end if;

      insert into checkoff_record(id,collect_account,id_credit,record_date,record_time,account_name,account_no,bank_name,batno,income,spending,balance,remark,update_user,create_time)
      values(seq_checkoff_record.nextval,collect_account,'',to_char(branch.pay_time,'yyyy-MM-dd'),to_char(branch.pay_time,'hh24:mi:ss'),branch.accout_name,
      branch.accout_no,branch.bank_name,branch.serial_number,0,branch.present_amount,balance,branch.remark,100000,branch.pay_time);

    commit;
    end loop;
    
    ----手动代扣
    for branch in
    (select t.id_credit,t.update_time,t.amount,t.bank_name,t.account_name,t.account_no,t.my_acc_code,t.batno,t.remark from checkoff_command t where t.pay_status='k'
     and trunc(t.update_time)
     =trunc(sysdate-1) order by t.update_time asc 
     --between date'2015-5-1' and date'2015-8-3' order by t.update_time asc
     )

    loop
      
    if branch.my_acc_code='MC9' then
      collect_account:='MC9';
      mc9balance:=mc9balance+branch.amount;
      balance:=mc9balance;
    elsif branch.my_acc_code='MC8' then
      collect_account:='MC8';
      mc8balance:=mc8balance+branch.amount;
      balance:=mc8balance;
    elsif branch.my_acc_code='MF3' then
      collect_account:='MF3';
      mf3balance:=mf3balance+branch.amount;
      balance:=mf3balance;
    end if;

      insert into checkoff_record(id,collect_account,id_credit,record_date,record_time,account_name,account_no,bank_name,batno,income,spending,balance,remark,update_user,create_time)
      values(seq_checkoff_record.nextval,collect_account,branch.id_credit,to_char(branch.update_time,'yyyy-MM-dd'),to_char(branch.update_time,'hh24:mi:ss'),branch.account_name,
      branch.account_no,branch.bank_name,branch.batno,branch.amount,0,balance,branch.remark,100000,branch.update_time);

    commit;
    end loop;
    
    
      p_ReturnCode:='A';
    
Exception
   When others Then
     error_info := sqlerrm;
     p_ReturnCode:='Z-'||error_info;
     rollback;
end;


/

