create function fun_get_collection_user(p_id_credit collection_data.id_credit%type)
                                          return varchar2 is
  v_user_name   cs_person.name%type;
  --Create User:wangxiaofeng;
  --Use:获取催收员姓名
begin
   select fun_get_user_name(t.collector_id) into v_user_name from collection_data t where t.id_credit=p_id_credit and t.stay_date>=trunc(sysdate) and rownum=1 order by stay_date desc;
   return(v_user_name);
end fun_get_collection_user;


/

