create function fun_get_dpd_overdue_days(p_id_credit cs_credit.id%type)
                                          return number is
  v_overdue_days   number;
  --v_paid           number;
--Create User:wangxiaofeng;
--Use:计算当前合同逾期天数
begin
   /*v_overdue_days:=0;

   for c_instalment in(select id_credit,min(date_due),num_instalment,sum(value_instalment) amount,trunc(sysdate)-min(date_due) over_days from instalment where status='a'
                        and id_credit=p_id_credit and type_instalment!=8 and trunc(sysdate)-date_due>=1 group by id_credit,num_instalment order by id_credit,num_instalment asc)
   loop
      select nvl(sum(amount_pay),0) into v_Paid from payinstalment a,instalment b
      where a.id_instalment=b.id and b.id_credit=c_instalment.id_credit and b.num_instalment=c_instalment.num_instalment and b.type_instalment<>8 and a.status='a';

      if (c_instalment.amount-v_Paid)>=50 then
        v_overdue_days:=c_instalment.over_days;
        return(v_overdue_days);
      end if;
   end loop;*/
   
   select nvl(max(over_days),0) into v_overdue_days from(select min(num_instalment) num_instalment,trunc(sysdate)-min(date_due) over_days 
              from instalment 
              where status='a'and id_credit=p_id_credit and type_instalment!=8 and trunc(sysdate)-date_due>=1 
              group by id_credit,num_instalment having sum(value_instalment)-sum(value_pay)>=50);
   
   if v_overdue_days is null or v_overdue_days<0 then
     v_overdue_days:=0;
   end if;

   return(v_overdue_days);
end fun_get_dpd_overdue_days;


/

