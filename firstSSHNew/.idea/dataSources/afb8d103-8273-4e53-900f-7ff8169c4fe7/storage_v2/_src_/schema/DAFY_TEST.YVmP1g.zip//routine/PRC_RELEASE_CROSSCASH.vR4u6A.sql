create procedure PRC_RELEASE_CROSSCASH(p_IdCredit cs_credit.id%type,
                                                      p_Paystatus  varchar2,
                                                      p_ReturnCode out varchar2) is
    error_info           varchar2(1000);
    v_count              integer:=0;
    v_remark             varchar2(20);
    v_paystatus          varchar2(2);
    
begin

    for branch in (
      select a.commit_time,a.loan_date,a.contract_no,
    fun_getreg_value(776,b.bank_name) bank_name,b.bank_no account_no,
    c.name account_name,a.credit_amount,a.init_pay,d.prod_code,d.payment_num,d.effective_interest_rate eir  
    from cs_credit a,cs_experience b,cs_person c,product d  
    where a.id=b.id_credit and a.id_person=c.id and a.id_product=d.id 
    and a.credit_type='SC' and a.id=p_IdCredit
    )
  loop
    select count(1) into v_count from release_credit where contractno=branch.contract_no; 
    if p_Paystatus='f' then 
      v_paystatus:='n';
      v_remark:='代付失败'; 
      else
      v_paystatus:='k';
      v_remark:='代付成功'; 
    end if;
    if v_count=0 then
   
     insert into release_credit(id,committime,loandate,contractno,
     bankname,accountname,accountno,creditamount,initpay,prodcode,num_instalment,eir,status,service_fee,paycount)
     values(seq_release_credit.nextval,branch.commit_time,branch.loan_date,to_char(branch.contract_no),
     branch.bank_name,branch.account_name,branch.account_no,branch.credit_amount,branch.init_pay,
     branch.prod_code,branch.payment_num,branch.eir,v_paystatus,0,1);
     
     insert into release_log(id,contractno,status,update_time,update_user,remark)
     values(seq_release_log.nextval,branch.contract_no,v_paystatus,sysdate,100000,v_remark);
     
     else
       
     update release_credit set bankname=branch.bank_name,accountname=branch.account_name,accountno=branch.account_no,
     status=v_paystatus,update_time=sysdate,paycount=paycount+1   
     where contractno=branch.contract_no;
     
      insert into release_log(id,contractno,status,update_time,update_user,remark)
      values(seq_release_log.nextval,branch.contract_no,v_paystatus,sysdate,100000,v_remark); 
     
     end if;
     
  end loop;
  
   commit;
   p_ReturnCode:='A';
   return;
Exception
   When others Then
     error_info := sqlerrm;
     p_ReturnCode:='Z-'||error_info;
     rollback;
end;


/

