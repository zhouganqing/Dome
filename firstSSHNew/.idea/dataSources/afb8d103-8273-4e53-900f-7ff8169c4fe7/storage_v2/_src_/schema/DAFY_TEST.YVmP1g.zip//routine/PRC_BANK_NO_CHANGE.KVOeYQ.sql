create procedure prc_bank_no_change(p_id_person        number,
                                               p_contract_no      number,
                                               p_new_bank_no      varchar2,
                                               p_new_bank_name    varchar2,
                                               p_new_branch       varchar2,
                                               p_new_is_dd        varchar2,
                                               p_old_bank_no      varchar2,
                                               p_old_bank_name    varchar2,
                                               p_old_branch       varchar2,
                                               p_old_is_dd        varchar2,
                                               p_update_user      number,
                                               p_id_credit        number,
                                               p_ReturnCode       out varchar2)
                                               is
error_info   varchar2(1000);
begin
  

  for cs in(select a.id id_credit,a.contract_no,a.id_person,a.credit_model,
    nvl(c.bank_name,' ') bank_name,nvl(c.bank_no,' ') bank_no,nvl(c.branch,' ') branch,decode(c.is_dd,1,'是','否') is_dd from cs_credit a,cs_experience c
    where a.status in('a','p','k') and a.id=c.id_credit and a.id_person=p_id_person)
  loop
    if cs.credit_model='P2P' then
      if cs.bank_name!=p_new_bank_name or cs.bank_no!=p_new_bank_no or cs.is_dd!=p_new_is_dd or cs.branch!=p_new_branch then
        update cs_experience a set a.bank_name=p_new_bank_name,a.bank_no=p_new_bank_no,a.branch=p_new_branch,update_time=sysdate,a.protocol_type=0,a.protocol_no='' 
        where a.id_credit=cs.id_credit;
        
        insert into cs_bank (id, id_person,bank_name,bank_no,type,create_user,create_time) 
        values(seq_cs_bank.nextval,p_id_person,cs.bank_name,cs.bank_no,'1',p_update_user,sysdate);

        if cs.id_credit=p_id_credit then
          insert into cs_bank_no_change(id,id_person,contract_no,new_bank_no,new_bank_name,new_branch,old_bank_no,old_bank_name,old_branch,update_user,update_time,old_is_dd,new_is_dd)
          values(seq_cs_bank_no_change.nextval,p_id_person,p_contract_no,p_new_bank_no,p_new_bank_name,p_new_branch,p_old_bank_no,p_old_bank_name,p_old_branch,p_update_user,sysdate,cs.is_dd,cs.is_dd);

          insert into cus_consult_event_info(consult_event_id,contract_no,id_person,update_user,remark)
          values('AT-Y6',p_contract_no,p_id_person,p_update_user,'申请代扣服务，代扣银行：'||fun_getreg_value(776,cs.bank_name)||' '||cs.branch||' 卡号'||cs.bank_no||'更新为：'||fun_getreg_value(776,p_new_bank_name)||' '||p_new_branch||' 卡号'||p_new_bank_no);
        else
          insert into cs_bank_no_change(id,id_person,contract_no,new_bank_no,new_bank_name,new_branch,old_bank_no,old_bank_name,old_branch,update_user,update_time,old_is_dd,new_is_dd)
          values(seq_cs_bank_no_change.nextval,p_id_person,cs.contract_no,p_new_bank_no,p_new_bank_name,p_new_branch,cs.bank_no,cs.bank_name,cs.branch,p_update_user,sysdate,p_old_is_dd,p_new_is_dd);

          insert into cus_consult_event_info(consult_event_id,contract_no,id_person,update_user,remark)
          values('AT-Y6',cs.contract_no,p_id_person,p_update_user,'申请代扣服务，代扣银行：'||fun_getreg_value(776,cs.bank_name)||' '||cs.branch||' 卡号'||cs.bank_no||'更新为：'||fun_getreg_value(776,p_new_bank_name)||' '||p_new_branch||' 卡号'||p_new_bank_no);
        end if;
      end if;
    else
      if cs.bank_name!=p_new_bank_name or cs.bank_no!=p_new_bank_no or cs.is_dd!=p_new_is_dd or cs.branch!=p_new_branch then
        update cs_experience a set a.bank_name=p_new_bank_name,a.bank_no=p_new_bank_no,a.branch=p_new_branch,a.is_dd=decode(p_new_is_dd,'是',1,0),update_time=sysdate,a.protocol_type=0,a.protocol_no=''
        where a.id_credit=cs.id_credit;
        
        insert into cs_bank (id, id_person,bank_name,bank_no,type,create_user,create_time) 
        values( seq_cs_bank.nextval,p_id_person,cs.bank_name,cs.bank_no,'1',p_update_user,sysdate);

        insert into cs_bank_no_change(id,id_person,contract_no,new_bank_no,new_bank_name,new_branch,old_bank_no,old_bank_name,old_branch,update_user,update_time,old_is_dd,new_is_dd)
        values(seq_cs_bank_no_change.nextval,p_id_person,cs.contract_no,p_new_bank_no,p_new_bank_name,p_new_branch,cs.bank_no,cs.bank_name,cs.branch,p_update_user,sysdate,p_old_is_dd,p_new_is_dd);

        insert into cus_consult_event_info(consult_event_id,contract_no,id_person,update_user,remark)
        values('AT-Y6',cs.contract_no,p_id_person,p_update_user,'申请代扣服务，代扣银行：'||fun_getreg_value(776,cs.bank_name)||' '||cs.branch||' 卡号'||cs.bank_no||'更新为：'||fun_getreg_value(776,p_new_bank_name)||' '||p_new_branch||' 卡号'||p_new_bank_no);

        if p_new_is_dd!=cs.is_dd then
          insert into cus_consult_event_info(consult_event_id,contract_no,id_person,update_user,remark)
          values('AT-Y7',cs.contract_no,p_id_person,p_update_user,decode(p_new_is_dd,'否','已取消代扣服务','已恢复代扣服务'));
        end if;
      end if;
    end if;
    
  end loop;
  
  for b in(select id_credit from checkoff_release where releasestatus='f' and id_credit=p_id_credit and pro_type='o')
    loop

        update checkoff_release set releasestatus='d',update_time=sysdate,update_user=p_update_user  
        where id_credit=b.id_credit and releasestatus='f' and pro_type='o';
        update checkoff_single t set t.followresult='1',t.update_user=p_update_user,t.update_time=sysdate  
        where t.accountno=p_old_bank_no and t.id_credit=b.id_credit and pro_type='o';

  end loop;
  
  for b in(select id_credit from checkoff_release where releasestatus='f' and id_credit in (select id from cycle_credit where id_person=p_id_person and status='a') and pro_type='c')
    loop

        update checkoff_release set releasestatus='d',update_time=sysdate,update_user=p_update_user  
        where id_credit=b.id_credit and releasestatus='f' and pro_type='c';
        update checkoff_single t set t.followresult='1',t.update_user=p_update_user,t.update_time=sysdate  
        where t.accountno=p_old_bank_no and t.id_credit=b.id_credit and pro_type='c';

  end loop;
  

  commit;
  p_ReturnCode:='A';
  return;
exception
  when others then
    error_info:=sqlerrm;
    rollback;

    p_ReturnCode:= 'Z-'||error_info;
end prc_bank_no_change;


/

