create procedure prc_save_cs_contact(p_UpdateUser     number,
                                                p_IdCredit       varchar2,
                                                p_ReturnCode     out varchar2) is
  error_info     varchar2(1000);
  v_Name         varchar2(50);
  v_PersonType   varchar2(20);
  v_UserType     varchar2(20);
  v_Count        number(2);
begin
  delete from cs_contact_portion a where a.id_credit=p_IdCredit and a.status is null;

  for personInfo in (select a.contact_value,a.person_type,a.contact_type,a.id_person,a.id_credit from cs_contact a where a.id_credit=p_IdCredit)
    loop
      select nvl(fun_getreg_value(decode(length(personInfo.Person_Type),1,265,396),personInfo.Person_Type),'第三方') into v_PersonType from dual;
      if v_PersonType = '本人' then
         v_PersonType:= '本人';
      elsif v_PersonType='父亲' or v_PersonType='母亲' then
          v_PersonType:= '父母';
      elsif substr(v_PersonType,1,2)='兄弟' or substr(v_PersonType,1,2)='姐妹' then
          v_PersonType:= '兄弟姐妹';
      elsif substr(v_PersonType,1,2)='儿子' or substr(v_PersonType,1,2)='女儿' then
          v_PersonType:= '儿女';
      elsif v_PersonType = '配偶' then
          v_PersonType:= '配偶';
      elsif substr(v_PersonType,1,2)='亲戚' then
          v_PersonType:= '其他亲戚';
      else
          v_PersonType:= '第三方';
      end if;

      select count(a.name) into v_Count from cs_other_person a where a.id_credit=personInfo.Id_Credit and a.person_type=personInfo.Person_Type;
      if v_Count>0 then
        select distinct a.name into v_Name from cs_other_person a
        where a.id_credit=personInfo.Id_Credit and a.person_type=personInfo.Person_Type;
      else
        select distinct a.name into v_Name from cs_person a where a.id=personInfo.Id_Person;
      end if;

      select role_id into v_UserType from sys_user_list a where a.id=p_UpdateUser;

      select count(1) into v_Count from cs_contact_portion a
      where a.name=v_Name
            and a.contact_value=personInfo.Contact_Value
            and a.person_type=v_PersonType
            and a.id_person=personInfo.Id_Person
            and a.contact_type=fun_getreg_value(395,personInfo.Contact_Type);

      if(v_Count<=0) then
        insert into cs_contact_portion(id,name,contact_value,person_type,contact_type,id_person,module,update_user,update_time,id_credit)
        values(seq_contact_portion.nextval,v_Name,personInfo.Contact_Value,v_PersonType,fun_getreg_value(395,personInfo.Contact_Type),personInfo.Id_Person,v_UserType,p_UpdateUser,sysdate,personInfo.Id_Credit);
      end if;
    end loop;

  commit;
  p_ReturnCode:='A';
  return;
Exception
  When others Then
    error_info := sqlerrm;
    Rollback;

    p_ReturnCode := 'Z-'||error_info;
end prc_save_cs_contact;


/

