create FUNCTION fun_eval
(str in VARCHAR2) RETURN VARCHAR2
As
  numval number;
begin
  execute immediate 'select '||str||' from dual' into numval;
  return numval;
end;


/

