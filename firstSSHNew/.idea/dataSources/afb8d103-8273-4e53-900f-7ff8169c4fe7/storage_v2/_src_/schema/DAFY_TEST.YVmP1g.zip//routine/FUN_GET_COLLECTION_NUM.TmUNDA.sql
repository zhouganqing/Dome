create function fun_get_collection_num(p_collector_id sys_user_list.id%type)
                                          return number is
  v_count   number;
--Create User:wangxiaofeng;
--Use:获取催收员当天分配催收案件总数
begin
   select count(distinct id_credit) into v_count
   from collection_data
   where collection_date>=trunc(sysdate) and collector_id=p_collector_id;
   return(v_count);
end fun_get_collection_num;


/

