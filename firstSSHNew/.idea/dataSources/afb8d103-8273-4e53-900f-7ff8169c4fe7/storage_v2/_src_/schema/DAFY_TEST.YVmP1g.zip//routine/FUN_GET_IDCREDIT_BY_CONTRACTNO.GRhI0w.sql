create function fun_get_idcredit_by_contractno(p_contract_no cs_credit.contract_no%type) return number is
  v_idcredit number;
begin
  v_idcredit:=0;
  select id into v_idcredit from cs_credit where contract_no=p_contract_no;
  return(v_idcredit);
  Exception
 When others Then
   return(v_idcredit);
end fun_get_idcredit_by_contractno;


/

