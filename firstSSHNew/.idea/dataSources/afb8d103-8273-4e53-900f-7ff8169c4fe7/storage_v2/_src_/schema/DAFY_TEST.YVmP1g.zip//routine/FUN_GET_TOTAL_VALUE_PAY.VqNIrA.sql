create function FUN_GET_TOTAL_VALUE_PAY(p_id_credit payin.id_credit%type)
                                          return number is
  v_value_pay   payin.value_pay%type;
begin
   select sum(t.value_pay) into v_value_pay from payin t
    where t.id_credit = p_id_credit and t.status='a';
  return(v_value_pay);
end FUN_GET_TOTAL_VALUE_PAY;


/

