create function fun_get_def_workflow(p_BranchId decision_branch_list.id%type,
                                                p_Stage   varchar2) return integer is
  v_WfiId   decision_work_flow.id%type;
begin
  if p_Stage='PRE' then
      select def_wfiid_uw into v_WfiId from decision_branch_list where id=p_BranchId;
  else
      select def_wfiid_ce into v_WfiId from decision_branch_list where id=p_BranchId;
  end if;
  return(v_WfiId);
end;


/

