create function fun_get_collection_parameters(p_para_id collection_parameters.para_id%type)
                                          return varchar2 is
  v_para_value   collection_parameters.para_value%type;
  --Create User:wangxiaofeng;
  --Use:获取传入参数id对应的值
begin
   select para_value into v_para_value from collection_parameters
   where para_id=p_para_id;
   return(v_para_value);
end fun_get_collection_parameters;


/

