create function fun_get_bank_brank_code(p_bankName cs_experience.bank_name%type)
                                          return number is
  v_code   checkoff_batch_detail.bankno%type;
--Create User:wangxiaofeng;
--Use:银行名称转换为银行清算行号;
begin
                if p_bankName='中国工商银行'then v_code := '102584000002';
                elsif p_bankName='中国建设银行'then v_code := '105584000005';
                elsif p_bankName='中国银行'then v_code := '104584000003';
                elsif p_bankName='中国农业银行'then v_code := '103584099993';
                elsif p_bankName='中国邮政储蓄银行'then v_code := '403584099005';
                elsif p_bankName='招商银行'then v_code := '308584001016';
                elsif p_bankName='中国光大银行'then v_code := '303584000004';
                elsif p_bankName='广发银行'then v_code := '306584001261';
                elsif p_bankName='中信银行'then v_code := '302584043105';
                elsif p_bankName='兴业银行'then v_code := '309584000000';
                elsif p_bankName='中国民生银行'then v_code := '305584000002';
                elsif p_bankName='平安银行'then v_code := '307584007998';
                elsif p_bankName='浦发银行'then v_code := '310584000006';
                elsif p_bankName='交通银行'then v_code := '301584000016';
                elsif p_bankName='华夏银行'then v_code := '304584040898';
                else
                  v_code := '';
                end if;
  return(v_code);
end fun_get_bank_brank_code;


/

