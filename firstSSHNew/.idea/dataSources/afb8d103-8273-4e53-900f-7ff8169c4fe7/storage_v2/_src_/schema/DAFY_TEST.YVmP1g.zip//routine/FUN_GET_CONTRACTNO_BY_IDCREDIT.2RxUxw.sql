create function fun_get_contractno_by_idcredit(p_id cs_credit.id%type) return number is
  v_contractno number;
begin
  v_contractno:=0;
  select contract_no into v_contractno from cs_credit where id=p_id;
  return(v_contractno);
  Exception
 When others Then
   return(v_contractno);
end fun_get_contractno_by_idcredit;


/

