create procedure PRC_EMAIL_ALERT_BLOCK(p_ReturnCode        out varchar2) is
  /*last modify  2015-02-04   author: luchangjiang
     卡单时，将数据插入邮件引擎，报警
   */
  error_info        varchar2(1000);

  v_Content         varchar2(4000):='';
  v_Count           integer:=0;
  v_MailTo          sys_parameters.para_value%type;
  v_MailCc          sys_parameters.para_value%type;
begin
  for cur in (select id,contract_no from cs_credit where status='s' and commit_time<=sysdate-5/24/60)
  loop
      v_Content:=v_Content || '<br>合同ID: ' || cur.id || '     合同编号: ' || to_char(cur.contract_no);
      v_Count:=v_Count+1;
  end loop;

  if v_Count>0 then
      v_Content:='来自达飞的邮件引擎： (卡单)消费金融系统待审池有 ['||v_Count ||'] 张合同超过5分钟的数据，单号分别为：'||v_Content;
      select para_value into v_MailTo from sys_parameters where para_id='CONTRACT_AUDIT_BLOCK_TO';
      select para_value into v_MailCc from sys_parameters where para_id='CONTRACT_AUDIT_BLOCK_CC';

      insert into sys_email_list(id,mail_type,key_word,from_user,mail_to,cc_to,subject,email_boby,status,create_time,plan_time)
               values(seq_sys_email_list.nextval,'U','卡单','uw@dafycredit.com',v_MailTo,v_MailCc,'消费金融卡单报警',v_Content,0,sysdate,sysdate);
  end if;
  commit;
  p_ReturnCode:='A';
  return;
Exception
  When others Then
    error_info := sqlerrm;
    Rollback;

    p_ReturnCode := 'Z-'||error_info;
end;


/

