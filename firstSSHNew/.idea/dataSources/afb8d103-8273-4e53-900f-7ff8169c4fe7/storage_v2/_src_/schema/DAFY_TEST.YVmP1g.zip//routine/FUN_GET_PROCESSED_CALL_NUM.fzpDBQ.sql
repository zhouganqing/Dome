create function fun_get_processed_call_num(p_collector_id sys_user_list.id%type)
                                          return number is
  v_count   number;
--Create User:wangxiaofeng;
--Use:获取催收员当天分配催收单，已备注总数
begin
   select count(distinct a.id_credit) into v_count
   from collection_data a,collection_call b
   where a.id_credit=b.id_credit and a.collection_date>=trunc(sysdate) and b.update_time>=a.collection_date and collector_id=p_collector_id;
   return(v_count);
end fun_get_processed_call_num;


/

