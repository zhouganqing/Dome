create function fun_get_person_assign_account(p_id_credit cs_credit.id%type) return varchar2 is
  v_assign_account  varchar2(60);
--create time;2015/01/22
--create user:WangXiaoFeng
--use:获取客户的指导还款账号
begin
  v_assign_account:='';
  select d.account_no||' '||c.id into v_assign_account from cs_credit a,cs_person b,trust_customer_code c,cs_creditmodel_trustcompany d 
  where a.id_person=b.id and a.credit_model=d.credit_model and c.status=1
   and b.name=c.name and b.ident=c.ident and a.credit_model like '%XT%' and a.id=p_id_credit;
  return(v_assign_account);
Exception
 When others Then
   return(v_assign_account);
end fun_get_person_assign_account;


/

