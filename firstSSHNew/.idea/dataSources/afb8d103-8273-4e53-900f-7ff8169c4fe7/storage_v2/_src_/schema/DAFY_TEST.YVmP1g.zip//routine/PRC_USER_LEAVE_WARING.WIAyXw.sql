create procedure prc_user_leave_Waring is
  -- Author  : WangRenle
  -- Create Date : 2014-12-16
  -- Purpose : email alert when sales user leave
  -- Status: disabled
  v_UserId       sys_user_list.id%type;
  v_UserName     sys_user_list.user_name%type;  
  v_OrgId        sys_organize.id%type;
  v_Content1     varchar(2000);
  v_Content2     varchar(2000);
  v_Count1       integer:=0;
  v_Count2       integer:=0;
  cursor cur is select distinct b.user_id,b.org_id,c.user_name from sys_organize a,sys_user_organize b,sys_user_list c
         where b.org_id = a.pid and b.user_id = c.id and c.status = 8;
begin  
  v_Content1:='以下员工已离职，请更新组织架构：<br>';
  v_Content2:='以下员工已离职，请更新组织架构：<br>';
  open cur;
  loop
     fetch cur into v_UserId,v_OrgId,v_UserName;
     exit when cur %notfound;
     if substr(v_UserId,1,1)='8' then
        v_Content1:=v_Content1||'<br>'||'      工号：'||v_UserId||'  姓名：'||v_UserName;
        v_Count1:=v_Count1+1;
     else
        v_Content2:=v_Content2||'<br>'||'      工号：'||v_UserId||'  姓名：'||v_UserName;
        v_Count2:=v_Count2+1;
     end if;
  end loop;
  close cur;
  if v_Count1>0 then
     insert into sys_email_list(id,mail_type,key_word,from_user,mail_to,cc_to,subject,email_boby,status,create_time,plan_time)values
            (seq_sys_email_list.nextval,'L','员工离职','email engine','dengxiaomei@dafycredit.com,tanxiaoying@dafycredit.com','luchangjiang@dafycredit.com',
            	'来自达飞邮件引擎：员工离职报警',v_Content1,0,sysdate,sysdate);
  end if;
  if v_Count2>0 then
     insert into sys_email_list(id,mail_type,key_word,from_user,mail_to,cc_to,subject,email_boby,status,create_time,plan_time)values
            (seq_sys_email_list.nextval,'L','员工离职','email engine','helpdesk@dafycredit.com','luchangjiang@dafycredit.com',
            	'来自达飞邮件引擎：员工离职报警',v_Content2,0,sysdate,sysdate);
  end if;
  commit;
end;


/

