create package pkg_call_service is

  -- Author  : wangxiaofeng
  -- Created : 2015/8/10 13:43:26
  -- Purpose : 呼叫中心IVR验证
  
  -- Author  : wangxiaofeng
  -- Create Date : 2015-08-10
  -- Purpose : 客户身份验证
  procedure prc_check_user_ident(p_Ident       varchar2,
                                 p_Result      out number,
                                 p_ReturnCode  out varchar2);
                                 
  -- Author  : wangxiaofeng
  -- Create Date : 2015-08-10
  -- Purpose : 客户是否逾期验证
  procedure prc_check_user_overdue(p_Ident       varchar2,
                                   p_Result      out number,
                                   p_ReturnCode  out varchar2);
                                   
  -- Author  : wangxiaofeng
  -- Create Date : 2015-08-10
  -- Purpose : 公司销售验证
  procedure prc_check_user_sa(p_Ident       varchar2,
                              p_Result      out number,
                              p_ReturnCode  out varchar2);
                              
  -- Author  : wangxiaofeng
  -- Create Date : 2015-08-13
  -- Purpose : 催收查询客户当前现行合同数，最大逾期天数，总欠款金额
  procedure prc_collection_query(p_Ident          varchar2,
                                 p_ContractNum    out varchar2,
                                 p_MaxOverDay     out varchar2,
                                 p_TotalDebt      out varchar2,
                                 p_ReturnCode     out varchar2);
                                 
  -- Author  : wangxiaofeng
  -- Create Date : 2015-08-13
  -- Purpose : 查询客户现行合同到期还款日
  procedure prc_person_duedate_query(p_Ident            varchar2,
                                        p_DueDate       out varchar2,
                                        p_ReturnCode    out varchar2);
                                 
  -- Author  : wangxiaofeng
  -- Create Date : 2015-08-13
  -- Purpose : 查询客户个人还款账号
  procedure prc_person_repayment_no_query(p_Ident         varchar2,
                                          p_RepaymentNo   out varchar2,
                                          p_ReturnCode    out varchar2);
                                          
  -- Author  : wangxiaofeng
  -- Create Date : 2015-08-14
  -- Purpose : 查询客户是否申请15天只还本金
  procedure prc_person_er15_query(p_Ident         varchar2,
                                  p_Result        out varchar2,
                                  p_ReturnCode    out varchar2);
                                  
  -- Author  : wangxiaofeng
  -- Create Date : 2015-08-14
  -- Purpose : 查询客户是否申请提前还款
  procedure prc_person_forward_query(p_Ident         varchar2,
                                     p_Result        out varchar2,
                                     p_DueDate       out varchar2,
                                     p_TotalMoney    out varchar2,
                                     p_ReturnCode    out varchar2);
                                     
  -- Author  : wangxiaofeng
  -- Create Date : 2015-08-14
  -- Purpose : 查询客户到期还款金额
  procedure prc_person_due_query(p_Ident         varchar2,
                                 p_DueDate       out varchar2,
                                 p_TotalMoney    out varchar2,
                                 p_ReturnCode    out varchar2);
                                 
  -- Author  : wangxiaofeng
  -- Create Date : 2015-08-14
  -- Purpose : 查询客户剩余还款金额
  procedure prc_person_debt_query(p_Ident         varchar2,
                                  p_TotalDebt     out varchar2,
                                  p_ReturnCode    out varchar2);
                                 
  -- Author  : wangxiaofeng
  -- Create Date : 2015-08-14
  -- Purpose : 查询客户还款到账记录
  procedure prc_person_payin_query(p_Ident         varchar2,
                                   p_Result        out varchar2,
                                   p_DatePay       out varchar2,
                                   p_ValuePay      out varchar2,
                                   p_ReturnCode    out varchar2);
  


end pkg_call_service;


/

