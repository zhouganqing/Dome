create procedure PRC_AUTO_SCHEDULING(p_ReturnCode      out varchar2) is
   -- Author  : Luchangjiang
   -- Create Date : 2014-10-23
   -- Purpose : entrance of hard check or decision system
  v_DecisionUsageRatio     number;
  v_Rand                   number;

  error_info               varchar2(1000);
begin
  select to_number(para_value) into v_DecisionUsageRatio from sys_parameters where para_id='DECISION_USAGE_RATIO';
  for credit in (select id from cs_credit where status='s' and decision_flag is null)
  loop
     v_Rand:=dbms_random.value();
     if v_Rand<v_DecisionUsageRatio then
        update cs_credit set decision_flag=1 where id=credit.id;
        insert into decision_log(id,id_credit,status,item_name,result,remark,formula,update_time)
          values(seq_decision_log.nextval,credit.id,'s','decision_flag',1,'','Random='||round(v_Rand,2),sysdate);
     else
        update cs_credit set decision_flag=0 where id=credit.id;
        insert into decision_log(id,id_credit,status,item_name,result,remark,formula,update_time)
          values(seq_decision_log.nextval,credit.id,'s','decision_flag',0,'','Random='||round(v_Rand,2),sysdate);
     end if;

  end loop;
  commit;

  PRC_AUTO_MINUTES(p_ReturnCode);
  PRC_AUTO_MINUTES_BRANCH(p_ReturnCode);
  return;
Exception
   When others Then
     error_info := sqlerrm;
     rollback;
     p_ReturnCode:='Z-'||error_info;
end;


/

