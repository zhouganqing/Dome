create package body PKG_COLLECTION is
  error_info  varchar2(1000);
  v_Count     number(4);
  v_Count1    number(4);
  
  --根据催收员备注中的联系结果（客户死亡/被捕，投诉，否认贷款）添加疑难案件
  procedure prc_add_coll_diffcult(p_ContractNo     varchar2,
                                  p_Update_User    number,
                                  p_Reason         varchar2,
                                  p_ReturnCode     out varchar2) is
  begin
    select count(1) into v_Count from collection_data_diffcult t where t.contract_no=p_ContractNo; 
    select count(1) into v_Count1 from collection_data_stop t where t.contract_no=p_ContractNo; 
    if v_Count<=0 and v_Count1<=0 then   
      insert into collection_data_log 
      (id_credit,contract_no,id_person,person_name,date_due,over_days,over_amount,status,update_user,update_time,reason)
      select t.id_credit,t.contract_no,t.id_person,t.name,t.date_due,t.over_days,t.overdue_fine,'d',p_Update_User,sysdate,p_Reason
      from v_collection_base_info t
      where t.contract_no=p_ContractNo;
      
      insert into collection_data_diffcult 
      (id_credit,contract_no,id_person,person_name,date_due,over_days,over_amount,update_user,update_time,reason)
      select t.id_credit,t.contract_no,t.id_person,t.name,t.date_due,t.over_days,t.overdue_fine,p_Update_User,sysdate,p_Reason
      from v_collection_base_info t
      where t.contract_no=p_ContractNo;
    end if;
    commit;
    p_ReturnCode := 'A';
    return;
  exception
    When others Then
      error_info := sqlerrm;
      Rollback;
    
      p_ReturnCode := 'Z-' || error_info;   
  end prc_add_coll_diffcult;

  --疑难案件处理
  procedure prc_coll_diffcult_manage(p_ContractNo     varchar2,
                                     p_Flag           number,
                                     p_Update_User    number,
                                     p_Reason         varchar2,
                                     p_ReturnCode     out varchar2) is
  begin
    -- p_Flag=1 释放疑难案件，否则为申请停催案件
    if p_Flag=1 then   
      insert into collection_data_log 
      (id_credit,contract_no,id_person,person_name,date_due,over_days,over_amount,status,update_user,update_time,reason)
      select t.id_credit,t.contract_no,t.id_person,t.person_name,t.date_due,t.over_days,t.over_amount,'dr',p_Update_User,sysdate,p_Reason
      from collection_data_diffcult t
      where t.contract_no=p_ContractNo;
      
      delete from collection_data_diffcult t where t.contract_no=p_ContractNo;
    else
      select count(1) into v_Count from collection_data_stop_apply t where t.contract_no=p_ContractNo;  
      if v_Count>=1 then
        p_ReturnCode := 'Z-已有申请还未处理，不能再次申请！';
        return;
      end if;
      
      update collection_data_diffcult set status=0 where contract_no=p_ContractNo;
    
      insert into collection_data_log 
      (id_credit,contract_no,id_person,person_name,date_due,over_days,over_amount,status,update_user,update_time,reason)
      select t.id_credit,t.contract_no,t.id_person,t.person_name,t.date_due,t.over_days,t.over_amount,'a',p_Update_User,sysdate,p_Reason
      from collection_data_diffcult t
      where t.contract_no=p_ContractNo;
      
      insert into collection_data_stop_apply 
      (id_credit,contract_no,id_person,person_name,date_due,over_days,over_amount,update_user,update_time)
      select t.id_credit,t.contract_no,t.id_person,t.name,t.date_due,t.over_days,t.overdue_fine,p_Update_User,sysdate
      from v_collection_base_info t
      where t.contract_no=p_ContractNo;
    end if;
    commit;
    p_ReturnCode := 'A';
    return;
  exception
    When others Then
      error_info := sqlerrm;
      Rollback;
    
      p_ReturnCode := 'Z-' || error_info;   
  end prc_coll_diffcult_manage;
  
  --申请停催案件处理
  procedure prc_coll_stop_apply_manage(p_ContractNo     varchar2,
                                       p_Flag           number,
                                       p_Update_User    number,
                                       p_Reason         varchar2,
                                       p_ReturnCode     out varchar2) is
  begin
    -- p_Flag=1 同意变更申请停催案件，否则拒绝
    if p_Flag=1 then   
      insert into collection_data_log 
      (id_credit,contract_no,id_person,person_name,date_due,over_days,over_amount,status,update_user,update_time,reason)
      select t.id_credit,t.contract_no,t.id_person,t.person_name,t.date_due,t.over_days,t.over_amount,'y',p_Update_User,sysdate,p_Reason
      from collection_data_stop_apply t
      where t.contract_no=p_ContractNo;

      insert into collection_data_stop 
      (id_credit,contract_no,id_person,person_name,date_due,over_days,over_amount,update_user,update_time)
      select t.id_credit,t.contract_no,t.id_person,t.name,t.date_due,t.over_days,t.overdue_fine,p_Update_User,sysdate
      from v_collection_base_info t
      where t.contract_no=p_ContractNo;
      
      delete from collection_data_diffcult t where t.contract_no=p_ContractNo;
      
      delete from collection_data_stop_apply t where t.contract_no=p_ContractNo;
    else
      update collection_data_diffcult set status=1 where contract_no=p_ContractNo;  
    
      insert into collection_data_log 
      (id_credit,contract_no,id_person,person_name,date_due,over_days,over_amount,status,update_user,update_time,reason)
      select t.id_credit,t.contract_no,t.id_person,t.person_name,t.date_due,t.over_days,t.over_amount,'n',p_Update_User,sysdate,p_Reason
      from collection_data_stop_apply t
      where t.contract_no=p_ContractNo;
      
      delete from collection_data_stop_apply t where t.contract_no=p_ContractNo;
    end if;
    commit;
    p_ReturnCode := 'A';
    return;
  exception
    When others Then
      error_info := sqlerrm;
      Rollback;
    
      p_ReturnCode := 'Z-' || error_info;   
  end prc_coll_stop_apply_manage;
  
  --停催案件处理
  procedure prc_coll_stop_manage(p_ContractNo     varchar2,
                                 p_Flag           number,
                                 p_Update_User    number,
                                 p_Reason         varchar2,
                                 p_ReturnCode     out varchar2) is
  begin
    -- p_Flag=1 停催案件释放，否则转为疑难案件
    if p_Flag=1 then   
      insert into collection_data_log 
      (id_credit,contract_no,id_person,person_name,date_due,over_days,over_amount,status,update_user,update_time,reason)
      select t.id_credit,t.contract_no,t.id_person,t.person_name,t.date_due,t.over_days,t.over_amount,'sr',p_Update_User,sysdate,p_Reason
      from collection_data_stop t
      where t.contract_no=p_ContractNo;

      delete from collection_data_stop t where t.contract_no=p_ContractNo;
    else
      insert into collection_data_log 
      (id_credit,contract_no,id_person,person_name,date_due,over_days,over_amount,status,update_user,update_time,reason)
      select t.id_credit,t.contract_no,t.id_person,t.person_name,t.date_due,t.over_days,t.over_amount,'sd',p_Update_User,sysdate,p_Reason
      from collection_data_stop t
      where t.contract_no=p_ContractNo;
      
      insert into collection_data_diffcult 
      (id_credit,contract_no,id_person,person_name,date_due,over_days,over_amount,update_user,update_time)
      select t.id_credit,t.contract_no,t.id_person,t.name,t.date_due,t.over_days,t.overdue_fine,p_Update_User,sysdate
      from v_collection_base_info t
      where t.contract_no=p_ContractNo;
      
      delete from collection_data_stop t where t.contract_no=p_ContractNo;
    end if;
    commit;
    p_ReturnCode := 'A';
    return;
  exception
    When others Then
      error_info := sqlerrm;
      Rollback;
    
      p_ReturnCode := 'Z-' || error_info;   
  end prc_coll_stop_manage;

  --催收每天自动跑取消分期过程
  procedure prc_auto_cancel_instalment(p_ReturnCode  out varchar2)
    is
    v_instalment  number;
    v_value_pay   number;
    v_principle   number;
    v_interes     number;
    v_financefee  number;
    v_csfee       number;
    v_insurance   number;
    v_version     number;
    begin
     /*1、CPD=91天时并且不再PTP期间内的，系统会自动取消分期(该客户的所有合同);
      2、如果PTP已经结束而且CPD>=91天的，系统会自动取消分期(该客户的所有合同);
      3、所有取消分期合同后，不在计算滞纳金，之前所产生的滞纳金条目不变;
      4、停催案件不会被取消分期;
      5、记录取消分期的状态和取消分期的时间;
      6、取大于等于取消分期时间最近期数的date_due和期数作为新的期款的date_due和期数生成一期期款，并且产生相应的版本变更记录，
      生成相应条目 本金-1（所有未还期数之和），利息-2（只收一期金额），
      账户管理费-13（所有未还期数之和），客户关怀费-51（所有未还期数之和），
      保险费-70（只收一期金额）;
      7、如果大于等于取消分期时间期数只有一期，则只更新状态和取消分期日时间，不做相应的版本变更记录;
      8、如果有期款已还部分金额，则重新匹配到变更后的相应期款中;*/
      
  --找出CPD>=91天的合同;  
  for cur in(select a.id id_credit,a.id_person from cs_credit a 
  where status='a'
  and not exists(select '#' from cs_cancel_instalment b where b.id_person=a.id_person and b.flag=1) 
  and a.id in(select distinct b.id_credit from instalment b 
              where b.status='a' and trunc(sysdate)-trunc(date_due)>=91 --and b.id_credit=101309
              and b.type_instalment<>'8' 
              group by b.id_credit,b.num_instalment 
              having sum(b.value_instalment)-nvl(sum(b.value_pay),0)>=50))
  loop
    --检查客户是否有停催合同
    select count(1) into v_Count from collection_data_stop t where t.id_person=cur.id_person;  
    if v_Count<=0 then  
      --检查客户合同是否在PTP期间  
      select count(1) into v_Count from checkoff_process t where t.idcredit in(select id from cs_credit where id_person=cur.id_person) and t.collection_date>trunc(sysdate);
      if v_Count<=0 then
        --检查客户合同是否有代扣中;
        select count(1) into v_Count from checkoff_batch_detail t where t.contractno in(select id from cs_credit where id_person=cur.id_person) and t.procode='代扣中';
        if v_Count<=0 then
          --查找客户所有合同
          for cs in(select t.id id_credit,t.contract_no,t.id_person from cs_credit t where t.id_person=cur.id_person and t.status='a')
            loop
              v_instalment:=0;
              v_value_pay:=0;
              v_principle:=0;
              v_interes:=0;
              v_financefee:=0;
              v_csfee:=0;
              v_insurance:=0;
              --查找客户合同大于当前时间未还款期数
              select count(1) into v_Count from(select a.num_instalment from instalment a 
              where a.id_credit=cs.id_credit and a.date_due>=trunc(sysdate) and a.type_instalment<>'8' and a.paystatus<>'k' and a.status='a' group by a.num_instalment);
              if v_Count>=2 then
                --计算客户各项还款费用
                for ins in
                  (select num_instalment,sum(principle) principle,max(interes) interes,
                   sum(csfee) csfee,sum(financefee) financefee,max(insurance) insurance
                   from(select a.id_credit,a.value_instalment,a.value_pay,a.num_instalment,
                       decode(a.type_instalment,'1',a.value_instalment,0) principle,
                       decode(a.type_instalment,'2',a.value_instalment,0) interes,
                       decode(a.type_instalment,'51',a.value_instalment,0) financefee,
                       decode(a.type_instalment,'13',a.value_instalment,0) csfee,
                       decode(a.type_instalment,'70',a.value_instalment,0) insurance
                       from instalment a where a.id_credit=cs.id_credit and a.date_due>=trunc(sysdate) and a.type_instalment<>'8' and a.status='a') b 
                   group by b.id_credit,b.num_instalment
                   having sum(value_instalment)-sum(value_pay)>0)
                loop
                  v_principle:=v_principle+ins.principle;
                  if v_interes<ins.interes then
                    v_interes:=ins.interes;
                  end if;
                  v_financefee:=v_financefee+ins.financefee;
                  v_csfee:=v_csfee+ins.csfee;
                  if v_insurance<ins.insurance then
                    v_insurance:=ins.insurance;
                  end if;
                end loop;
                --插入客户合同新的费用条目
                for inst in(select max(id_credit) id_credit,min(date_due) date_due,min(num_instalment) num_instalment,max(version) version 
                from(select id_credit,min(date_due) date_due,min(num_instalment) num_instalment,max(version) version from instalment a 
                where a.id_credit=cs.id_credit and a.date_due>=trunc(sysdate) and a.type_instalment<>'8' and a.paystatus<>'k' and a.status='a' group by a.id_credit,a.num_instalment))
                loop   
                  v_version:=inst.version;             
                  --插入财务费用条目
                  insert into instalment(id,id_credit,date_due,num_instalment,priority,status,type_instalment,value_instalment,value_pay,version,date_client,update_time,ins_time,paystatus,paytype)
                  values(seq_instalment.nextval,inst.id_credit,inst.date_due,inst.num_instalment,'10','a','51',v_financefee,0,inst.version+1,inst.date_due-10,sysdate,sysdate,'a','5');
                  --插入服务费用条目
                  insert into instalment(id,id_credit,date_due,num_instalment,priority,status,type_instalment,value_instalment,value_pay,version,date_client,update_time,ins_time,paystatus,paytype)
                  values(seq_instalment.nextval,inst.id_credit,inst.date_due,inst.num_instalment,'20','a','13',v_csfee,0,inst.version+1,inst.date_due-10,sysdate,sysdate,'a','5');
                  --插入利息条目
                  insert into instalment(id,id_credit,date_due,num_instalment,priority,status,type_instalment,value_instalment,value_pay,version,date_client,update_time,ins_time,paystatus,paytype)
                  values(seq_instalment.nextval,inst.id_credit,inst.date_due,inst.num_instalment,'90','a','2',v_interes,0,inst.version+1,inst.date_due-10,sysdate,sysdate,'a','5');
                  --插入本金条目
                  insert into instalment(id,id_credit,date_due,num_instalment,priority,status,type_instalment,value_instalment,value_pay,version,date_client,update_time,ins_time,paystatus,paytype)
                  values(seq_instalment.nextval,inst.id_credit,inst.date_due,inst.num_instalment,'100','a','1',v_principle,0,inst.version+1,inst.date_due-10,sysdate,sysdate,'a','5');
                  --插入保险费用条目
                  if v_insurance>0 then 
                    insert into instalment(id,id_credit,date_due,num_instalment,priority,status,type_instalment,value_instalment,value_pay,version,date_client,update_time,ins_time,paystatus,paytype)
                    values(seq_instalment.nextval,inst.id_credit,inst.date_due,inst.num_instalment,'95','a','70',v_insurance,0,inst.version+1,inst.date_due-10,sysdate,sysdate,'a','5');
                  end if;
                end loop;
                
                --将已配置部分还款金额改为无效
                update payinstalment set status='n' where id_instalment in(select id from instalment a,
                (select b.id_credit,b.num_instalment from instalment b where b.status='a' and b.id_credit=cs.id_credit and b.date_due>=trunc(sysdate) and b.type_instalment<>'8' 
                group by b.id_credit,b.num_instalment having sum(b.value_instalment)-nvl(sum(b.value_pay),0)>0 and nvl(sum(b.value_pay),0)>0) c
                where a.id_credit=c.id_credit and a.num_instalment=c.num_instalment);
                
                --获取部分已还金额,重新配置
                for p in (select sum(amount_pay) amount_pay,id_payin from payinstalment where id_instalment in(select id from instalment a,
                (select b.id_credit,b.num_instalment from instalment b where b.status='a' and b.id_credit=cs.id_credit and b.date_due>=trunc(sysdate) and b.type_instalment<>'8' 
                group by b.id_credit,b.num_instalment having sum(b.value_instalment)-nvl(sum(b.value_pay),0)>0 and nvl(sum(b.value_pay),0)>0) c
                where a.id_credit=c.id_credit and a.num_instalment=c.num_instalment) group by id_payin)
                  loop
                    if p.amount_pay>0 then
                      v_value_pay:=p.amount_pay;
                      for ins in(select id,value_instalment,value_pay from instalment a where id_credit=cs.id_credit and status='a' and paystatus<>'k' and version=v_version+1 order by num_instalment,priority asc)
                        loop
                          /*if ins.value_pay>0 and ins.value_instalment-ins.value_pay>0 then
                            v_value_pay:=v_value_pay+ins.value_pay;
                            update payinstalment set status='n' where id_instalment=ins.id;
                          end if;*/
                          if v_value_pay+ins.value_pay-ins.value_instalment>=0 then
                            v_value_pay:=v_value_pay-ins.value_instalment;
                             
                            update instalment set value_pay=ins.value_instalment,date_pay=sysdate,paystatus='k' where id=ins.id;
                            
                            insert into payinstalment(id,id_instalment,id_payin,amount_pay,date_pay,status,dd_flag,update_time,update_user)
                            values(seq_payinstalment.nextval,ins.id,p.id_payin,ins.value_instalment-ins.value_pay,sysdate,'a','1',sysdate,'100000');
                          else  
                            if v_value_pay>0 then
                              update instalment set value_pay=v_value_pay+ins.value_pay,paystatus='a' where id=ins.id;
                            
                              insert into payinstalment(id,id_instalment,id_payin,amount_pay,date_pay,status,dd_flag,update_time,update_user)
                              values(seq_payinstalment.nextval,ins.id,p.id_payin,v_value_pay,sysdate,'a','1',sysdate,'100000');
                              v_value_pay:=0;
                            else
                              exit;
                            end if;
                          end if; 
                        end loop;
                    end if; 
                  end loop;
                
                --将取消分期之外的未还清期数status 改为 n
                update instalment set status='n',paystatus='a',paytype='5' 
                where id_credit=cs.id_credit and version=v_version and num_instalment in
                (select num_instalment from instalment b where b.status='a' and b.date_due>=trunc(sysdate) and b.type_instalment<>'8' and paystatus<>'k' and b.version=v_version and b.id_credit=cs.id_credit);
                --更新循环贷取消分期日期
                update cycle_credit t set t.update_user=100000,t.update_time=sysdate,t.cancel_instalment_flag=1
                where t.id_person=cs.id_person;
                
                delete from cs_cancel_instalment where contract_no=cs.contract_no;
                --增加取消分期记录
                insert into cs_cancel_instalment(id,id_credit,id_person,flag,update_time,update_user,contract_no)
                values(seq_cs_cancel_instalment.nextval,cs.id_credit,cs.id_person,1,sysdate,100000,cs.contract_no);
                
                --增加循环贷取消分期记录
                insert into cs_cancel_instalment(id,id_credit,id_person,flag,update_time,update_user,contract_no)
                select seq_cs_cancel_instalment.nextval,t.id,t.id_person,1,sysdate,100000,t.contract_no 
                from cycle_credit t where t.id_person=cs.id_person;
              else
                delete from cs_cancel_instalment where contract_no=cs.contract_no;
                --增加取消分期记录
                insert into cs_cancel_instalment(id,id_credit,id_person,flag,update_time,update_user,contract_no)
                values(seq_cs_cancel_instalment.nextval,cs.id_credit,cs.id_person,1,sysdate,100000,cs.contract_no);
                
                --更新循环贷取消分期日期
                update cycle_credit t set t.update_user=100000,t.update_time=sysdate,t.cancel_instalment_flag=1
                where t.id_person=cs.id_person;
                --增加循环贷取消分期记录
                insert into cs_cancel_instalment(id,id_credit,id_person,flag,update_time,update_user,contract_no)
                select seq_cs_cancel_instalment.nextval,t.id,t.id_person,1,sysdate,100000,t.contract_no 
                from cycle_credit t where t.id_person=cs.id_person;
              end if;
            end loop;
        end if;
      end if;
    end if;
  end loop;
    commit;
    p_ReturnCode := 'A';
    return;
  exception
    When others Then
      error_info := sqlerrm;
      Rollback;
      p_ReturnCode := 'Z-' || error_info;
      insert into sys_email_list(id,mail_type,key_word,from_user,mail_to,cc_to,subject,mail_content,status,create_time,plan_time)
        values(seq_sys_email_list.nextval,'C2','自动取消分期Job','collection@dafycredit.com','wangxiaofeng@dafycredit.com','luchangjiang@dafycredit.com','自动取消分期Job','自动取消分期Job异常信息:'|| error_info,0,sysdate,sysdate);
         
  end prc_auto_cancel_instalment;

  --恢复取消分期合同
  procedure prc_recover_cancel_instalment(p_id_person   cs_person.id%type,
                                          p_ReturnCode  out varchar2)
    is
    v_value_pay    number;
    v_version      number;
    begin
      --查找取消分期合同
      for c in(select id_credit from cs_cancel_instalment t where t.id_person=p_id_person and flag=1)
      loop
        --查找除滞纳金以外是否还有未还期款
        select count(1) into v_Count from instalment a where a.id_credit=c.id_credit and a.status='a' and a.paystatus<>'k' and a.type_instalment<>'8';
        if v_Count>=1 then
          select max(version) into v_version from instalment a where a.id_credit=c.id_credit and a.status='a';
          if v_version>=2 then
            --恢复被取消的分期期数
            update instalment set status='a',version=v_version+1,paytype='1',value_pay=0 where id_credit=c.id_credit and status='n' and version=v_version-1 and paytype='5';
            --将已配置部分还款金额改为无效
            update payinstalment set status='n' where id_instalment in(select id from instalment where id_credit=c.id_credit and status='a' and version=v_version);
            --将取消分期条目改为无效
            update instalment set status='n' where id_credit=c.id_credit and status='a' and version=v_version;
            --获取部分已还金额,重新配置
            for p in(select sum(amount_pay) amount_pay,id_payin from payinstalment where id_instalment in(select id from instalment where id_credit=c.id_credit and status='n' and version=v_version) 
              group by id_payin)
              loop
                if p.amount_pay>0 then
                  v_value_pay:=p.amount_pay;
                  for ins in(select id,value_instalment,value_pay from instalment a 
                    where id_credit=c.id_credit and status='a' and paystatus<>'k' order by num_instalment,priority asc)
                    loop
                     /* if ins.value_pay>0 and (ins.value_instalment-ins.value_pay)>0 then
                        v_value_pay:=v_value_pay+ins.value_pay;
                        update payinstalment set status='n' where id_instalment=ins.id;
                      end if;*/
                      
                      if v_value_pay+ins.value_pay-ins.value_instalment>=0 then
                        v_value_pay:=v_value_pay+ins.value_pay-ins.value_instalment;
                                    
                        update instalment set value_pay=ins.value_instalment,date_pay=sysdate,paystatus='k' where id=ins.id;
                          
                        insert into payinstalment(id,id_instalment,id_payin,amount_pay,date_pay,status,dd_flag,update_time,update_user)
                        values(seq_payinstalment.nextval,ins.id,p.id_payin,ins.value_instalment-ins.value_pay,sysdate,'a','1',sysdate,'100000');
                      else  
                        if v_value_pay>0 then
                          update instalment set value_pay=v_value_pay+ins.value_pay,paystatus='a' where id=ins.id;
                          
                          insert into payinstalment(id,id_instalment,id_payin,amount_pay,date_pay,status,dd_flag,update_time,update_user)
                          values(seq_payinstalment.nextval,ins.id,p.id_payin,v_value_pay,sysdate,'a','1',sysdate,'100000');
                          v_value_pay:=0;
                        else
                          exit;
                        end if;
                      end if; 
                    end loop;
                end if;    
              end loop; 
          end if; 
        end if;    
      end loop;
    ---更新取消分期表
    update cs_cancel_instalment set flag=0 where id_person=p_id_person;
    
    commit;
    p_ReturnCode := 'A';
    return;
  exception
    When others Then
      error_info := sqlerrm;
      Rollback;
    
      p_ReturnCode := 'Z-' || error_info;   
  end prc_recover_cancel_instalment;                                    

  --催收手动取消分期
  procedure prc_hand_cancel_instalment(p_contract_no   varchar2,
                                       p_update_user   number,
                                       p_ReturnCode    out varchar2)
    is
    v_id_person   number;
    v_instalment  number;
    v_value_pay   number;
    v_principle   number;
    v_interes     number;
    v_financefee  number;
    v_csfee       number;
    v_insurance   number;
    v_version     number;
    begin
      v_id_person:=0;
      --清空错误记录表
      delete from cs_cancel_instalment_error;
      
      --查找该客户所有合同
      for cur in(select id id_credit,contract_no,id_person from cs_credit a where id_person=(select id_person from cs_credit where status='a' and contract_no=p_contract_no))
        loop
          if v_id_person!=cur.id_person then
            v_id_person:=cur.id_person;
            --查找客户是否已取消分期
            select count(1) into v_Count from cs_cancel_instalment b where b.id_person=v_id_person and b.flag=1;
            if v_Count>=1 then
              insert into cs_cancel_instalment_error(contract_no,id_person,error_remark,update_user)
              values(p_contract_no,cur.id_person,'该客户已取消分期',p_update_user);
            else 
              --查找客户是否有停催案件
              select count(1) into v_Count from collection_data_stop t where t.id_person=cur.id_person;
              if v_Count>=1 then
              insert into cs_cancel_instalment_error(contract_no,id_person,error_remark,update_user)
              values(p_contract_no,cur.id_person,'该客户有停催案件',p_update_user);
            else
              --查找客户是否有合同在PTP期间
              select count(1) into v_Count from checkoff_process t where t.idcredit in(select id from cs_credit where id_person=cur.id_person) and t.collection_date>trunc(sysdate);
              if v_Count>=1 then
                insert into cs_cancel_instalment_error(contract_no,id_person,error_remark,update_user)
                values(p_contract_no,cur.id_person,'该客户有合同在PTP期间',p_update_user);
              else
                --查找客户合同是否有在代扣中;
                select count(1) into v_Count from checkoff_batch_detail t where t.contractno in(select id from cs_credit where id_person=cur.id_person) and t.procode='代扣中';
                if v_Count>=1 then
                  insert into cs_cancel_instalment_error(contract_no,id_person,error_remark,update_user)
                  values(p_contract_no,cur.id_person,'该客户有合同在代扣中',p_update_user);
                else
                  --查找客户所有合同
                for cs in(select t.id id_credit,t.contract_no,t.id_person from cs_credit t where t.id_person=cur.id_person and t.status='a')
                  loop
                    v_instalment:=0;
                    v_value_pay:=0;
                    v_principle:=0;
                    v_interes:=0;
                    v_financefee:=0;
                    v_csfee:=0;
                    v_insurance:=0;
                    --查找客户合同大于当前时间未还款期数
                    select count(1) into v_Count from(select a.num_instalment from instalment a 
                    where a.id_credit=cs.id_credit and a.date_due>=trunc(sysdate) and a.type_instalment<>'8' and a.paystatus<>'k' and a.status='a' group by a.num_instalment);
                    if v_Count>=2 then
                      --计算客户各项还款费用
                      for ins in
                        (select num_instalment,sum(principle) principle,max(interes) interes,
                         sum(csfee) csfee,sum(financefee) financefee,max(insurance) insurance
                         from(select a.id_credit,a.value_instalment,a.value_pay,a.num_instalment,
                             decode(a.type_instalment,'1',a.value_instalment,0) principle,
                             decode(a.type_instalment,'2',a.value_instalment,0) interes,
                             decode(a.type_instalment,'51',a.value_instalment,0) financefee,
                             decode(a.type_instalment,'13',a.value_instalment,0) csfee,
                             decode(a.type_instalment,'70',a.value_instalment,0) insurance
                             from instalment a where a.id_credit=cs.id_credit and a.date_due>=trunc(sysdate) and a.type_instalment<>'8' and a.status='a') b 
                         group by b.id_credit,b.num_instalment
                         having sum(value_instalment)-sum(value_pay)>0)
                      loop
                        v_principle:=v_principle+ins.principle;
                        if v_interes<ins.interes then
                          v_interes:=ins.interes;
                        end if;
                        v_financefee:=v_financefee+ins.financefee;
                        v_csfee:=v_csfee+ins.csfee;
                        if v_insurance<ins.insurance then
                          v_insurance:=ins.insurance;
                        end if;
                      end loop;
                      --插入客户合同新的费用条目
                      for inst in(select max(id_credit) id_credit,min(date_due) date_due,min(num_instalment) num_instalment,max(version) version 
                      from(select id_credit,min(date_due) date_due,min(num_instalment) num_instalment,max(version) version from instalment a 
                      where a.id_credit=cs.id_credit and a.date_due>=trunc(sysdate) and a.type_instalment<>'8' and a.paystatus<>'k' and a.status='a' group by a.id_credit,a.num_instalment))
                      loop   
                        v_version:=inst.version;             
                        --插入财务费用条目
                        insert into instalment(id,id_credit,date_due,num_instalment,priority,status,type_instalment,value_instalment,value_pay,version,date_client,update_time,ins_time,paystatus,paytype)
                        values(seq_instalment.nextval,inst.id_credit,inst.date_due,inst.num_instalment,'10','a','51',v_financefee,0,inst.version+1,inst.date_due-10,sysdate,sysdate,'a','5');
                        --插入服务费用条目
                        insert into instalment(id,id_credit,date_due,num_instalment,priority,status,type_instalment,value_instalment,value_pay,version,date_client,update_time,ins_time,paystatus,paytype)
                        values(seq_instalment.nextval,inst.id_credit,inst.date_due,inst.num_instalment,'20','a','13',v_csfee,0,inst.version+1,inst.date_due-10,sysdate,sysdate,'a','5');
                        --插入利息条目
                        insert into instalment(id,id_credit,date_due,num_instalment,priority,status,type_instalment,value_instalment,value_pay,version,date_client,update_time,ins_time,paystatus,paytype)
                        values(seq_instalment.nextval,inst.id_credit,inst.date_due,inst.num_instalment,'90','a','2',v_interes,0,inst.version+1,inst.date_due-10,sysdate,sysdate,'a','5');
                        --插入本金条目
                        insert into instalment(id,id_credit,date_due,num_instalment,priority,status,type_instalment,value_instalment,value_pay,version,date_client,update_time,ins_time,paystatus,paytype)
                        values(seq_instalment.nextval,inst.id_credit,inst.date_due,inst.num_instalment,'100','a','1',v_principle,0,inst.version+1,inst.date_due-10,sysdate,sysdate,'a','5');
                        --插入保险费用条目
                        if v_insurance>0 then 
                          insert into instalment(id,id_credit,date_due,num_instalment,priority,status,type_instalment,value_instalment,value_pay,version,date_client,update_time,ins_time,paystatus,paytype)
                          values(seq_instalment.nextval,inst.id_credit,inst.date_due,inst.num_instalment,'95','a','70',v_insurance,0,inst.version+1,inst.date_due-10,sysdate,sysdate,'a','5');
                        end if;
                      end loop;
                      
                      --将已配置部分还款金额改为无效
                      update payinstalment set status='n' where id_instalment in(select id from instalment a,
                      (select b.id_credit,b.num_instalment from instalment b where b.status='a' and b.id_credit=cs.id_credit and b.date_due>=trunc(sysdate) and b.type_instalment<>'8' 
                      group by b.id_credit,b.num_instalment having sum(b.value_instalment)-nvl(sum(b.value_pay),0)>0 and nvl(sum(b.value_pay),0)>0) c
                      where a.id_credit=c.id_credit and a.num_instalment=c.num_instalment);
                      
                      --获取部分已还金额,重新配置
                      for p in (select sum(amount_pay) amount_pay,id_payin from payinstalment where id_instalment in(select id from instalment a,
                      (select b.id_credit,b.num_instalment from instalment b where b.status='a' and b.id_credit=cs.id_credit and b.date_due>=trunc(sysdate) and b.type_instalment<>'8' 
                      group by b.id_credit,b.num_instalment having sum(b.value_instalment)-nvl(sum(b.value_pay),0)>0 and nvl(sum(b.value_pay),0)>0) c
                      where a.id_credit=c.id_credit and a.num_instalment=c.num_instalment) group by id_payin)
                        loop
                          if p.amount_pay>0 then
                            v_value_pay:=p.amount_pay;
                            for ins in(select id,value_instalment,value_pay from instalment a where id_credit=cs.id_credit and status='a' and paystatus<>'k' and version=v_version+1 order by num_instalment,priority asc)
                              loop
                                /*if ins.value_pay>0 and ins.value_instalment-ins.value_pay>0 then
                                  v_value_pay:=v_value_pay+ins.value_pay;
                                  update payinstalment set status='n' where id_instalment=ins.id;
                                end if;*/
                                if v_value_pay+ins.value_pay-ins.value_instalment>=0 then
                                  v_value_pay:=v_value_pay-ins.value_instalment;
                                   
                                  update instalment set value_pay=ins.value_instalment,date_pay=sysdate,paystatus='k' where id=ins.id;
                                  
                                  insert into payinstalment(id,id_instalment,id_payin,amount_pay,date_pay,status,dd_flag,update_time,update_user)
                                  values(seq_payinstalment.nextval,ins.id,p.id_payin,ins.value_instalment-ins.value_pay,sysdate,'a','1',sysdate,'100000');
                                else  
                                  if v_value_pay>0 then
                                    update instalment set value_pay=v_value_pay+ins.value_pay,paystatus='a' where id=ins.id;
                                  
                                    insert into payinstalment(id,id_instalment,id_payin,amount_pay,date_pay,status,dd_flag,update_time,update_user)
                                    values(seq_payinstalment.nextval,ins.id,p.id_payin,v_value_pay,sysdate,'a','1',sysdate,'100000');
                                    v_value_pay:=0;
                                  else
                                    exit;
                                  end if;
                                end if; 
                              end loop;
                          end if; 
                        end loop;
                      
                      --将取消分期之外的未还清期数status 改为 n
                      update instalment set status='n',paystatus='a',paytype='5' 
                      where id_credit=cs.id_credit and version=v_version and num_instalment in
                      (select num_instalment from instalment b where b.status='a' and b.date_due>=trunc(sysdate) and b.type_instalment<>'8' and paystatus<>'k' and b.version=v_version and b.id_credit=cs.id_credit);
                      
                      --更新循环贷取消分期日期
                      update cycle_credit t set t.update_user=p_update_user,t.update_time=sysdate,t.cancel_instalment_flag=1
                      where t.id_person=cs.id_person;
                      
                      delete from cs_cancel_instalment where contract_no=cs.contract_no;
                      --增加取消分期记录
                      insert into cs_cancel_instalment(id,id_credit,id_person,flag,update_time,update_user,contract_no)
                      values(seq_cs_cancel_instalment.nextval,cs.id_credit,cs.id_person,1,sysdate,p_update_user,cs.contract_no);
                      
                      --增加循环贷取消分期记录
                      insert into cs_cancel_instalment(id,id_credit,id_person,flag,update_time,update_user,contract_no)
                      select seq_cs_cancel_instalment.nextval,t.id,t.id_person,1,sysdate,p_update_user,t.contract_no 
                      from cycle_credit t where t.id_person=cs.id_person;
                    else
                      delete from cs_cancel_instalment where contract_no=cs.contract_no;
                      --增加取消分期记录
                      insert into cs_cancel_instalment(id,id_credit,id_person,flag,update_time,update_user,contract_no)
                      values(seq_cs_cancel_instalment.nextval,cs.id_credit,cs.id_person,1,sysdate,p_update_user,cs.contract_no);
                      
                      --更新循环贷取消分期日期
                      update cycle_credit t set t.update_user=p_update_user,t.update_time=sysdate,t.cancel_instalment_flag=1
                      where t.id_person=cs.id_person;
                      --增加循环贷取消分期记录
                      insert into cs_cancel_instalment(id,id_credit,id_person,flag,update_time,update_user,contract_no)
                      select seq_cs_cancel_instalment.nextval,t.id,t.id_person,1,sysdate,p_update_user,t.contract_no 
                      from cycle_credit t where t.id_person=cs.id_person;
                    end if;
                  end loop;
                end if;
              end if;
            end if;
            end if;
          end if;
        end loop;
    commit;
    p_ReturnCode := 'A';
    return;
    exception
      When others Then
        error_info := sqlerrm;
        Rollback;

        p_ReturnCode := 'Z-' || error_info;  
    end prc_hand_cancel_instalment;

  --修改在PTP期间的错误备注转态
  procedure prc_edit_coll_call_status(p_contract_no    varchar2,
                                      p_coll_call_id   number,
                                      p_ptp_type       varchar2,
                                      p_update_user    number,
                                      p_ReturnCode     out varchar2)
    is
  begin
    --是代扣PTP的删除发起代扣条目
    if p_ptp_type='代扣PTP' then
      update collection_call t set t.status=0,t.update_user=p_update_user,t.update_time=sysdate where t.id=p_coll_call_id;
      
      delete from checkoff_process t where t.contract_no=p_contract_no and t.collection_date>=trunc(sysdate);
    else
      update collection_call t set t.status=0,t.update_user=p_update_user,t.update_time=sysdate where t.id=p_coll_call_id;
    end if;
  commit;
    p_ReturnCode := 'A';
    return;
  exception
    When others Then
      error_info := sqlerrm;
      Rollback;

      p_ReturnCode := 'Z-' || error_info;  
  end prc_edit_coll_call_status;
  
   
end PKG_COLLECTION;
/

