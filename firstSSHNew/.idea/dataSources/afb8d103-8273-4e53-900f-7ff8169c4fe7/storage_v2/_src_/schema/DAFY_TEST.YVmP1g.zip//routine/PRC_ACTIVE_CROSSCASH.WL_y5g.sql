create procedure PRC_ACTIVE_CROSSCASH( p_IdCredit cs_credit.id%type,
                                                p_ReturnCode out varchar2) is
   /*2015-4-15  庾文峰
    交叉现金贷现行合同*/
   error_info            varchar2(1000);  
   v_IdCredit            cs_credit.id%type;
   v_IdPerson            cs_person.id%type;
   v_DeductDate          Date;
   v_RegTime             Date;
   v_CreditAmount        cs_credit.credit_amount%type;
   v_Annuity             cs_credit.annuity%type;
   v_PaymentNum          product.payment_num%type;
   v_Eir                 product.effective_interest_rate%type;
   v_MonthIr             number;--product.month_ir%type;
   v_AccountFee          number;--product.account_fee%type;
   v_CsFee               product.cs_fee%type;
   v_StampFee            product.commision_rate%type;
   v_InsuranceFee        cs_experience.insurance_fee%type;
   v_IsSSI               cs_experience.is_ssi%type;

   v_Principal           number;
   v_Interest            number;
   v_DueDate             Date;
   v_Idx                 integer;
   v_Day                 number;
   v_i                   number;
   v_j                   number;


   cursor cur is select a.id,trunc(a.Deduct_Date),trunc(a.reg_time),a.credit_amount,nvl(a.annuity,0) annuity,b.payment_num,b.effective_interest_rate eir,b.month_ir/100 month_ir,b.account_fee/100 account_fee,b.cs_fee/100 cs_fee,c.insurance_fee,c.is_ssi,c.id_person
           from cs_credit a,product b,cs_experience c where a.id_product=b.id and a.id=c.id_credit and a.id=p_IdCredit;

   function GetDuePrinciple(n integer) return number is
        ret  number;
   begin
     if v_MonthIr=0 then
        ret := v_CreditAmount/v_PaymentNum;
       else
      ret := (v_CreditAmount * v_MonthIr * power(1 + v_MonthIr, n)) / (power(1 + v_MonthIr, v_PaymentNum) - 1);
      end if;
      return Round(ret,3);
   end;

   function GetDueInterest(n integer) return number is
        ret  number;
   begin
     if v_MonthIr=0 then
       ret:=0;
     else
      ret := (v_CreditAmount * v_MonthIr * power(1 + v_MonthIr, v_PaymentNum)) / (power(1 + v_MonthIr, v_PaymentNum) - 1)
            - (v_CreditAmount * v_MonthIr * power(1 + v_MonthIr, n)) / (power(1 + v_MonthIr, v_PaymentNum) - 1);
      end if;
      return Round(ret,3);
   end;

begin

   open cur;
   loop
      fetch cur into v_IdCredit,v_DeductDate,v_RegTime,v_CreditAmount,v_Annuity,v_PaymentNum,v_Eir,v_MonthIr,v_AccountFee,v_CsFee,v_InsuranceFee,v_IsSSI,v_IdPerson;
      exit when cur%notfound;

      v_StampFee:=trunc(v_CreditAmount*5/100000,3);
      v_AccountFee:=Round(v_CreditAmount * v_AccountFee,3);

      delete instalment where id_credit=v_IdCredit;

      for v_Idx in 1..v_PaymentNum loop

          v_DueDate:=add_months(v_DeductDate,v_Idx-1);
          /*新加的判断2月28号*/
          v_Day:=to_number(to_char(v_DueDate,'dd'));
          if v_Day>28 then
            v_DueDate:=to_date(to_char(v_DueDate,'yyyy-MM-')||'28','yyyy-MM-dd');
          end if;
          /*新加的判断2月28号*/

          v_Interest:=GetDueInterest(v_Idx-1);
          v_Principal:=GetDuePrinciple(v_Idx-1);
          -----------------------------------------------------
          v_CsFee:=v_Annuity-v_Principal-v_Interest-v_AccountFee;

          if v_MonthIr<>0 then

            if v_CreditAmount>=2000 and v_Idx=1  then
                insert into instalment(id,id_credit,date_due,num_instalment,priority,status,type_instalment,value_instalment,version,date_client,update_time)
                values(seq_instalment.nextval,v_IdCredit,v_DueDate,v_Idx,20,'a',13,v_CsFee-v_StampFee,1,v_DueDate-10,sysdate);
                insert into instalment(id,id_credit,date_due,num_instalment,priority,status,type_instalment,value_instalment,version,date_client,update_time)
                values(seq_instalment.nextval,v_IdCredit,v_DueDate,v_Idx,120,'a',46,v_StampFee,1,v_DueDate-10,sysdate);
            else
               insert into instalment(id,id_credit,date_due,num_instalment,priority,status,type_instalment,value_instalment,version,date_client,update_time)
               values(seq_instalment.nextval,v_IdCredit,v_DueDate,v_Idx,20,'a',13,v_CsFee,1,v_DueDate-10,sysdate);
           end if;

          insert into instalment(id,id_credit,date_due,num_instalment,priority,status,type_instalment,value_instalment,version,date_client,update_time)
              values(seq_instalment.nextval,v_IdCredit,v_DueDate,v_Idx,10,'a',51,v_AccountFee,1,v_DueDate-10,sysdate);

          insert into instalment(id,id_credit,date_due,num_instalment,priority,status,type_instalment,value_instalment,version,date_client,update_time)
              values(seq_instalment.nextval,v_IdCredit,v_DueDate,v_Idx,90,'a',2,v_Interest,1,v_DueDate-10,sysdate);

             if v_IsSSI=1 then
              insert into instalment(id,id_credit,date_due,num_instalment,priority,status,type_instalment,value_instalment,version,date_client,update_time)
              values(seq_instalment.nextval,v_IdCredit,v_DueDate,v_Idx,110,'a',70,v_InsuranceFee,1,v_DueDate-10,sysdate);
             end if;

           end if;

          insert into instalment(id,id_credit,date_due,num_instalment,priority,status,type_instalment,value_instalment,version,date_client,update_time)
              values(seq_instalment.nextval,v_IdCredit,v_DueDate,v_Idx,100,'a',1,v_Principal,1,v_DueDate-10,sysdate);

      end loop;
      update cs_credit set status='a',loan_date=trunc(sysdate) ,Update_Time=sysdate where id=v_IdCredit and status='h';
      
      
      select count(1) into v_i from checkoff_release where id_credit=v_IdCredit;
       if v_i>0 then
         
          select count(1) into v_j from checkoff_release where id_credit=v_IdCredit and releasestatus in('k','u');
          if v_j=0 then
            update checkoff_release set releasestatus='d' where id_credit=v_IdCredit;
          end if;  
         
      else   
      insert into checkoff_release(id_credit,releasestatus,update_user,pro_type)values(v_IdCredit,'a',100000,'o');
      end if;
      
      
       ---修改该客户所有的合同银行账号与最新现行合同的相同，P2T的合同的is_dd一定是（代扣转态is_dd=1）
      for exp in(select c.bank_name,c.bank_no,c.branch,c.is_dd,c.protocol_type,c.protocol_no from cs_experience c where c.id_credit=v_IdCredit and c.is_dd=1)
      loop
        for cs in(select a.id id_credit,a.contract_no,a.id_person,nvl(c.bank_name,' ') bank_name,a.credit_model,nvl(c.bank_no,' ') bank_no,nvl(c.branch,' ') branch,c.is_dd,c.protocol_type from cs_credit a,cs_experience c
                  where a.status in('a','p','k') and a.id=c.id_credit and a.id_person=v_IdPerson and a.id!=v_IdCredit)
        loop        
  
              
            if exp.bank_name!=cs.bank_name or exp.bank_no!=cs.bank_no or exp.is_dd!=cs.is_dd or exp.branch!=cs.branch or exp.protocol_type!=cs.protocol_type then
              update cs_experience a set a.bank_name=exp.bank_name,a.bank_no=exp.bank_no,a.branch=exp.branch,a.is_dd=exp.is_dd,a.protocol_type=exp.protocol_type,a.protocol_no=exp.protocol_no,update_time=sysdate
              where a.id_credit=cs.id_credit;

              insert into cs_bank_no_change(id,id_person,contract_no,new_bank_no,new_bank_name,new_branch,old_bank_no,old_bank_name,old_branch,update_user,update_time,old_is_dd,new_is_dd)
              values(seq_cs_bank_no_change.nextval,v_IdPerson,cs.contract_no,exp.bank_no,exp.bank_name,exp.branch,cs.bank_no,cs.bank_name,cs.branch,100000,sysdate,decode(cs.is_dd,1,'是','否'),decode(exp.is_dd,1,'是','否'));
            end if;

            if exp.bank_name!=cs.bank_name or exp.bank_no!=cs.bank_no or exp.branch!=cs.branch or exp.protocol_type!=cs.protocol_type then
              insert into cus_consult_event_info(consult_event_id,contract_no,id_person,update_user,remark)
              values('AT-Y6',cs.contract_no,v_IdPerson,100000,'系统自动变更-申请代扣服务，代扣银行'||fun_getreg_value(776,cs.bank_name)||' '||cs.branch||' 卡号'||cs.bank_no||'更新为：'||fun_getreg_value(776,exp.bank_name)||' '||exp.branch||' 卡号'||exp.bank_no);
            end if;

              
        end loop;
      end loop;
      
       
   end loop;
   close cur;
   commit;
   p_ReturnCode:='A';
   return;
Exception
   When others Then
     error_info := sqlerrm;
     p_ReturnCode:='Z-'||error_info;
     rollback;
end;


/

