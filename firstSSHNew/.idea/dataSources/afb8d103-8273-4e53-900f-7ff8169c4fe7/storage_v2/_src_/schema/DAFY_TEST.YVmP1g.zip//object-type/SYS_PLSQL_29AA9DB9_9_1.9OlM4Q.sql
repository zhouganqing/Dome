create type             SYS_PLSQL_29AA9DB9_9_1 as table of VARCHAR2(2048 BYTE);
/

