create function fun_get_call_result_value(p_Id tm_outbound_result_combox.id%type)
                                          return varchar2 is
  v_ResultValue   varchar2(50);
--Create Time:2015/05/05
--Create User:wangxiaofeng;
--Use:获取电销呼叫结果值
begin
   select t.combox_result into v_ResultValue from tm_outbound_result_combox t where t.id=p_Id;
   return(v_ResultValue);
Exception
 When others Then
   return '';
end fun_get_call_result_value;


/

