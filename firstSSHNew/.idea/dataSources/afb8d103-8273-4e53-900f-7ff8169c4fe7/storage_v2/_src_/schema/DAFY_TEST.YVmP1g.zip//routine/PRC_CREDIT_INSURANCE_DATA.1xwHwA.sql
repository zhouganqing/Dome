create procedure PRC_CREDIT_INSURANCE_DATA  is
  v_count number(10);
  v_insurance_rates  number(10,3);
  v_insurance_company_name  varchar2(100);
begin
  select count(contract_no) into v_count from cs_credit where credit_insurance_flag =0 ;
  if v_count>0 then
  select para_value into v_insurance_company_name  from sys_parameters t where para_id='INSURANCE_COMPANY';
  select para_value into v_insurance_rates from sys_parameters where para_id='INSURANCE_COMPANY_COST';

  insert into credit_insurance (id, credit_insurance_name, credit_insurance_cost, credit_insurance_rates, update_time, status, contract_no)

  select seq_credit_insurance.nextval,
         v_insurance_company_name insurance_company_name,
         credit_amount,
         v_insurance_rates insurance_rates,
         commit_time,
         '投保',
         contract_no  from (
  select
         a.id,a.contract_no ,a.app_date,a.price,a.annuity,a.id_product,a.credit_amount*v_insurance_rates credit_amount,a.deduct_date,a.status,
         case when to_number(to_char(commit_time,'dd'))>=1 and to_number(to_char(commit_time,'dd'))<=19 then add_months(trunc(commit_time,'mm')+6,1) else add_months(trunc(commit_time,'mm')+6,2) end commit_time,
         to_char（a.commit_time + 15,'yyyy-mm-dd HH24:MI:SS'）,
         b.name,decode(b.sex,'m','男','女') sex,b.ident,
         c.end_date,c.start_date,
         d.init_pay,d.payment_num ,d.prod_name,
         e.name proname,
         f.education,f.total_wk_exp,
         g.contact_value,
         j.province ,j.city,j.region,j.town,j.street ,
         k.producer
  from cs_credit a ,cs_person b,cs_employer c,product d,goods_category e,cs_experience f,cs_contact g
       ,(select province,city,region,town,street,id_person from cs_address i where i.address_type=2   and rownum = 1  order by update_time desc)  j
       ,cs_goods k,
       (select g.id_credit from cs_goods g group by g.id_credit having count(g.id_credit)=1 )  m
        --,cs_cancel_instalment n
       where a.credit_insurance_flag=0
           and a.id_person=b.id
           and a.id=c.id_credit
           and c.position='9'   --职位为学生
           and a.id_product=d.id
           and d.goods_ca_id = e.id
           and a.id=f.id_credit
           and a.id=g.id_credit
           and g.contact_type=2
           and g.person_type='1'
           and a.id=k.id_credit
           and f.id_credit=c.id_credit
           and education in ('5','6','7') --学历
           and e.name in ('电脑','手机','时尚消费品') and a.price<=15000 and m.id_credit=a.id --3C产品 ,不超过15000  只购买一部
           and add_months(a.deduct_date,d.payment_num-1) < add_months(c.start_date,f.cur_wk_exp*12-3)  --最后一期还款日需在毕业前一个月    第一期付款*（期数-1）<毕业时间
           and a.commit_time< trunc(sysdate)-15 and a.status='a' --合同状态现行     即不是提前还款
           and not exists(select '#' from cs_cancel_instalment t where t.flag=1 and t.id_credit=a.id)
           and not exists(select count(1) from cs_credit t where t.status='a' and t.id_person=a.id_person having count(1)>=2)  --判断同一个人是否有两张现行单
           --and rownum=1
           );
  end if;
  update (select contract_no, credit_insurance_flag from cs_credit where credit_insurance_flag=0) a set a.credit_insurance_flag=1
  where a.contract_no in (select contract_no from credit_insurance );
   commit;
  end;


/

