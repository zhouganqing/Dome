create function fun_get_overdue_count(p_id_credit  cs_credit.id%type,
                                                 p_flag       number)
                                                 return number is
v_Count  number;
--Create User:wangxiaofeng;
--Use:p_plag=0 时获取滞纳金等于30的次数
begin
  if p_flag=0 then
    select count(1) into v_Count from instalment a where a.type_instalment='8' and a.value_instalment=30 and a.id_credit=p_id_credit;
  else
    select count(1) into v_Count from instalment a where a.type_instalment='8' and a.value_instalment>30 and a.id_credit=p_id_credit;
  end if;

  return(v_Count);
end fun_get_overdue_count;


/

