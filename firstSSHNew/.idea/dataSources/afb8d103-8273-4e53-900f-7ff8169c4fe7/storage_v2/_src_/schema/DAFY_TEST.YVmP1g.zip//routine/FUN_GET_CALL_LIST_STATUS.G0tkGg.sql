create function fun_get_call_list_status(p_IdPerson number,p_ActiveId number)
                                          return number is
  v_Count number(10):=0;
--Create Time:2015/05/13
--Create User:wangxiaofeng;
--Use:获取客户是否符合交叉现金贷活动资格
begin
   --tm_outbound_call_list中的状态3,4,9表示不主动拨打，但是有活动资质
   select count(1) into v_Count from tm_outbound_call_list a,cross_active_detail b
   where a.active_id=b.active_id and a.id_person=b.id_person
   and a.status in(0,3,4,9) and b.status=0 and b.active_id=p_ActiveId and b.id_person=p_IdPerson;

   return(v_Count);
Exception
 When others Then
   return 0;
end fun_get_call_list_status;


/

