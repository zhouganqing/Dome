create package body PKG_DECISION is
  -- Private type declarations
    function get_branchid(p_IdCredit cs_credit.id%type)
       -- Author  : Luchangjiang
       -- Create Date : 2014-10-8
       -- Purpose : Get decision branch ID;
       return integer is
       v_BranchId         decision_branch_list.id%type;
       v_Count            integer;
    begin
       for branch in (select id,formula from decision_branch_list where status=1 order by seq)
       loop
          if pkg_decision.fun_check_formula_data(p_IdCredit,branch.formula)=true then
              return branch.id;
          end if;
       end loop;
       select count(1) into v_Count from decision_branch_list where status=1 and default_flag=1;
       if v_Count>0 then
           select id into v_BranchId from decision_branch_list where rownum=1 and status=1 and default_flag=1;
           return v_BranchId;
       else
           return -1;
       end if;
    end;

    function get_riskgroup(p_IdCredit cs_credit.id%type,
                           p_BranchId decision_risk_group.branch_id%type,
                           p_Stage decision_risk_group.stage%type)
      return integer is
      v_Id                 decision_risk_group.id%type;
      v_Formula            decision_risk_group.formula%type;

      spltElements         ty_str_split;
      spltElement          ty_str_split;

      v_ElementValue       decision_element_data.element_value%type;
      v_ValueType          decision_element_define.value_type%type;

      v_Temp               varchar2(1000);
      idx                  integer;
      v_Count              integer;
      v_Sql                varchar2(4000);
      cursor cur is select id,formula from decision_risk_group where branch_id = p_BranchId and stage=p_Stage and status=1 order by seq;
    begin
      open cur;
      loop
         fetch cur into v_Id,v_Formula;
         exit when cur%notfound;

         spltElements:=fun_split_lr(v_Formula,'[',']');
         if spltElements.Count>0 then
            /*???ùóD?a??±ê??ì???3é??ì?μ??μ*/
            for idx in 1..spltElements.Count loop
                spltElement:=fun_split(Replace(Replace(spltElements(idx),'*.',''),'..','.'),'.');
                if spltElement.Count=3 then
                    select count(1) into v_Count from decision_element_data where id_credit=p_IdCredit
                       and element_type=spltElement(1) and element_sub_type=spltElement(2) and element_name=spltElement(3);
                    if v_Count>=1 then
                       select element_value into v_ElementValue from decision_element_data where rownum=1 and id_credit=p_IdCredit
                          and element_type=spltElement(1) and element_sub_type=spltElement(2) and element_name=spltElement(3);
                       
                        select value_type into v_ValueType from decision_element_define where element_type=spltElement(1)
                      and element_sub_type=spltElement(2) and element_name=spltElement(3);
                      
                       if v_ValueType='integer' then
                          v_Formula:=replace(v_Formula,'['||spltElements(idx)||']',v_ElementValue);
                       elsif v_ValueType='decimal' then
                          v_Formula:=replace(v_Formula,'['||spltElements(idx)||']',v_ElementValue);
                       elsif v_ValueType='date' then
                          if instr(lower(v_Formula),'to_date([')=0 then
                            v_Formula:=replace(v_Formula,'['||spltElements(idx)||']','to_date('''||v_ElementValue||''',''yyyy-mm-dd'')');
                          else
                            v_Formula:=replace(v_Formula,'['||spltElements(idx)||']',''''||v_ElementValue||'''');
                          end if;
                       elsif v_ValueType='datetime' then
                         if instr(lower(v_Formula),'to_date([')=0 then
                           v_Formula:=replace(v_Formula,'['||spltElements(idx)||']','to_date('''||v_ElementValue||''',''yyyy-mm-dd hh24:mi:ss'')');
                         else
                           v_Formula:=replace(v_Formula,'['||spltElements(idx)||']',''''||v_ElementValue||'''');
                         end if;
                       else
                          v_Formula:=replace(v_Formula,spltElements(idx),v_ElementValue);
                       end if;
                    else
                       v_Formula:=replace(v_Formula,'['||spltElements(idx)||']','null');
                       v_Formula:=replace(v_Formula,'null is null','1=1');
                       v_Formula:=replace(v_Formula,'null is not null','1=2');
                       v_Temp:=lower(replace(replace(replace(v_Formula,'[',''),']',''),' ',''));                   
                       if instr(v_Temp,'to_date(,',1)>=1 or instr(v_Temp,'nullnot')>0 or instr(v_Temp,'null!=')>0 or instr(v_Temp,'!=null')>0 or instr(v_Temp,'null=')>0 or instr(v_Temp,'null>')>0
                          or instr(v_Temp,'null<')>0 or instr(v_Temp,'nulllike')>0 or instr(v_Temp,'nullin')>0 or instr(v_Temp,'to_date(null',1)>=1 then
                          goto next_loop;
                       end if;
                    end if;
                elsif spltElement.Count=2 then
                    select count(1) into v_Count from decision_element_data where id_credit=p_IdCredit
                       and element_type=spltElement(1) and element_sub_type='*' and element_name=spltElement(2);
                    if v_Count>=1 then
                       select element_value into v_ElementValue from decision_element_data where rownum=1 and id_credit=p_IdCredit
                          and element_type=spltElement(1) and element_sub_type='*' and element_name=spltElement(2);
                       
                       select element_value into v_ElementValue from decision_element_data where rownum=1 and id_credit=p_IdCredit
                        and element_type=spltElement(1) and element_sub_type='*' and element_name=spltElement(2);
                     
                       select value_type into v_ValueType from decision_element_define where element_type=spltElement(1)
                          and element_sub_type='*' and element_name=spltElement(2);
                       if v_ValueType='integer' or v_ValueType='bool' then
                          v_Formula:=replace(v_Formula,'['||spltElements(idx)||']',v_ElementValue);
                       elsif v_ValueType='decimal' then
                          v_Formula:=replace(v_Formula,'['||spltElements(idx)||']',v_ElementValue);
                       elsif v_ValueType='date' then
                          if instr(lower(v_Formula),'to_date([')=0 then
                            v_Formula:=replace(v_Formula,'['||spltElements(idx)||']','to_date('''||v_ElementValue||''',''yyyy-mm-dd'')');
                          else
                            v_Formula:=replace(v_Formula,'['||spltElements(idx)||']',''''||v_ElementValue||'''');
                          end if;
                       elsif v_ValueType='datetime' then
                          if instr(lower(v_Formula),'to_date([')=0 then
                            v_Formula:=replace(v_Formula,'['||spltElements(idx)||']','to_date('''||v_ElementValue||''',''yyyy-mm-dd hh24:mi:ss'')');
                          else
                            v_Formula:=replace(v_Formula,'['||spltElements(idx)||']',''''||v_ElementValue||'''');
                          end if;
                       else
                          v_Formula:=replace(v_Formula,spltElements(idx),v_ElementValue);
                       end if;
                    else
                       v_Formula:=replace(v_Formula,'['||spltElements(idx)||']','null');
                       v_Formula:=replace(v_Formula,'null is null','1=1');
                       v_Formula:=replace(v_Formula,'null is not null','1=2');
                       v_Temp:=lower(replace(replace(replace(v_Formula,'[',''),']',''),' ',''));                   
                       if instr(v_Temp,'to_date(,',1)>=1 or instr(v_Temp,'nullnot')>0 or instr(v_Temp,'null!=')>0 or instr(v_Temp,'!=null')>0 or instr(v_Temp,'null=')>0 or instr(v_Temp,'null>')>0
                          or instr(v_Temp,'null<')>0 or instr(v_Temp,'nulllike')>0 or instr(v_Temp,'nullin')>0 or instr(v_Temp,'to_date(null',1)>=1 then
                          goto next_loop;
                       end if;
                    end if;
                end if;
            end loop;
         end if;
         v_Sql:='select count(1) from dual where '||replace(replace(replace(v_Formula,'[',''''),']',''''),'''null''','null');
         execute immediate v_Sql into v_Count;
         if v_Count>=1 then
            return v_Id;
         end if;
<<next_loop>>
         v_Count:=0;
      end loop;
      close cur;
      return(-1);
    end;

    function get_wfiid(p_IdCredit cs_credit.id%type,p_RiskGroup decision_wfi_selection.risk_group%type,
                       p_BranchId decision_wfi_selection.branch_id%type,p_Stage decision_wfi_selection.stage%type)
                                       return integer is
      v_Id                 decision_wfi_selection.id%type;
      v_Formula            decision_wfi_selection.formula%type;

      spltElements         ty_str_split;
      spltElement          ty_str_split;

      v_ElementValue       decision_element_data.element_value%type;
      v_ValueType          decision_element_define.value_type%type;

      v_Temp               varchar2(1000);
      idx                  integer;
      v_Count              integer;
      v_Sql                varchar2(4000);
      cursor cur is select id,formula from decision_wfi_selection where branch_id=p_BranchId and stage=p_Stage and (risk_group=p_RiskGroup or risk_group=-1) order by seq;
    begin
      open cur;
      loop
         fetch cur into v_Id,v_Formula;
         exit when cur%notfound;

         spltElements:=fun_split_lr(v_Formula,'[',']');
         if spltElements.Count>0 then
            /*???ùóD?a??±ê??ì???3é??ì?μ??μ*/
            for idx in 1..spltElements.Count loop
                spltElement:=fun_split(Replace(Replace(spltElements(idx),'*.',''),'..','.'),'.');
                if spltElement.Count=3 then
                    select count(1) into v_Count from decision_element_data where id_credit=p_IdCredit
                       and element_type=spltElement(1) and element_sub_type=spltElement(2) and element_name=spltElement(3);
                    if v_Count>=1 then
                       select element_value into v_ElementValue from decision_element_data where rownum=1 and id_credit=p_IdCredit
                          and element_type=spltElement(1) and element_sub_type=spltElement(2) and element_name=spltElement(3);
                       
                      select value_type into v_ValueType from decision_element_define where element_type=spltElement(1)
                      and element_sub_type=spltElement(2) and element_name=spltElement(3);
                      
                     if v_ValueType='integer' then
                        v_Formula:=replace(v_Formula,'['||spltElements(idx)||']',v_ElementValue);
                     elsif v_ValueType='decimal' then
                        v_Formula:=replace(v_Formula,'['||spltElements(idx)||']',v_ElementValue);
                     elsif v_ValueType='date' then
                        if instr(lower(v_Formula),'to_date([')=0 then
                          v_Formula:=replace(v_Formula,'['||spltElements(idx)||']','to_date('''||v_ElementValue||''',''yyyy-mm-dd'')');
                        else
                          v_Formula:=replace(v_Formula,'['||spltElements(idx)||']',''''||v_ElementValue||'''');
                        end if;
                     elsif v_ValueType='datetime' then
                       if instr(lower(v_Formula),'to_date([')=0 then
                         v_Formula:=replace(v_Formula,'['||spltElements(idx)||']','to_date('''||v_ElementValue||''',''yyyy-mm-dd hh24:mi:ss'')');
                       else
                         v_Formula:=replace(v_Formula,'['||spltElements(idx)||']',''''||v_ElementValue||'''');
                       end if;
                     else
                        v_Formula:=replace(v_Formula,spltElements(idx),v_ElementValue);
                     end if;
                    else
                       v_Formula:=replace(v_Formula,'['||spltElements(idx)||']','null');
                       v_Formula:=replace(v_Formula,'null is null','1=1');
                       v_Formula:=replace(v_Formula,'null is not null','1=2');
                       v_Temp:=lower(replace(replace(replace(v_Formula,'[',''),']',''),' ',''));                   
                       if instr(v_Temp,'to_date(,',1)>=1 or instr(v_Temp,'nullnot')>0 or instr(v_Temp,'null!=')>0 or instr(v_Temp,'!=null')>0 or instr(v_Temp,'null=')>0 or instr(v_Temp,'null>')>0
                          or instr(v_Temp,'null<')>0 or instr(v_Temp,'nulllike')>0 or instr(v_Temp,'nullin')>0 or instr(v_Temp,'to_date(null',1)>=1 then
                          goto next_loop;
                       end if;
                    end if;
                elsif spltElement.Count=2 then
                    select count(1) into v_Count from decision_element_data where id_credit=p_IdCredit
                       and element_type=spltElement(1) and element_sub_type='*' and element_name=spltElement(2);
                    if v_Count>=1 then
                       select element_value into v_ElementValue from decision_element_data where rownum=1 and id_credit=p_IdCredit
                          and element_type=spltElement(1) and element_sub_type='*' and element_name=spltElement(2);
                       
                       select element_value into v_ElementValue from decision_element_data where rownum=1 and id_credit=p_IdCredit
                        and element_type=spltElement(1) and element_sub_type='*' and element_name=spltElement(2);
                     
                       select value_type into v_ValueType from decision_element_define where element_type=spltElement(1)
                          and element_sub_type='*' and element_name=spltElement(2);
                       if v_ValueType='integer' or v_ValueType='bool' then
                          v_Formula:=replace(v_Formula,'['||spltElements(idx)||']',v_ElementValue);
                       elsif v_ValueType='decimal' then
                          v_Formula:=replace(v_Formula,'['||spltElements(idx)||']',v_ElementValue);
                       elsif v_ValueType='date' then
                          if instr(lower(v_Formula),'to_date([')=0 then
                            v_Formula:=replace(v_Formula,'['||spltElements(idx)||']','to_date('''||v_ElementValue||''',''yyyy-mm-dd'')');
                          else
                            v_Formula:=replace(v_Formula,'['||spltElements(idx)||']',''''||v_ElementValue||'''');
                          end if;
                       elsif v_ValueType='datetime' then
                          if instr(lower(v_Formula),'to_date([')=0 then
                            v_Formula:=replace(v_Formula,'['||spltElements(idx)||']','to_date('''||v_ElementValue||''',''yyyy-mm-dd hh24:mi:ss'')');
                          else
                            v_Formula:=replace(v_Formula,'['||spltElements(idx)||']',''''||v_ElementValue||'''');
                          end if;
                       else
                          v_Formula:=replace(v_Formula,spltElements(idx),v_ElementValue);
                       end if;
                    else
                       v_Formula:=replace(v_Formula,'['||spltElements(idx)||']','null');
                       v_Formula:=replace(v_Formula,'null is null','1=1');
                       v_Formula:=replace(v_Formula,'null is not null','1=2');
                       v_Temp:=lower(replace(replace(replace(v_Formula,'[',''),']',''),' ',''));                   
                       if instr(v_Temp,'to_date(,',1)>=1 or instr(v_Temp,'nullnot')>0 or instr(v_Temp,'null!=')>0 or instr(v_Temp,'!=null')>0 or instr(v_Temp,'null=')>0 or instr(v_Temp,'null>')>0
                          or instr(v_Temp,'null<')>0 or instr(v_Temp,'nulllike')>0 or instr(v_Temp,'nullin')>0 or instr(v_Temp,'to_date(null',1)>=1 then
                          goto next_loop;
                       end if;
                    end if;
                end if;
            end loop;
         end if;
         v_Sql:='select count(1) from dual where '||replace(replace(replace(v_Formula,'[',''''),']',''''),'''null''','null');
         execute immediate v_Sql into v_Count;
         if v_Count>=1 then
            return v_Id;
         end if;
<<next_loop>>
         v_Count:=0;
      end loop;
      close cur;
      return(-1);
    end;

    function fun_get_element_valuetype(p_ElementType      decision_element_define.element_type%type,
                                      p_ElementSubType   decision_element_define.element_sub_type%type,
                                      p_ElementName      decision_element_define.element_name%type)
             return varchar2 is
       v_Count         integer;
       v_ValueType      decision_element_define.value_type%type;
    begin
       select count(1) into v_Count from decision_element_define where element_type=p_ElementType
          and element_sub_type=p_ElementSubType and element_name=p_ElementName;
       if v_Count=0 then
          return 'string';
       else
          select value_type into v_ValueType from decision_element_define where element_type=p_ElementType
             and element_sub_type=p_ElementSubType and element_name=p_ElementName;
          return v_ValueType;
       end if;
    end;

    function fun_check_formula_data(p_IdCredit cs_credit.id%type,p_Formula varchar2)
       return boolean is
       v_Formula            decision_wfi_selection.formula%type;
       spltElements          ty_str_split;
       spltElement          ty_str_split;

       v_ElementValue       decision_element_data.element_value%type;
       v_ValueType          decision_element_define.value_type%type;

       v_Count              integer;
       v_Sql                varchar2(4000);
       v_Temp               varchar2(1000);
    begin
       v_Formula:=p_Formula;
       spltElements:=fun_split_lr(v_Formula,'[',']');
       if spltElements.Count>0 then
          for idx in 1..spltElements.Count loop
              spltElement:=fun_split(Replace(Replace(spltElements(idx),'*.',''),'..','.'),'.');
              if spltElement.Count=3 then
                select count(1) into v_Count from decision_element_data where id_credit=p_IdCredit
                  and element_type=spltElement(1) and element_sub_type=spltElement(2) and element_name=spltElement(3);
                if v_Count>=1 then
                   select element_value into v_ElementValue from decision_element_data where rownum=1 and id_credit=p_IdCredit
                      and element_type=spltElement(1) and element_sub_type=spltElement(2) and element_name=spltElement(3);

                   select value_type into v_ValueType from decision_element_define where element_type=spltElement(1)
                      and element_sub_type=spltElement(2) and element_name=spltElement(3);
                      
                   if v_ValueType='integer' then
                      v_Formula:=replace(v_Formula,'['||spltElements(idx)||']',v_ElementValue);
                   elsif v_ValueType='decimal' then
                      v_Formula:=replace(v_Formula,'['||spltElements(idx)||']',v_ElementValue);
                   elsif v_ValueType='date' then
                      if instr(lower(v_Formula),'to_date([')=0 then
                        v_Formula:=replace(v_Formula,'['||spltElements(idx)||']','to_date('''||v_ElementValue||''',''yyyy-mm-dd'')');
                      else
                        v_Formula:=replace(v_Formula,'['||spltElements(idx)||']',''''||v_ElementValue||'''');
                      end if;
                   elsif v_ValueType='datetime' then
                     if instr(lower(v_Formula),'to_date([')=0 then
                       v_Formula:=replace(v_Formula,'['||spltElements(idx)||']','to_date('''||v_ElementValue||''',''yyyy-mm-dd hh24:mi:ss'')');
                     else
                       v_Formula:=replace(v_Formula,'['||spltElements(idx)||']',''''||v_ElementValue||'''');
                     end if;
                   else
                      v_Formula:=replace(v_Formula,spltElements(idx),v_ElementValue);
                   end if;
                else
                   v_Formula:=replace(v_Formula,'['||spltElements(idx)||']','null');
                   v_Formula:=replace(v_Formula,'null is null','1=1');
                   v_Formula:=replace(v_Formula,'null is not null','1=2');
                   v_Temp:=lower(replace(replace(replace(v_Formula,'[',''),']',''),' ',''));                   
                   if instr(v_Temp,'to_date(,',1)>=1 or instr(v_Temp,'nullnot')>0 or instr(v_Temp,'null!=')>0 or instr(v_Temp,'!=null')>0 or instr(v_Temp,'null=')>0 or instr(v_Temp,'null>')>0
                      or instr(v_Temp,'null<')>0 or instr(v_Temp,'nulllike')>0 or instr(v_Temp,'nullin')>0 or instr(v_Temp,'to_date(null',1)>=1 then
                       return false;
                   end if;
                end if;
              elsif spltElement.Count=2 then
                  select count(1) into v_Count from decision_element_data where id_credit=p_IdCredit
                     and element_type=spltElement(1) and element_sub_type='*' and element_name=spltElement(2);
                  if v_Count>=1 then
                     select element_value into v_ElementValue from decision_element_data where rownum=1 and id_credit=p_IdCredit
                        and element_type=spltElement(1) and element_sub_type='*' and element_name=spltElement(2);
                     
                     select value_type into v_ValueType from decision_element_define where element_type=spltElement(1)
                        and element_sub_type='*' and element_name=spltElement(2);
                     if v_ValueType='integer' or v_ValueType='bool' then
                        v_Formula:=replace(v_Formula,'['||spltElements(idx)||']',v_ElementValue);
                     elsif v_ValueType='decimal' then
                        v_Formula:=replace(v_Formula,'['||spltElements(idx)||']',v_ElementValue);
                     elsif v_ValueType='date' then
                        if instr(lower(v_Formula),'to_date([')=0 then
                          v_Formula:=replace(v_Formula,'['||spltElements(idx)||']','to_date('''||v_ElementValue||''',''yyyy-mm-dd'')');
                        else
                          v_Formula:=replace(v_Formula,'['||spltElements(idx)||']',''''||v_ElementValue||'''');
                        end if;
                     elsif v_ValueType='datetime' then
                        if instr(lower(v_Formula),'to_date([')=0 then
                          v_Formula:=replace(v_Formula,'['||spltElements(idx)||']','to_date('''||v_ElementValue||''',''yyyy-mm-dd hh24:mi:ss'')');
                        else
                          v_Formula:=replace(v_Formula,'['||spltElements(idx)||']',''''||v_ElementValue||'''');
                        end if;
                     else
                        v_Formula:=replace(v_Formula,spltElements(idx),v_ElementValue);
                     end if;
                  else
                     v_Formula:=replace(v_Formula,'['||spltElements(idx)||']','null');
                     v_Formula:=replace(v_Formula,'null is null','1=1');
                     v_Formula:=replace(v_Formula,'null is not null','1=2');
                     v_Temp:=lower(replace(replace(replace(v_Formula,'[',''),']',''),' ',''));                   
                     if instr(v_Temp,'to_date(,',1)>=1 or instr(v_Temp,'nullnot')>0 or instr(v_Temp,'null!=')>0 or instr(v_Temp,'!=null')>0 or instr(v_Temp,'null=')>0 or instr(v_Temp,'null>')>0
                        or instr(v_Temp,'null<')>0 or instr(v_Temp,'nulllike')>0 or instr(v_Temp,'nullin')>0 or instr(v_Temp,'to_date(null',1)>=1 then
                         return false;
                     end if;
                  end if;
              end if;
          end loop;
        end if;
        v_Sql:='select count(1) from dual where '||replace(replace(replace(v_Formula,'[',''''),']',''''),'''null''','null');
        execute immediate v_Sql into v_Count;
        if v_Count>=1 then
            return true;
        else
            return false;
        end if;
    end;

    procedure prc_check_formula(p_Formula decision_risk_group.formula%type,p_ReturnCode out varchar2) is
       --check if the formula is correct
       error_info           varchar2(4000);
       spltElements         ty_str_split;
       spltElement          ty_str_split;

       v_ValueType          decision_element_define.value_type%type;
       v_Formula            decision_wfi_selection.formula%type;
       v_Count              integer;
       v_Sql                varchar2(4000);
    begin
       v_Formula:=p_Formula;
       spltElements:=fun_split_lr(p_Formula,'[',']');
       if spltElements.Count>0 then
          for idx in 1..spltElements.Count loop
              spltElement:=fun_split(Replace(Replace(spltElements(idx),'*.',''),'..','.'),'.');
              if spltElement.Count=3 then
                select count(1) into v_Count from decision_element_define where element_type=spltElement(1)
                   and element_sub_type=spltElement(2) and element_name=spltElement(3);
                if v_Count=0 then
                   p_ReturnCode:='Z-没有找到元素 ['||spltElements(idx)||']';
                   return;
                else
                   select value_type into v_ValueType from decision_element_define where element_type=spltElement(1)
                      and element_sub_type=spltElement(2) and element_name=spltElement(3);
                   if v_ValueType='integer' then
                      v_Formula:=replace(v_Formula,'['||spltElements(idx)||']',0);
                   elsif v_ValueType='decimal' then
                      v_Formula:=replace(v_Formula,'['||spltElements(idx)||']',1.2);
                   elsif v_ValueType='date' then
                      if instr(lower(v_Formula),'to_date([')=0 then
                        v_Formula:=replace(v_Formula,'['||spltElements(idx)||']','to_date(''1995-1-1'',''yyyy-mm-dd'')');
                      else
                        v_Formula:=replace(v_Formula,'['||spltElements(idx)||']','''1995-1-1''');
                      end if;
                   elsif v_ValueType='datetime' then
                     if instr(lower(v_Formula),'to_date([')=0 then
                       v_Formula:=replace(v_Formula,'['||spltElements(idx)||']','to_date(''1995-1-1 12:12:12'',''yyyy-mm-dd hh24:mi:ss'')');
                     else
                       v_Formula:=replace(v_Formula,'['||spltElements(idx)||']','''1995-1-1 12:12:12''');
                     end if;
                   else
                      v_Formula:=replace(v_Formula,spltElements(idx),'t');
                   end if;
                end if;
              elsif spltElement.Count=2 then
                  select count(1) into v_Count from decision_element_define where element_type=spltElement(1)
                     and element_sub_type='*' and element_name=spltElement(2);
                  if v_Count=0 then
                     p_ReturnCode:='Z-没有找到元素 ['||spltElements(idx)||']';
                     return;
                  else
                     select value_type into v_ValueType from decision_element_define where element_type=spltElement(1)
                        and element_sub_type='*' and element_name=spltElement(2);
                     if v_ValueType='integer' or v_ValueType='bool' then
                        v_Formula:=replace(v_Formula,'['||spltElements(idx)||']',0);
                     elsif v_ValueType='decimal' then
                        v_Formula:=replace(v_Formula,'['||spltElements(idx)||']',1.2);
                     elsif v_ValueType='date' then
                        if instr(lower(v_Formula),'to_date([')=0 then
                          v_Formula:=replace(v_Formula,'['||spltElements(idx)||']','to_date(''1995-1-1'',''yyyy-mm-dd'')');
                        else
                          v_Formula:=replace(v_Formula,'['||spltElements(idx)||']','''1995-1-1''');
                        end if;
                     elsif v_ValueType='datetime' then
                        if instr(lower(v_Formula),'to_date([')=0 then
                          v_Formula:=replace(v_Formula,'['||spltElements(idx)||']','to_date(''1995-1-1 12:12:12'',''yyyy-mm-dd hh24:mi:ss'')');
                        else
                          v_Formula:=replace(v_Formula,'['||spltElements(idx)||']','''1995-1-1 12:12:12''');
                        end if;
                     else
                        v_Formula:=replace(v_Formula,spltElements(idx),'t');
                     end if;
                  end if;
              end if;
          end loop;
       end if;
       v_Sql:='select count(1) from dual where '||replace(replace(v_Formula,'[',''''),']','''');
       execute immediate v_Sql into v_Count;
       p_ReturnCode:='A-'||v_Sql;
    exception
       When others Then
         error_info := sqlerrm;
         p_ReturnCode:='Z-'||error_info||fun_crlf||v_Sql;
    end;

    procedure prc_collect_element(p_IdCredit cs_credit.id%type,p_ReturnCode out varchar2) is
       error_info                  varchar2(1000);
       -- Author  : Luchangjiang
       -- Create Date : 2014-10-16
       -- Purpose : put credit data into decision_element_data table;
       v_ContractNo                cs_credit.contract_no%type;
       v_AppDate                   cs_credit.app_date%type;
       v_CommitTime                cs_credit.commit_time%type;
       v_InterCode                 cs_credit.inter_code%type;
       v_IdSa                      cs_credit.id_sa%type;
       v_SaName                    sys_user_list.user_name%type;
       v_SaMobile                  sys_user_list.phone%type;
       v_SaIdent                   sys_user_list.ident%type;
       v_SaInDate                  sys_user_list.update_time%type;

       v_CreditAmount              cs_credit.credit_amount%type;
       v_InitPay                   cs_credit.init_pay%type;
       v_Price                     cs_credit.price%type;
       v_Annuity                   cs_credit.annuity%type;

       v_IdPerson                  cs_person.id%type;
       v_PersonName                cs_person.name%type;
       v_Ident                     cs_person.ident%type;
       v_IdentAuth                 cs_person.ident_auth%type;
       v_IdentExp                  cs_person.ident_exp%type;
       v_Birthday                  varchar2(20);
       v_Age                       integer;
       v_Sex                       cs_person.sex%type;
       v_National                  cs_person.national%type;

       v_IdSellerPlace             sellerplace.id%type;
       v_DealerName                sellerplace.name%type;
       v_PosCode                   sellerplace.pos_code%type;
       v_Province                  sellerplace.province%type;
       v_City                      sellerplace.city%type;
       v_DealerActivityStart       sellerplace.activity_start%type;
       v_Address                   sellerplace.address%type;

       v_AreaCode                  cn_city_list.area_code%type;

       v_IdSeller                  seller.id%type;
       v_SellerName                seller.name%type;
       v_SellerActivityStart       seller.activity_start%type;

       v_IdProduct                 product.id%type;
       v_ProdCode                  product.prod_code%type;
       v_ProdName                  product.prod_name%type;
       v_PaymentNum                product.payment_num%type;
       v_ProdType                  product.prod_type%type;
       v_ValidFrom                 varchar2(20);
       v_ValidTo                   varchar2(20);
       v_Eir                       product.effective_interest_rate%type;
       v_MonthIr                   product.month_ir%type;
       v_MonthFee                  product.month_fee%type;
       v_AccountFee                product.account_fee%type;
       v_CsFee                     product.cs_fee%type;
       v_OverPayYear               product.overpay_year%type;
       v_CreditFrom                product.credit_from%type;
       v_CreditTo                  product.credit_to%type;

       v_OtherPersonType           registers.reg_val_name%type;

       v_GoodsVolume               number:=0;
       v_MaxGoodsPrice             number:=-1;
       v_MaxGoodsType              goods_type.name%type;
       v_MinGoodsPrice             number:=-1;
       v_MinGoodsType              goods_type.name%type;

       v_Position                  number:=-1;
       
       v_ElementType               decision_element_data.element_type%type;
       v_ValueIndex                decision_element_data.value_index%type;
       v_Seq                       decision_element_data.seq%type;
       
       v_FamilyPhoneUseCount           number:=0;
       v_OtherPhoneUseCount            number:=0;
       v_FamilyPhoneUseSameCityCount   number:=0;
       v_FamilyPhoneUseSamePosCount    number:=0;
       v_OtherPhoneUseSameCityCount    number:=0;
       v_OtherPhoneUseSamePosCount     number:=0;
       v_UseCity                   sellerplace.city%type;
       
       v_CurrentAddressCity        wechat_credit_address.current_address_city%type;
       v_CurrentCity               wechat_credit_address.current_city%type;

       v_Temp                      varchar2(50);
       v_IdCredit                  number;
       v_Count                     integer;
       strSql                      varchar2(4000);
    begin
       delete decision_element_data where id_credit=p_IdCredit;
       ---------------------------------------------------------
       prc_save_cs_contact(100000,p_IdCredit,p_ReturnCode);
       
       v_Seq:=0;
       v_ElementType:='Special';
       insert into decision_element_data(id_credit,element_type,element_name,element_value,seq)
            values(p_IdCredit,v_ElementType,'Random1',round(dbms_random.value(),6),v_Seq+1);
       insert into decision_element_data(id_credit,element_type,element_name,element_value,seq)
            values(p_IdCredit,v_ElementType,'Random2',round(dbms_random.value(),6),v_Seq+2);
       insert into decision_element_data(id_credit,element_type,element_name,element_value,seq)
            values(p_IdCredit,v_ElementType,'Random3',round(dbms_random.value(),6),v_Seq+3);
       insert into decision_element_data(id_credit,element_type,element_name,element_value,seq)
            select p_IdCredit,v_ElementType,para_id,para_value,v_Seq+4 from sys_parameters where para_id='BIB';
       insert into decision_element_data(id_credit,element_type,element_name,element_value,seq)
            select p_IdCredit,v_ElementType,para_id,para_value,v_Seq+5 from sys_parameters where para_id='BIB2';
       v_Seq:=v_Seq + 5;
       ---------------------------------------------------------
       v_ElementType:='Credit';
       select a.contract_no,a.app_date,a.commit_time,a.inter_code,nvl(a.id_sa,''),nvl(b.user_name,'') sa_name,nvl(b.ident,'') sa_ident,nvl(b.phone,'') sa_mobile,nvl(trunc(b.update_time),trunc(sysdate)),a.credit_amount,a.init_pay,a.price,a.annuity,a.id_sellerplace,a.id_product,a.id_person
         into v_ContractNo,v_AppDate,v_CommitTime,v_InterCode,v_IdSa,v_SaName,v_SaIdent,v_SaMobile,v_SaInDate,v_CreditAmount,v_InitPay,v_Price,v_Annuity,v_IdSellerPlace,v_IdProduct,v_IdPerson
         from cs_credit a,sys_user_list b where a.id_sa=b.id(+) and a.id=p_IdCredit;

       strSql:='insert into decision_element_data(id_credit,element_type,element_name,element_value,seq)
                select '||p_IdCredit||','''||v_ElementType||''','||'''ContractNo'''||','''||v_ContractNo||''','||(v_Seq+1)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''AppDate'''||','''||to_char(v_AppDate,'yyyy-MM-dd')||''','||(v_Seq+2)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''CommitTime'''||','''||to_char(v_CommitTime,'yyyy-MM-dd HH24:mi:ss')||''','||(v_Seq+3)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''InterCode'''||','''||v_InterCode||''','||(v_Seq+4)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''IdSa'''||','''||v_IdSa||''','||(v_Seq+5)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''SaName'''||','''||v_SaName||''','||(v_Seq+6)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''SaMobile'''||','''||v_SaMobile||''','||(v_Seq+7)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''SaIdent'''||','''||v_SaIdent||''','||(v_Seq+8)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''SaInDate'''||','''||to_char(v_SaInDate,'yyyy-MM-dd')||''','||(v_Seq+9)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''CreditAmount'''||','''||v_CreditAmount||''','||(v_Seq+10)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''InitPay'''||','''||v_InitPay||''','||(v_Seq+11)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''Price'''||','''||v_Price||''','||(v_Seq+12)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''Annuity'''||','''||v_Annuity||''','||(v_Seq+13)||' from dual';
       Execute immediate strSql;
       v_Seq:=v_Seq + 13;
       ---------------------------------------------------------
       v_ElementType:='Person';
       select name,ident,nvl(ident_auth,''),nvl(ident_exp,''),sex,nvl(fun_getreg_value(790,a.national),'汉')
         into v_PersonName,v_Ident,v_IdentAuth,v_IdentExp,v_Sex,v_National
         from cs_person a where id=v_IdPerson;

       if length(v_Ident)=15 then
           v_Birthday:=to_char(to_date('19'||substr(v_Ident,7,6),'yyyy-MM-dd'),'yyyy-MM-dd');
           select to_number(to_char(sysdate,'yyyy')) - to_number('19'||substr(v_Ident,7,2)) into v_Age from dual;
       else
           v_Birthday:=to_char(to_date(substr(v_Ident,7,8),'yyyy-MM-dd'),'yyyy-MM-dd');
           select to_number(to_char(sysdate,'yyyy')) - to_number(substr(v_Ident,7,4)) into v_Age from dual;
       end if;
       strSql:='insert into decision_element_data(id_credit,element_type,element_name,element_value,seq)
                select '||p_IdCredit||','''||v_ElementType||''','||'''Name'''||','''||v_PersonName||''','||(v_Seq+1)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''IdPerson'''||','''||v_IdPerson||''','||(v_Seq+2)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''Ident'''||','''||v_Ident||''','||(v_Seq+3)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''IdentAuth'''||','''||v_IdentAuth||''','||(v_Seq+4)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''IdentExp'''||','''||to_char(v_IdentExp,'yyyy-MM-dd')||''','||(v_Seq+5)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''Birthday'''||','''||v_Birthday||''','||(v_Seq+6)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''Age'''||','''||v_Age||''','||(v_Seq+7)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''Sex'''||','''||v_Sex||''','||(v_Seq+8)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''National'''||','''||v_National||''','||(v_Seq+9)||' from dual';

       Execute immediate strSql;

       v_Seq:=v_Seq + 9;

       ---------------------------------------------------------
       /*v_ElementType:='SellerPlace';
       
       select name,province,city,address,activity_start,id_seller,pos_code
         into v_DealerName,v_Province,v_City,v_Address,v_DealerActivityStart,v_IdSeller,v_PosCode
         from sellerplace where id=v_IdSellerPlace;
       v_UseCity:=v_City;
       
       insert into decision_element_data(id_credit,element_type,element_name,element_value,seq)
                  select p_IdCredit,v_ElementType,'ActiveDate',decode(min(update_time),null,'',to_char(min(update_time),'yyyy-mm-dd')),v_Seq+1 
                  from sellerplace_status_change t where t.new_status=1 and t.id_sellerplace=v_IdSellerPlace;
       v_Seq:=v_Seq + 1;
       
       strSql:='insert into decision_element_data(id_credit,element_type,element_name,element_value,seq)
                select '||p_IdCredit||','''||v_ElementType||''','||'''Name'''||','''||v_DealerName||''','||(v_Seq+1)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''Province'''||','''||v_Province||''','||(v_Seq+2)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''PosCode'''||','''||v_PosCode||''','||(v_Seq+3)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''City'''||','''||v_City||''','||(v_Seq+4)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''Address'''||','''||v_Address||''','||(v_Seq+5)||' from dual';
                --union select '||p_IdCredit||','''||v_ElementType||''','||'''ActiveDate'''||','''||to_char(v_DealerActivityStart,'yyyy-MM-dd')||''','||(v_Seq+6)||' from dual';

       Execute immediate strSql;

       select area_code into v_AreaCode from cn_city_list where rownum=1 and province=v_Province and city=v_City;
       strSql:='insert into decision_element_data(id_credit,element_type,element_name,element_value,seq)
               select '||p_IdCredit||','''||v_ElementType||''',''AreaCode'','''||v_AreaCode||''','||(v_Seq+7)||' from dual';
       Execute immediate strSql;
       
       strSql:='insert into decision_element_data(id_credit,element_type,element_name,element_value,seq)
               select '||p_IdCredit||','''||v_ElementType||''',''RiskCate'',risk_cate,'||(v_Seq+8)||' from mv_DF_POS_RISK_CATE_GL where pos_code='''||v_PosCode||'''';
       Execute immediate strSql;
       v_Seq:=v_Seq + 8;
       ---------------------------------------------------------
       v_ElementType:='Seller';
       select name,province,city,activity_start
         into v_SellerName,v_Province,v_City,v_SellerActivityStart
         from seller where id=v_IdSeller;

       strSql:='insert into decision_element_data(id_credit,element_type,element_name,element_value,seq)
                select '||p_IdCredit||','''||v_ElementType||''','||'''Name'''||','''||v_DealerName||''','||(v_Seq+1)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''Province'''||','''||v_Province||''','||(v_Seq+2)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''City'''||','''||v_City||''','||(v_Seq+3)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''ActiveDate'''||','''||to_char(v_SellerActivityStart,'yyyy-MM-dd')||''','||(v_Seq+4)||' from dual';
       Execute immediate strSql;
       
       select count(1) into v_Count from sellerplace where id_seller=v_IdSeller;
       strSql:='insert into decision_element_data(id_credit,element_type,element_name,element_value,seq)
               select '||p_IdCredit||',''Seller'',''DealerCount'','''||v_Count||''','||(v_Seq+5)||' from dual';
       Execute immediate strSql;*/
       select count(1) into v_Count from sellerplace where id=v_IdSellerPlace;
       if v_Count=1 then
           v_ElementType:='SellerPlace';
           select name,province,city,address,activity_start,id_seller,pos_code
             into v_DealerName,v_Province,v_City,v_Address,v_DealerActivityStart,v_IdSeller,v_PosCode
             from sellerplace where id=v_IdSellerPlace;
           v_UseCity:=v_City;
             
           insert into decision_element_data(id_credit,element_type,element_name,element_value,seq)
                  select p_IdCredit,v_ElementType,'ActiveDate',decode(min(update_time),null,'',to_char(min(update_time),'yyyy-mm-dd')),v_Seq+1 
                  from sellerplace_status_change t where t.new_status=1 and t.id_sellerplace=v_IdSellerPlace;
           v_Seq:=v_Seq + 1;
                    
           strSql:='insert into decision_element_data(id_credit,element_type,element_name,element_value,seq)
                    select '||p_IdCredit||','''||v_ElementType||''','||'''Name'''||','''||v_DealerName||''','||(v_Seq+1)||' from dual
                    union select '||p_IdCredit||','''||v_ElementType||''','||'''Province'''||','''||v_Province||''','||(v_Seq+2)||' from dual
                    union select '||p_IdCredit||','''||v_ElementType||''','||'''PosCode'''||','''||v_PosCode||''','||(v_Seq+3)||' from dual
                    union select '||p_IdCredit||','''||v_ElementType||''','||'''City'''||','''||v_City||''','||(v_Seq+4)||' from dual
                    union select '||p_IdCredit||','''||v_ElementType||''','||'''Address'''||','''||v_Address||''','||(v_Seq+5)||' from dual';
                    --union select '||p_IdCredit||','''||v_ElementType||''','||'''ActiveDate'''||','''||to_char(v_DealerActivityStart,'yyyy-MM-dd')||''','||(v_Seq+6)||' from dual';

           Execute immediate strSql;

           select area_code into v_AreaCode from cn_city_list where rownum=1 and province=v_Province and city=v_City;
           strSql:='insert into decision_element_data(id_credit,element_type,element_name,element_value,seq)
                   select '||p_IdCredit||','''||v_ElementType||''',''AreaCode'','''||v_AreaCode||''','||(v_Seq+7)||' from dual';
           Execute immediate strSql;
           
           strSql:='insert into decision_element_data(id_credit,element_type,element_name,element_value,seq)
                   select '||p_IdCredit||','''||v_ElementType||''',''RiskCate'',risk_cate,'||(v_Seq+8)||' from mv_DF_POS_RISK_CATE_GL@Dbl_Dafy_Sales.dafycredit where pos_code='''||v_PosCode||''''; 
           Execute immediate strSql;
           
           strSql:='insert into decision_element_data(id_credit,element_type,element_name,element_value,seq)
                   select '||p_IdCredit||','''||v_ElementType||''',''RiskCate_Challenge'',risk_cate_Challenge,'||(v_Seq+9)||' from mv_DF_POS_RISK_CATE_GL@Dbl_Dafy_Sales.dafycredit where pos_code='''||v_PosCode||''''; 
           Execute immediate strSql;
           v_Seq:=v_Seq + 9;
           ---------------------------------------------------------
           v_ElementType:='Seller';
           select name,province,city,activity_start
             into v_SellerName,v_Province,v_City,v_SellerActivityStart
             from seller where id=v_IdSeller;

           strSql:='insert into decision_element_data(id_credit,element_type,element_name,element_value,seq)
                    select '||p_IdCredit||','''||v_ElementType||''','||'''Name'''||','''||v_DealerName||''','||(v_Seq+1)||' from dual
                    union select '||p_IdCredit||','''||v_ElementType||''','||'''Province'''||','''||v_Province||''','||(v_Seq+2)||' from dual
                    union select '||p_IdCredit||','''||v_ElementType||''','||'''City'''||','''||v_City||''','||(v_Seq+3)||' from dual
                    union select '||p_IdCredit||','''||v_ElementType||''','||'''ActiveDate'''||','''||to_char(v_SellerActivityStart,'yyyy-MM-dd')||''','||(v_Seq+4)||' from dual';
           Execute immediate strSql;
           
           select count(1) into v_Count from sellerplace where id_seller=v_IdSeller;
           strSql:='insert into decision_element_data(id_credit,element_type,element_name,element_value,seq)
                   select '||p_IdCredit||',''Seller'',''DealerCount'','''||v_Count||''','||(v_Seq+5)||' from dual';
           Execute immediate strSql;
       end if;
       v_Seq:=v_Seq + 5;
       ---------------------------------------------------------
       v_ElementType:='Product';
       select prod_code,prod_name,payment_num,decode(valid_from, null, '', to_char(valid_from, 'yyyy-MM-dd')),decode(valid_to, null, '', to_char(valid_to, 'yyyy-MM-dd')),
              effective_interest_rate,month_ir,month_fee,account_fee,cs_fee,overpay_year,init_pay,credit_from,credit_to,prod_type
         into v_ProdCode,v_ProdName,v_PaymentNum,v_ValidFrom,v_ValidTo,v_Eir,v_MonthIr,v_MonthFee,v_AccountFee,v_CsFee,v_OverPayYear,v_InitPay,v_CreditFrom,v_CreditTo,v_ProdType
         from product where id=v_IdProduct;

       strSql:='insert into decision_element_data(id_credit,element_type,element_name,element_value,seq)
                select '||p_IdCredit||','''||v_ElementType||''','||'''ProdCode'''||','''||v_ProdCode||''','||(v_Seq+1)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''ProdName'''||','''||v_ProdName||''','||(v_Seq+2)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''PaymentNum'''||','''||v_PaymentNum||''','||(v_Seq+3)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''InitPay'''||','''||v_InitPay||''','||(v_Seq+4)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''CreditFrom'''||','''||v_CreditFrom||''','||(v_Seq+5)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''CreditTo'''||','''||v_CreditTo||''','||(v_Seq+6)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''EIR'''||','''||v_Eir||''','||(v_Seq+7)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''MonthIr'''||','''||v_MonthIr||''','||(v_Seq+8)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''MonthFee'''||','''||v_MonthFee||''','||(v_Seq+9)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''AccountFee'''||','''||v_AccountFee||''','||(v_Seq+10)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''CsFee'''||','''||v_CsFee||''','||(v_Seq+11)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''OverPayYear'''||','''||v_OverPayYear||''','||(v_Seq+12)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''ProdType'''||','''||v_ProdType||''','||(v_Seq+13)||' from dual
                union select '||p_IdCredit||','''||v_ElementType||''','||'''ValidFrom'''||','''||v_ValidFrom||''','||(v_Seq+14)||' from dual';
       Execute immediate strSql;
       v_Seq:=v_Seq + 14;
       if v_ValidTo is not null then
           insert into decision_element_data(id_credit,element_type,element_name,element_value,seq)
           select p_IdCredit,''||v_ElementType||'','ValidTo',''||v_ValidTo||'',(v_Seq+1) from dual;
           v_Seq:=v_Seq + 1;
       end if;
       ---------------------------------------------------------
       v_ElementType:='Photo';
       v_Count:=0;
       for photo in (select file_name,fun_getreg_value(775,a.photo_type) photo_type from cs_client_photo a where id_credit=p_IdCredit)
       loop
            insert into decision_element_data(id_credit,element_type,element_name,element_value,seq)values
               (p_IdCredit,v_ElementType,photo.photo_type,photo.file_name,v_Seq+1);
            v_Count:=v_Count+1;
            v_Seq:=v_Seq + 1;
       end loop;
       insert into decision_element_data(id_credit,element_type,element_name,element_value,seq)values
               (p_IdCredit,v_ElementType,'Count',v_Count,v_Seq+1);
       v_Seq:=v_Seq + 1;
       ---------------------------------------------------------
       v_ElementType:='Goods';
       v_ValueIndex:=0;
       for goods in (select b.name goods_category,c.name goods_type,producer,brand,goods_price from cs_goods a,goods_category b,goods_type c
              where a.id_goods_category=b.id and a.id_goods_type=c.id and a.id_credit=p_IdCredit)
       loop
           v_ValueIndex:=v_ValueIndex+1;
           if v_MaxGoodsPrice=-1 or v_MaxGoodsPrice<goods.goods_price then
              v_MaxGoodsPrice:=goods.goods_price;
              v_MaxGoodsType:=goods.goods_type;
           end if;
           
           if v_MinGoodsPrice=-1 or v_MinGoodsPrice>goods.goods_price then
              v_MinGoodsPrice:=goods.goods_price;
              v_MinGoodsType:=goods.goods_type;
           end if;
           
           insert into decision_element_data(id_credit,element_type,element_name,element_value,value_index,seq)values
               (p_IdCredit,v_ElementType,'Category',goods.goods_category,v_ValueIndex,v_Seq+1);
           insert into decision_element_data(id_credit,element_type,element_name,element_value,value_index,seq)values
               (p_IdCredit,v_ElementType,'GoodsType',goods.goods_type,v_ValueIndex,v_Seq+2);
           insert into decision_element_data(id_credit,element_type,element_name,element_value,value_index,seq)values
               (p_IdCredit,v_ElementType,'Producer',goods.producer,v_ValueIndex,v_Seq+3);
           insert into decision_element_data(id_credit,element_type,element_name,element_value,value_index,seq)values
               (p_IdCredit,v_ElementType,'Brand',goods.brand,v_ValueIndex,v_Seq+4);
           v_Seq:=v_Seq + 4;
           v_GoodsVolume:=v_GoodsVolume+1;
       end loop;
       insert into decision_element_data(id_credit,element_type,element_name,element_value,value_index,seq)values
               (p_IdCredit,v_ElementType,'MaxPrice',v_MaxGoodsPrice,v_ValueIndex,v_Seq+1);
       insert into decision_element_data(id_credit,element_type,element_name,element_value,value_index,seq)values
               (p_IdCredit,v_ElementType,'MaxGoodsType',v_MaxGoodsType,v_ValueIndex,v_Seq+2);
       insert into decision_element_data(id_credit,element_type,element_name,element_value,value_index,seq)values
               (p_IdCredit,v_ElementType,'MinGoodsType',v_MinGoodsType,v_ValueIndex,v_Seq+3);
       insert into decision_element_data(id_credit,element_type,element_name,element_value,value_index,seq)values
               (p_IdCredit,v_ElementType,'GoodsVolume',v_GoodsVolume,v_ValueIndex,v_Seq+4);
       v_Seq:=v_Seq + 3;
       ---------------------------------------------------------
       v_ElementType:='Contact';
       for contact in (select fun_getreg_value(395,contact_type) contact_type,contact_value from cs_contact where person_type='1' and id_credit=p_IdCredit)
       loop
           insert into decision_element_data(id_credit,element_type,element_name,element_value,seq)values
               (p_IdCredit,v_ElementType,contact.contact_type,contact.contact_value,v_Seq+1);
           v_Seq:=v_Seq + 1;
       end loop;
       ---------------------------------------------------------
       v_ElementType:='Address';
       v_ValueIndex:=0;
       for address in (select decode(address_type,1,'ResidentAddress',2,'CurrentAddress','CompanyAddress') address_type,province,city,region,town,street,building,room
              from cs_address where id_credit=p_IdCredit order by address_type)
       loop
           v_ValueIndex:=v_ValueIndex+1;
           insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)values
               (p_IdCredit,v_ElementType,address.address_type,'Province',address.province,v_ValueIndex,v_Seq+1);
           insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)values
               (p_IdCredit,v_ElementType,address.address_type,'City',address.city,v_ValueIndex,v_Seq+2);
           insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)values
               (p_IdCredit,v_ElementType,address.address_type,'Region',address.region,v_ValueIndex,v_Seq+3);
           insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)values
               (p_IdCredit,v_ElementType,address.address_type,'Town',address.town,v_ValueIndex,v_Seq+4);
           insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)values
               (p_IdCredit,v_ElementType,address.address_type,'Street',address.street,v_ValueIndex,v_Seq+5);
           insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)values
               (p_IdCredit,v_ElementType,address.address_type,'Building',address.building,v_ValueIndex,v_Seq+6);
           insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)values
               (p_IdCredit,v_ElementType,address.address_type,'Room',address.room,v_ValueIndex,v_Seq+7);
           if address.address_type='CurrentAddress' then
               select area_code into v_AreaCode from cn_city_list where rownum=1 and province=address.province and city=address.city;
               strSql:='insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,seq)
                       select '||p_IdCredit||','''||v_ElementType||''','''||address.address_type||''',''AreaCode'','''||v_AreaCode||''','||(v_Seq+8)||' from dual';
               Execute immediate strSql;
               v_Seq:=v_Seq + 8;
           else
               v_Seq:=v_Seq + 7;
           end if;
       end loop;
       ---------------------------------------------------------
       v_ElementType:='OtherPerson';
       v_ValueIndex:=0;
       for otherperson in (select a.name,fun_getreg_value(decode(length(a.person_type),1,265,396),a.person_type) persontype,b.contact_value
              from cs_other_person a,cs_contact b where a.id_credit=b.id_credit and a.person_type=b.person_type and a.id_credit=p_IdCredit order by a.id)
       loop
           if instr(otherperson.persontype,'-')>0 then
              v_OtherPersonType:=substr(otherperson.persontype,1,instr(otherperson.persontype,'-')-1);
           else
              v_OtherPersonType:=otherperson.persontype;
           end if;
           v_ValueIndex:=v_ValueIndex+1;
           insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)values
               (p_IdCredit,v_ElementType,v_OtherPersonType,'Name',otherperson.name,v_ValueIndex,v_Seq+1);
           insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)values
               (p_IdCredit,v_ElementType,v_OtherPersonType,'ContactValue',otherperson.contact_value,v_ValueIndex,v_Seq+2);

           v_Seq:=v_Seq + 2;
       end loop;

       ---------------------------------------------------------
       v_ElementType:='Career';
       v_ValueIndex:=0;

       for employer in (select nvl(fun_getreg_value(399,a.company_type),'') as company_type,nvl(fun_getreg_value(397,a.industry),'') as industry,a.position,
              nvl(b.university,a.company_name1) university,nvl(a.department,'') as department,decode(a.start_date, null, '', to_char(a.start_date, 'yyyy-MM-dd')) startdate,decode(a.end_date, null, '', to_char(a.end_date, 'yyyy-MM-dd')) enddate
              from cs_employer a,university b where a.company_name=b.id(+) and a.id_credit=p_IdCredit)
       loop
           v_ValueIndex:=v_ValueIndex+1;
           v_Position:=employer.position;
           insert into decision_element_data(id_credit,element_type,element_name,element_value,value_index,seq)values
               (p_IdCredit,v_ElementType,'CompanyType',employer.company_type,v_ValueIndex,v_Seq+1);
           insert into decision_element_data(id_credit,element_type,element_name,element_value,value_index,seq)values
               (p_IdCredit,v_ElementType,'Industry',employer.Industry,v_ValueIndex,v_Seq+2);
           insert into decision_element_data(id_credit,element_type,element_name,element_value,value_index,seq)values
               (p_IdCredit,v_ElementType,'Position',employer.position,v_ValueIndex,v_Seq+3);
           insert into decision_element_data(id_credit,element_type,element_name,element_value,value_index,seq)values
               (p_IdCredit,v_ElementType,'University',employer.university,v_ValueIndex,v_Seq+4);
           insert into decision_element_data(id_credit,element_type,element_name,element_value,value_index,seq)values
               (p_IdCredit,v_ElementType,'Department',employer.department,v_ValueIndex,v_Seq+5);
           insert into decision_element_data(id_credit,element_type,element_name,element_value,value_index,seq)values
               (p_IdCredit,v_ElementType,'StartDate',employer.startdate,v_ValueIndex,v_Seq+6);
           if employer.enddate is not null then
               insert into decision_element_data(id_credit,element_type,element_name,element_value,value_index,seq)values
                   (p_IdCredit,v_ElementType,'EndDate',employer.enddate,v_ValueIndex,v_Seq+7);
               v_Seq:=v_Seq + 7;
           else
               v_Seq:=v_Seq + 6;
           end if;
       end loop;

       ---------------------------------------------------------
       v_ElementType:='Other';
       
       for experience in (select nvl(a.total_wk_exp,0) total_wk_exp,nvl(a.wk_income,0) wk_income,nvl(a.other_income,0) other_income,nvl(a.family_income,0) family_income,
              nvl(fun_getreg_value(11,a.education),'') education,nvl(ssi,'') ssi,nvl(a.cur_wk_exp,0) cur_wk_exp,fun_getreg_value(776,a.bank_name) bank_name,a.bank_no,a.branch,
              fun_get_ybscity(a.id_ybs_city) bank_region,nvl(a.is_dd,0) is_dd,nvl(a.is_ssi,0) is_ssi,to_char(a.fst_date_pay, 'yyyy-MM-dd') fst_date_pay
              from cs_experience a where id_credit=p_IdCredit)
       loop
          if v_Position=9 then
               v_Temp:='LeftGraduateMonth';
          else
               v_Temp:='CurrentEmpMonth';
          end if;
          insert into decision_element_data(id_credit,element_type,element_name,element_value,seq)values
                 (p_IdCredit,v_ElementType,v_Temp,experience.total_wk_exp,v_Seq+1);
          insert into decision_element_data(id_credit,element_type,element_name,element_value,seq)values
                 (p_IdCredit,v_ElementType,'PersonIncome',experience.wk_income,v_Seq+2);
          insert into decision_element_data(id_credit,element_type,element_name,element_value,seq)values
                 (p_IdCredit,v_ElementType,'OtherIncome',experience.other_income,v_Seq+3);
          insert into decision_element_data(id_credit,element_type,element_name,element_value,seq)values
                 (p_IdCredit,v_ElementType,'FamilyIncome',experience.family_income,v_Seq+4);
          insert into decision_element_data(id_credit,element_type,element_name,element_value,seq)values
                 (p_IdCredit,v_ElementType,'Education',experience.education,v_Seq+5);
          insert into decision_element_data(id_credit,element_type,element_name,element_value,seq)values
                 (p_IdCredit,v_ElementType,'LengthOfSchooling',experience.ssi,v_Seq+6);
          insert into decision_element_data(id_credit,element_type,element_name,element_value,seq)values
                 (p_IdCredit,v_ElementType,'BankName',experience.bank_name,v_Seq+7);
          insert into decision_element_data(id_credit,element_type,element_name,element_value,seq)values
                 (p_IdCredit,v_ElementType,'BankNo',experience.bank_no,v_Seq+8);
          insert into decision_element_data(id_credit,element_type,element_name,element_value,seq)values
                 (p_IdCredit,v_ElementType,'BankCity',experience.bank_region,v_Seq+9);
          insert into decision_element_data(id_credit,element_type,element_name,element_value,seq)values
                 (p_IdCredit,v_ElementType,'Branch',experience.branch,v_Seq+10);
          insert into decision_element_data(id_credit,element_type,element_name,element_value,seq)values
                 (p_IdCredit,v_ElementType,'IsDD',experience.is_dd,v_Seq+11);
          insert into decision_element_data(id_credit,element_type,element_name,element_value,seq)values
                 (p_IdCredit,v_ElementType,'IsSSI',experience.is_ssi,v_Seq+12);
          insert into decision_element_data(id_credit,element_type,element_name,element_value,seq)values
                 (p_IdCredit,v_ElementType,'SSI',experience.ssi,v_Seq+13);
          insert into decision_element_data(id_credit,element_type,element_name,element_value,seq)values
                 (p_IdCredit,v_ElementType,'FirstPayDate',experience.fst_date_pay,v_Seq+14);
       
          v_Seq:=v_Seq + 14;
       end loop;
       
       v_ElementType:='FamilyInfo';       
       for familyinfo in (select decode(id_spouse, 1, '未婚', 2, '已婚', '其它') mariage,nvl(child,0) children_count,fun_getreg_value(2, house_type) house_type,expense_month
                   from cs_family_info where id_credit=p_IdCredit)
       loop
          insert into decision_element_data(id_credit,element_type,element_name,element_value,seq)values
                 (p_IdCredit,v_ElementType,'Marriage',familyinfo.mariage,v_Seq+1);
          insert into decision_element_data(id_credit,element_type,element_name,element_value,seq)values
                 (p_IdCredit,v_ElementType,'ChildrenCount',familyinfo.children_count,v_Seq+2);
          insert into decision_element_data(id_credit,element_type,element_name,element_value,seq)values
                 (p_IdCredit,v_ElementType,'HouseType',familyinfo.house_type,v_Seq+3);
          insert into decision_element_data(id_credit,element_type,element_name,element_value,seq)values
                 (p_IdCredit,v_ElementType,'ExpenseMonth',familyinfo.expense_month,v_Seq+4);              
          v_Seq:=v_Seq + 4;
       end loop;
       
       -----------------以下为需要计算的变量-----------------------------------------------
       
       --IsSAIdent客户申请时,身份证是否属于销售代表
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
       select p_IdCredit,'HardCheck','*','IsSAIdent',decode(count(1),0,0,1),1,v_Seq+1 
       from sys_user_list a where upper(a.role_id)='SA' and a.ident=v_Ident;
       v_Seq:=v_Seq + 1;
       
       --IsMysteryIdent 客户申请时身份证是否属于暗访人员白名单(select ident from mv_WHITELIST_MYST_INVE where status='a')
       /*insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
         select p_IdCredit,'HardCheck','*','IsMysteryIdent',decode(count(1),0,0,1),1,v_Seq+1 
         from mv_WHITELIST_MYST_INVE t where status='a' and t.ident=v_Ident;
       v_Seq:=v_Seq + 1;*/
       
       ---客户现行合同的总贷款额---
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
         select p_IdCredit,'HardCheck','*','SumActiveCreditAmount',nvl(sum(a.credit_amount),0),1,v_Seq+1 
         from cs_credit a where a.id_person=v_IdPerson and a.status='a';
       v_Seq:=v_Seq + 1;
       
       --此门店第一张合同的申请时间，status<>'r'
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
         select p_IdCredit,'SellerPlace','*','FirstAppDate',to_char(nvl(min(trunc(a.commit_time)),trunc(sysdate)),'yyyy-mm-dd'),1,v_Seq+1 
         from cs_credit a where a.id_sellerplace=v_IdSellerPlace and a.id_sa!=800079 and a.commit_time>to_date('2014-09-01','yyyy-mm-dd') and a.status!='r';
       v_Seq:=v_Seq + 1;
       
       --客户在申请此合同时，前30天内的合同总次数
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
            select p_IdCredit,'HardCheck','*','ApplicationLast30Day',count(1),1,v_Seq+1 from cs_credit a where a.id_person=v_IdPerson
               and a.id<>p_IdCredit and trunc(a.commit_time)>=trunc(sysdate)-30;
       v_Seq:=v_Seq + 1;

       --客户在申请此合同时，当天取消的合同总数
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
            select p_IdCredit,'HardCheck','*','CancleApplicationSameDay',count(1),1,v_Seq+1 from cs_credit a where a.id_person=v_IdPerson
               and trunc(a.commit_time)=trunc(sysdate) and a.status='t' and a.id<>p_IdCredit;
       v_Seq:=v_Seq + 1;

       --客户在申请此合同时前面一张合同的申请时间
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
            select p_IdCredit,'HardCheck','*','PrevCommitTime',to_char(max(commit_time),'yyyy-MM-dd HH24:mi:ss'),1,v_Seq+1 from cs_credit
             where id_person=v_IdPerson and commit_time<=v_CommitTime and id!=p_IdCredit;
       v_Seq:=v_Seq + 1;

       --客户在申请此合同时前面一张通过的合同的申请时间，除拒绝和取消的合同外（状态为d/t/x的除外）
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
            select p_IdCredit,'HardCheck','*','MaxPrevCommitTime',to_char(max(commit_time),'yyyy-MM-dd HH24:mi:ss'),1,v_Seq+1 from cs_credit
             where id_person=v_IdPerson and commit_time<=v_CommitTime and id!=p_IdCredit and status not in ('d','t','x');
       v_Seq:=v_Seq + 1;

       --客户在申请此合同时前面一张拒绝的合同的申请时间（状态为d）
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
            select p_IdCredit,'HardCheck','*','RejectPrevCommitTime',to_char(max(commit_time),'yyyy-MM-dd HH24:mi:ss'),1,v_Seq+1 from cs_credit
             where id_person=v_IdPerson and commit_time<=v_CommitTime and id!=p_IdCredit and status='d';
       v_Seq:=v_Seq + 1;

      
       --客户本人手机号码所属城市
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
       select p_IdCredit,'Other','*','PhoneNoCity',nvl(max(a.city),'null'),1,v_Seq+1
       from mv_df_phone_attribution_gl@dbl_dafy_sales.dafycredit a where a.mobilenumber=(select substr(contact_value,1,7) from cs_contact t
         where t.id_credit=p_IdCredit and t.person_type = '1' and t.contact_type='2');
         v_Seq:=v_Seq + 1;    
         

       --客户在申请此合同时前面一张合同的状态
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
            select p_IdCredit,'HardCheck','*','PrevStatus',status,1,v_Seq+1 from cs_credit where id_person=v_IdPerson
               and id=(select max(id) from cs_credit where id_person=v_IdPerson and id!=p_IdCredit);
       v_Seq:=v_Seq + 1;

       for pre_credit in (select to_char(max(commit_time),'yyyy-MM-dd HH24:mi:ss') commit_time,count(1) sumdue,sum(annuity) annuity from cs_credit where id_person=v_IdPerson and commit_time<=v_CommitTime and id!=p_IdCredit and status ='a')
       loop
           --客户在申请此合同时前面一张现行的合同的申请时间（状态为a)
           insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
                values(p_IdCredit,'HardCheck','*','PrevApproveTime',pre_credit.commit_time,1,v_Seq+1);
           v_Seq:=v_Seq + 1;
           --客户在申请此合同时现行状态的合同数量(状态为a）
           --select count(sum(1)) into v_Count from v_previous_contract where prev_status='a' and id_credit=p_IdCredit group by id_credit;
           insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
                values(p_IdCredit,'HardCheck','*','SumDue',pre_credit.sumdue,1,v_Seq+1);
           v_Seq:=v_Seq + 1;
           --客户在申请此合同时现行状态的合同的每期期款之和(状态为a）
           --select count(sum(prev_annuity)) into v_Count from v_previous_contract where prev_status='a' and id_credit=p_IdCredit group by id_credit;
           insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
                values(p_IdCredit,'HardCheck','*','SumSurplusValueInstalment',pre_credit.annuity,1,v_Seq+1);
           v_Seq:=v_Seq + 1;
       end loop;
       --客户在申请此合同时通过状态的合同数量（状态为a/k/p）
       for pre_credit in (select count(1) sumdue,sum(credit_amount) sumamount from cs_credit where id_person=v_IdPerson and id!=p_IdCredit and status in ('a','k','p'))
       loop
           insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
                values(p_IdCredit,'HardCheck','*','SumPassContract',pre_credit.sumdue,1,v_Seq+1);
           v_Seq:=v_Seq + 1;
           --客户在申请此合同时通过状态的合同贷款额之和（状态为a/k/p）
           --select count(sum(prev_credit_amount)) into v_Count from v_previous_contract where prev_status in ('a','k','p') and id_credit=p_IdCredit group by id_credit;
           insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
                values(p_IdCredit,'HardCheck','*','SumPassCreditAmount',pre_credit.sumamount,1,v_Seq+1);
           v_Seq:=v_Seq + 1;
       end loop;
       
       --1. SumAgrSameOffPhoneLast6M:客户在申请此合同时，客户办公号码在过去6个月被其他客户（作为申请人办公号码）
       --使用过的可衡量30天逾期的合同数( select sum(agr_fpd30) from risk_control.df_pd_sum_gl)
       --2. SumDefSameOffPhoneLast6M:客户在申请此合同时，客户办公号码在过去6个月被其他客户（作为申请人办公号码）
       --使用过的出现30天逾期的合同数( select sum(fpd30) from risk_control.df_pd_sum_gl)
       for cs in(select sum(decode(a.agr_fpd30,null,0,a.agr_fpd30)) agr_fpd30,sum(decode(a.fpd30,null,0,a.fpd30)) fpd30 from mv_df_pd_sum_gl@Dbl_Dafy_Sales.dafycredit a 
                 where exists(select 1 from cs_contact b where b.id_credit=a.id_credit and b.contact_type='3' 
                              and b.contact_value=(select contact_value from cs_contact c where c.contact_type='3' and c.id_credit=p_IdCredit)  
                              and b.update_time>=trunc(v_CommitTime-180) and b.update_time<=v_CommitTime))
       loop
         insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
                values(p_IdCredit,'HardCheck','*','SumAgrSameOffPhoneLast6M',cs.agr_fpd30,1,v_Seq+1);
           v_Seq:=v_Seq + 1;
         insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
                values(p_IdCredit,'HardCheck','*','SumDefSameOffPhoneLast6M',cs.fpd30,1,v_Seq+1);
           v_Seq:=v_Seq + 1;
       end loop;
       
       --客户在申请此合同时，非客户本人的手机号码在过去6个月被其他客户用作非本人的手机号码相同且姓名不同的次数（除状态为t，r的合同）
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
       select p_IdCredit,'HardCheck','*','MobileUseDiffNameCountLast6M',count(1),1,v_Seq+1 
       from cs_credit t
       join cs_contact a on a.id_credit=t.id and a.person_type!='1' and a.contact_type='2'
       join cs_other_person b on b.id_credit=a.id_credit and b.person_type=a.person_type
       join (select e.name,g.contact_value from cs_contact g 
            join cs_other_person e on e.id_credit=g.id_credit and e.person_type=g.person_type
            where g.person_type!='1' and g.contact_type='2' and g.id_credit=p_IdCredit
            ) c on c.contact_value=a.contact_value and b.name!=c.name
       where t.status not in('t','r') and t.commit_time>=trunc(v_CommitTime-180) and t.commit_time<=v_CommitTime;

       /*鲁长江   2015-6-9*/
       select count(1) into v_Count from WFI_FRAUD_METRIX_RESULT a,WFI_FRAUD_METRIX_RULE b where a.id = b.fraud_metrix_result_id and a.event_name = 'Credit' and a.associated_id=p_IdCredit 
          and rule_name in ('3个月内在全局手机使用多个身份证进行借款', '3个月内在本平台手机使用多个身份证进行借款', '3个月内手机在多个平台借款次数过多','3个月内身份证在多个平台借款次数过多',
                      '3个月内身份证在多个平台借款','3个月内手机在多个平台借款','3个月内在全局范围内使用多个手机或身份证进行借款', '3个月内身份证借款平台数过多','3个月内手机借款平台数过多');
       if v_Count>0 then
          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
              values(p_IdCredit,'HardCheck','*','MultiLoanFraudMetrix','1',1,v_Seq+1); 
       else
          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
              values(p_IdCredit,'HardCheck','*','MultiLoanFraudMetrix','0',1,v_Seq+1);
       end if;  
       v_Seq:=v_Seq + 1;    
       select count(1) into v_Count from WFI_FRAUD_METRIX_RESULT a,WFI_FRAUD_METRIX_RULE b where a.id = b.fraud_metrix_result_id and a.event_name = 'Credit' and a.associated_id=p_IdCredit 
          and rule_name in ('借款时手机号命中全局诈骗骚扰证据库','借款时身份证命中全局欺诈证据库', '借款时邮箱命中全局欺诈证据库', '借款时座机命中全局欺诈证据库','借款手机号命中虚假号码',
                                '借款手机号命中失信名单', '借款手机命中支付欺诈','借款时身份证命中法院执行','借款时座机命中失信名单证据库',
                                '借款人身份证命中法院失信证据库','借款人身份证命中法院执行证据库');
       if v_Count>0 then
          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
              values(p_IdCredit,'HardCheck','*','BlackListFraudMetrix','1',1,v_Seq+1); 
       else
          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
              values(p_IdCredit,'HardCheck','*','BlackListFraudMetrix','0',1,v_Seq+1);
       end if;
       
       select nvl(max(b.extra_data),0) into v_Count
       from WFI_FRAUD_METRIX_RESULT a 
       join WFI_FRAUD_METRIX_RULE b on a.id=b.fraud_metrix_result_id
       where b.rule_name in ('3个月内手机在多个平台借款','3个月内手机在多个平台借款','3个月内身份证借款平台数','3个月内手机借款平台数')
             and a.event_name='Credit' and a.associated_id=p_IdCredit;
       
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
              values(p_IdCredit,'HardCheck','*','MultiLoanCountFraudMetrix',v_Count,1,v_Seq+1);
       v_Seq:=v_Seq + 1;
       v_Count:=0;       
       /*for prev_instalment in
           (select prev.id_credit,
               min(case when num_instalment=1 then date_due else null end) as date_due_first,--客户最早的应还款日期
               max(cpd) as cpd,--客户在申请合同时其他合同的现在的未还的逾期天数，精确到天
               sum(remaining_amount) as remaining_amount, --客户在申请此合同时其他合同剩余的未还期金额（包含未到期的）
               sum(remaining_instal) as remaining_instal, --客户在申请此合同时其他合同剩余的未还期数之和（包含未到期的）
               max(max_dpd) as max_dpd,--客户在申请合同时历史上最大逾期天数，精确到天
               max(case when add_months(date_due,3)>=trunc(sysdate) then max_dpd else 0 end) as last_3m_dpd, --客户在申请合同时最近三个月（自然月）的最大逾期天数，精确到天
               max(case when add_months(date_due,3)>=trunc(sysdate) and lpad(max_dpd,2,0)>0 then date_due else null end) as date_3m_dpd,--客户在申请合同时最近三个月（自然月）的最大逾期天数所处的当期的应还款日期
               sum(case when remaining_amount<=0 and max_dpd<=0 then 1 else 0 end) as m_paid_ndpd,--客户在申请此合同前成功还款且没有逾期的期数总合
               sum(case when date_due<trunc(sysdate) then 1 else 0 end) as m_due--客户在申请此合同时前面已经到期的期数之和
           from v_previous_contract prev
           left join v_dpd_instalment dpd on prev.prev_id_credit=dpd.id_credit
           where prev.id_credit=p_IdCredit
           group by prev.id_credit)*/
       for prev_instalment in
          (select to_char(min(date_due_first),'yyyy-MM-dd') as date_due_first,--客户最早的应还款日期
               max(cpd) as cpd,--客户在申请合同时其他合同的现在的未还的逾期天数，精确到天
               sum(remaining_amount) as remaining_amount, --客户在申请此合同时其他合同剩余的未还期金额（包含未到期的）
               sum(remaining_instal) as remaining_instal, --客户在申请此合同时其他合同剩余的未还期数之和（包含未到期的）
               max(max_dpd) as max_dpd,--客户在申请合同时历史上最大逾期天数，精确到天
               max(last_3m_dpd) as last_3m_dpd, --客户在申请合同时最近三个月（自然月）的最大逾期天数，精确到天
               to_char(to_date(substr(max(date_3m_dpd),4,8),'yyyy-MM-dd'),'yyyy-MM-dd') as date_3m_dpd,
               sum(m_paid_ndpd) as m_paid_ndpd,--客户在申请此合同前成功还款且没有逾期的期数总合
               sum(m_due) as m_due--客户在申请此合同时前面已经到期的期数之和
              from mv_DF_PD_SUM_GL@Dbl_Dafy_Sales.dafycredit where id_person=v_IdPerson)
       loop
            if prev_instalment.date_due_first is not null then
                insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
                    values(p_IdCredit,'HardCheck','*','DateDueFirst',prev_instalment.date_due_first,1,v_Seq+1);
                v_Seq:=v_Seq + 1;

                insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
                     values(p_IdCredit,'HardCheck','*','Cpd',prev_instalment.cpd,1,v_Seq+1);
                v_Seq:=v_Seq + 1;
                insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
                     values(p_IdCredit,'HardCheck','*','RemainingAmount',prev_instalment.remaining_amount,1,v_Seq+1);
                v_Seq:=v_Seq + 1;
                insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
                     values(p_IdCredit,'HardCheck','*','RemainingInstal',prev_instalment.remaining_instal,1,v_Seq+1);
                v_Seq:=v_Seq + 1;
                insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
                     values(p_IdCredit,'HardCheck','*','MaxDpd',prev_instalment.max_dpd,1,v_Seq+1);
                v_Seq:=v_Seq + 1;
                insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
                     values(p_IdCredit,'HardCheck','*','Last3mDpd',prev_instalment.last_3m_dpd,1,v_Seq+1);
                v_Seq:=v_Seq + 1;
                if prev_instalment.date_3m_dpd is not null then
                   insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
                        values(p_IdCredit,'HardCheck','*','Date3mDpd',prev_instalment.date_3m_dpd,1,v_Seq+1);
                   v_Seq:=v_Seq + 1;
                end if;

                insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
                     values(p_IdCredit,'HardCheck','*','MPaidNdpd',prev_instalment.m_paid_ndpd,1,v_Seq+1);
                v_Seq:=v_Seq + 1;
                insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
                     values(p_IdCredit,'HardCheck','*','MDue',prev_instalment.m_due,1,v_Seq+1);
                v_Seq:=v_Seq + 1;
            end if;
       end loop;
       
       --交叉现金贷元素
       if v_ProdType in(6,7) then
         --客户第一次参加活动的活动开始时间
         insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
            select p_IdCredit,'Credit','*','ValidFromFirst',to_char(min(b.start_date),'yyyy-mm-dd'),1,v_Seq+1 
            from cross_active_detail a,cross_active_list b where a.active_id=b.active_id and a.id_person=v_IdPerson;
         v_Seq:=v_Seq + 1;  
         
         --客户正在参加的活动相关信息
         for active in(select a.max_amount,b.start_date,b.end_date,b.active_type from cross_active_detail a,cross_active_list b 
         where a.active_id=b.active_id and b.status=1 and a.id_person=v_IdPerson)
         loop
           --当前活动最大额度
           insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
            values(p_IdCredit,'Credit','*','Limit',active.max_amount,1,v_Seq+1);
           v_Seq:=v_Seq + 1;
           --当前活动开始时间
           insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
            values(p_IdCredit,'Credit','*','ValidFrom',to_char(active.start_date,'yyyy-mm-dd'),1,v_Seq+1);
           v_Seq:=v_Seq + 1;
           --当前活动结束时间
           insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
            values(p_IdCredit,'Credit','*','ValidTo',to_char(active.end_date,'yyyy-mm-dd'),1,v_Seq+1);
           v_Seq:=v_Seq + 1;
           --当前活动类型
           insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
            values(p_IdCredit,'Credit','*','ActiveType',active.active_type,1,v_Seq+1);
           v_Seq:=v_Seq + 1;
         end loop;
       end if;

       -----------黑名单客户------------------------------------
       --如果客户存在黑名单有效期限里,则创建拒绝原因"黑名单."
       --客户身份证黑名单
       select count(1) into v_Count from customer_blacklist where ident=v_Ident;
       if v_Count>0 then
          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
              values(p_IdCredit,'HardCheck','*','BlackListIDent','1',1,v_Seq+1);
          v_Seq:=v_Seq + 1;
       end if;
       --客户本人手机号码黑名单
       select count(1) into v_Count from customer_blacklist where mobile in(select contact_value from cs_contact where id_person=(select id_person from cs_credit where id=p_IdCredit) and person_type='1' and contact_type in(2,3,18,19));
       if v_Count>0 then
          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
              values(p_IdCredit,'HardCheck','*','BlackListMobile','1',1,v_Seq+1);
          v_Seq:=v_Seq + 1;
       end if;
       --客户其它手机号码黑名单
       select count(1) into v_Count from customer_blacklist where mobile in(select contact_value from cs_contact where id_person=(select id_person from cs_credit where id=p_IdCredit) and person_type<>'1' and contact_type in(2,3,18,19));
       if v_Count>0 then
          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
              values(p_IdCredit,'HardCheck','*','BlackListOtherMobile','1',1,v_Seq+1);
          v_Seq:=v_Seq + 1;
       end if;
       --客户家庭电话黑名单
       select count(1) into v_Count from customer_blacklist where home_num in(select contact_value from cs_contact where id_person=(select id_person from cs_credit where id=p_IdCredit) and contact_type=18);
       if v_Count>0 then
          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
              values(p_IdCredit,'HardCheck','*','BlackListHomePhone','1',1,v_Seq+1);
          v_Seq:=v_Seq + 1;
       end if;
       --公司工作电话黑名单
       select count(1) into v_Count from company_blacklist where office_num in(select contact_value from cs_contact where id_person=(select id_person from cs_credit where id=p_IdCredit) and contact_type=3);
       if v_Count>0 then
          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
              values(p_IdCredit,'HardCheck','*','BlackListOfficePhone','1',1,v_Seq+1);
          v_Seq:=v_Seq + 1;
       end if;
       --公司名称黑名单
       select count(1) into v_Count from company_blacklist where employer_name in(select company_name1 from cs_employer where id_person=(select id_person from cs_credit where id=p_IdCredit));
       if v_Count>0 then
          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
              values(p_IdCredit,'HardCheck','*','BlackListCompanyName','1',1,v_Seq+1);
          v_Seq:=v_Seq + 1;
       end if;

       --客户在申请此合同时,历史其他客户使用过的银行账号（除本人外，除状态为t,d,r的合同）
       select count(1) into v_Count from cs_experience a,cs_credit b where a.id_credit=b.id and a.id_person<>v_IdPerson and b.status not in('d','t','r')
                                                                     and a.bank_no=(select bank_no from cs_experience where id_credit=p_IdCredit and id_person=v_IdPerson);
       if v_Count>0 then
          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
              values(p_IdCredit,'HardCheck','*','BankAccNo','1',1,v_Seq+1);
          v_Seq:=v_Seq + 1;
       end if;

       for phone_depository in (select relationship,contact_value,status,contact_type,id_sellerplace,city from v_phone_depository where id_credit=p_IdCredit)
       loop
          if phone_depository.relationship='client' and phone_depository.contact_type='2' then
              --客户在申请此合同时，前6个月内客户手机号码被使用过次数
              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
                   select p_IdCredit,'HardCheck','*','SameMobileLast6Month',count(1),1,v_Seq+1 from v_phone_depository
                    where contact_value=phone_depository.contact_value and contact_type='2' and relationship='client' and id_person!=v_IdPerson and status not in('d','t') and commit_time>=sysdate-180;
              v_Seq:=v_Seq + 1;
              --客户在申请此合同时，客户手机号码被历史其他客户（作为申请人移动电话）使用过的次数（除状态为t,d,r的合同）
              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
                   select p_IdCredit,'HardCheck','*','SameMobileHisCount',count(1),1,v_Seq+1 from v_phone_depository
                    where contact_value=phone_depository.contact_value and contact_type='2' and relationship='client' and id_person!=v_IdPerson and status not in('d','t','r');
              v_Seq:=v_Seq + 1;
              --客户办公电话在过去30天在同个城市被其他人重复使用为办公电话的情况；状态不等于tr 使用过的次数（除状态为t,r的合同）
              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
                   select p_IdCredit,'HardCheck','*','MobPhoneUseSameCityCount',count(1),1,v_Seq+1 from v_phone_depository
                    where contact_value=phone_depository.contact_value and id_person!=v_IdPerson and commit_time>=sysdate-30 and status not in('t','r') and city=phone_depository.city;
              v_Seq:=v_Seq + 1; 
              --客户办公电话在过去30天在同个城市被其他人重复使用为办公电话的情况；状态不等于tr 使用过的次数（除状态为t,r的合同）
              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
                   select p_IdCredit,'HardCheck','*','MobPhoneUseSamePosCount',count(1),1,v_Seq+1 from v_phone_depository
                    where contact_value=phone_depository.contact_value and id_person!=v_IdPerson and commit_time>=sysdate-30 and status not in('t','r') and id_sellerplace=phone_depository.id_sellerplace;
              v_Seq:=v_Seq + 1;
              --客户在申请此合同时，客户手机号码存在，在职SA移动电话列表
              select count(1) into v_Count from sys_user_list a where upper(a.role_id)='SA' and a.phone=phone_depository.contact_value;
              if v_Count>0 then
                 insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
                   values(p_IdCredit,'HardCheck','*','SAMobilelist','1',1,v_Seq+1);
                 v_Seq:=v_Seq + 1;
              end if;
          elsif phone_depository.relationship='client' and phone_depository.contact_type='18' then
              --客户在申请此合同时，客户家庭固话被历史其他客户（作为家庭固话）使用过的次数（除状态为t,d,r的合同）
              insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
                   select p_IdCredit,'HardCheck','*','FamilyPhoneHisUseCount',count(1),1,v_Seq+1 from v_phone_depository
                    where contact_value=phone_depository.contact_value and contact_type='18' and relationship='client' and id_person!=v_IdPerson and status not in('d','t','r');
              v_Seq:=v_Seq + 1;
          elsif phone_depository.relationship='family' then
              --家庭成员电话在最近180天被其他不同的客户用作其他所有电话（办公电话除外）的次数
              select count(distinct(id_credit||contact_value)) into v_Count from v_phone_depository
              where contact_value=phone_depository.contact_value and id_person!=v_IdPerson and commit_time>=sysdate-180 and commit_time<=v_CommitTime and status not in('t','r'); 
              v_FamilyPhoneUseCount:=v_FamilyPhoneUseCount+v_Count;
              --家庭成员电话在过去30天在同个城市被其他人重复使用的情况；状态不等于tr的次数
              select count(distinct(id_credit||contact_value)) into v_Count from v_phone_depository
              where contact_value=phone_depository.contact_value and id_person!=v_IdPerson and commit_time>=sysdate-30 and commit_time<=v_CommitTime and status not in('t','r') and city=phone_depository.city; 
              v_FamilyPhoneUseSameCityCount:=v_FamilyPhoneUseSameCityCount+v_Count;
              --家庭成员电话在过去30天在同个门店被其他人重复使用的情况；状态不等于tr的次数
              select count(distinct(id_credit||contact_value)) into v_Count from v_phone_depository
              where contact_value=phone_depository.contact_value and id_person!=v_IdPerson and commit_time>=sysdate-30 and commit_time<=v_CommitTime and status not in('t','r') and id_sellerplace=phone_depository.id_sellerplace; 
              v_FamilyPhoneUseSamePosCount:=v_FamilyPhoneUseSamePosCount+v_Count;
          elsif phone_depository.relationship='others' then
              --其他联系人电话在最近180天被其他不同的客户用作其他所有电话（办公电话除外）的次数
              select count(distinct(id_credit||contact_value)) into v_Count from v_phone_depository
              where contact_value=phone_depository.contact_value and id_person!=v_IdPerson and commit_time>=sysdate-180 and commit_time<=v_CommitTime and status not in('t','r');
              v_OtherPhoneUseCount:=v_OtherPhoneUseCount+v_Count;
              v_Seq:=v_Seq + 1;
              --其他联系人电话在过去30天在同个城市被其他人重复使用的情况；状态不等于tr的次数
              select count(distinct(id_credit||contact_value)) into v_Count from v_phone_depository
              where contact_value=phone_depository.contact_value and id_person!=v_IdPerson and commit_time>=sysdate-30 and commit_time<=v_CommitTime and status not in('t','r') and city=phone_depository.city;
              v_OtherPhoneUseSameCityCount:=v_OtherPhoneUseSameCityCount+v_Count;
              v_Seq:=v_Seq + 1;
              --其他联系人电话在过去30天在同个门店被其他人重复使用的情况；状态不等于tr的次数
              select count(distinct(id_credit||contact_value)) into v_Count from v_phone_depository
              where contact_value=phone_depository.contact_value and id_person!=v_IdPerson and commit_time>=sysdate-30 and commit_time<=v_CommitTime and status not in('t','r') and id_sellerplace=phone_depository.id_sellerplace;
              v_OtherPhoneUseSamePosCount:=v_OtherPhoneUseSamePosCount+v_Count;
              v_Seq:=v_Seq + 1;
          end if;
       end loop;
       
       --家庭成员电话在最近180天被其他不同的客户用作其他所有电话（办公电话除外）总的次数
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
            values(p_IdCredit,'HardCheck','*','FamilyPhoneUseCount',v_FamilyPhoneUseCount,1,v_Seq+1);
       v_Seq:=v_Seq + 1;
       
       --家庭成员电话在过去30天在同个城市被其他人重复使用的情况；状态不等于tr（办公电话除外）总的次数
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
            values(p_IdCredit,'HardCheck','*','FamilyPhoneUseSameCityCount',v_FamilyPhoneUseSameCityCount,1,v_Seq+1);
       v_Seq:=v_Seq + 1;
       
       --家庭成员电话在过去30天在同个门店被其他人重复使用的情况；状态不等于tr（办公电话除外）总的次数
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
            values(p_IdCredit,'HardCheck','*','FamilyPhoneUseSamePosCount',v_FamilyPhoneUseSamePosCount,1,v_Seq+1);
       v_Seq:=v_Seq + 1;

       --其他联系人电话在最近180天被其他不同的客户用作其他所有电话（办公电话除外）总的次数
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
            values(p_IdCredit,'HardCheck','*','OtherPhoneUseCount',v_OtherPhoneUseCount,1,v_Seq+1);
       v_Seq:=v_Seq + 1;
       
       --其他联系人电话在过去30天在同个城市被其他人重复使用的情况；状态不等于tr（办公电话除外）总的次数
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
            values(p_IdCredit,'HardCheck','*','OtherPhoneUseSameCityCount',v_OtherPhoneUseSameCityCount,1,v_Seq+1);
       v_Seq:=v_Seq + 1;
       
       --其他联系人电话在过去30天在同个门店被其他人重复使用的情况；状态不等于tr（办公电话除外）总的次数
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
            values(p_IdCredit,'HardCheck','*','OtherPhoneUseSamePosCount',v_OtherPhoneUseSamePosCount,1,v_Seq+1);
       v_Seq:=v_Seq + 1;
       
       --此门店历史上通过的合同数量
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
         select p_IdCredit,'HardCheck','*','SumApprovedSamePos',count(1),1,v_Seq+1 from cs_credit
           where id_person!=v_IdPerson and commit_time<=v_CommitTime and status in('a','b','m','n','y','k','p') and id_sellerplace=v_IdSellerplace;
       v_Seq:=v_Seq + 1;
       
       --客户办公电话在过去30天在同个城市被其他人重复使用为办公电话的情况；状态不等于tr，总的次数
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
       select p_IdCredit,'HardCheck','*','OffPhoneUseSameCityCount',count(1),1,v_Seq+1 from cs_credit a,cs_contact b,sellerplace c
         where a.id=b.id_credit(+) and a.id_sellerplace=c.id(+) and b.contact_type='3' and a.id_person!=v_IdPerson and a.status not in('t','r') and a.commit_time>=sysdate-30
         and b.contact_value in(select t.contact_value from cs_contact t where t.contact_type='3' and t.id_credit=p_IdCredit) and c.city=v_UseCity;
       v_Seq:=v_Seq + 1;

       --客户办公电话在过去30天在同个门店被其他人重复使用为办公电话的情况；状态不等于tr,总的次数
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
         select p_IdCredit,'HardCheck','*','OffPhoneUseSamePosCount',count(1),1,v_Seq+1 from cs_credit a,cs_contact b,sellerplace c
           where a.id=b.id_credit(+) and a.id_sellerplace=c.id(+) and b.contact_type='3' and a.id_person!=v_IdPerson and a.status not in('t','r') and a.commit_time>=sysdate-30
           and b.contact_value in(select t.contact_value from cs_contact t where t.contact_type='3' and t.id_credit=p_IdCredit) and a.id_sellerplace=v_IdSellerplace;
       v_Seq:=v_Seq + 1;
       
       --客户此合同一共提供了多少个电话
       select count(1) into v_Count from cs_contact where contact_type in ('2','3','18','19') and id_credit=p_IdCredit;
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
            values(p_IdCredit,'HardCheck','*','TotalPhoneCount',v_Count,1,v_Seq+1);
       v_Seq:=v_Seq + 1;
       
       --一共提供了多少个家庭联系人电话
       select count(1) into v_Count from cs_contact 
       where person_type in(select reg_val_code from registers t where reg_number=265 and status='a' and reg_val_code!='1') and contact_type in('2','3','18','19') and id_credit=p_IdCredit;
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
            values(p_IdCredit,'HardCheck','*','TotalFamilyPhoneCount',v_Count,1,v_Seq+1);
       v_Seq:=v_Seq + 1;
       
       --一共提供了多少个其他联系人电话
       select count(1) into v_Count from cs_contact
       where person_type in(select reg_val_code from registers t where reg_number=396 and status='a') and contact_type in('2','3','18','19') and id_credit=p_IdCredit;
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
            values(p_IdCredit,'HardCheck','*','TotalOtherPhoneCount',v_Count,1,v_Seq+1);
       v_Seq:=v_Seq + 1;
       
       --一共提供了多少个家庭联系人电话和其他联系人中亲人的电话
       select count(1) into v_Count from cs_contact a 
       where a.contact_type in(2,3,18,19) 
        and a.person_type!='1'
        and (a.person_type in('BA','BB','BC','SA','SB','SC')
            or a.person_type in(select reg_val_code from registers b where b.reg_number=265))
        and a.id_credit=p_IdCredit;
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
            values(p_IdCredit,'HardCheck','*','TotalRelativePhoneCount',v_Count,1,v_Seq+1);
       v_Seq:=v_Seq + 1;
       
       --在HardCheck类别下面添加元素InterCodeRateSamePos。同一个门店再过去90天的内部代码(3,4)占总申请量的比率，status not in（‘t’,‘r’）;
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
       select p_IdCredit,'HardCheck','*','InterCodeRateSamePos',round(nvl(sum(decode(t.inter_code,3,1,4,1,0)),0)/decode(count(1),0,1,count(1)),6),1,v_Seq+1
       from cs_credit t 
       where t.status not in('t','r') and t.commit_time>=trunc(sysdate-90) and t.commit_time<=v_CommitTime and t.id_sellerplace=v_IdSellerPlace; 
       v_Seq:=v_Seq + 1;
       
       --在Credit类别下面添加元素SaFirstAppDate 销售第一张申请合同的时间，status not in（‘t’,‘r’）
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
       select p_IdCredit,'Credit','*','SaFirstAppDate',to_char(min(t.commit_time),'yyyy-MM-dd'),1,v_Seq+1
       from cs_credit t where t.status not in('t','r') and t.id_sa=v_IdSa; 
       v_Seq:=v_Seq + 1;
       
       --同一年龄下在过去3个月（<90天）的QQ平均长度
       insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
       select p_IdCredit,'HardCheck','*','Last3MonthQQAvgLen',round(nvl(sum(qq_length),0)/decode(count(1),0,1,count(1)),4),1,v_Seq+1
       from mv_qq_length@Dbl_Dafy_Sales.dafycredit t where t.birth_year=substr(v_Ident,7,4);
       /*from(
        select length(nvl(b.contact_value,0)) qq_length,substr(c.ident,7,4) birth_year
        from cs_credit a
        left join cs_contact b on b.id_credit=a.id and b.contact_type='13'
        join cs_person c on c.id=b.id_person
        where a.status!='r'and a.commit_time>=trunc(sysdate-90) and a.commit_time<trunc(sysdate)
       ) where birth_year=substr(v_Ident,7,4);*/
       v_Seq:=v_Seq + 1;
            
       --该客户上一单拒绝原因
       select nvl(max(id),0) into v_IdCredit from cs_credit t where id_person=v_IdPerson and t.id!=p_IdCredit and t.status='d';
       if v_IdCredit!=0 then 
         insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
         select p_IdCredit,'HardCheck','*','PreRejectReason',case when c.event is null then fun_get_reject_reason(a.id) else replace(replace(fun_getreg_value(779,nvl(c.event,-1)),'[',''),']','') end,1,v_Seq+1 
         from cs_credit a,wfi_final_decision c where a.id=c.id_credit(+) and a.id=v_IdCredit;
       end if;
       v_Seq:=v_Seq + 1; 

       for cs_exp in(select t.total_wk_exp,t.is_ssi,t.insurance_fee from cs_experience t where t.id_credit=p_IdCredit)
         loop
           --是否购买保险
           insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
           values(p_IdCredit,'Other','*','IsInsurance',cs_exp.is_ssi,1,v_Seq+1);
           v_Seq:=v_Seq + 1;
           
           --保险费用
           insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
           values(p_IdCredit,'Credit','*','InsuranceFee',cs_exp.insurance_fee,1,v_Seq+1);
           v_Seq:=v_Seq + 1;
           
           --距离毕业时间/现公司工作时间（月）
           insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
           values(p_IdCredit,'Career','*','CurrentMonth',cs_exp.total_wk_exp,1,v_Seq+1);
           v_Seq:=v_Seq + 1;
       end loop;
       /*鲁长江   2015-6-9*/
       select count(1) into v_Count from wechat_credit_address where id_credit=p_IdCredit;
       if v_Count>0 then        
          select current_address_city,current_city into v_CurrentAddressCity,v_CurrentCity
            from wechat_credit_address where rownum=1 and id_credit=p_IdCredit;
          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
           values(p_IdCredit,'Other','*','MobTrueCity',v_CurrentAddressCity,1,v_Seq+1);
          v_Seq:=v_Seq + 1;
          
          insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
           values(p_IdCredit,'Other','*','MobSelectCity',v_CurrentCity,1,v_Seq+1);
       end if;
       delete decision_element_data where id_credit=p_IdCredit and element_value is null;
       commit;

       p_ReturnCode:='A';
       return;
    exception
       When others Then
         error_info := sqlerrm;
         p_ReturnCode:='Z-'||error_info;
         rollback;
    end;

    -- Author  : wangxiaofeng
    -- Create Date : 2015-10-13
    -- Purpose : 腾讯反欺诈元素生成
    procedure prc_TencentAnti_Element(p_IdCredit    number,
                                      p_IdPerson    number,
                                      p_ReturnCode  out varchar2)
      is
      v_Count     number(5);
      error_info  varchar2(1000);
    begin
      select count(1) into v_Count from decision_element_data t where t.element_type='External' and t.element_sub_type='TencentAnti' and t.id_credit=p_IdCredit;
      if v_Count<=0 then
        --腾讯数据反欺诈评级
        insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
        select p_IdCredit,'External','TencentAnti','IdentAntiCheatRank',t.anticheat_rank,1,9999
        from tencent_ncheat_detailed t where t.type='identity' and t.id_person=p_IdPerson;
          
        insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
        select p_IdCredit,'External','TencentAnti','IdentRelaChainRank',t.relachain_rank,1,9999
        from tencent_ncheat_detailed t where t.type='identity' and t.id_person=p_IdPerson;
          
        insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
        select p_IdCredit,'External','TencentAnti','QQAntiCheatRank',t.anticheat_rank,1,9999
        from tencent_ncheat_detailed t where t.type='QQ' and t.id_person=p_IdPerson;
          
        insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
        select p_IdCredit,'External','TencentAnti','QQRelaChainRank',t.relachain_rank,1,9999
        from tencent_ncheat_detailed t where t.type='QQ' and t.id_person=p_IdPerson;
          
        insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
        select p_IdCredit,'External','TencentAnti','MobAntiCheatRank',t.anticheat_rank,1,9999
        from tencent_ncheat_detailed t where t.type='mobile' and t.id_person=p_IdPerson;
          
        insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
        select p_IdCredit,'External','TencentAnti','MobRelaChainRank',t.relachain_rank,1,9999
        from tencent_ncheat_detailed t where t.type='mobile' and t.id_person=p_IdPerson;
        
        commit;
      end if;
    exception
       When others Then
         error_info := sqlerrm;
         p_ReturnCode:='Z-'||error_info;
    end prc_TencentAnti_Element;

    -- Author  : wangxiaofeng
    -- Create Date : 2015-11-03
    -- Purpose : 腾讯征信报告元素生成
    procedure prc_TencentReport_Element(p_IdCredit    number,
                                        p_IdPerson    number,
                                        p_ReturnCode  out varchar2)
      is
      v_Count     number(5);
      error_info  varchar2(1000);
    begin
      select count(1) into v_Count from decision_element_data t 
      where t.element_type='External' and t.element_sub_type='TencentReport' and t.id_credit=p_IdCredit;
      if v_Count<=0 then
        for t in(select t.floan_balance,t.floan_unpay_cnt,t.floan_state,t.flast_dead_line,t.fdead_unpay_cnt 
                   from tencent_report t where t.id_person=p_IdPerson)
          loop
            insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
            values( p_IdCredit,'External','TencentReport','LoanBalance',t.floan_balance,1,9999);
            
            insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
            values( p_IdCredit,'External','TencentReport','LoanUnpayCount',t.floan_unpay_cnt,1,9999);
            
            insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
            values( p_IdCredit,'External','TencentReport','LoanState',t.floan_state,1,9999);
            
            insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
            values( p_IdCredit,'External','TencentReport','LastDeadLine',t.flast_dead_line,1,9999);
            
            insert into decision_element_data(id_credit,element_type,element_sub_type,element_name,element_value,value_index,seq)
            values( p_IdCredit,'External','TencentReport','DeadUnpayCount',t.fdead_unpay_cnt,1,9999);
          end loop;
          commit;
      end if; 
    exception
       When others Then
         error_info := sqlerrm;
         p_ReturnCode:='Z-'||error_info;
    end prc_TencentReport_Element;

    
end;
/

