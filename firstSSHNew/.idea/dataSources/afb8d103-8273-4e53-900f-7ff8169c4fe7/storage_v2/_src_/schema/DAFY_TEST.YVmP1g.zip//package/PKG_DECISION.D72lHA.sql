create package PKG_DECISION is

  -- Author  : 100009
  -- Create Date : 2014/10/8 14:36:22
  -- Purpose : Decision System

  -- Public type declarations
  function get_branchid(p_IdCredit cs_credit.id%type) return integer;

  -- Author  : Luchangjiang
  -- Create Date : 2014-10-12
  -- Purpose : Get Risk Group ID;
  function get_riskgroup(p_IdCredit cs_credit.id%type,p_BranchId decision_risk_group.branch_id%type,p_Stage decision_risk_group.stage%type) return integer;

  -- Author  : Luchangjiang
  -- Create Date : 2014-10-13
  -- Purpose : Get decision work flow id;
  function get_wfiid(p_IdCredit cs_credit.id%type,p_RiskGroup decision_wfi_selection.risk_group%type,
           p_BranchId decision_wfi_selection.branch_id%type,p_Stage decision_wfi_selection.stage%type) return integer;

  -- Author  : Luchangjiang
  -- Create Date : 2014-10-14
  -- Purpose : Get value type of element;
  function fun_get_element_valuetype(p_ElementType      decision_element_define.element_type%type,
                                      p_ElementSubType   decision_element_define.element_sub_type%type,
                                      p_ElementName      decision_element_define.element_name%type) return varchar2;

  -- Author  : Luchangjiang
  -- Create Date : 2014-10-15
  -- Purpose : check formula by data;
  function fun_check_formula_data(p_IdCredit cs_credit.id%type,p_Formula varchar2) return boolean;

  -- Author  : Luchangjiang
  -- Create Date : 2014-10-15
  -- Purpose : check formula with no data;
  -- used by verify formula where define it
  procedure prc_check_formula(p_Formula decision_risk_group.formula%type,p_ReturnCode out varchar2);
  
  -- Author  : Luchangjiang
  -- Create Date : 2014-10-16
  -- Purpose : put credit data into decision_element_data table;
  procedure prc_collect_element(p_IdCredit cs_credit.id%type,p_ReturnCode out varchar2);

end;


/

