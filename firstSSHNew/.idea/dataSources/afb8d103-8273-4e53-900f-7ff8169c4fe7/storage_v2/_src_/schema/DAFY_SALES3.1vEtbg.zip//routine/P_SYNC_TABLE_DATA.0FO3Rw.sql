create procedure p_sync_table_data(tablename in varchar2)
--该存储过程处理生产库到开发库的表数据同步需求
--该存储过程仅能对表进行处理，如果传入参数不是有效表名，则不会进行处理
--开发库和生产库的表结构如果相同，则只同步表数据；如果表结构不同，则删除开发库中表，重新同步表结构、数据，并重新创建索引
--开发库和生产库之间的数据传输依赖dblink，该dblink为开发库访问生产库，名称为dg0
as
--声明变量
  v_tablename        varchar2(50);          --接收传入的名称
  v_istable          integer;               --判断传入的名称是否为表名
begin
  --将传入的名称转换为大写字母
  v_tablename := upper(tablename);
  --查询传入名称是否为表名，只处理表数据的同步
  select count(*)
    into v_istable
    from user_objects
   where object_type = 'TABLE'
     and object_name = v_tablename;
  --当传入的名称为表名时，禁用该表上的外键约束和触发器，并将表修改为nologging模式
  if(v_istable>0) then
    --禁用该表上的外键约束
    p_disable_constraint(v_tablename);
    --禁用该表上的触发器
    p_disable_trigger(v_tablename);
    --将该表修改为nologging模式
    p_alter_table_nologging(v_tablename);
    --对比生产库和开发库中，该表结构是否有差异
    --如果表结构没有差异，可以直接重新插入数据
    if(f_contrast_table(v_tablename)=0) then 
      --清空表中现有数据
      p_truncate_table(v_tablename);
      --从生产库同步该表数据
      p_insert_into_table_from(v_tablename);
    --如果表结构有差异，则删除该表，通过重新创建表的方式从生产库同步数据
    else
      --删除表
      p_drop_table(v_tablename);
      --重新创建该表
      p_create_table_as(v_tablename);
      --创建该表上的索引
      p_create_index(v_tablename);
      --将新建的索引的并行度修改为1
      p_alter_index_parallel(v_tablename);
    --完成表的同步
    end if;
  --当传入的名称不为表时，不进行处理
  else
    return;
  end if;
    
end;
/

