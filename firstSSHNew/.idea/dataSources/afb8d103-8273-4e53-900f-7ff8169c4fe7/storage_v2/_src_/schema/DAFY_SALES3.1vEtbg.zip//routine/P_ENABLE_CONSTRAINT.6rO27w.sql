create procedure p_enable_constraint(tablename in varchar2)
--该存储过程用于启用表上的外键约束
as
  v_tablename varchar2(50);        --接收传入的表名
  v_sql       varchar2(1000);      --存放游标取得的SQL语句
  --将启用表上外键约束的语句赋予游标c_constraint
  cursor c_constraint is
    select 'alter table ' || table_name || ' enable constraint ' ||
           constraint_name
      from user_constraints
     where constraint_type = 'R'
       and table_name = v_tablename;
begin
  --将传入的表名转换为大写字母
  v_tablename := upper(tablename);
  --禁用该表上的外键约束
  open c_constraint;
    loop
      fetch c_constraint into v_sql;
      exit when c_constraint%notfound;
        execute immediate v_sql;
    end loop;
  close c_constraint;
end;
/

