create procedure p_create_index(tablename in varchar2)
--该存储过程用于创建表上的索引
 as
  v_tablename varchar2(50);     --接收传入的表名
  v_sql       varchar2(1000);   --存放游标取得的SQL语句
  --将创建索引的语句赋予游标c_createindex
  cursor c_createindex is
    select distinct c.idx_ddl
      from (select 'create index ' || a.index_name || ' on ' || a.table_name || '(' ||
                   b.idx_cols || ') parallel 4' as idx_ddl
              from user_ind_columns@dg0 a
              join (select distinct index_name,
                                   listagg(column_name, ',') within group(order by column_position) over(partition by index_name) as idx_cols
                     from user_ind_columns@dg0) b
                on a.index_name = b.index_name
             where a.table_name = v_tablename
             order by a.index_name) c;
begin
  --将传入的名称转换为大写字母
  v_tablename := upper(tablename);
  --创建该表上的索引
  open c_createindex;
  loop
    fetch c_createindex into v_sql;
    exit when c_createindex%notfound;
      execute immediate v_sql;
  end loop;
  close c_createindex;
end;
/

