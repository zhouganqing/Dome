create procedure p_disable_trigger(tablename in varchar2)
--该存储过程用于禁用表上的触发器
 as
  v_tablename varchar2(50);     --接收传入的表名
  v_sql       varchar2(1000);   --存放游标取得的SQL语句
  --将禁用表上触发器的语句赋予游标c_trigger
  cursor c_trigger is
  select 'alter trigger ' || trigger_name || ' disable' from user_triggers
   where table_name = v_tablename;
begin
  --将传入的名称转换为大写字母
  v_tablename := upper(tablename);
  --禁用该表上的触发器
  open c_trigger;
  loop
    fetch c_trigger into v_sql;
    exit when c_trigger%notfound;
      execute immediate v_sql;
  end loop;
  close c_trigger;
end;
/

