create procedure p_alter_table_nologging(tablename in varchar2)
--该存储过程用于将表修改为nologging模式
 as
  v_tablename varchar2(50);     --接收传入的表名
  v_sql       varchar2(1000);   --存放游标取得的SQL语句
  --将修改表为nologging模式的语句赋予游标c_nologging
  cursor c_nologging is
    select 'alter table ' || table_name || ' nologging'
      from user_tables
     where table_name = v_tablename;
begin
  --将传入的名称转换为大写字母
  v_tablename := upper(tablename);
  --将该表修改为nologging模式
  open c_nologging;
  loop
    fetch c_nologging into v_sql;
    exit when c_nologging%notfound;
    execute immediate v_sql;
  end loop;
  close c_nologging;
end;
/

