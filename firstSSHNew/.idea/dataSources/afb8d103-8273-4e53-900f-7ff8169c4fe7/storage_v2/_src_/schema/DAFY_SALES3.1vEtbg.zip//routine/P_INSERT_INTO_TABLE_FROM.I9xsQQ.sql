create procedure p_insert_into_table_from(tablename in varchar2)
--该存储过程用于将生产库中表的数据同步到开发库表中
 as
  v_tablename varchar2(50);     --接收传入的表名
  v_sql       varchar2(1000);   --存放游标取得的SQL语句
  --将同步表数据的语句赋予游标c_insert
  cursor c_insert is
    select 'insert /*+ parallel(t,4),append nologging */ into ' ||
           table_name || ' t select * from ' || table_name || '@dg0'
      from user_tables
     where table_name = v_tablename;
begin
  --将传入的名称转换为大写字母
  v_tablename := upper(tablename);
  --从生产库同步该表数据
  open c_insert;
  loop
    fetch c_insert into v_sql;
    exit when c_insert%notfound;
      execute immediate v_sql;
      execute immediate 'commit';
  end loop;
  close c_insert;
end;
/

