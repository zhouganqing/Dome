create package htmldb_lang
--  Copyright (c) Oracle Corporation 2003. All Rights Reserved.
--
--    DESCRIPTION
--      globalization services
--
--    NOTES
--      This program allows for translation of text strings from
--      on national language to another.
--
--    RUNTIME DEPLOYMENT: YES
is

function message (
    -- Function to return a message from the message repository.
    --
    -- p_name           - name of message to be printed
    -- p0 - p9          - substitution parameters that replace text srings
    --                    %0 through %9
    -- p_lang           - optional parameter to override the language
    -- p_application_id - optional parameter for a specific application ID instead of the current one
    --
    p_name                      in varchar2 default null,
    p0                          in varchar2 default null,
    p1                          in varchar2 default null,
    p2                          in varchar2 default null,
    p3                          in varchar2 default null,
    p4                          in varchar2 default null,
    p5                          in varchar2 default null,
    p6                          in varchar2 default null,
    p7                          in varchar2 default null,
    p8                          in varchar2 default null,
    p9                          in varchar2 default null,
    p_lang                      in varchar2 default null,
    p_application_id            in number default null)
    return varchar2
    ;



procedure message_p (
    -- Print a message from the message repository.
    --
    -- p_name           - name of message to be printed
    -- p0 - p9          - substitution parameters that replace text srings
    --                    %0 through %9
    -- p_lang           - optional parameter to override the language
    -- p_application_id - optional parameter for a specific application ID instead of the current one
    --
    p_name                      in varchar2 default null,
    p0                          in varchar2 default null,
    p1                          in varchar2 default null,
    p2                          in varchar2 default null,
    p3                          in varchar2 default null,
    p4                          in varchar2 default null,
    p5                          in varchar2 default null,
    p6                          in varchar2 default null,
    p7                          in varchar2 default null,
    p8                          in varchar2 default null,
    p9                          in varchar2 default null,
    p_lang                      in varchar2 default null,
    p_application_id            in number   default null)
    ;


function lang (
   -- Return a translated text string from the
   -- translatable messages repository within HTMLDB.
   --
   -- p_primary_text_string - text string to be translated
   -- p0 - p9  - substitution parameters that replace text srings
   --            %0 through %9
   -- p_primary_text_context-
   -- p_primary_language    -
   --
   p_primary_text_string       in varchar2 default null,
   p0                          in varchar2 default null,
   p1                          in varchar2 default null,
   p2                          in varchar2 default null,
   p3                          in varchar2 default null,
   p4                          in varchar2 default null,
   p5                          in varchar2 default null,
   p6                          in varchar2 default null,
   p7                          in varchar2 default null,
   p8                          in varchar2 default null,
   p9                          in varchar2 default null,
   p_primary_language          in varchar2 default null)
   return varchar2
   ;


procedure create_message(
    --
    -- Create a runtime message
    --
    p_application_id in number,
    p_name           in varchar2,
    p_language       in varchar2,
    p_message_text   in varchar2 )
    ;

procedure update_message(
    --
    -- Update a text message specified by ID
    --
    p_id           in number,
    p_message_text in varchar2 );

procedure delete_message(
    --
    -- Delete a runtime message
    --
    p_id in number );


procedure update_translated_string(
    --
    -- Update the string in the translation repository
    --
    p_id       in number,
    p_language in varchar2,
    p_string   in varchar2);


procedure seed_translations(
    --
    -- Seed the translation repository for the specified application
    -- and language.
    --
    p_application_id in number,
    p_language       in varchar2 );

procedure create_language_mapping(
    --
    -- Create a language mapping for the specified application.  A mapping
    -- includes the target application ID and also the language code (e.g., de, en-us, etc.)
    --
    p_application_id             in number,
    p_language                   in varchar2,
    p_translation_application_id in number);


procedure update_language_mapping(
    --
    -- Update the mapping for specified application and language.  Only the mapping to the new translation
    -- ID can be updated.  The language cannot be updated.
    --
    p_application_id             in number,
    p_language                   in varchar2,
    p_new_trans_application_id   in number);


procedure delete_language_mapping(
    --
    -- Delete a language mapping for the specified application and language.
    --
    p_application_id in number,
    p_language       in varchar2);


procedure publish_application(
    --
    -- Publish the translations of an application.  You can optionally specify
    -- a new application ID for the specific translation mapping.
    --
    p_application_id           in number,
    p_language                 in varchar2,
    p_new_trans_application_id in number default null );


end htmldb_lang;
/

