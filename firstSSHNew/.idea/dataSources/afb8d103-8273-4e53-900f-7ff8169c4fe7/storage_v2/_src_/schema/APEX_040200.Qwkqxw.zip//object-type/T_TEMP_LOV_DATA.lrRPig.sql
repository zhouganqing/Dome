create type t_temp_lov_data is table of t_temp_lov_value
/

