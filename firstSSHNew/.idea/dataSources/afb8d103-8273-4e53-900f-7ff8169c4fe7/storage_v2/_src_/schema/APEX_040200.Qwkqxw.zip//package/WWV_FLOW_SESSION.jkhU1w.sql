create package wwv_flow_session
as
--------------------------------------------------------------------------------
--
--  Copyright (c) Oracle Corporation 2011. All Rights Reserved.
--
--    NAME
--      wwv_flow_session.sql
--
--    DESCRIPTION
--      This package is resonsible for session management
--
--    RUNTIME DEPLOYMENT: YES
--
--    MODIFIED   (MM/DD/YYYY)
--    cneumuel    04/14/2011 - Created
--    cneumuel    05/18/2011 - Added get_builder_cookie_name, get_by_cookie_name, builtin_cookie_sentry, removed get_by_hashed_id
--    cneumuel    10/25/2011 - Added update_security_group_id (bug #13101596)
--    cneumuel    12/22/2011 - Added global item state handling (bug #13528522)
--    cneumuel    02/10/2012 - Added generate_unique_hashed_id,update_hashed_id (bug #13707875)
--    cneumuel    04/05/2012 - Moved is_global_item_name,set_global_item_value,get_global_item_value to wwv_flow_session_state (feature #897)
--    cneumuel    04/05/2012 - Moved wwv_flow_data handling code to wwv_flow_session_state (feature #897)
--    cneumuel    05/09/2012 - Removed dead code: update_cookie_session_id
--    cneumuel    05/31/2012 - Added get_builder_session_id
--    cneumuel    06/04/2012 - Moved c_session_time_item_name to spec
--
--------------------------------------------------------------------------------
--
subtype t_session_record is wwv_flow_sessions$%rowtype;
--
x_session_does_not_exist exception;

--==============================================================================
-- name for global session item that contains session meta-information
c_session_time_item_name constant varchar2(30) := 'FSP_SESSION_TIME';
--
--
--==============================================================================
-- return the cookie name used for builder authentication
--==============================================================================
function get_builder_cookie_name
    return varchar2;
--
--==============================================================================
-- return the session id of the builder session if the user is logged in to
-- the builder with the same workspace
--==============================================================================
function get_builder_session_id
    return number;
--
--==============================================================================
-- return if a session record exists for the current g_instance. If
-- p_check_sgid is true then the returned session has to have the current
-- security group id set.
--==============================================================================
function is_existing (
    p_check_sgid in boolean default false )
    return boolean;
--
--==============================================================================
-- return the current session's session_id_hashed
--==============================================================================
function get_hashed_id
    return varchar2;
--
--==============================================================================
-- return the current session by g_instance or an empty record if g_instance is
-- not a valid session id. If p_check_sgid is true then the returned session
-- has to have the current security group id set.
--==============================================================================
function get_current (
    p_check_sgid in boolean default false )
    return t_session_record;
--
--==============================================================================
-- return the session by reading the cookie or an empty record.
--==============================================================================
function get_by_cookie_name (
    p_cookie_name          in varchar2 )
    return t_session_record;
--
--==============================================================================
-- try to establish a valid session and user by comparing the given cookie's
-- values with the current session id. if that fails, compare with the builder
-- cookie's values.
--
-- this is the core of the default session sentry if nothing else is specified
-- in the authentication scheme.
--
-- on success, this sets
--   - wwv_flow.g_instance
--   - wwv_flow_security.g_instance
--   - wwv_flow.g_user
--==============================================================================
function builtin_cookie_sentry (
    p_cookie_name          in varchar2 )
    return boolean;
--
--
--
--==============================================================================
-- generate a new unique session id
--==============================================================================
function generate_unique_session_id
    return number;
--
--==============================================================================
-- generate a new unique value for the session cookie
--==============================================================================
function generate_unique_hashed_id
    return varchar2;
--
--==============================================================================
-- create a new session
--==============================================================================
procedure create_new (
    p_generate_id             in boolean  default true,
    p_save_new_instance_fired in boolean  default false,
    p_cookie_session_id       in varchar2 default null );
--
--==============================================================================
-- try to attach to the current session/g_instance, if security group id and
-- user match.
--
-- returns:
--   - true if session can be used
--   - false if session can not be used
--==============================================================================
--function can_reuse_session
--    return boolean;
procedure create_or_reuse_session (
    p_raise_error_if_not_exists in boolean default false );
--
--
--
--==============================================================================
-- deletes session with id p_id
--==============================================================================
procedure delete_session (
    p_id in number default wwv_flow_security.g_instance);
--
--
--
--==============================================================================
-- saves p_username into wwv_flow_sessions$.cookie for the current session id.
-- raises x_session_does_not_exist if session record for current g_instance and
-- g_security_group_id does not exit.
--==============================================================================
procedure update_user (
    p_new_username in varchar2 );
--
--==============================================================================
-- saves p_new_security_group_id into wwv_flow_sessions$.security_group_id for
-- the current session id. raises x_session_does_not_exist if session record
-- for current g_instance and g_security_group_id does not exit.
--==============================================================================
procedure update_security_group_id (
    p_new_security_group_id in number );
--
--==============================================================================
-- creates a new session_id_hashed and saves it in the current session.
-- a new hashed id is required after login, to avoid session fixation problems.
--==============================================================================
function update_hashed_id
    return varchar2;
--
--==============================================================================
-- overwrites user, workspace and cookie_session_id in current session. to be
-- used in wwv_flow_login (builder login).
-- raises x_session_does_not_exist if session record for current g_instance does not exist.
--==============================================================================
procedure reuse_for_different_workspace (
    p_new_username          in varchar2,
    p_new_security_group_id in number,
    p_new_cookie_session_id in varchar2,
    p_old_security_group_id in number default wwv_flow_security.g_security_group_id );
--
--==============================================================================
-- add current application to on_new_instance_fired_for of current session
--==============================================================================
procedure set_session_fired_for_flow;
--
--==============================================================================
-- remove current application to on_new_instance_fired_for of current session
--==============================================================================
procedure unset_session_fired_for_flow (
    p_flow_id in varchar2 default null );

--==============================================================================
-- see apex_util.set_session_lifetime_seconds
--==============================================================================
procedure set_session_lifetime_seconds(
    p_seconds in number );

--==============================================================================
-- see apex_util.set_session_max_idle_seconds
--==============================================================================
procedure set_session_max_idle_seconds(
    p_seconds  in number );
--
--==============================================================================
-- Check for session timeout if application gets executed via "show", based on
-- 1. maximum allowed session life
-- 2. maximum allowed session idle time
--==============================================================================
procedure check_session_timeout_show;
--
--==============================================================================
-- Check for session timeout if application gets executed via "accept", based on
-- 1. maximum allowed session life
-- 2. maximum allowed session idle time
--==============================================================================
procedure check_session_timeout_accept;

end wwv_flow_session;
/

