create package wwv_flow_pkg_app_ui
is


function get_data (p_str               varchar2,
                   p_lang              varchar2 default 'en',
                   p_system_message    varchar2 default null,
                   p_escape            boolean  default true,
                   p_app_id            varchar2 default null,
                   p_alternate_message varchar2 default null)
                   return varchar2;

procedure p50_applications (
    p_app_id         in number,
    p_app_page_id    in number,
    p_app_session    in number,
    p_app_category   in varchar2 default null,
    p_app_type       in varchar2 default null
    );

procedure p81_app_detail (
    p_app_id       in number,
    p_app_session  in number,
    p_pkg_app_id   in number default null,
    p_app_type     in varchar2 default null
    );

end wwv_flow_pkg_app_ui;
/

