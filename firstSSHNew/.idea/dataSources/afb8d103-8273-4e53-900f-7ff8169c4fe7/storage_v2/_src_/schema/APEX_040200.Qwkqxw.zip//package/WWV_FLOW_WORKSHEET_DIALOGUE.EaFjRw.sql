create package wwv_flow_worksheet_dialogue
as


function get_sql_functions return vc4000Array;

function get_row_filter_operators return vc4000Array;

function get_pseudo_column_label (
    p_db_column_name in varchar2) return varchar2;



procedure get_column_list (
    p_worksheet_id      in number,
    p_app_user          in varchar2,
    p_report_id         in varchar2,
    p_type              in varchar2 default null,
    p_display_pseudo_column in varchar2 default 'Y',
    p_column_label      out wwv_flow_global.vc_arr2,
    p_db_column_name    out wwv_flow_global.vc_arr2,
    p_is_displayed      out wwv_flow_global.vc_arr2,
    p_group_id          out wwv_flow_global.vc_arr2,
    p_column_type       out wwv_flow_global.vc_arr2,
    p_column_category   out wwv_flow_global.vc_arr2,
    p_rows              out number);

procedure print_button (
    p_worksheet_id in number default null,
    p_cancel       in varchar2 default null,
    p_delete       in varchar2 default null,
    p_apply        in varchar2 default null,
    p_add          in varchar2 default null,
    p_apply_label  in varchar2 default null,
    p_add_label    in varchar2 default null
    );

procedure print_button2 (
    p_worksheet_id in number default null,
    p_cancel       in varchar2 default null,
    p_delete       in varchar2 default null,
    p_reset        in varchar2 default null,
    p_apply        in varchar2 default null,
    p_add          in varchar2 default null,
    p_delete_label in varchar2 default null,
    p_reset_label  in varchar2 default null,
    p_apply_label  in varchar2 default null,
    p_add_label    in varchar2 default null
    );

procedure print_column_lov (
    p_worksheet_id            in number,
    p_base_report_id          in number,
    p_derived_report_id       in number,
    p_app_user                in varchar2,
    p_report_columns          in varchar2 default null,
    p_selected_column         in varchar2 default null,
    p_column_type             in varchar2 default null,
    p_dialog_type             in varchar2 default null,
    p_display_computed_column in varchar2 default 'Y',
    p_display_null            in varchar2 default 'Y',
    p_display_pseudo_column   in varchar2 default 'Y',
    p_include_class           in varchar2 default 'N'
    );

procedure show_format_mask (
    p_worksheet_id in number,
    p_app_user     in varchar2,
    p_report_id    in varchar2);

procedure show_column_list (
    p_worksheet_id in number,
    p_app_user     in varchar2,
    p_report_id    in varchar2,
    p_column_type  in varchar2 default null);

procedure show_select_columns (
    p_worksheet_id in number,
    p_app_user     in varchar2,
    p_report_id    in varchar2);

procedure save_column_list (
    p_worksheet_id in number,
    p_app_user     in varchar2,
    p_report_id    in varchar2,
    p_column_list  in wwv_flow_global.vc_arr2);

procedure show_highlight (
    p_worksheet_id in number,
    p_app_user     in varchar2,
    p_report_id    in number,
    p_condition_id in varchar2 default null);

procedure show_filter (
    p_worksheet_id in number,
    p_app_user     in varchar2,
    p_report_id    in number,
    p_condition_id in varchar2 default null);

procedure show_ordering (
    p_worksheet_id in number,
    p_app_user     in varchar2,
    p_report_id    in number);

procedure show_group_by_sort (
    p_worksheet_id      in number,
    p_report_id         in number,
    p_app_user          in varchar2
    );

procedure show_save (
    p_worksheet_id in number,
    p_app_user     in varchar2,
    p_report_id    in number,
    p_save_type    in varchar2 default 'SAVE');

procedure show_save_default (
    p_worksheet_id in number,
    p_app_user     in varchar2,
    p_report_id    in number,
    p_save_type    in varchar2 default 'SAVE');

procedure show_chart (
    p_worksheet_id in number,
    p_app_user     in varchar2,
    p_report_id    in number);

procedure show_calendar (
    p_worksheet_id in number,
    p_app_user     in varchar2,
    p_report_id    in number);

procedure show_delete (
    p_worksheet_id in number,
    p_app_user     in varchar2,
    p_report_id    in number,
    p_is_default   in varchar2 default 'N');

procedure show_aggregate (
    p_worksheet_id in number,
    p_app_user     in varchar2,
    p_report_id    in number,
    p_aggregate    in varchar2 default null);

procedure show_flashback (
    p_worksheet_id in number,
    p_app_user     in varchar2,
    p_report_id    in number);

procedure show_reset (
    p_worksheet_id in number,
    p_app_user     in varchar2,
    p_report_id    in number);

procedure show_computation (
    p_worksheet_id   in number,
    p_app_user       in varchar2,
    p_report_id      in number,
    p_computation_id in varchar2 default null);

procedure show_download (
    p_worksheet_id in number,
    p_app_user     in varchar2,
    p_report_id    in number);

procedure show_control_break (
    p_worksheet_id in number,
    p_app_user     in varchar2,
    p_report_id    in number);

procedure show_group_by (
    p_worksheet_id in number,
    p_app_user     in varchar2,
    p_report_id    in number,
    p_group_by_id  in number default null);

procedure show_notify (
    p_worksheet_id  in number,
    p_app_user      in varchar2,
    p_report_id     in number
    );
end  wwv_flow_worksheet_dialogue;
/

