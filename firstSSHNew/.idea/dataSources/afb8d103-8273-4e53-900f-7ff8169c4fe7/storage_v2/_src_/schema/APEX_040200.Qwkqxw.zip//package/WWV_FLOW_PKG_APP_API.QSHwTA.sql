create package wwv_flow_pkg_app_api
as
--------------------------------------------------------------------------------
--
--  Copyright (c) Oracle Corporation 1999 - 2012. All Rights Reserved.
--
--    NAME
--      wwv_flow_pkg_app_api.plb
--
--    DESCRIPTION
--      Exports all Packaged Application related data of a workspace.
--
--    RUNTIME DEPLOYMENT: NO
--    PUBLIC:             NO
--
--    MODIFIED   (MM/DD/YYYY)
--    hfarrell    05/25/2012 - Created
--
--------------------------------------------------------------------------------

--
-- Export data of Packaged Applications from the INTERNAL workspace into
-- a SQL script with all settings for SQL*Plus.
-- p_format can be DOS or UNIX.
--
procedure export_script (
    p_format  in varchar2 default 'UNIX',
    p_version in varchar2 default null);

--
-- Export data of all Packaged Application components in INTERNAL workspace.
-- p_format can be DOS or UNIX.
--
procedure export (
    p_format in varchar2 default 'UNIX' );

end wwv_flow_pkg_app_api;
/

