create package wwv_flow_region_api
as
--------------------------------------------------------------------------------
--
--  Copyright (c) Oracle Corporation 2012. All Rights Reserved.
--
--    NAME
--      wwv_flow_region_api.sql
--
--    DESCRIPTION
--      This package is the public API for handling regions.
--
--    MODIFIED   (MM/DD/YYYY)
--      pawolf    04/12/2012 - Created
--
--------------------------------------------------------------------------------

--==============================================================================
-- Global types
--==============================================================================


--==============================================================================
-- Global constants
--==============================================================================


--==============================================================================
-- Global variables
--==============================================================================


--==============================================================================
-- Returns TRUE if the current region is rendered read only and FALSE if not.
-- If the function is called from a context where no region is currently
-- processed it will return NULL.
--==============================================================================
function is_read_only return boolean;

--==============================================================================
-- Purge the region cache of the specified application, page and region.
--
-- Parameters:
--   p_application_id Id of the application where the region caches should be purged.
--   p_page_id        Id of the page where the region caches should be purged.
--                    If no value is specified all regions of the specified application
--                    will be purged.
--   p_region_id      Id of a specific region on a page which should be purged.
--                    If no value is specified all regions of the specified page
--                    will be purged.
--==============================================================================
procedure purge_cache (
    p_application_id in number,
    p_page_id        in number default null,
    p_region_id      in number default null );

--
end wwv_flow_region_api;
/

