create package wwv_flow_page_api
as
--------------------------------------------------------------------------------
--
--  Copyright (c) Oracle Corporation 2012. All Rights Reserved.
--
--    NAME
--      wwv_flow_page_api.sql
--
--    DESCRIPTION
--      This package is the public API for handling pages.
--
--    MODIFIED   (MM/DD/YYYY)
--      pawolf    02/29/2012 - Created
--      pawolf    04/12/2012 - Added is_read_only
--
--------------------------------------------------------------------------------

--==============================================================================
-- Global types
--==============================================================================


--==============================================================================
-- Global constants
--==============================================================================
c_ui_type_desktop    constant varchar2(10) := 'DESKTOP';
c_ui_type_smartphone constant varchar2(10) := 'SMARTPHONE';
c_ui_type_tablet     constant varchar2(10) := 'TABLET';

--==============================================================================
-- Global variables
--==============================================================================


--==============================================================================
-- Returns TRUE if the current page has been designed for Desktop browsers.
--==============================================================================
function is_desktop_ui return boolean;
--
--==============================================================================
-- Returns TRUE if the current page has been designed for smartphone devices
-- using jQuery Mobile.
--==============================================================================
function is_jqm_smartphone_ui return boolean;
--
--==============================================================================
-- Returns TRUE if the current page has been designed for tablet devices
-- using jQuery Mobile.
--==============================================================================
function is_jqm_tablet_ui return boolean;
--
--==============================================================================
-- Returns the UI type for which the current page has been designed for.
--==============================================================================
function get_ui_type return varchar2;

--==============================================================================
-- Returns TRUE if the current page is rendered read only and FALSE if not.
--==============================================================================
function is_read_only return boolean;
--
--==============================================================================
-- Purge the cache of the specified application, page and optional for
-- the specified user. If the user isn't specified, all cached versions of
-- that page are purged.
--==============================================================================
procedure purge_cache (
    p_application_id in number,
    p_page_id        in number,
    p_user_name      in varchar2 default null );
--
end wwv_flow_page_api;
/

