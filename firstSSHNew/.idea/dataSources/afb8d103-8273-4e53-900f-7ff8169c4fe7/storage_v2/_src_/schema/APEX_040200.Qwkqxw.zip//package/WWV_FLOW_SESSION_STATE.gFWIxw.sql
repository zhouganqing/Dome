create package wwv_flow_session_state as
--------------------------------------------------------------------------------
--
--  Copyright (c) Oracle Corporation 1999 - 2012. All Rights Reserved.
--
--    NAME
--      wwv_flow_session_state.sql
--
--    DESCRIPTION
--      This package encapsulates all access to session state (wwv_flow_data)
--
--    RUNTIME DEPLOYMENT: NO
--    PUBLIC:             NO
--
--    MODIFIED   (MM/DD/YYYY)
--    cneumuel    04/05/2012 - Created
--    cneumuel    04/10/2012 - Added get_deferred_session_val_id for wwv_flow_item (feature #897)
--    cneumuel    04/12/2012 - Added clear_state_for_id,clear_all_state_for_id
--    cneumuel    04/12/2012 - Added initialize_all_page_items, clear_all_state_for_name
--    cneumuel    05/24/2012 - Renamed save to save_by_id, added save, save_by_name,
--                             has_component_value, set_component_values, get_component_values, clear_component_values,
--                             set_substitution_cache_byname, set_substitution_cache, replace_substitution_names, v,
--                             renamed fetch_flow_item to get_item_value (feature #940)
--    cneumuel    06/01/2012 - Added get_global_item_id, added p_item_scope to save_nocache (feature #897)
--    cneumuel    08/01/2012 - Added do_hash_substitutions: #xxx# substitution for wwv_flow.do_substitutions (bug #14399765)
--    cneumuel    08/06/2012 - In do_hash_substitutions: add p_start_pos. replace #MIN#, #APP_VERSION#, #APEX_VERSION#
--
--------------------------------------------------------------------------------

c_deep_link_item_name constant varchar2(4000) := 'FSP_AFTER_LOGIN_URL';

--==============================================================================
-- helper for wwv_flow.clear_page_cache
--
-- Reset all cached items for a given page to null
--==============================================================================
procedure clear_state_for_page (
    p_page_id in number default null);

--==============================================================================
-- For the current session remove session state for the given flow.  Requires
-- wwv_flow_security.g_instance to be set to the current session.
--==============================================================================
procedure clear_state_for_application (
    p_application_id in varchar2 );

--==============================================================================
-- ...
--==============================================================================
procedure clear_state_for_user;

--==============================================================================
-- remove session state by item id in the current session
--==============================================================================
procedure clear_state_for_id (
    p_item_id        in number );

--==============================================================================
-- remove session state by item id, for all sessions
--==============================================================================
procedure clear_all_state_for_id (
    p_item_id        in number,
    p_application_id in number default wwv_flow_security.g_flow_id );

--==============================================================================
-- remove session state by item name, for all sessions
--==============================================================================
procedure clear_all_state_for_name (
    p_item_name      in varchar2,
    p_application_id in number default wwv_flow_security.g_flow_id );

--==============================================================================
-- wwv_flow_process: INITIALIZE_ALL_PAGE_ITEMS (possibly obsolete)
--==============================================================================
procedure initialize_all_page_items;

--==============================================================================
-- ...
--==============================================================================
procedure save_deferred_session_vals;
--==============================================================================
-- ...
--==============================================================================
function get_deferred_session_val_id (
    p_string in varchar2 )
    return number;

--==============================================================================
-- return if p_item_name is the name of a global item
--==============================================================================
function is_builtin_global_item_name (
    p_item_name in varchar2 )
    return boolean;

--==============================================================================
-- Set global session state (i.e. independent of application, e.g. deep link)
--==============================================================================
procedure set_builtin_global_item_value (
    p_item_name in varchar2,
    p_value     in varchar2,
    p_do_update in boolean default false );

--==============================================================================
-- Get "id" for global session state item
--==============================================================================
function get_global_item_id (
    p_item_name in varchar2 )
    return number;

--==============================================================================
-- Get global session state (i.e. independent of application, e.g. deep link)
--==============================================================================
function get_builtin_global_item_value (
    p_item_name         in varchar2,
    p_session_id        in number default wwv_flow_security.g_instance )
    return varchar2;

--==============================================================================
-- Save item to session state (ignoring the substitution cache) and commit
--==============================================================================
procedure save_nocache (
    p_item_id        in number,
    p_item_scope     in wwv_flow_meta_data.t_item_scope,
    p_item_name      in varchar2,
    p_item_value     in varchar2,
    p_item_filter    in varchar2 default 'N',
    p_is_encrypted   in varchar2 default 'N',
    p_application_id in number   default wwv_flow_security.g_flow_id,
    p_do_update      in boolean  default false );

--==============================================================================
-- Save session state to plsql memory cache and database.
--
-- item             = application or page item
-- item_value       = value of item to be stored as session state
-- p_external_input = if true, escape input
--==============================================================================
procedure save (
    p_item              in wwv_flow_meta_data.t_item_properties,
    p_item_value        in varchar2,
    p_external_input    in boolean );

--==============================================================================
-- Save session state to plsql memory cache and database.
--
-- item_id    = id of application or page item
-- item_value = value of item to be stored as session state
--==============================================================================
procedure save_by_id (
    p_item_id           in number,
    p_item_value        in varchar2 );

--==============================================================================
-- Save session state to plsql memory cache and database.
--
-- item_name  = name of application or page item
-- item_value = value of item to be stored as session state
--==============================================================================
procedure save_by_name (
    p_item_name         in varchar2,
    p_item_value        in varchar2 );

--==============================================================================
-- Return if p_name is part of the component value map
--==============================================================================
function has_component_value (
    p_name in varchar2 )
    return boolean;

--==============================================================================
-- Sets the component specific values which can then be used as bind variables,
-- substitution values, ...
-- p_value_map is index by the uppercase column names of the component.
--
-- Note: Always call clear_component_values after a row of your component has
--       been processed to make sure that these values are not accidentially
--       used outside your component. Don't forget about the exception handler!!
--==============================================================================
procedure set_component_values (
    p_value_map in wwv_flow_global.vc_map );

--==============================================================================
-- Returns the component specific values. These values can change if the bind
-- variable was used as an assignment target.
-- p_value_map is index by the uppercase column names of the component.
--==============================================================================
function get_component_values
    return wwv_flow_global.vc_map;

--==============================================================================
-- Clears the component specific values which can then be used as bind variables,
-- substitution values, ...
--
-- This procedure should always be called after a row of your component has
-- been processed to make sure that these values are not accidentially
-- used outside your component. Don't forget about the exception handler to call
-- this procedure there as well!!
--==============================================================================
procedure clear_component_values;

--==============================================================================
-- Update the cache of session state maintained in a pl/sql table.
--
-- p_name      = name of the application or page item
-- p_value     = Session state value for the item
--==============================================================================
procedure set_substitution_cache_byname (
    p_name       in varchar2,
    p_value      in varchar2 );

--==============================================================================
-- Update the cache of session state maintained in a pl/sql table.
-- This procedure does not write the change to disk.
--
-- p_id        = ID of the application or page item
-- p_value     = Session state value for the item
-- p_name      = name of the application or page item
-- p_filter    = filter value of the item (escape on http output)
-- p_encrypted = encrypted (Y/N) flag of the item
--==============================================================================
procedure set_substitution_cache (
    p_id         in number,
    p_value      in varchar2,
    p_name       in varchar2 default null,
    p_filter     in varchar2 default null,
    p_encrypted  in varchar2 default null );

--==============================================================================
-- fetch all of the application's session state into the substitution cache,
-- i.e. the wwv_flow.g_substitution_item% variables.
--==============================================================================
procedure fetch_into_substitution_cache (
    p_exact_substitutions_only in boolean );

--==============================================================================
-- replace substitution names in p_str
--
-- part of do_substitutions
--==============================================================================
procedure do_cache_substitutions (
    p_str    in out nocopy varchar2,
    p_escape in boolean );

--==============================================================================
-- replace generic #xxx# values in p_str
--
-- part of do_substitutions, but can also be used to replace the xxxIMAGExxx
-- and xxxOWNERxxx values.
--==============================================================================
procedure do_hash_substitutions (
    p_str       in out nocopy varchar2,
    p_start_pos in binary_integer default null );

--==============================================================================
-- return flow value (formerly stand-alone v function)
--
-- This program allows you to reference flow variables using
-- v('FLOW_VAR') syntax.  This prevents the shared pool from
-- filling up and running out of enqueues when running with
-- large numbers of concurrent users.
--
-- p_item_id  = Case insensitive name of the item for which you
--              wish to have the session state fetched.
-- p_flow     = Identifies the flow ID
-- p_scope    = Valid values are "SESSION_AND_USER" and "SESSION"
--              SESSION_AND_USER will look in session state in both
--              the session cache and in the user cache.
--              SESSION will look only in the session cache and will
--              omit looking for this value in the user cache.
--              SESSION caching is caching of session state of an
--              item value for a flows session.  User caching is
--              the caching of an item value for a user over all
--              sessions for that user.
--==============================================================================
function v (
    p_item   in varchar2,
    p_flow   in number   default null,
    p_scope  in varchar2 default 'SESSION_AND_USER',
    p_escape in varchar2 default 'N')
    return varchar2;

--==============================================================================
-- Given a flow-level item name, locate item in current or specified
-- application and current or specified session and return item value.
--
--
-- Security:
--    Caller must be a package,procedure, or function whose
--    owner can be identified by owa_util.who_called_me.
--    This owner will be used to find the security_group_id
--    associated with that schema.
--==============================================================================
function get_item_value (
    p_item         in varchar2,
    p_flow         in number default wwv_flow_security.g_flow_id,
    p_instance     in number default wwv_flow_security.g_instance )
    return varchar2;

--==============================================================================
-- internal helper routine to get an item value by item_id
--==============================================================================
function fetch_value_by_id (
    p_item_id     in number )
    return varchar2;

--==============================================================================
-- internal helper routine to get a numeric item value by item_id
--==============================================================================
function fetch_num_value_by_id (
    p_item_id in number )
    return number;

--==============================================================================
-- internal helper routine to return the changed status
-- (wwv_flow_data.session_state_status)
--==============================================================================
function get_status (
    p_item_properties in wwv_flow_meta_data.t_item_properties )
    return wwv_flow_data.session_state_status%type;

--==============================================================================
-- internal helper routine to return if any session_state_status is 'U'
-- if p_application_id is null, the application id is ignored
--==============================================================================
function is_status_changed (
    p_application_id in number )
    return boolean;

end wwv_flow_session_state;
/

