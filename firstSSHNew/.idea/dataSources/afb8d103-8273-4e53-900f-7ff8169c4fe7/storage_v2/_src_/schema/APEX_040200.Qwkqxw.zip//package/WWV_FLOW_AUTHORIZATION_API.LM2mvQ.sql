create package wwv_flow_authorization_api as
--------------------------------------------------------------------------------
--
--  Copyright (c) Oracle Corporation 1999 - 2012. All Rights Reserved.
--
--    NAME
--      wwv_flow_authorization_api.sql
--
--    DESCRIPTION
--      Public interface to the authorization subsystem.
--
--      This package contains public utility functions for controlling and
--      querying access rights to the application.
--
--    RUNTIME DEPLOYMENT: NO
--    PUBLIC:             YES
--
--    MODIFIED   (MM/DD/YYYY)
--    cneumuel    05/02/2012 - Created
--    cneumuel    06/05/2012 - Added reset_cache, is_authorized
--
--------------------------------------------------------------------------------

--==============================================================================
-- Reset authorization caches for the session and force a re-evaluation when
-- an authorization has to be checked next.
--==============================================================================
procedure reset_cache;

--==============================================================================
-- Determine if the current user passes the authorization with name
-- "p_authorization_name". For performance reasons, authorization results are
-- cached, so this function may not always evaluate the authorization when
-- called, but take the result out of the cache (see attribute "Evaluation
-- Point" in the authorization schemes).
--
-- ARGUMENTS
-- * p_authorization_name: The name of an authorization scheme in the
--                         application.
--
-- RETURNS
-- * TRUE if the authorization was successful
-- * FALSE if the authorization was not successful
--==============================================================================
function is_authorized (
    p_authorization_name in varchar2 )
    return boolean;

end wwv_flow_authorization_api;
/

