create package wwv_flow_ws_attachment
as

procedure add_doc (
    p_ws_app_id       in number,
    p_webpage_id      in number default null,
    p_websheet_id     in number default null,
    p_row_id          in varchar2 default null,
    p_component_level in varchar2 default null,
    p_file_name       in varchar2 default null,
    p_image_alias     in varchar2 default null,
    p_desc            in varchar2 default null
    );

procedure delete_doc (
    p_doc_id    in varchar2
    );

procedure change_image_attr (
    p_ws_app_id        in number,
    p_file_id          in number,
    p_page_id          in number default null,
    p_image_alias      in varchar2 default null,
    p_image_attributes in varchar2 default null,
    p_description      in varchar2 default null
    );

function get_ws_file_src (
    p_file_id in number )
    return varchar2;

procedure get_ws_file (
    p_session_id in number,
    p_file_id    in number,
    p_checksum   in varchar2 );

end wwv_flow_ws_attachment;
/

