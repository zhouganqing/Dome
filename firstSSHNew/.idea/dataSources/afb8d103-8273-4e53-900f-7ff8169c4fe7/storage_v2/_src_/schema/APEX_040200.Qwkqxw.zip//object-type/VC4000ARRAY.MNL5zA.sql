create type vc4000Array as table of varchar2(32767)
/

