create package wwv_flow_data_upload

as
empty_vc_arr               wwv_flow_global.vc_arr2;

procedure create_collections_from_data (
    p_first_row_is_col_name   in varchar2 default 'N',
	p_data_type				  in varchar2 default 'PASTE',
	p_file_name 			  in varchar2 default null,
    --
    p_separator               in varchar2 default chr(9),
    p_enclosed_by             in varchar2 default null,
    --
    p_currency                in varchar2 default '$',
    p_group_separator         in varchar2 default '.',
    p_decimal_char            in varchar2 default ',',
    p_charset                 in varchar2 default null);

procedure display_table_mapping (
    p_load_table_id     in number,
	p_flow_id			in number);

procedure save_column_mapping (
    p_cnames                in wwv_flow_global.vc_arr2,
    p_data_format           in wwv_flow_global.vc_arr2 default empty_vc_arr);

procedure create_load_collection;

procedure create_verify_collection (
    p_id    in number);

procedure load_data (
    p_id                    in number,
    p_session_id            in number,
    p_insert_count          out varchar2,
    p_update_count          out varchar2,
    p_error_count           out varchar2,
    p_review_count          out varchar2);

function get_owner_name(
    p_owner_name            in varchar2,
    p_flow_id               in number)
    return varchar2;

procedure fix_pre42(p_flow_id          in number );

end wwv_flow_data_upload;
/

