create package wwv_flow_crypto as
--------------------------------------------------------------------------------
--
--  Copyright (c) Oracle Corporation 2011. All Rights Reserved.
--
--    NAME
--      wwv_flow_crypto.sql
--
--    DESCRIPTION
--      This package is resonsible for encryption, decryption and randomizing
--
--    RUNTIME DEPLOYMENT: YES
--
--    MODIFIED (MM/DD/YYYY)
--     tkyte    05/01/2001 - Created
--     sdillon  05/15/2001 - Added "oneway_hash" for a least common denominator where we are
--                           using 8.1.6 & 8.1.7, and we want to do diff things on diff versions.
--     cneumuel 03/03/2011 - Removed obsolete functions encryptString,
--                           decryptString, encryptRaw, decryptRaw, encryptLob, decryptLob
--     cneumuel 04/21/2011 - renamed from wwv_crypt to wwv_flow_crypto, added
--                           crypto funcs from package wwv_flow_security
--
--------------------------------------------------------------------------------

--==============================================================================
--
-- These subtypes make it easier to declare a return variable
-- that can accept checksums.  They are not needed, you can
-- assign the checksums to varchar2s or raws as you see fit
--
subtype checksum_str is varchar2(16);
subtype checksum_raw is raw(16);

--==============================================================================
-- return p_str encrypted with key p_key and converted from raw to hex
--==============================================================================
function mac_md5_hex (
    p_src in raw,
    p_key in raw )
    return varchar2;

--==============================================================================
-- encrypt p_src with key p_key and algorithm sys.DBMS_CRYPTO.AES_CBC_PKCS5
-- and return the converted value as hexadecimal
--==============================================================================
function aes_encrypt_hex (
    p_src in varchar2,
    p_key in raw )
    return varchar2;

--==============================================================================
-- decrypt the hexadecimal p_src with key p_key and algorithm
-- sys.DBMS_CRYPTO.AES_CBC_PKCS5 and return the converted value
--==============================================================================
function aes_decrypt_hex (
    p_src in varchar2,
    p_key in raw )
    return varchar2;

--==============================================================================
-- return a random number
--==============================================================================
function randomnumber return number;

--==============================================================================
-- return a random byte sequence
--==============================================================================
function randombytes (
    p_numbytes in pls_integer )
    return raw;

--==============================================================================
-- A set of functions to take a string or upto 32k in size
-- or a LOB of any size and compute the md5 checksum of it.
-- Notice we avoid overloading RAW and
-- VARCHAR2 functions again for the same reason as encrypt
-- and decrypt
--==============================================================================
function md5str( p_data in varchar2 ) return checksum_str;
function md5raw( p_data in raw ) return checksum_raw;

--==============================================================================
-- Used to encapsulate the actual function being used. This is
-- helpful when using multiple db versions.
--==============================================================================
function one_way_hash_str( p_data in varchar2 ) return checksum_str;
function one_way_hash_raw( p_data in raw ) return checksum_str;

--==============================================================================
-- The MD5LOB functions take the first 32k of the BLOB or CLOB
-- and compute a checksum for them.
--==============================================================================
function md5lob( p_data in clob ) return checksum_str;
function md5lob( p_data in blob ) return checksum_raw;

end wwv_flow_crypto;
/

