create package wwv_flow_process
as
--------------------------------------------------------------------------------
--
--  Copyright (c) Oracle Corporation 1999 - 2012. All Rights Reserved.
--
--    NAME
--      wwv_flow_process.sql
--
--    DESCRIPTION
--      This package is responsible for handling processes.
--
--    MODIFIED   (MM/DD/YYYY)
--      pawolf    01/04/2011 - Created (feature# 542)
--
--------------------------------------------------------------------------------

--==============================================================================
-- Global types
--==============================================================================


--==============================================================================
-- Global constants
--==============================================================================
e_error_occurred exception;

--==============================================================================
-- Global variables
--==============================================================================


--==============================================================================
-- Performs all processes defined for the specified process point
--==============================================================================
procedure perform (
    p_process_point in varchar2 );

--==============================================================================
-- Adds a process error message to the error stack and raises e_error_occurred
-- afterwards. This procedure is public, because it's also used by wwv_flow_item.mru*
--==============================================================================
procedure add_error_message (
    p_process_error    in varchar2,
    p_error            in varchar2,
    p_display_location in varchar2 );

procedure add_error_message (
    p_error_code       in varchar2,
    p0                 in varchar2 default null,
    p1                 in varchar2 default null,
    p2                 in varchar2 default null,
    p3                 in varchar2 default null,
    p4                 in varchar2 default null,
    p5                 in varchar2 default null,
    p6                 in varchar2 default null,
    p7                 in varchar2 default null,
    p8                 in varchar2 default null,
    p9                 in varchar2 default null,
    p_display_location in varchar2 );

procedure add_error_message (
    p_process_error    in varchar2,
    p_error            in varchar2,
    p_display_location in varchar2,
    p_region_id        in number,
    p_row_num          in number );

procedure add_error_message (
    p_error_code       in varchar2,
    p0                 in varchar2 default null,
    p1                 in varchar2 default null,
    p2                 in varchar2 default null,
    p3                 in varchar2 default null,
    p4                 in varchar2 default null,
    p5                 in varchar2 default null,
    p6                 in varchar2 default null,
    p7                 in varchar2 default null,
    p8                 in varchar2 default null,
    p9                 in varchar2 default null,
    p_display_location in varchar2,
    p_region_id        in number,
    p_row_num          in number );

end wwv_flow_process;
/

