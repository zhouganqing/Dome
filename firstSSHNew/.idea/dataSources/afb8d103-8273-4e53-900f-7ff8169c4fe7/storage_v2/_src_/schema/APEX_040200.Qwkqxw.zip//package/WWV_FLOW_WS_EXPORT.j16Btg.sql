create package wwv_flow_ws_export
is

g_mime_shown                 boolean := false;
g_file_id                    number;
g_blob_content               blob;
g_text                       varchar2(32767) := null;
g_lf                         varchar2(10) := unistr('\000a');
g_cr                         varchar2(10) := unistr('\000d');

procedure export (
    p_ws_app_id                   in number,
    p_format                      in varchar2 default 'UNIX',
    p_commit                      in varchar2 default 'YES',
    p_export_datagrid_data        in varchar2 default 'N',
    p_export_datagrid_annotations in varchar2 default 'N',
    p_export_page_annotations     in varchar2 default 'N',
    p_export_public_reports       in varchar2 default 'N',
    p_export_private_reports      in varchar2 default 'N',
    p_export_subscriptions        in varchar2 default 'N',
    p_file_id                     in number   default null
    );

end wwv_flow_ws_export;
/

