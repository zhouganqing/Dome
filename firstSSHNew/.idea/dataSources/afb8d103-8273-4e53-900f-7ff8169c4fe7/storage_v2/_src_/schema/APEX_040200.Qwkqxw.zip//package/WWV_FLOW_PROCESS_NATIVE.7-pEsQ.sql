create package wwv_flow_process_native
as
--------------------------------------------------------------------------------
--
--  Copyright (c) Oracle Corporation 2011 - 2012. All Rights Reserved.
--
--    NAME
--      wwv_flow_process_native.sql
--
--    DESCRIPTION
--      This package is resonsible for handling native process types.
--
--    MODIFIED   (MM/DD/YYYY)
--    pawolf      03/12/2010 - Created
--    pawolf      06/07/2011 - Added dispatcher
--    pawolf      02/27/2012 - Renamed package wwv_flow_plugin to wwv_flow_plugin_api and wwv_flow_plugin_engine to wwv_flow_plugin
--    pawolf      04/02/2012 - Added p_plugin to APIs
--    pawolf      04/04/2012 - Renamed wwv_flow_native_process to wwv_flow_process_native
--
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
-- Public type definitions
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
-- Public constant definitions
--------------------------------------------------------------------------------
c_send_email            constant varchar2(40) := 'NATIVE_SEND_EMAIL';
c_parse_uploaded_data   constant varchar2(40) := 'NATIVE_PARSE_UPLOADED_DATA';
c_prepare_uploaded_data constant varchar2(40) := 'NATIVE_PREPARE_UPLOADED_DATA';
c_load_uploaded_data    constant varchar2(40) := 'NATIVE_LOAD_UPLOADED_DATA';

--==============================================================================
-- Dispatcher which actually calls the native process plug-in.
--==============================================================================
function execute_process (
    p_type    in varchar2,
    p_plugin  in wwv_flow_plugin_api.t_plugin,
    p_process in wwv_flow_plugin_api.t_process )
    return wwv_flow_plugin_api.t_process_exec_result;
--
--
end wwv_flow_process_native;
/

