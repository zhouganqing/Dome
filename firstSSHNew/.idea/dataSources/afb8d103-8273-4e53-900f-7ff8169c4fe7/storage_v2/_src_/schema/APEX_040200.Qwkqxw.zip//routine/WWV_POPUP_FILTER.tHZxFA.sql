create function wwv_popup_filter wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
58 96
cjthVZTjbPP0WjbWgYYiHKqqV78wg8eZgcfLCNL+XhaWlm2WhZYWYuOu2Uc+oWIJ58CyvbKb
XufHdMAzuHRlCbh0K7jAMv7S1qFGBweVmDrOBx6+xlvOW0Y525hCkkZTOZPVU5K+VIKmpn28
q+U=
/

