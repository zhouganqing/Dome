create package wwv_flow_meta_data as
--------------------------------------------------------------------------------
--
--  Copyright (c) Oracle Corporation 1999 - 2009. All Rights Reserved.
--
--    DESCRIPTION
--      Fetch meta data for flow rendering
--
--    NOTES
--      Information required to render and process page information is queried from
--      tables using this package.  Template information is queried using the
--      wwv_flow_templates_util package.

--    SECURITY
--      only executable by flows engine
--
--    SECURITY
--
--    RUNTIME DEPLOYMENT: YES
--
--    MODIFIED  (MM/DD/YYYY)
--      mhichwa  11/13/1999 - Created
--      mhichwa  12/09/1999 - Added fetch_toplevel_tab_info
--      mhichwa  01/09/2000 - Removed alt_flow_step_id argument
--      mhichwa  01/12/2000 - Added fetch_page_plugs function
--      mhichwa  02/19/2000 - Moved fetch_template_preference from fetch_flow_info
--      mhichwa  05/02/2000 - Added g_first_displayable_field global
--      mhichwa  11/08/2000 - Added static subs
--      mhichwa  12/12/2000 - fetch_required_roles is obsolete
--      mhichwa  12/22/2000 - Added security checks passed global
--      mhichwa  12/26/2000 - Added security checks failed
--      mhichwa  01/20/2001 - Added g_on_new_instance_fired_for
--      mhichwa  08/01/2001 - Set sec failed and fast to 4000 from 5000 bytes
--      tmuth    10/03/2002 - Changed g_first_displayable_field to 50 char instead of 8
--      mhichwa  10/20/2002 - Added fetch_show and accept processing
--      sspadafo 12/27/2002 - Added fetch_show_branch_info and fetch_accept_branch_info (Bug 2729764)
--      sspadafo 02/09/2003 - Added globals for new build option evaluation method (Bug 2748385)
--      sspadafo 02/10/2003 - Added functions fetch_g_build_options_.. to return build option globals (Bug 2748385)
--      sspadafo 02/08/2005 - Added fetch_protected_item_ids, fetch_protected_page_info procedures for URL tampering feature
--      sspadafo 02/27/2006 - Remove obsolete fetch_process_info
--      sspadafo 04/23/2006 - Added fetch_public_page_info for zero session ID feature
--      sspadafo 12/03/2007 - Removed fetch_protected_item_ids procedure
--      mhichwa  09/11/2008 - Added p_mode argument
--      sspadafo 01/11/2009 - Removed obsolete procedure fetch_branch_info
--      pawolf   04/10/2009 - Moved format_lov_query to wwv_flow_meta_data
--      pawolf   06/09/2009 - Added is_ok_to_display and is_valid_build_option
--      pawolf   06/10/2009 - Moved functions from wwv_flow_meta_data to wwv_flow_meta_util
--      cneumuel 06/30/2011 - Added do_static_substitutions and find_static_substitution, moved g_static_substitution% from spec to body (bug #12636771)
--      cneumuel 05/21/2012 - Removed fetch_template_preference, fetch_items_on_new_instance
--      cneumuel 05/24/2012 - Added find_item_by_name, find_item_by_id
--      cneumuel 05/29/2012 - in t_item_properties: removed dependency to wwv_flow_step_items because of dependency problem in coreins.sql (mail vlad)
--      cneumuel 05/31/2012 - In t_item_properties and cursors: add scope (feature #897)
--      cneumuel 06/01/2012 - Added t_item_scope.c_report_scope for saving report metadata in session state
--                          - In find_item_by_name: added p_application_id
--
--------------------------------------------------------------------------------

--==============================================================================
-- item properties
--==============================================================================
subtype t_item_scope is varchar2(6);
c_page_item_scope   constant t_item_scope := 'PAGE';   -- page item
c_app_item_scope    constant t_item_scope := 'APP';    -- app-local app item
c_global_item_scope constant t_item_scope := 'GLOBAL'; -- global app item
c_report_scope      constant t_item_scope := 'REPORT'; -- report metadata pseudo-item
type t_item_properties is record (
    id                    number,
    security_group_id     number,
    scope                 t_item_scope,
    name                  varchar2(255),
    prompt                varchar2(4000),
    data_type             varchar2(30),
    restricted_characters varchar2(20),
    is_persistent         varchar2(1),
    is_encrypted          boolean,
    is_password_dnss      boolean,
    escape_on_http_input  boolean,
    protection_level_nr   pls_integer );

--==============================================================================
-- package globals
--==============================================================================
g_first_displayable_field      varchar2(50);
g_on_new_instance_fired_for    varchar2(4000);
g_build_options_included       varchar2(32767);
g_build_options_excluded       varchar2(32767);

--==============================================================================
-- flow level fetch
--==============================================================================
function  fetch_flow_info
    return number;
function  fetch_icon_bar_info
    return number;

--==============================================================================
-- page level fetch
--==============================================================================
function  fetch_step_info (p_mode in varchar2 default null)
    return number;
function  fetch_tab_info
    return number;
function  fetch_toplevel_tab_info (p_tabset in varchar2)
    return number;
function  fetch_button_info
    return number;
function  fetch_show_branch_info
    return number;
function  fetch_accept_branch_info
    return number;
function  fetch_item_type_settings
    return number;
function  fetch_item_info
    return number;

function  fetch_show_process_info
    return number;
function  fetch_accept_process_info
    return number;

function fetch_g_build_options_included
    return varchar2;
function fetch_g_build_options_excluded
    return varchar2;
function  fetch_computations
    return number;
function  fetch_page_plugs
    return number;
procedure fetch_protected_page_info;
procedure fetch_public_page_info;

--==============================================================================
-- return item properties
--
-- t_item_properties.id is the ID of the ITEM (p_name) or 0 for items that begin
-- with IR and are not an existing item name or -1 if the item is contained in
-- the component value array
--==============================================================================
function find_item_by_name (
    p_name                  in  varchar2,
    p_application_id        in  number default wwv_flow_security.g_flow_id )
    return t_item_properties;

--==============================================================================
-- return item properties
--
-- t_item_properties.id is the ID of the ITEM (p_name) or 0 for items that begin
-- with IR and are not an existing item name or -1 if the item is contained in
-- the component value array
--
--==============================================================================
function find_item_by_id (
    p_id in number )
    return t_item_properties;

--==============================================================================
-- replace application-level substitution variables in p_str
--==============================================================================
procedure do_static_substitutions (
    p_str in out nocopy varchar2 );
--
--==============================================================================
-- look up application-level substitution variable p_name. if found, return true
-- and the variable's value in p_value
--==============================================================================
function find_static_substitution (
    p_name  in varchar2,
    p_value in out nocopy varchar2 )
    return boolean;

end wwv_flow_meta_data;
/

