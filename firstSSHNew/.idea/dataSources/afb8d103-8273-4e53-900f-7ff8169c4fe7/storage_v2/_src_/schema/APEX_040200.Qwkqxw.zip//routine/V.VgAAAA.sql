create function v wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
197 10b
PVSraxgy7nHZiDOC39/W4UHOdWwwgzLIr8usfC+iAP7VM0AU29bqUaE+bd8+mSlhQ7SdpfgC
CYmibuv1ThtVMf+3wCPKMK+T3dh/JwcAEazKOyPyEjubNIJqoEf6/rKjES23GVM63kdAS6tg
aBckw6+FerW2bA2zgoPg2crVOpai6VgWbf8Flsr5DAMRpWveLBPoyKfQBcuKGmoMhfC/l0P7
SP6KCg8UVajvbSRnPNrYWptbWbmQdYrZo8oNL/zr/eW5VEU=
/

