create function vrn wrapped
a000000
1
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
9a b2
anaAakaOCEpEXqPGnCAAgCaU5vkwg8eZgcfLCNL+XhbVl15QjwmmrKkwci/qD0SuJAJ8xsoX
KMbK7y5LMMj2WhEv5siZy3rWvm5xVQBzyFxEvjnOV3uYJ919fLLjLex7/OVCY62t5fx7P2si
IsrR40BSO75xc3GOFazk2Iim0pcUow==
/

