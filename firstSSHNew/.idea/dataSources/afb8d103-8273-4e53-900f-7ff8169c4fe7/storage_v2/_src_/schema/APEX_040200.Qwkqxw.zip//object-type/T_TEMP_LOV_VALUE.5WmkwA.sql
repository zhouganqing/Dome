create type t_temp_lov_value is object (
    insert_order number,
    disp         varchar2(4000),
    val          varchar2(4000) )
/

