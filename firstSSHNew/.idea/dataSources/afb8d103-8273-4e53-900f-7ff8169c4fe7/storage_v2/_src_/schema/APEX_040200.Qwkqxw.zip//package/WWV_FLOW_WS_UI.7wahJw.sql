create package wwv_flow_ws_ui
as

procedure page_header (
    p_app_id     in number,
    p_session    in number,
    p_app_user   in varchar2,
    p_ws_app_id  in number);

procedure control_panel (
    p_app_id      in number,
    p_session     in number,
    p_ws_app_id   in number,
    p_ws_page_id  in number);

procedure show_breadcrumbs (
    p_ws_app_id            in number,
    p_app_session          in number,
    p_page_id              in number,
    p_image_prefix         in varchar2 default null,
    p_parent_entry         in varchar2 default null,
    p_parent_entry_page_id in number default null,
    p_current_entry        in varchar2 default null);

procedure show_slide_breadcrumbs (
    p_ws_app_id            in number,
    p_app_session          in number,
    p_page_id              in number,
    p_image_prefix         in varchar2 default null);

procedure show_attachments (
    p_ws_app_id   in number,
    p_webpage_id  in number);

procedure show_notes (
    p_session     in number,
    p_ws_app_id   in number,
    p_webpage_id  in number);

procedure show_tags (
    p_ws_app_id   in number,
    p_webpage_id  in number);

procedure p22_data_grid_list (
    p_app_id       in number,
    p_app_session  in number,
    p_ws_app_id    in number,
    p_data_grid_id in number);

procedure p22_data_grid_columns (
    p_data_grid_id   in number);

procedure p22_data_grid_query (
    p_data_grid_id   in number);

procedure p900_footer (
    p_app_id          in number default 0,
    p_ws_app_id       in number default 0,
    p_page_id         in number default 0,
    p_app_session     in number default 0
    );

procedure print_custom_css (
    p_ws_app_id  in number
    );

procedure plsql_example;

procedure show_data_grid_menu (
    p_ws_app_id   in number,
    p_app_session in number);

procedure show_report_menu (
    p_ws_app_id   in number,
    p_app_session in number);

procedure data_grid_sql_help (
    p_app_id       in number,
    p_app_session  in number,
    p_ws_app_id    in number);
end wwv_flow_ws_ui;
/

