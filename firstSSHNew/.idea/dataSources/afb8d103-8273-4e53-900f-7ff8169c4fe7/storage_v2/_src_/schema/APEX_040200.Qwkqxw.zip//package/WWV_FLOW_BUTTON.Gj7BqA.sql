create package wwv_flow_button
as

--==============================================================================
-- Global types
--==============================================================================


--==============================================================================
-- Global constants
--==============================================================================
c_action_submit         constant varchar2(15) := 'SUBMIT';
c_action_redirect_url   constant varchar2(15) := 'REDIRECT_URL';
c_action_redirect_page  constant varchar2(15) := 'REDIRECT_PAGE';
c_action_defined_by_da  constant varchar2(15) := 'DEFINED_BY_DA';
c_action_javascript     constant varchar2(15) := 'JAVASCRIPT';
c_action_report         constant varchar2(15) := 'REPORT';


--==============================================================================
-- Global variables
--==============================================================================


--==============================================================================
-- Function returning the HTML for an APEX page button
--==============================================================================
function render_native_button (
    p_style                     in varchar2,
    p_action                    in varchar2,
    p_redirect_url              in varchar2 default null,
    p_button_id                 in varchar2 default null,
    p_button_name               in varchar2,
    p_button_label              in varchar2 default null,
    p_button_css_classes        in varchar2 default null,
    p_button_attributes         in varchar2 default null,
    --
    p_button_image              in varchar2 default null,
    p_button_image_attributes   in varchar2 default null,
    p_template                  in varchar2 default null )
    return varchar2;

--==============================================================================
-- Procedure to print the HTML for an APEX page button to the buffer
--==============================================================================
procedure render_native_button (
    p_style                     in varchar2,
    p_action                    in varchar2,
    p_redirect_url              in varchar2 default null,
    p_button_id                 in varchar2 default null,
    p_button_name               in varchar2,
    p_button_label              in varchar2 default null,
    p_button_css_classes        in varchar2 default null,
    p_button_attributes         in varchar2 default null,
    --
    p_button_image              in varchar2 default null,
    p_button_image_attributes   in varchar2 default null,
    p_template                  in varchar2 default null );

--==============================================================================
-- Function that returns the button redirect_url, based on button attributes
--==============================================================================
function get_button_redirect_url (
    p_button_action in varchar2,
    p_clear_page    in varchar2,
    p_clear_cache   in varchar2,
    p_page_id       in varchar2,
    p_request       in varchar2,
    p_arg_names     in varchar2,
    p_arg_values    in varchar2,
    p_url_target    in varchar2 )
    return varchar2;


end wwv_flow_button;
/

