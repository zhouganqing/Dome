create package wwv_flow_flash_chart
as

g_chart_engine  varchar2(255) := 'ANYCHART';
g_clob                       clob;

procedure chart (
    p_region_id in number
    );

procedure show (
    p_region_id        in number,
    p_region_static_id in varchar2,
    p_region_source    in varchar2 );

function static_xml (
    p_region_id in number
    ) return varchar2;

procedure ajax;

end wwv_flow_flash_chart;
/

