create type          SYS_PLSQL_10CA3684_125_1 as table of "CTXSYS"."SYS_PLSQL_10CA3684_100_1";
/

