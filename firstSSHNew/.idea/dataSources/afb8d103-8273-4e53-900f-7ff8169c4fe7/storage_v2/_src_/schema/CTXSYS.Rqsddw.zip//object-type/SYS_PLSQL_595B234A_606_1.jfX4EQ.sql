create type          SYS_PLSQL_595B234A_606_1 as table of "CTXSYS"."SYS_PLSQL_595B234A_586_1";
/

