create package dririo as

  LOCK_WAIT     constant number := null;
  LOCK_NOWAIT   constant number := 0;
  IGNORE_ERRORS constant boolean := TRUE;

/*------------------------------ lock_rio --------------------------------*/

procedure lock_rio(
  cid        in number,
  pid        in number,
  timeout    in number
);

/*----------------------------- unlock_rio ------------------------------*/

procedure unlock_rio(
  ignore_errors in boolean default false
);

/*----------------------------- shadow_name ------------------------------*/
/* return the name of the shadow policy, given source policy id */

function shadow_name(
  idx_id in number,
  ixp_id in number default null
) return varchar2;

/*------------------------- lock_rio_all_part ----------------------------*/

procedure lock_rio_all_part(
  cid        in number
);

/*------------------------ unlock_rio_all_part ---------------------------*/

procedure unlock_rio_all_part(
  ignore_errors in boolean default false
);

procedure create_shadow(
  idx        dr_def.idx_rec,
  idx_shadow in out nocopy dr_def.idx_rec
);

procedure create_shadow_partMD(
   idx         dr_def.idx_rec,
   ixp_id      number
);

end dririo;
/

