create type          SYS_PLSQL_10CA3684_66_1 as table of "CTXSYS"."SYS_PLSQL_10CA3684_38_1";
/

