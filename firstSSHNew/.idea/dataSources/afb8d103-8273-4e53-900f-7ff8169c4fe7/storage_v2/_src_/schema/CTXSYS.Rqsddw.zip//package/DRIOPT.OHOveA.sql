create package driopt as

  p_inv_count number;

  LOCK_WAIT     constant number := null;
  LOCK_NOWAIT   constant number := 0;
  IGNORE_ERRORS constant boolean := TRUE;

/*------------------------------ lock_opt_AF-------------------------------*/

procedure lock_opt_AF(
  cid        in number,
  timeout    in number,
  retval     out number
);

/*------------------------------ lock_opt --------------------------------*/

procedure lock_opt(
  cid        in number,
  pid        in number,
  timeout    in number
);
function lock_opt_ret(
  cid        in number,
  pid        in number,
  timeout    in number
) return number;

/*------------------------- lock_opt_rebuild ------------------------------*/
/* Added for bug 5079472 */

procedure lock_opt_rebuild(
  cid        in number,
  pid        in number,
  lock_mode  in number,
  timeout    in number,
  release_on_commit in boolean default FALSE
);

/*------------------------- lock_opt_all_part ----------------------------*/
/* NOTE: gets multiple locks.  If fails, it's up to calling procedure to  */
/* release any locks it may have gotten                                   */
procedure lock_opt_all_part(
  cid        in number
);

/*--------------------------- lock_opt_mvdata ---------------------------*/
/* lock optimize mvdata against commit callback of update_mvdata
 * releases lock on commit */
procedure lock_opt_mvdata(
  cid in number,
  pid in number
);

/*----------------------------- unlock_opt ------------------------------*/

procedure unlock_opt(
  ignore_errors in boolean default false
);

/*----------------------------- unlock_opt_AF-----------------------------*/

procedure unlock_opt_AF(
  ignore_errors in boolean default false
);

/*------------------------- unlock_opt_rebuild ----------------------------*/
/* Added for bug 5079472 */

procedure unlock_opt_rebuild(
  ignore_errors in boolean default false
);

/*------------------------ unlock_opt_all_part ---------------------------*/

procedure unlock_opt_all_part(
  ignore_errors in boolean default false
);

/*---------------------------- start_timer ---------------------------*/
/*
  NAME
    start_timer

  DESCRIPTION
    start the optimization timer
*/
procedure start_timer;

/*---------------------------- get_timer ------------------------------*/
/*
  NAME
    get_timer

  DESCRIPTION
    get the amount of minutes since last start_timer call
*/
function get_timer return number;

/*---------------------------- get_state ------------------------------*/
/*
  NAME
    get_state

  DESCRIPTION
    get the current state of optimization
*/
procedure get_state(
  p_idx_id      in  number
, p_ixp_id      in  number
, p_opt_token   out varchar2
, p_opt_type    out number
);

/*---------------------------- set_state ------------------------------*/
/*
  NAME
    set_state

  DESCRIPTION
    set the new state of optimization for next time
*/
procedure set_state(
  p_idx_id      in  number
, p_ixp_id      in  number
, p_opt_token   in  varchar2
, p_opt_type    in  number
);

/*--------------------------- set_ddl_lock_timeout -------------------------*/
/* set_ddl_lock_timeout parameter for this session */
procedure set_ddl_lock_timeout(
  p_timeout in number default 1000000
);

/*--------------------------- get_ddl_lock_timeout -------------------------*/
/* get_ddl_lock_timeout parameter for this session */
function get_ddl_lock_timeout
return number;

/*---------------------- IndexOptimizeRebuild_Verify ------------------------*/
PROCEDURE IndexOptimizeRebuild_Verify(
  idx           in  dr_def.idx_rec,
  ixp           in  dr_def.ixp_rec,
  base_itab_obj in  varchar2,
  base_xidx_obj in varchar2,
  char_semantics out varchar2,
  ipart          out varchar2
  ) ;

/*------------------------- getSegmentInfo ---------------------------------*/
procedure getSegmentInfo(
  idxowner       in varchar2,
  base_itab_obj  in varchar2,
  blocks         out number,
  bytes          out number
);


end driopt;
/

