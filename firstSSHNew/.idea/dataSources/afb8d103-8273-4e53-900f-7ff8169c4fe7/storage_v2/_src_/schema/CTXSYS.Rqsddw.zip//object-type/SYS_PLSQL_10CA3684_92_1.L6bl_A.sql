create type          SYS_PLSQL_10CA3684_92_1 as table of "CTXSYS"."SYS_PLSQL_10CA3684_74_1";
/

