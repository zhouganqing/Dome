create function dri_version wrapped
a000000
1f
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
abcd
8
127 10b
Xd8KnhMcMzoG098hDR6Hqza8YjgwgzLQfyisZ3QCkDqUVd1GyLeNvbvlceECaKSFn23LVuxw
BrvEsBFZd98ppYHtizKxt/VFbFf/t52Qix71rdY1sf2sayHCxS7Lg2Avj4vw8XHnLdFBV7UV
umj2BmNlo94FAVdR9ejE/wN6a7ziXs512ORMimQNMlh+iZZcjPooEVbGcyC9f+uA5eo0pfIO
6UaM29HP2W2EAjY7Cs4cpRoRf1syVsJjC9/3xSu/R/2i1g==
/

