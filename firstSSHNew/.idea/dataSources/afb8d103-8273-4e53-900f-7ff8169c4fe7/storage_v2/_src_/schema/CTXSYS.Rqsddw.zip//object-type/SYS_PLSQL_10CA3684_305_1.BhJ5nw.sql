create type          SYS_PLSQL_10CA3684_305_1 as table of "CTXSYS"."SYS_PLSQL_10CA3684_290_1";
/

