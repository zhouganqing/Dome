create type          SYS_PLSQL_10CA3684_30_1 as table of "CTXSYS"."SYS_PLSQL_10CA3684_12_1";
/

